#!/usr/bin/python3
import argparse
import json
import os
from pythoncm.cluster import Cluster
from bcm.rack import Rack
from bcm.subnet import Subnet
from bcm.fsexport import clone_fsexport_entries
from mnnvl_rack import create_mnnvl_rack
from utils import get_rack_compute_trays, get_rack_powershelfs

# Get the script's directory
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def read_ip_allocation_file(ip_file):
    """Read IP allocation file and return dictionary with format: device_name: [list of ip addresses]"""
    ip_allocation = {}
    if ip_file and os.path.exists(ip_file):
        with open(ip_file, 'r') as f:
            for line in f:
                line = line.strip()
                if line:
                    parts = line.split(',')
                    if len(parts) >= 2:
                        device_name = parts[0]
                        ip_addresses = parts[1:]
                        ip_allocation[device_name] = ip_addresses
    return ip_allocation


def prepare_tray_ip_addresses(tray_name, ip_allocation_dict, compute_node_interfaces_subnets, rack_name, bmc_interface=None):
    """
    Prepare interface-to-IP mapping for a compute tray.
    
    Args:
        tray_name: Name of the tray (e.g., 'p1-r01-ct01')
        ip_allocation_dict: Dictionary mapping device names to lists of IP addresses
        compute_node_interfaces_subnets: Dictionary mapping interface names to their configuration
        rack_name: Rack name (e.g., 'p1-r01')
        bmc_interface: BMC interface name (if any)
    
    Returns:
        Dictionary mapping interface names to IP addresses
    """
    if tray_name not in ip_allocation_dict:
        return {}
    
    ip_list = ip_allocation_dict[tray_name]
    result = {}
    
    interfaces = list(compute_node_interfaces_subnets.keys())
    
    for i, interface in enumerate(interfaces):
        if i < len(ip_list):
            result[interface] = ip_list[i]
    
    return result


def create_subnet(args):
    """Create a new subnet specification"""
    # Initialize PythonCM cluster with default settings
    cluster = Cluster()

    # Create subnet using Subnet class from bcm_subnet.py
    subnet = Subnet(
        name=args.subnet_name,
        base_network_ip=args.network,
        netmaskBits=args.netmaskbits,
        gateway=args.gateway,
        cluster=cluster,
        dynamic_start=args.dynamic_start,
        dynamic_end=args.dynamic_end
    )

    # Call Subnet.create() method
    subnet.create()

    # Add filesystem export entries if requested
    if args.add_fs_export:
        clone_fsexport_entries(cluster, args.subnet_name)

    # Disconnect from cluster
    cluster.disconnect()


def create_device_type(args):
    """Create device specification with interface list"""
    print("🚀 🚀 🚀 🚀 create_device_type starting...")
    # Set output file name based on device type
    output_file = os.path.join("spec", f"{args.device_type}.json")

    # Create spec folder if it doesn't exist
    spec_folder = os.path.join("spec")
    if not os.path.exists(spec_folder):
        os.makedirs(spec_folder)

    # Check conditional requirements
    if args.nvl_rack:
        if not args.nvswitch_tray_interfaces or not args.powershelf_interfaces:
            raise ValueError('--nvswitch_tray_interfaces and --powershelf_interfaces are required when --nvl_rack is true')

    # Process interface lists
    compute_node_interfaces = args.compute_node_interfaces.split(args.delimiter)
    compute_node_interfaces = [iface.strip() for iface in compute_node_interfaces]

    nvswitch_interfaces = []
    if args.nvswitch_tray_interfaces:
        nvswitch_interfaces = args.nvswitch_tray_interfaces.split(args.delimiter)
        nvswitch_interfaces = [iface.strip() for iface in nvswitch_interfaces]

    powershelf_interfaces = []
    if args.powershelf_interfaces:
        powershelf_interfaces = args.powershelf_interfaces.split(args.delimiter)
        powershelf_interfaces = [iface.strip() for iface in powershelf_interfaces]

    # Process compute_node BMC interfaces
    compute_node_bmc_interface = args.compute_node_bmc_interface.strip() if args.compute_node_bmc_interface else None

    # Add BMC interface to compute_node_interfaces if not already present
    if compute_node_bmc_interface and compute_node_bmc_interface not in compute_node_interfaces:
        compute_node_interfaces.append(compute_node_bmc_interface)

    # Process nvswitch_tray BMC interfaces
    nvswitch_bmc_interface = args.nvswitch_tray_bmc_interface.strip() if args.nvswitch_tray_bmc_interface else None

    # Parse bonding specification
    bonding_config = {}
    if args.bonding_spec:
        bonds = args.bonding_spec.split(',')
        for bond in bonds:
            bond = bond.strip()
            if ':' in bond:
                bond_name, slaves_str = bond.split(':', 1)
                bond_name = bond_name.strip()
                slaves = [slave.strip() for slave in slaves_str.split('|')]

                # Add bond interface to compute_node_interfaces if not already present
                if bond_name not in compute_node_interfaces:
                    compute_node_interfaces.append(bond_name)

                # Create bonding configuration with new structure
                bonding_config[bond_name] = {
                    "slave_interfaces": slaves,
                    "bonding_mode": 4
                }
        print(f"🔗 Bonding Configuration: {bonding_config}")

    print(f"🔍 Device Type: {args.device_type}")
    print(f"🔍 Compute Node Interfaces: {compute_node_interfaces}")
    print(f"🔍 Compute Node BMC Interface: {compute_node_bmc_interface}")
    print(f"🔍 Provisioning Interface: {args.provisioning_interface}")
    print(f"🔍 NVSwitch Tray Interfaces: {nvswitch_interfaces}")
    print(f"🔍 NVSwitch Tray BMC Interface: {nvswitch_bmc_interface}")
    print(f"🔍 Powershelf Interfaces: {powershelf_interfaces}")
    print(f"🔍 NVL Rack Mode: {args.nvl_rack}")
    print(f"🔍 Delimiter used: '{args.delimiter}'")
    print(f"🔍 Output file: {output_file}")

    # Set default data file name
    data_file = os.path.join("spec", "default_device_spec.json")

    # Check if data file exists
    if os.path.exists(data_file):
        # Load existing data from data file
        try:
            with open(data_file, 'r') as f:
                existing_data = json.load(f)
            print(f"📂 Loaded existing data from {data_file}")

            # Convert existing_data to dictionary if it's a list (for backward compatibility)
            if isinstance(existing_data, list):
                print("🔄 Converting existing list data to dictionary format...")
                new_dict = {}
                for device in existing_data:
                    if "device_name" in device:
                        new_dict[device["device_name"]] = device
                        print(f"➕ Added device {device['device_name']} to dictionary")
                    else:
                        print("⚠️ Warning: Skipping device entry without 'device_name' field")
                existing_data = new_dict
                print("🟢 Conversion completed successfully")
            elif not isinstance(existing_data, dict):
                # If it's neither list nor dict, start fresh
                existing_data = {}
                print("⚠️ Warning: Existing data is not a list or dictionary. Starting with empty dictionary.")

        except json.JSONDecodeError:
            existing_data = {}
            print(f"⚠️ Warning: {data_file} exists but contains invalid JSON. Creating new configuration.")
    else:
        existing_data = {}
        print(f"📄 Data file {data_file} does not exist. Creating new configuration.")

    # Create device specification based on nvl_rack value
    device_spec = {
        "nvl_rack": args.nvl_rack,
        "compute_node": {
            "interfaces": compute_node_interfaces,
            "bmc_interface": compute_node_bmc_interface,
            "provisioning_interface": args.provisioning_interface
        }
    }

    # Add nvswitch_tray only if there are interfaces provided
    if nvswitch_interfaces:
        device_spec["nvswitch_tray"] = {
            "interfaces": nvswitch_interfaces,
            "bmc_interface": nvswitch_bmc_interface
        }

    # Add bonding configuration if provided
    if bonding_config:
        device_spec["compute_node"]["bonding"] = bonding_config

    if args.nvl_rack:
        # NVL rack mode - include nvswitch and powershelf interfaces
        device_spec.update({
            "powershelf": {
                "interfaces": powershelf_interfaces
            }
        })
    else:
        device_spec["rack_type"] = "standard"

    # Add the new device specification to the dictionary using device_type as key
    existing_data[args.device_type] = device_spec

    # Write to output file
    with open(output_file, 'w') as f:
        json.dump(existing_data, f, indent=2)

    print(f"🟢 Successfully created device specification: {args.device_type}")
    print(f"📁 Device specification saved to: {output_file}")
    print(f"🟢 Device specification summary: {args.device_type} - {len(compute_node_interfaces)} compute interfaces, {len(nvswitch_interfaces)} nvswitch interfaces, {len(powershelf_interfaces)} powershelf interfaces")


def create_device(args):
    """Create device specification with subnet mapping"""
    print("🚀 🚀 🚀 🚀 create_device starting...")
    # Read IP allocation file
    ip_allocation_dict = read_ip_allocation_file(args.ip_allocation_file)
    
    # Filter IP allocation to only include entries matching the device_name
    rack_name = args.device_name
    filtered_ip_allocation = {}
    for device_name, ip_list in ip_allocation_dict.items():
        # Match exact device name or prefix pattern (for rack-based naming)
        if device_name == rack_name or device_name.startswith(f"{rack_name}-"):
            filtered_ip_allocation[device_name] = ip_list
    ip_allocation_dict = filtered_ip_allocation

    # Load device_spec to extract bonding information
    device_spec_bonding = {}
    compute_node_bmc_interface = None
    nvswitch_tray_bmc_interface = None
    device_spec_nvswitch_interfaces = []
    device_spec_powershelf_interfaces = []
    device_spec_compute_node_interfaces = []

    if args.device_spec and os.path.exists(args.device_spec):
        try:
            with open(args.device_spec, 'r') as f:
                device_spec_data = json.load(f)
                # Get bonding info from device_spec if available
                device_data = None

                # First try to find the exact device name
                if args.device_name in device_spec_data:
                    device_data = device_spec_data[args.device_name]
                # If not found, use the first device in the file
                elif device_spec_data:
                    device_data = next(iter(device_spec_data.values()))

                # Extract bonding info if we found device data
                if device_data and 'compute_node' in device_data and 'bonding' in device_data['compute_node']:
                    device_spec_bonding = device_data['compute_node']['bonding']

                # Extract BMC interface for compute node if available
                if device_data and 'compute_node' in device_data and 'bmc_interface' in device_data['compute_node']:
                    compute_node_bmc_interface = device_data['compute_node']['bmc_interface']

                # Extract BMC interface for nvswitch tray if available
                if device_data and 'nvswitch_tray' in device_data and 'bmc_interface' in device_data['nvswitch_tray']:
                    nvswitch_tray_bmc_interface = device_data['nvswitch_tray']['bmc_interface']

                # Extract interfaces from device_spec if available
                if device_data:
                    if 'compute_node' in device_data and 'interfaces' in device_data['compute_node']:
                        device_spec_compute_node_interfaces = device_data['compute_node']['interfaces']
                    if 'nvswitch_tray' in device_data and 'interfaces' in device_data['nvswitch_tray']:
                        device_spec_nvswitch_interfaces = device_data['nvswitch_tray']['interfaces']
                    if 'powershelf' in device_data and 'interfaces' in device_data['powershelf']:
                        device_spec_powershelf_interfaces = device_data['powershelf']['interfaces']
        except json.JSONDecodeError:
            print(f"⚠️ Warning: Could not parse device_spec file: {args.device_spec}")
        except Exception as e:
            print(f"⚠️ Warning: Error reading device_spec file: {e}")
    elif args.device_spec:
        print(f"🟢 Error: Device spec file not found: {args.device_spec}")
        return

    # Process compute node interfaces subnets
    compute_node_interfaces_subnets = {}
    if args.compute_node_interfaces_subnets:
        for subnet_entry in args.compute_node_interfaces_subnets.split(args.delimiter):
            subnet_entry = subnet_entry.strip()
            if ':' in subnet_entry:
                interface, subnet_name = subnet_entry.split(':', 1)
                interface = interface.strip()
                subnet_name = subnet_name.strip()

                # Create the interface configuration
                interface_config = {"subnet_name": subnet_name}

                # Add slave interfaces and bonding_mode if this is a bond interface and we have bonding info
                if interface in device_spec_bonding:
                    if "slave_interfaces" in device_spec_bonding[interface]:
                        interface_config["slave_interfaces"] = device_spec_bonding[interface]["slave_interfaces"]
                    if "bonding_mode" in device_spec_bonding[interface]:
                        interface_config["bonding_mode"] = device_spec_bonding[interface]["bonding_mode"]

                compute_node_interfaces_subnets[interface] = interface_config

    # Add all interfaces from device_spec that are not already in compute_node_interfaces_subnets with empty dict
    for interface in device_spec_compute_node_interfaces:
        if interface not in compute_node_interfaces_subnets:
            compute_node_interfaces_subnets[interface] = {}

    # Process NVSwitch tray interfaces subnets
    nvswitch_tray_interfaces_subnets = {}
    if args.nvswitch_tray_interfaces_subnets:
        for subnet_entry in args.nvswitch_tray_interfaces_subnets.split(args.delimiter):
            subnet_entry = subnet_entry.strip()
            if ':' in subnet_entry:
                interface, subnet_name = subnet_entry.split(':', 1)
                nvswitch_tray_interfaces_subnets[interface.strip()] = {
                    "subnet_name": subnet_name.strip()
                }

    # Add all interfaces from device_spec that are not already in nvswitch_tray_interfaces_subnets with empty dict
    for interface in device_spec_nvswitch_interfaces:
        if interface not in nvswitch_tray_interfaces_subnets:
            nvswitch_tray_interfaces_subnets[interface] = {}

    # Process powershelf interfaces subnets
    powershelf_interfaces_subnets = {}
    if args.powershelf_interface_subnet:
        for subnet_entry in args.powershelf_interface_subnet.split(args.delimiter):
            subnet_entry = subnet_entry.strip()
            if ':' in subnet_entry:
                interface, subnet_name = subnet_entry.split(':', 1)
                powershelf_interfaces_subnets[interface.strip()] = {
                    "subnet_name": subnet_name.strip()
                }
            else:
                powershelf_interfaces_subnets[subnet_entry.strip()] = {}

    # Add all interfaces from device_spec that are not already in powershelf_interfaces_subnets with empty dict
    for interface in device_spec_powershelf_interfaces:
        if interface not in powershelf_interfaces_subnets:
            powershelf_interfaces_subnets[interface] = {}

    # Process compute node management subnet
    compute_node_management_subnet = None
    if args.compute_node_management_subnet:
        compute_node_management_subnet = args.compute_node_management_subnet.strip()

    # Process compute node category
    compute_node_category = args.compute_node_category.strip()

    # Process nvswitch management subnet
    nvswitch_management_subnet = None
    if args.nvswitch_management_subnet:
        nvswitch_management_subnet = args.nvswitch_management_subnet.strip()

    # Create the subnet specification dictionary
    subnet_spec = {
        "nvl_rack": args.nvl_rack,
        "compute_node": {
            "interfaces": compute_node_interfaces_subnets
        }
    }

    # Add compute node BMC interface if available
    if compute_node_bmc_interface:
        subnet_spec["compute_node"]["bmc_interface"] = compute_node_bmc_interface

    # Add compute node category
    subnet_spec["compute_node"]["category"] = compute_node_category

    # Add compute node management subnet if provided
    if compute_node_management_subnet:
        subnet_spec["compute_node"]["management_subnet"] = compute_node_management_subnet

    # Add nvswitch_tray only if there are subnets provided or in nvl_rack mode or nvswitch management subnet or bmc interface
    if nvswitch_tray_interfaces_subnets or args.nvl_rack or nvswitch_management_subnet or nvswitch_tray_bmc_interface:
        subnet_spec["nvswitch_tray"] = {
            "interfaces": nvswitch_tray_interfaces_subnets
        }

        # Add nvswitch management subnet if provided
        if nvswitch_management_subnet:
            subnet_spec["nvswitch_tray"]["management_subnet"] = nvswitch_management_subnet

        # Add nvswitch tray BMC interface if available
        if nvswitch_tray_bmc_interface:
            subnet_spec["nvswitch_tray"]["bmc_interface"] = nvswitch_tray_bmc_interface

    # Add powershelf only if subnet is provided or in nvl_rack mode
    if powershelf_interfaces_subnets or args.nvl_rack:
        subnet_spec["powershelf"] = {
            "interfaces": powershelf_interfaces_subnets
        }

        # Set management_subnet if powershelf interface subnet is provided
        if powershelf_interfaces_subnets:
            # Get the subnet_name from the first interface with a subnet
            for interface_config in powershelf_interfaces_subnets.values():
                if "subnet_name" in interface_config:
                    subnet_spec["powershelf"]["management_subnet"] = interface_config["subnet_name"]
                    break

    subnet_spec["device_name"] = args.device_name
    # Add device_spec if provided
    if args.device_spec:
        subnet_spec["device_spec"] = args.device_spec

    # Add IP allocation from file
    if ip_allocation_dict:
        subnet_spec["ip_allocation"] = ip_allocation_dict

    # Print subnet spec details
    print(f"🔍 Device Name: {args.device_name}")
    print(f"🔍 NVL Rack Mode: {args.nvl_rack}")
    print(f"🔍 Compute Node Interfaces Subnets: {compute_node_interfaces_subnets}")
    print(f"🔍 Compute Node Management Subnet: {compute_node_management_subnet}")
    print(f"🏷️ Compute Node Category: {compute_node_category}")
    if args.nvl_rack:
        print(f"🔍 NVSwitch Tray Interfaces Subnets: {nvswitch_tray_interfaces_subnets}")
        print(f"🔍 Powershelf Interfaces Subnets: {powershelf_interfaces_subnets}")
        print(f"🔍 NVSwitch Management Subnet: {nvswitch_management_subnet}")
    print(f"📄 Device Spec: {args.device_spec}")
    print("📡 IP Allocation:")
    for device, ips in ip_allocation_dict.items():
        print(f"  {device}: {ips}")
    print(f"🔍 Delimiter used: '{args.delimiter}'")
    print(f"📁 Output file: {args.output}")

    # Create MNNVL rack if nvl_rack mode is enabled
    if args.nvl_rack:
        from utils import get_rack_nvswitch_trays
        restructured_ip_allocation = {}
        
        compute_tray_names = get_rack_compute_trays(args.device_name)
        for tray_name in compute_tray_names:
            tray_ips = prepare_tray_ip_addresses(
                tray_name=tray_name,
                ip_allocation_dict=ip_allocation_dict,
                compute_node_interfaces_subnets=compute_node_interfaces_subnets,
                rack_name=args.device_name,
                bmc_interface=compute_node_bmc_interface
            )
            restructured_ip_allocation[tray_name] = tray_ips
        
        nvswitch_tray_names = get_rack_nvswitch_trays(args.device_name)
        nvswitch_interfaces = list(subnet_spec.get('nvswitch_tray', {}).get('interfaces', {}).keys())
        for tray_name in nvswitch_tray_names:
            if tray_name in ip_allocation_dict:
                restructured_ip_allocation[tray_name] = {interface: ip for interface, ip in zip(
                    nvswitch_interfaces, ip_allocation_dict[tray_name]
                )}
        
        powershelf_names = get_rack_powershelfs(args.device_name)
        powershelf_interfaces = list(subnet_spec.get('powershelf', {}).get('interfaces', {}).keys())
        for shelf_name in powershelf_names:
            if shelf_name in ip_allocation_dict:
                restructured_ip_allocation[shelf_name] = {interface: ip for interface, ip in zip(
                    powershelf_interfaces, ip_allocation_dict[shelf_name]
                )}
        
        print("\n🔄 Restructured IP Allocation:")
        for tray_name in compute_tray_names:
            print(f"  {tray_name}: {restructured_ip_allocation.get(tray_name, {})}")
        for tray_name in nvswitch_tray_names:
            print(f"  {tray_name}: {restructured_ip_allocation.get(tray_name, {})}")
        for shelf_name in powershelf_names:
            print(f"  {shelf_name}: {restructured_ip_allocation.get(shelf_name, {})}")
        
        cluster = Cluster()
        compute_trays, nvswitch_trays, powershelfs = create_mnnvl_rack(
            cluster=cluster,
            device_spec=subnet_spec,
            ip_addresses=restructured_ip_allocation,
            createIfNotExists=True,
            category_name=compute_node_category,
            rack_name=args.device_name
        )
        print("🟢 Summary:")
        successful_compute = [t for t in compute_trays if t is not None and t.device is not None]
        failed_compute = len(compute_trays) - len(successful_compute)
        successful_nvswitch = [t for t in nvswitch_trays if t is not None and t.device is not None]
        failed_nvswitch = len(nvswitch_trays) - len(successful_nvswitch)
        successful_powershelf = [s for s in powershelfs if s is not None and s.device is not None]
        failed_powershelf = len(powershelfs) - len(successful_powershelf)
        compute_msg = f"Created {len(successful_compute)}/{len(compute_trays)} compute trays for MNNVL rack"
        print(f"    {'❌' if failed_compute > 0 else '🟢'} {compute_msg}" + (f" ({failed_compute} failed)" if failed_compute > 0 else ""))
        nvswitch_msg = f"Created {len(successful_nvswitch)}/{len(nvswitch_trays)} NVSwitch trays for MNNVL rack"
        print(f"    {'❌' if failed_nvswitch > 0 else '🟢'} {nvswitch_msg}" + (f" ({failed_nvswitch} failed)" if failed_nvswitch > 0 else ""))
        powershelf_msg = f"Created {len(successful_powershelf)}/{len(powershelfs)} power shelves for MNNVL rack"
        print(f"    {'❌' if failed_powershelf > 0 else '🟢'} {powershelf_msg}" + (f" ({failed_powershelf} failed)" if failed_powershelf > 0 else ""))
        cluster.disconnect()
    else:
        # Create a single Compute Tray when not in NVL rack mode
        from bcm.compute_tray import ComputeTray
        
        # Prepare interface-to-IP mapping
        interface_ip_map = prepare_tray_ip_addresses(
            tray_name=args.device_name,
            ip_allocation_dict=ip_allocation_dict,
            compute_node_interfaces_subnets=compute_node_interfaces_subnets,
            rack_name=args.device_name,
            bmc_interface=compute_node_bmc_interface
        )
        
        cluster = Cluster()
        
        compute_tray = ComputeTray(
            name=args.device_name,
            cluster=cluster,
            device_spec=subnet_spec,
            ip_addresses=interface_ip_map,
            createIfNotExists=True,
            category_name=compute_node_category,
            rack_name=args.device_name,
            rack_position=None
        )
        
        print("🟢 Summary:")
        if compute_tray is not None and compute_tray.device is not None:
            print(f"🟢 Successfully created compute tray: {args.device_name}")

            if args.output is None:
                args.output = os.path.join("spec", "devices", f"{args.device_name}.json")
            else:
                if not os.path.dirname(args.output):
                    args.output = os.path.join("spec", "devices", args.output)

            output_dir = os.path.dirname(args.output)
            if output_dir and not os.path.exists(output_dir):
                os.makedirs(output_dir)

            with open(args.output, 'w') as f:
                json.dump(subnet_spec, f, indent=2)

            print(f"    💾 Saved device specification to: {args.output}")
        else:
            print(f"❌ Failed to create compute tray: {args.device_name}")

        cluster.disconnect()


def read_mac_address_file(mac_file):
    """Read MAC address file and return dictionary with format: device_name: {interface_name: mac}"""
    mac_allocation = {}
    if mac_file and os.path.exists(mac_file):
        with open(mac_file, 'r') as f:
            for line in f:
                line = line.strip()
                if line:
                    parts = line.split(',')
                    if len(parts) >= 2:
                        device_name = parts[0]
                        macs = parts[1:]
                        mac_allocation[device_name] = macs
    return mac_allocation


def prepare_interface_mac_map(interfaces_list, macs):
    """Prepare interface-to-MAC mapping for a device."""
    interface_mac_map = {}
    interfaces = [iface.strip() for iface in interfaces_list.split(',')]

    for i, interface in enumerate(interfaces):
        if i < len(macs):
            interface_mac_map[interface] = macs[i].strip()

    return interface_mac_map


def update_mac(args):
    """Update MAC addresses for a device or all devices in a rack"""
    print("🚀 🚀 🚀 🚀 update_mac starting...")

    mac_allocation = read_mac_address_file(args.mac_file)

    compute_interfaces = args.compute_tray_interfaces_list
    nvswitch_interfaces = args.nvswitch_tray_interfaces_list
    powershelf_interfaces = args.powershelf_interfaces_list

    compute_interfaces_list = [iface.strip() for iface in compute_interfaces.split(',')] if compute_interfaces else []
    nvswitch_interfaces_list = [iface.strip() for iface in nvswitch_interfaces.split(',')] if nvswitch_interfaces else []
    powershelf_interfaces_list = [iface.strip() for iface in powershelf_interfaces.split(',')] if powershelf_interfaces else []

    cluster = Cluster()

    if args.nvl_rack:
        from utils import get_rack_compute_trays, get_rack_nvswitch_trays, get_rack_powershelfs
        from bcm.compute_tray import ComputeTray
        from bcm.nvswitch_tray import NVSwitchTray
        from bcm.powershelf import Powershelf

        compute_tray_names = get_rack_compute_trays(args.device_name)
        nvswitch_tray_names = get_rack_nvswitch_trays(args.device_name)
        powershelf_names = get_rack_powershelfs(args.device_name)

        all_devices = []

        for tray_name in compute_tray_names:
            if tray_name in mac_allocation and compute_interfaces_list:
                macs = mac_allocation[tray_name]
                mac_dict = prepare_interface_mac_map(compute_interfaces, macs)
                tray = ComputeTray(
                    name=tray_name,
                    cluster=cluster,
                    ip_addresses={},
                    createIfNotExists=False,
                    category_name='default',
                    rack_name=args.device_name,
                    rack_position=None
                )
                if tray.device:
                    if tray.update_mac(mac_dict):
                        all_devices.append((tray_name, True))
                        print(f"🟢 Updated MACs for compute tray: {tray_name} - Interfaces: {', '.join(mac_dict.keys())} - MACs: {', '.join(mac_dict.values())}")
                    else:
                        all_devices.append((tray_name, False))
                        print(f"🔴 Failed to update MACs for compute tray: {tray_name}")
                else:
                    all_devices.append((tray_name, False))
                    print(f"⚠️ Compute tray {tray_name} not found")

        for tray_name in nvswitch_tray_names:
            if tray_name in mac_allocation and nvswitch_interfaces_list:
                macs = mac_allocation[tray_name]
                mac_dict = prepare_interface_mac_map(nvswitch_interfaces, macs)
                tray = NVSwitchTray(
                    name=tray_name,
                    cluster=cluster,
                    ip_addresses={},
                    createIfNotExists=False,
                    rack_name=args.device_name,
                    rack_position=None
                )
                if tray.device:
                    if tray.update_mac(mac_dict):
                        all_devices.append((tray_name, True))
                        print(f"🟢 Updated MACs for nvswitch tray: {tray_name} - Interfaces: {', '.join(mac_dict.keys())} - MACs: {', '.join(mac_dict.values())}")
                    else:
                        all_devices.append((tray_name, False))
                        print(f"🔴 Failed to update MACs for nvswitch tray: {tray_name}")
                else:
                    all_devices.append((tray_name, False))
                    print(f"⚠️ NVSwitch tray {tray_name} not found")

        for shelf_name in powershelf_names:
            if shelf_name in mac_allocation and powershelf_interfaces_list:
                macs = mac_allocation[shelf_name]
                mac_dict = prepare_interface_mac_map(powershelf_interfaces, macs)
                shelf = Powershelf(
                    name=shelf_name,
                    cluster=cluster,
                    ip_addresses={},
                    createIfNotExists=False,
                    rack_name=args.device_name,
                    rack_position=None
                )
                if shelf.device:
                    if shelf.update_mac(mac_dict):
                        all_devices.append((shelf_name, True))
                        print(f"🟢 Updated MACs for powershelf: {shelf_name} - Interfaces: {', '.join(mac_dict.keys())} - MACs: {', '.join(mac_dict.values())}")
                    else:
                        all_devices.append((shelf_name, False))
                        print(f"🔴 Failed to update MACs for powershelf: {shelf_name}")
                else:
                    all_devices.append((shelf_name, False))
                    print(f"⚠️ Powershelf {shelf_name} not found")

        successful = sum(1 for _, success in all_devices if success)
        print(f"🟢 Summary: Updated MACs for {successful}/{len(all_devices)} devices in rack {args.device_name}")
    else:
        from bcm.compute_tray import ComputeTray

        if args.device_name in mac_allocation:
            macs = mac_allocation[args.device_name]
            mac_dict = prepare_interface_mac_map(compute_interfaces, macs)

            tray = ComputeTray(
                name=args.device_name,
                cluster=cluster,
                ip_addresses={},
                createIfNotExists=False,
                category_name='default',
                rack_name=args.device_name,
                rack_position=None
            )

            if tray.device:
                if tray.update_mac(mac_dict):
                    print(f"🟢 Updated MACs for device: {args.device_name} - Interfaces: {', '.join(mac_dict.keys())} - MACs: {', '.join(mac_dict.values())}")
                else:
                    print(f"🔴 Failed to update MACs for device: {args.device_name}")
            else:
                print(f"⚠️ Device {args.device_name} not found")
        else:
            print(f"⚠️ No MAC addresses found for {args.device_name} in {args.mac_file}")

    cluster.disconnect()
    print("✨ MAC address update completed.")


def update_mac_by_rf(args):
    """Update MAC addresses via Redfish for devices in a rack"""
    print("🚀 🚀 🚀 🚀 update_mac_by_rf starting...")
    print(f"📋 NVL Rack Mode: {args.nvl_rack}")
    print(f"🟢  Device Name: {args.device_name}")
    print(f"🟢 Regex Config File: {args.regex_config_file}")
    print(f"🔄 PXE Reboot: {args.pxe_reboot}")
    print(f"🟢 Update Bootorder: {args.update_bootorder}")

    regex_config = None
    try:
        with open(args.regex_config_file, 'r') as f:
            regex_config = json.load(f)
        print(f"🟢 Loaded regex config: {regex_config}")
    except (IOError, json.JSONDecodeError) as e:
        print(f"⚠️ Warning: Failed to read or parse regex_config_file: {e}")
        return

    cluster = Cluster()
    print("🔗 Connected to cluster")

    if args.nvl_rack:
        from utils import get_rack_compute_trays
        from bcm.compute_tray import ComputeTray
        import os

        compute_tray_names = get_rack_compute_trays(args.device_name)
        print(f"📦 Found {len(compute_tray_names)} compute trays in rack {args.device_name}")

        os.makedirs('log', exist_ok=True)

        successful_trays = []
        failed_trays = []

        for tray_name in compute_tray_names:
            log_file_path = f"log/{tray_name}.log"
            print(f"🔄 Processing compute tray: {tray_name}")
            
            with open(log_file_path, 'w') as log_file:
                log_file.write(f"Processing compute tray: {tray_name}\n")
                
                tray = ComputeTray(
                    name=tray_name,
                    cluster=cluster,
                    ip_addresses={},
                    createIfNotExists=False,
                    category_name='default',
                    rack_name=args.device_name,
                    rack_position=None
                )
                if tray.device:
                    print(f"  📡 Calling update_macs_by_redfish for {tray_name}...")
                    log_file.write(f"Calling update_macs_by_redfish for {tray_name}\n")
                    macs = tray.update_macs_by_redfish(
                        bmc_username=args.bmc_user,
                        bmc_password=args.bmc_pw,
                        regex_config=regex_config,
                        pxe_reboot=args.pxe_reboot,
                        update_bootorder=args.update_bootorder
                        )
                    if macs:
                        print(f"  🟢 Updated MACs via Redfish for compute tray: {tray_name} - {macs}")
                        log_file.write(f"SUCCESS: Updated MACs via Redfish - {macs}\n")
                        successful_trays.append(tray_name)
                    else:
                        print(f"  🔴 Failed to update MACs via Redfish for compute tray: {tray_name} - {macs}")
                        log_file.write(f"FAILED: Updated MACs via Redfish failed - {macs}\n")
                        failed_trays.append(tray_name)
                else:
                    print(f"  ⚠️ Compute tray {tray_name} not found")
                    log_file.write(f"ERROR: Compute tray {tray_name} not found\n")
                    failed_trays.append(tray_name)

        print(f"🟢 Summary: Updated MACs via Redfish for compute trays in rack {args.device_name}")
        if successful_trays:
            print(f"  🟢 Successful updates ({len(successful_trays)}): {','.join(successful_trays)}")
        if failed_trays:
            print(f"  🟢 Failed updates ({len(failed_trays)}): {','.join(failed_trays)}")
    else:
        from bcm.compute_tray import ComputeTray

        print(f"🔄 Processing device: {args.device_name}")
        tray = ComputeTray(
            name=args.device_name,
            cluster=cluster,
            ip_addresses={},
            createIfNotExists=False,
            category_name='default',
            rack_name=args.device_name,
            rack_position=None
        )

        if tray.device:
            print(f"  📡 Calling update_macs_by_redfish for {args.device_name}...")
            macs = tray.update_macs_by_redfish(
                bmc_username=args.bmc_user,
                bmc_password=args.bmc_pw,
                regex_config=regex_config,
                pxe_reboot=args.pxe_reboot,
                update_bootorder=args.update_bootorder
            )
            if macs:
                print(f"  🟢 Updated MACs via Redfish for device: {args.device_name} - {macs}")
            else:
                print(f"  🟢 Updated MACs via Redfish failed for device: {args.device_name} - {macs}")
        else:
            print(f"  ⚠️ Device {args.device_name} not found")

    cluster.disconnect()
    print("✨ MAC address update via Redfish completed.")


def create_rack(args):
    """Create a rack specification."""
    rack = Rack(rack_name=args.rack_name, cluster=Cluster())
    rack.create()


def main():
    parser = argparse.ArgumentParser(description='BCM Operation - Subnet and Device Management')

    # Create subparsers for different modes
    subparsers = parser.add_subparsers(dest='mode', help='Operation mode')
    subparsers.required = True  # Python 3.7+ requires this for required subcommands

    # Subparser for creating a new subnet
    subnet_parser = subparsers.add_parser('create_subnet', help='Create a new subnet specification')
    subnet_parser.add_argument('--subnet_name', required=True, help='Name of the subnet')
    subnet_parser.add_argument('--network', required=True, help='Network address (e.g., 192.168.1.0)')
    subnet_parser.add_argument('--netmaskbits', required=True, type=int, help='Netmask bits (e.g., 24 for 255.255.255.0)')
    subnet_parser.add_argument('--gateway', required=True, help='Gateway address')
    subnet_parser.add_argument('--dynamic_start', help='Start of dynamic IP range (e.g., 192.168.1.100)')
    subnet_parser.add_argument('--dynamic_end', help='End of dynamic IP range (e.g., 192.168.1.200)')
    subnet_parser.add_argument('--add-fs-export', action='store_true', help='Add filesystem export entries for this subnet')
    subnet_parser.set_defaults(func=create_subnet)

    # Subparser for creating device specifications
    device_type_parser = subparsers.add_parser('create_device_type', help='Create device specification with interface list')
    device_type_parser.add_argument('--device_type', required=True, choices=['dgx-h200', 'dgx-b200', 'dgx-b300', 'dgx-gb200', 'dgx-gb300'], help='Device type')
    device_type_parser.add_argument('--compute_node_interfaces', required=True, help='List of compute_node interfaces separated by a delimiter')
    device_type_parser.add_argument('--compute_node_bmc_interface', default="rf0", help='Compute node BMC interface')
    device_type_parser.add_argument('--provisioning_interface', required=True, help='Provisioning interface for compute node')
    device_type_parser.add_argument('--nvswitch_tray_interfaces', help='List of nvswitch_tray interfaces separated by a delimiter')
    device_type_parser.add_argument('--nvswitch_tray_bmc_interface', default="rf0", help='NVSwitch tray BMC interface')
    device_type_parser.add_argument('--powershelf_interfaces', help='List of powershelf interfaces separated by a delimiter')
    device_type_parser.add_argument('--nvl_rack', action='store_true', help='Enable NVL rack mode (requires nvswitch_tray_interfaces and powershelf_interfaces)')
    device_type_parser.add_argument('--bonding-spec', '-b', help='Bonding specification in format: bond0:eth0|eth1,bond1:eth2|eth3')
    device_type_parser.add_argument('--delimiter', default=',', help='Delimiter used to separate interfaces (default: comma)')
    device_type_parser.set_defaults(func=create_device_type)

    # Subparser for creating device with subnet mapping
    device_parser = subparsers.add_parser('create_device', help='Create device specification with subnet mapping')
    device_parser.add_argument('--device_name', required=True, help='Device name')
    device_parser.add_argument('--nvl_rack', action='store_true', help='Whether it is NVL rack')
    device_parser.add_argument('--compute_node_interfaces_subnets', help='List of compute_node interfaces subnets in format: interface:subnet_name,interface:subnet_name')
    device_parser.add_argument('--compute_node_management_subnet', help='Compute node management subnet')
    device_parser.add_argument('--compute_node_category', default='default', help='Compute node category (default: default)')
    device_parser.add_argument('--nvswitch_tray_interfaces_subnets', help='List of nvswitch_tray interfaces subnets in format: interface:subnet_name,interface:subnet_name')
    device_parser.add_argument('--nvswitch_management_subnet', help='NVSwitch management subnet')
    device_parser.add_argument('--powershelf_interface_subnet', help='Powershelf interface subnet in format: interface:subnet_name')
    device_parser.add_argument('--device_spec', required=True, help='Device specification')
    device_parser.add_argument('--ip_allocation_file', required=True, help='IP allocation file containing device_name: IP addresses')
    device_parser.add_argument('--delimiter', default=',', help='Delimiter used to separate subnets (default: comma)')
    device_parser.add_argument('--output', '-o', default=None, help='Output file name (default: device name + .json)')
    device_parser.set_defaults(func=create_device)

    # Subparser for creating rack specification
    rack_parser = subparsers.add_parser('create_rack', help='Create rack specification')
    rack_parser.add_argument('--rack_name', required=True, help='Name of the rack')
    rack_parser.set_defaults(func=create_rack)

    # Subparser for updating MAC addresses
    update_mac_parser = subparsers.add_parser('update_mac', help='Update MAC addresses for devices')
    update_mac_parser.add_argument('--device_name', required=True, help='Device name (or rack name for nvl_rack mode)')
    update_mac_parser.add_argument('--nvl_rack', action='store_true', help='Update MACs for all devices in the rack')
    update_mac_parser.add_argument('--compute_tray_interfaces_list', required=True, help='Comma-separated list of compute tray interface names')
    update_mac_parser.add_argument('--nvswitch_tray_interfaces_list', help='Comma-separated list of nvswitch tray interface names')
    update_mac_parser.add_argument('--powershelf_interfaces_list', help='Comma-separated list of powershelf interface names')
    update_mac_parser.add_argument('--mac_file', required=True, help='MAC address file (format: device_name,mac1,mac2,...)')
    update_mac_parser.set_defaults(func=update_mac)

    # Subparser for updating MAC addresses via Redfish
    update_mac_rf_parser = subparsers.add_parser('update_mac_by_rf', help='Update MAC addresses via Redfish')
    update_mac_rf_parser.add_argument('--nvl_rack', action='store_true', help='Update MACs for all compute trays in the rack')
    update_mac_rf_parser.add_argument('--device_name', required=True, help='Device name (or rack name for nvl_rack mode)')
    update_mac_rf_parser.add_argument('--bmc_user', required=True, help='BMC username')
    update_mac_rf_parser.add_argument('--bmc_pw', required=True, help='BMC password')
    update_mac_rf_parser.add_argument('--regex_config_file', required=True, help='JSON file with regex patterns for each interface (format: {"eth0":"pattern", "eth1":"pattern"})')
    update_mac_rf_parser.add_argument('--pxe_reboot', action='store_true', help='Reboot to PXE after updating MAC')
    update_mac_rf_parser.add_argument('--update_bootorder', action='store_true', help='Update boot order after updating MAC')
    update_mac_rf_parser.add_argument('--verbose', action='store_true', help='Enable verbose logging')
    update_mac_rf_parser.set_defaults(func=update_mac_by_rf)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
