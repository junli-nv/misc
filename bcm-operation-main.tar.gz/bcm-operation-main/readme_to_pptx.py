#!/usr/bin/env python3
import re
import sys
from pathlib import Path
from pptx import Presentation
from pptx.util import Inches, Pt

def extract_title(readme_content):
    match = re.search(r'^#\s+(.+)$', readme_content, re.MULTILINE)
    return match.group(1) if match else "README"

def extract_sections(readme_content):
    sections = []
    current_section = {"title": None, "content": [], "subsections": []}
    lines = readme_content.split('\n')
    in_code_block = False
    code_block_content = []

    for line in lines:
        if line.strip().startswith('```'):
            if in_code_block:
                current_section["content"].append(("code", '\n'.join(code_block_content)))
                code_block_content = []
            in_code_block = not in_code_block
            continue

        if in_code_block:
            code_block_content.append(line)
            continue

        h2_match = re.match(r'^####\s+(.+)$', line)
        if h2_match:
            if current_section["title"]:
                sections.append(current_section)
            current_section = {"title": h2_match.group(1), "content": [], "subsections": []}
            continue

        h3_match = re.match(r'^###\s+(.+)$', line)
        if h3_match:
            if current_section["title"]:
                sections.append(current_section)
            current_section = {"title": h3_match.group(1), "content": [], "subsections": []}
            continue

        if line.strip():
            current_section["content"].append(("text", line))

    if current_section["title"]:
        sections.append(current_section)

    return sections

def add_slide(prs, title, content, layout_idx=1):
    slide_layout = prs.slide_layouts[layout_idx]
    slide = prs.slides.add_slide(slide_layout)

    if title:
        title_shape = slide.shapes.title
        title_shape.text = title
        title_shape.text_frame.paragraphs[0].font.size = Pt(28)
        title_shape.text_frame.paragraphs[0].font.bold = True

    left = Inches(0.5)
    top = Inches(1.5)
    width = Inches(9)
    height = Inches(5)

    textbox = slide.shapes.add_textbox(left, top, width, height)
    text_frame = textbox.text_frame
    text_frame.word_wrap = True

    for item_type, item_content in content:
        p = text_frame.add_paragraph()
        if item_type == "code":
            p.text = item_content
            p.font.name = "Courier New"
            p.font.size = Pt(10)
            p.level = 0
        else:
            p.text = item_content
            p.font.size = Pt(14)
            p.level = 0
        p.space_after = Pt(6)

    return slide

def create_pptx(readme_path, output_path=None):
    readme_path = Path(readme_path)
    if not readme_path.exists():
        print(f"Error: {readme_path} not found")
        sys.exit(1)

    output_path = Path(output_path) if output_path else readme_path.with_suffix('.pptx')

    content = readme_path.read_text()

    prs = Presentation()
    prs.slide_width = Inches(10)
    prs.slide_height = Inches(7.5)

    title = extract_title(content)
    title_slide_layout = prs.slide_layouts[0]
    title_slide = prs.slides.add_slide(title_slide_layout)
    title_slide.shapes.title.text = title
    subtitle = title_slide.placeholders[1]
    subtitle.text = "BCM Operation Guide"

    sections = extract_sections(content)

    for section in sections:
        add_slide(prs, section["title"], section["content"])

    prs.save(str(output_path))
    print(f"Created: {output_path}")

if __name__ == "__main__":
    readme_file = "README.md"
    output_file = "README.pptx"

    if len(sys.argv) > 1:
        readme_file = sys.argv[1]
    if len(sys.argv) > 2:
        output_file = sys.argv[2]

    create_pptx(readme_file, output_file)
