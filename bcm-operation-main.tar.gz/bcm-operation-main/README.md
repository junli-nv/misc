# bcm-operation

```bash
module load python3
```

## BCM Operation - Subnet and Device Management

#### Create Rack
```bash
for i in $(seq -w 01 08); do
    python3 bcm_operation.py create_rack --rack_name p1-r$i
done
```

#### 🌐 Create Inband subnet in BCM for Humain project (a 57 HGX-B300 project)
```bash
python3 bcm_operation.py create_subnet --subnet_name hm-inband --network 10.0.1.0 --netmaskbits 24 --gateway 10.0.1.254 --dynamic_start 10.0.1.240 --dynamic_end 10.0.1.250 --add-fs-export
python3 bcm_operation.py create_subnet --subnet_name hm-oob --network 10.0.9.0 --netmaskbits 24 --gateway 10.0.9.254 --dynamic_start 10.0.9.240 --dynamic_end 10.0.9.250
python3 bcm_operation.py create_subnet --subnet_name hm-ipoib --network 192.168.0.0 --netmaskbits 16 --gateway 0.0.0.0 --dynamic_start 0.0.0.0 --dynamic_end 0.0.0.0
```

#### 🌐 Create Inband subnet in BCM (bulk)
```bash
cat > inband_subnet << EOF
inband-rack01,10.135.0.0,26,10.135.0.62,10.135.0.51,10.135.0.61
inband-rack02,10.135.0.64,26,10.135.0.126,10.135.0.116,10.135.0.126
inband-rack03,10.135.0.128,26,10.135.0.190,10.135.0.188,10.135.0.189
inband-rack04,10.135.0.192,26,10.135.0.254,10.135.0.230,10.135.0.240
inband-rack05,10.135.1.0,26,10.135.1.62,10.135.1.51,10.135.1.61
inband-rack06,10.135.1.64,26,10.135.1.126,10.135.1.116,10.135.1.126
inband-rack07,10.135.1.128,26,10.135.1.190,10.135.1.188,10.135.1.189
inband-rack08,10.135.1.192,26,10.135.1.254,10.135.1.230,10.135.1.240
EOF

for i in $(cat inband_subnet);do
    IFS=',' read subnet_name subnet bits gw start end <<< $(echo $i)
    python3 bcm_operation.py create_subnet --subnet_name $subnet_name --network $subnet --netmaskbits $bits  --gateway $gw --dynamic_start $start --dynamic_end $end --add-fs-export
done

python3 bcm_operation.py create_subnet --subnet_name ipoib --network 100.64.0.0 --netmaskbits 16 --gateway 0.0.0.0 --dynamic_start 0.0.0.0 --dynamic_end 0.0.0.0

```

#### 🌐 Create oob subnet in BCM
```bash
cat > oob_subnet << EOF
oob-rack01,10.135.32.0,25,10.135.32.126,10.135.32.100,10.135.32.110
oob-rack02,10.135.32.128,25,10.135.32.254,10.135.32.220,10.135.32.230
oob-rack03,10.135.33.0,25,10.135.33.126,10.135.33.100,10.135.33.110
oob-rack04,10.135.33.128,25,10.135.33.254,10.135.33.220,10.135.33.230
oob-rack05,10.135.34.0,25,10.135.34.126,10.135.34.100,10.135.34.110
oob-rack06,10.135.34.128,25,10.135.34.254,10.135.34.220,10.135.34.230
oob-rack07,10.135.35.0,25,10.135.35.126,10.135.35.100,10.135.35.110
oob-rack08,10.135.35.128,25,10.135.35.254,10.135.35.220,10.135.35.230
powershelf1,10.135.36.0,25,10.135.36.126,10.135.36.100,10.135.36.110
powershelf2,10.135.36.128,25,10.135.36.254,10.135.36.240,10.135.36.250
EOF

for i in $(cat oob_subnet);do
    IFS=',' read subnet_name subnet bits gw start end <<< $(echo $i)
    python3 bcm_operation.py create_subnet --subnet_name $subnet_name --network $subnet --netmaskbits $bits  --gateway $gw --dynamic_start $start --dynamic_end $end
done
```

#### Create DHCP configuration files from IP allocation data
```bash
python3 bcm_operation.py create_dhcp_conf --ip_allocation_file su1_su2/bf3-bmc-ip-alloc
```

#### Create Device Spec for dgx-h100/b300/gb200/gb300 ....

```bash
#### for GB200 Rack
python3 bcm_operation.py create_device_type\
    --device_type dgx-gb200  \
    --nvl_rack \
    --compute_node_interfaces enP22p3s0f0np0,enP22p3s0f0np1,enP5p9s0,enP6p3s0f0np0,enP6p3s0f0np1,ibP16p3s0,ibP18p3s0,ibP2p3s0,ibp3s0 \
    --compute_node_bmc_interface rf0 \
    --nvswitch_tray_interfaces eth0,eth1 \
    --nvswitch_tray_bmc_interface rf0 \
    --powershelf_interfaces eth0 \
    --bonding-spec "bond0:enP22p3s0f0np0|enP6p3s0f0np0,bond1:enP22p3s0f0np1|enP6p3s0f0np1" \
    --provisioning_interface bond0


#### for HGX-B300 server Interface list may be not correct
python bcm_operation.py create_device_type\
        --device_type dgx-b300 \
        --compute_node_interfaces ipmi0,enp170s0f1np1,enp41s0f1np1,ibp154s0,ibp170s0f0,ibp192s0,ibp206s0,ibp220s0,ibp24s0,ibp41s0f0,ibp64s0,ibp79s0,ibp94s0 \
        --compute_node_bmc_interface ipmi0 \
        --bonding-spec "bond0:enp170s0f1np1|enp41s0f1np1" \
        --provisioning_interface bond0

```

#### Create device definition based on device_spec

> **Note:** Ensure the category (e.g., `straitdeer`, `hm`) is created in BCM before running the device creation commands.

```bash
#### for GB200 server
for i in $(seq -w 01 08); do
    if [ $i -le 04 ]; then
        powershelf="powershelf1"
    else
        powershelf="powershelf2"
    fi
    python3 bcm_operation.py create_device --device_name p1-r$i --nvl_rack \
                    --compute_node_interfaces_subnets bond0:inband-rack$i,ibP16p3s0:ipoib,ibP18p3s0:ipoib,ibP2p3s0:ipoib,ibp3s0:ipoib,rf0:oob-rack$i \
                    --compute_node_management_subnet inband-rack$i \
                    --compute_node_category straitdeer \
                    --nvswitch_tray_interfaces_subnets rf0:oob-rack$i,eth0:oob-rack$i,eth1:oob-rack$i \
                    --nvswitch_management_subnet oob-rack$i \
                    --powershelf_interface_subnet eth0:$powershelf \
                    --device_spec spec/dgx-gb200.json \
                    --ip_allocation_file ip-allocation.csv
done
```


```bash
#### for HGX B300 - Bulk create from ip-allocation-hm.csv
while IFS=',' read -r device_name _ _; do
    python3 bcm_operation.py create_device --device_name $device_name \
                    --compute_node_interfaces_subnets ipmi0:hm-oob,bond0:hm-inband \
                    --compute_node_management_subnet hm-inband \
                    --compute_node_category hm \
                    --device_spec spec/dgx-b300.json \
                    --ip_allocation_file ip-allocation-hm.csv
done < ip-allocation-hm.csv
```

#### Update MAC addresses for all devices in the rack
```bash
python3 bcm_operation.py update_mac --nvl_rack --device_name p1-r01 --mac_file mac_address.p1-r01 --compute_tray_interfaces_list rf0 --nvswitch_tray_interfaces_list rf0,eth0 --powershelf_interfaces_list eth0
```

#### Create IPMI user
```bash
while IFS=',' read -r device_name pw; do
  python3 bcm_operation.py create_ipmi_user --device_name $device_name --current_bmc_user admin --current_bmc_pw $pw --new_bmc_user bright --new_bmc_pw V1sionBay@2026 --new_bmc_user_id 6 --bmc_interface ipmi0
done < oob_pw
```
