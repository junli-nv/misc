import argparse
import requests
import warnings

warnings.filterwarnings("ignore", message="Unverified HTTPS request")


def set_bf3_bmc_pw(bmc_ip, current_password, new_password, account_id="root"):
    base_url = f"https://{bmc_ip}/redfish/v1"
    resp = requests.patch(
        f"{base_url}/AccountService/Accounts/{account_id}",
        auth=("root", current_password),
        json={"Password": new_password},
        verify=False,
    )
    return resp


def set_bf3_bmc_static_ip(bmc_ip, bmc_user, bmc_pw, ip_address, subnet_mask, gw):
    base_url = f"https://{bmc_ip}/redfish/v1"
    resp = requests.patch(
        f"{base_url}/Managers/Bluefield_BMC/EthernetInterfaces/eth0",
        auth=(bmc_user, bmc_pw),
        json={
            "IPv4StaticAddresses": [
                {"Address": ip_address, "SubnetMask": subnet_mask, "Gateway": gw, "AddressOrigin": "Static"}
            ],
        },
        verify=False,
    )
    return resp


def main():
    parser = argparse.ArgumentParser(description="BMC operations via Redfish")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    parser_pw = subparsers.add_parser("set_password", help="Set BMC account password")
    parser_pw.add_argument("--bmc_ip", required=True, help="BMC IP address or hostname")
    parser_pw.add_argument("--current_password", required=True, help="Current password for authentication")
    parser_pw.add_argument("--new_password", required=True, help="New password to set")
    parser_pw.add_argument("--account_id", default="root", help="Account ID (e.g. 1, 2, 3)")

    parser_ip = subparsers.add_parser("set_static_ip", help="Set BMC static IP")
    parser_ip.add_argument("--bmc_ip", required=True, help="BMC IP address or hostname")
    parser_ip.add_argument("--bmc_user", default="root", help="BMC username")
    parser_ip.add_argument("--bmc_pw", required=True, help="BMC password")
    parser_ip.add_argument("--ip_address", required=True, help="Static IP address")
    parser_ip.add_argument("--subnet_mask", required=True, help="Subnet mask")
    parser_ip.add_argument("--gw", required=True, help="Gateway")

    args = parser.parse_args()

    if args.command == "set_password":
        resp = set_bf3_bmc_pw(args.bmc_ip, args.current_password, args.new_password, args.account_id)
    elif args.command == "set_static_ip":
        resp = set_bf3_bmc_static_ip(args.bmc_ip, args.bmc_user, args.bmc_pw, args.ip_address, args.subnet_mask, args.gw)
    else:
        parser.print_help()
        return

    print(f"Status: {resp.status_code}")
    print(resp.text)


if __name__ == "__main__":
    main()
