#!/cm/local/apps/python3/bin/python
#
# SPDX-FileCopyrightText: Copyright (c) 2023 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.
#

from __future__ import annotations

import argparse
from uuid import UUID

from tabulate import tabulate

from pythoncm import entity
from pythoncm.cluster import Cluster
from pythoncm.namerange.expand import Expand


def parse_args():
    parser = argparse.ArgumentParser(description="set serial/part number for devices from redfish hardware information")
    parser.add_argument(
        "--category",
        type=str,
        default=None,
        help="Category",
    )
    parser.add_argument(
        "--hostname",
        type=str,
        default=None,
        help="Hostname",
    )
    parser.add_argument(
        "--type",
        metavar="type",
        type=str,
        default=None,
        help="Type",
    )
    parser.add_argument(
        "--update",
        dest="update",
        action="store_true",
        default=False,
        help="Update devices",
    )
    return parser.parse_args()


def main():
    args = parse_args()
    if args is None:
        return

    cluster = Cluster()

    devices = []
    if args.type is not None:
        for it in args.type.split(","):
            devices += cluster.get_by_type(it)
    if args.category is not None:
        for it in args.category.split(","):
            if category := cluster.get_by_name(it, entity.Category):
                devices += category.devices
            else:
                print(f"Category not found: {it}")
    if args.hostname is not None:
        for it in Expand.expand(args.hostname):
            if device := cluster.get_by_name(it, entity.Device):
                devices.append(device)
            else:
                print(f"Unable to find: {it}")

    if args.type is None and args.category is None and args.hostname is None:
        devices = cluster.get_by_type(entity.Device)
    else:
        devices = list(set(devices))

    if not bool(devices):
        print("No devices selected")
        cluster.disconnect()
        return

    hardware_info = {
        UUID(it["device"]): (it.get("serial_number", ""), it.get("part_number", ""))
        for it in cluster.parallel.get_hardware_inventory_info(devices)
    }

    data = []
    alterations = []
    for device in devices:
        serial_number, part_number = hardware_info.get(device.uuid, ("", ""))
        if serial_number == device.serialNumber and part_number == device.partNumber:
            status = "OK"
        else:
            status = "wrong"
        data.append([device.hostname, device.serialNumber, device.partNumber, serial_number, part_number, status])
        if args.update and status != "OK":
            device.serialNumber = serial_number
            device.partNumber = part_number
            alterations.append(device)

    headers = [
        "Hostname",
        "Configured serial number",
        "Configured part number",
        "Collected serial number",
        "Collected part number",
        "Status",
    ]
    print(tabulate(data, headers=headers))

    if bool(alterations):
        _, result = cluster.commit(alterations)
        if not result.good:
            print(result)

    cluster.disconnect()


if __name__ == '__main__':
    main()
