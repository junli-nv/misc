import os
import re
from datetime import datetime


def format_mac_address(mac):
    """Format a 12-character MAC address as colon-separated octets."""
    return ':'.join(mac[i:i+2] for i in range(0, 12, 2))


def _write_device_log(device_name, message, mode='a'):
    if not device_name:
        return
    os.makedirs("log", exist_ok=True)
    with open(f"log/{device_name}.log", mode) as log_file:
        log_file.write(message)


OEM_REGISTRY = {}


def register_oem(oem_name):
    """Decorator to register an OEM extraction handler."""
    def decorator(func):
        OEM_REGISTRY[oem_name.lower()] = func
        return func
    return decorator


def _extract_mac_nvidia(boot_option, pci_path, verbose=False):
    """Extract MAC address for NVIDIA OEM hardware."""
    text = boot_option[0]
    escaped_pci_path = re.escape(pci_path.rstrip('/'))
    full_pattern = rf'.*{escaped_pci_path}.*?/MAC\(([A-F0-9]{{12}}),0x[0-9A-Fa-f]+\)/'
    if verbose:
        print(f"  📡 Trying to match text: {text[:100]}...")
    match = re.search(full_pattern, text)
    if match:
        return match.group(1)
    return None


@register_oem("nvidia")
def extract_macs_oem(regex_config, uefiDevicePath_arrs, verbose=False):
    """Extract MAC addresses for NVIDIA DGX hardware."""
    macs = {}
    ordered_bootoptions = []
    for interface, pci_path in regex_config['interfaces'].items():
        if verbose:
            print(f"  📡 Matching interface {interface} with PCI path: {pci_path}")
        for boot_option in uefiDevicePath_arrs:
            mac_address = _extract_mac_nvidia(boot_option, pci_path, verbose)
            if mac_address:
                macs[interface] = format_mac_address(mac_address)
                ordered_bootoptions.append(boot_option[2])
                print(f"  📡 Found MAC for {interface}: {macs[interface]} - UEFI path: {boot_option[0]} - Reference: {boot_option[2]}")
                break
    return macs, ordered_bootoptions


@register_oem("dell")
def extract_macs_oem(regex_config, uefiDevicePath_arrs, verbose=False):
    """Extract MAC addresses for Dell hardware."""
    macs = {}
    ordered_bootoptions = []
    for interface, pci_path in regex_config['interfaces'].items():
        if verbose:
            print(f"  📡 Matching interface {interface} with PCI path: {pci_path}")
        for boot_option in uefiDevicePath_arrs:
            text = boot_option[0]
            escaped_pci_path = re.escape(pci_path.rstrip('/'))
            full_pattern = rf'.*{escaped_pci_path}.*?MAC\[([A-F0-9]{{12}})\]'
            if verbose:
                print(f"  📡 Trying to match text: {text[:100]}...")
            match = re.search(full_pattern, text)
            if match:
                mac_address = match.group(1)
                macs[interface] = format_mac_address(mac_address)
                ordered_bootoptions.append(boot_option[2])
                print(f"  📡 Found MAC for {interface}: {macs[interface]} - UEFI path: {text} - Reference: {boot_option[2]}")
                break
    return macs, ordered_bootoptions


@register_oem("hp")
def extract_macs_oem(regex_config, uefiDevicePath_arrs, verbose=False):
    """Extract MAC addresses for HP/HPE hardware."""
    macs = {}
    ordered_bootoptions = []
    for interface, pci_path in regex_config['interfaces'].items():
        if verbose:
            print(f"  📡 Matching interface {interface} with PCI path: {pci_path}")
        for boot_option in uefiDevicePath_arrs:
            text = boot_option[0]
            escaped_pci_path = re.escape(pci_path.rstrip('/'))
            full_pattern = rf'.*{escaped_pci_path}.*?/Eth\(([A-F0-9]{{12}})\)/'
            if verbose:
                print(f"  📡 Trying to match text: {text[:100]}...")
            match = re.search(full_pattern, text)
            if match:
                mac_address = match.group(1)
                macs[interface] = format_mac_address(mac_address)
                ordered_bootoptions.append(boot_option[2])
                print(f"  📡 Found MAC for {interface}: {macs[interface]} - UEFI path: {text} - Reference: {boot_option[2]}")
                break
    return macs, ordered_bootoptions


def get_mac(
    bmc_ip,
    bmc_username,
    bmc_password,
    regex_config=None,
    verbose=False,
    device_name=None,
):
    """Retrieve interface MAC addresses from Redfish BootOptions.

    Args:
        bmc_ip: BMC IP address.
        bmc_username: Username for BMC authentication.
        bmc_password: Password for BMC authentication.
        regex_config: Dictionary with Redfish paths and interface PCI paths.
        verbose: Enable verbose logging.
        device_name: Optional device name used for per-device logs.

    Returns:
        Dictionary mapping interface names to MAC addresses, and ordered boot options list.
    """
    if not regex_config or 'interfaces' not in regex_config:
        print("  ⚠️ No regex_config with interfaces provided, exiting")
        return {}, []

    oem = regex_config.get('oem', 'nvidia').lower()
    print(f"  📡 Using OEM: {oem}")

    if oem not in OEM_REGISTRY:
        print(f"  ⚠️ OEM '{oem}' not supported, available: {list(OEM_REGISTRY.keys())}")
        return {}, []

    from redfish import redfish_client

    base_url = f"https://{bmc_ip}"
    print(f"  📡 Connecting to Redfish API at {base_url}")

    def is_403_error(e):
        error_str = str(e)
        return "403" in error_str or "Forbidden" in error_str or "<title>403" in error_str

    max_retries = 3
    retry_delay = 2

    redfish_obj = None
    for attempt in range(1, max_retries + 1):
        try:
            redfish_obj = redfish_client(
                base_url=base_url,
                username=bmc_username,
                password=bmc_password,
                default_prefix='/redfish/v1',
                timeout=30,
                max_retry=3
            )
            redfish_obj.login()
            print("  📡 Redfish login successful")
            break
        except Exception as e:
            if is_403_error(e) and attempt < max_retries:
                print(f"  ⚠️ Redfish login attempt {attempt} failed with 403, retrying in {retry_delay}s...")
            else:
                print(f"  ❌ Redfish login failed: {e}")
                return {}, []

    _write_device_log(
        device_name,
        f"{datetime.now()} - Starting MAC address update for {device_name}\n",
        mode='w'
    )

    try:
        bootoptions_path = regex_config.get('redfish_api_path_bootoptions', '/redfish/v1/Systems/System_0/BootOptions')
        response = redfish_obj.get(bootoptions_path)
        uefiDevicePath_arrs = []

        print(f"  📡 Fetching BootOptions... Status: {response.status}")

        if response.status == 200:
            for item in response.dict['Members']:
                response = redfish_obj.get(item['@odata.id'])
                boot_option = (
                    response.dict.get('UefiDevicePath', ''),
                    response.dict.get('@odata.etag', ''),
                    response.dict.get('BootOptionReference', ''),
                    response.dict.get('BootOptionEnabled')
                )
                uefiDevicePath_arrs.append(boot_option)
                log_message = f"  📡 Found BootOption: {boot_option[0]}, Reference: {boot_option[2]}, Enabled: {boot_option[3]}, ETag: {boot_option[1]}"
                _write_device_log(device_name, f"{datetime.now()} - {log_message}\n")
        else:
            print(f"  ⚠️ Failed to fetch BootOptions: {response.status}")

        print(f"  📡 Extracting MAC addresses using regex patterns with {regex_config['interfaces']}")
        print(f"  📡 Number of BootOptions: {len(uefiDevicePath_arrs)}")

        macs, ordered_bootoptions = OEM_REGISTRY[oem](regex_config, uefiDevicePath_arrs, verbose)

        return macs, ordered_bootoptions, uefiDevicePath_arrs, redfish_obj
    except Exception as e:
        print(f"  ❌ Error in get_mac: {e}")
        return {}, [], [], None
    finally:
        try:
            redfish_obj.logout()
        except Exception as e:
            print(f"  ⚠️ Logout exception: {e}")


def oem_get_mac(
    bmc_ip,
    bmc_username,
    bmc_password,
    regex_config=None,
    verbose=False,
    device_name=None,
):
    """Retrieve interface MAC addresses from OEM-specific Redfish API (e.g., NetworkAdapters).

    Args:
        bmc_ip: BMC IP address.
        bmc_username: Username for BMC authentication.
        bmc_password: Password for BMC authentication.
        regex_config: Dictionary with interface names mapped to Redfish API paths.
        verbose: Enable verbose logging.
        device_name: Optional device name used for per-device logs.

    Returns:
        Dictionary mapping interface names to MAC addresses.
    """
    if not regex_config or 'interfaces' not in regex_config:
        print("  ⚠️ No regex_config with interfaces provided, exiting")
        return {}

    oem = regex_config.get('oem', '').lower()
    print(f"  📡 Using OEM: {oem} (oem_get_mac)")

    from redfish import redfish_client

    base_url = f"https://{bmc_ip}"
    print(f"  📡 Connecting to Redfish API at {base_url}")

    def is_403_error(e):
        error_str = str(e)
        return "403" in error_str or "Forbidden" in error_str or "<title>403" in error_str

    max_retries = 3
    retry_delay = 2

    redfish_obj = None
    for attempt in range(1, max_retries + 1):
        try:
            redfish_obj = redfish_client(
                base_url=base_url,
                username=bmc_username,
                password=bmc_password,
                default_prefix='/redfish/v1',
                timeout=30,
                max_retry=3
            )
            redfish_obj.login()
            print("  📡 Redfish login successful")
            break
        except Exception as e:
            if is_403_error(e) and attempt < max_retries:
                print(f"  ⚠️ Redfish login attempt {attempt} failed with 403, retrying in {retry_delay}s...")
            else:
                print(f"  ❌ Redfish login failed: {e}")
                return {}

    _write_device_log(
        device_name,
        f"{datetime.now()} - Starting OEM MAC address update for {device_name}\n",
        mode='w'
    )

    try:
        macs = {}
        print(f"  📡 Extracting MAC addresses from OEM API for {len(regex_config['interfaces'])} interfaces")

        for interface, api_path in regex_config['interfaces'].items():
            if verbose:
                print(f"  📡 Fetching MAC for {interface} at {api_path}")
            response = redfish_obj.get(api_path)
            if response.status == 200:
                mac_address = response.dict.get('Ethernet', {}).get('PermanentMACAddress')
                if mac_address:
                    macs[interface] = mac_address.lower()
                    print(f"  📡 Found MAC for {interface}: {macs[interface]}")
                else:
                    print(f"  ⚠️ No PermanentMACAddress found for {interface}")
            else:
                print(f"  ⚠️ Failed to fetch {interface}: {response.status}")

        return macs
    except Exception as e:
        print(f"  ❌ Error in oem_get_mac: {e}")
        return {}
    finally:
        try:
            redfish_obj.logout()
        except Exception as e:
            print(f"  ⚠️ Logout exception: {e}")


def set_bios_settings(bmc_ip, bmc_username, bmc_password, bios_settings, api_interface):
    """Apply BIOS settings via Redfish PATCH request.

    Args:
        bmc_ip: BMC IP address.
        bmc_username: Username for BMC authentication.
        bmc_password: Password for BMC authentication.
        bios_settings: Dictionary containing BIOS settings to apply.
        api_interface: Redfish API path for BIOS settings (e.g., /redfish/v1/Systems/Self/Bios/SD).

    Returns:
        True if settings were applied successfully, False otherwise.
    """
    from redfish import redfish_client

    base_url = f"https://{bmc_ip}"
    print(f"  📡 Connecting to Redfish API at {base_url}")
    print(f"  📡 Target API: {api_interface}")
    print(f"  📡 BIOS Settings: {bios_settings}")

    def is_403_error(e):
        error_str = str(e)
        return "403" in error_str or "Forbidden" in error_str or "<title>403" in error_str

    max_retries = 3
    retry_delay = 2

    redfish_obj = None
    for attempt in range(1, max_retries + 1):
        try:
            redfish_obj = redfish_client(
                base_url=base_url,
                username=bmc_username,
                password=bmc_password,
                default_prefix='/redfish/v1',
                timeout=30,
                max_retry=3
            )
            redfish_obj.login()
            print("  📡 Redfish login successful")
            break
        except Exception as e:
            if is_403_error(e) and attempt < max_retries:
                print(f"  ⚠️ Redfish login attempt {attempt} failed with 403, retrying in {retry_delay}s...")
            else:
                print(f"  ❌ Redfish login failed: {e}")
                return False

    try:
        headers = {"content-type": "application/json"}

        response = redfish_obj.get(api_interface)
        print(f"  📡 BIOS GET response status: {response.status}")
        etag = None
        if response.status == 200:
            etag = response.dict.get('@odata.etag')
            print(f"  📡 BIOS GET response dict keys: {response.dict.keys()}")
            if etag:
                headers["If-Match"] = etag
                print(f"  📡 Using ETag: {etag}")
            else:
                print(f"  ⚠️ No ETag found in response, using wildcard If-Match: *")
                headers["If-Match"] = "*"
        else:
            print(f"  ⚠️ GET request failed, using wildcard If-Match: *")
            headers["If-Match"] = "*"

        print(f"  📡 Headers being sent: {headers}")
        response = redfish_obj.patch(api_interface, body=bios_settings, headers=headers)
        print(f"  📡 BIOS settings PATCH response status: {response.status}")

        if response.status in [200, 204]:
            print("  ✅ BIOS settings applied successfully")
            return True
        else:
            print(f"  ⚠️ BIOS settings apply failed: {response.dict}")
            return False
    finally:
        try:
            redfish_obj.logout()
        except Exception as e:
            print(f"  ⚠️ Logout exception: {e}")


def update_bootorder(redfish_obj, regex_config, ordered_bootoptions, uefiDevicePath_arrs, verbose=False):
    """Update boot order based on matched interfaces.

    Args:
        redfish_obj: Authenticated Redfish client object.
        regex_config: Dictionary with Redfish paths.
        ordered_bootoptions: List of boot option references in desired order.
        uefiDevicePath_arrs: List of boot option tuples with UEFI paths.
        verbose: Enable verbose logging.

    Returns:
        True if boot order was updated successfully, False otherwise.
    """
    if not ordered_bootoptions:
        print("  ⚠️ No ordered_bootoptions provided, skipping boot order update")
        return False

    print("  📡 update_bootorder is True, adding remaining bootoptions to ordered_bootoptions")
    for boot_option in uefiDevicePath_arrs:
        bootopt_ref = boot_option[2]
        if bootopt_ref not in ordered_bootoptions:
            ordered_bootoptions.append(bootopt_ref)
            if verbose:
                print(f"  📡 Added remaining bootoption: {bootopt_ref}")
    print(f"  📡 ordered_bootoptions: {ordered_bootoptions}")

    print("  📡 Updating boot order via Redfish PATCH request")
    etag = uefiDevicePath_arrs[0][1] if uefiDevicePath_arrs else ""
    patch_path = regex_config.get('redfish_api_path_update_bootorder', '/redfish/v1/Systems/System_0/SD')
    headers = {
        "content-type": "application/json"
    }
    if etag:
        headers["If-None-Match"] = f'"{etag}"'
    data = {"Boot": {"BootOrder": ordered_bootoptions}}
    response = redfish_obj.patch(patch_path, body=data, headers=headers)
    print(f"  📡 Boot order PATCH response status: {response.status}")
    if response.status in [200, 204]:
        override_data = {"Boot": {"BootSourceOverrideTarget": "Pxe", "BootSourceOverrideEnabled": "Continuous"}}
        override_response = redfish_obj.patch(patch_path, body=override_data, headers=headers)
        print(f"  📡 PXE boot override PATCH response status: {override_response.status}")
        if override_response.status not in [200, 204]:
            print(f"  ⚠️ PXE boot override failed: {override_response.dict}")
            return False
        return True
    else:
        print(f"  ⚠️ Boot order update failed: {response.dict}")
        return False


def pxe_reboot(redfish_obj, regex_config, verbose=False):
    """Reboot the system to PXE.

    Args:
        redfish_obj: Authenticated Redfish client object.
        regex_config: Dictionary with Redfish paths.
        verbose: Enable verbose logging.

    Returns:
        True if reboot was successful, False otherwise.
    """
    print("  📡 pxe_reboot is True, performing PowerCycle...")
    reset_path = regex_config.get('redfish_api_path_ComputerSystem.Reset', '/redfish/v1/Systems/System_0/Actions/ComputerSystem.Reset')
    try:
        response = redfish_obj.post(
            reset_path,
            body={"ResetType": "PowerCycle"}
        )
        print(f"  📡 PowerCycle POST response status: {response.status}")
        if response.status not in [200, 202, 204]:
            print(f"  ⚠️ PowerCycle failed: {response.dict}")
            return False
        return True
    except Exception as e:
        print(f"  ❌ PowerCycle exception: {e}")
        return False


def create_ipmi_user(bmc_ip, bmc_username, bmc_password, new_username, new_password, new_user_id):
    """Create an IPMI user via ipmitool.

    Args:
        bmc_ip: BMC IP address.
        bmc_username: Current BMC username for authentication.
        bmc_password: Current BMC password for authentication.
        new_username: Username for the new IPMI user.
        new_password: Password for the new IPMI user.
        new_user_id: User ID for the new IPMI user.

    Returns:
        True if user was created successfully, False otherwise.
    """
    import subprocess

    def run_ipmitool(args):
        cmd = ['ipmitool', '-I', 'lanplus', '-H', bmc_ip, '-U', bmc_username, '-P', bmc_password] + args
        result = subprocess.run(cmd, capture_output=True, text=True)
        return result.returncode, result.stdout, result.stderr

    print(f"  📡 Creating IPMI user {new_username} (ID: {new_user_id}) on BMC {bmc_ip}")

    commands = [
        (['user', 'set', 'name', str(new_user_id), new_username], "set username"),
        (['user', 'set', 'password', str(new_user_id), new_password], "set password"),
        (['channel', 'setaccess', '1', str(new_user_id), 'callin=on', 'ipmi=on', 'link=on', 'privilege=4'], "set channel access"),
#        (['raw', '0x6', '0x43', '1', str(new_user_id), '4', '4', '0'], "set privilege"),
        (['sol', 'payload', 'enable', '1', str(new_user_id)], "enable SOL payload"),
        (['user', 'enable', str(new_user_id)], "enable user"),
    ]

    for cmd, desc in commands:
        ret, stdout, stderr = run_ipmitool(cmd)
        if ret != 0:
            print(f"  ⚠️ Failed to {desc}: {stderr.strip()}")
            return False
        print(f"  📡 {desc}: OK")

    print(f"  📡 Successfully created IPMI user {new_username}")
    return True
