#!/usr/bin/python3


def precheck(entries):
    """Check the existence of each entry in BCM.

    Args:
        entries: Dictionary with format {name: class} where class is the BCM object type
                 e.g., {"oobnet1": "Subnet", "oobnet2": "Subnet"}

    Returns:
        Tuple (bool, str): (True, "") if all entries exist
                           (False, error_string) if any entry doesn't exist
    """
    from pythoncm.cluster import Cluster

    cluster = Cluster()
    missing = []

    for name, obj_type in entries.items():
        obj = cluster.get_by_name(name, obj_type)
        if not obj:
            missing.append(f"{name} ({obj_type})")

    cluster.disconnect()

    if missing:
        error_msg = f"Precheck failed. Missing entries in BCM: {', '.join(missing)}"
        return False, error_msg

    return True, ""


if __name__ == "__main__":
    import json

    sample = {
        "oobnet1": "Subnet",
        "oobnet2": "Subnet",
    }

    success, error = precheck(sample)
    if success:
        print("Precheck passed: All entries exist")
    else:
        print(f"Precheck failed: {error}")
