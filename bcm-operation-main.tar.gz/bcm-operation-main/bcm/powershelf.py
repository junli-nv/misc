import os
from datetime import datetime
from pythoncm.entity import PowerShelf
from pythoncm.entity import NetworkBmcInterface, NetworkPhysicalInterface
from .device import Device
from utils import generate_random_mac


class Powershelf(Device):
    """Represents a power shelf device in the cluster.
    
    Inherits from the base Device class and provides functionality for
    creating and managing power shelf devices with their network interfaces.
    
    Attributes:
        category: The category of the device
        spec: Dictionary containing device specifications
        ip_addresses: Dictionary mapping interface names to IP addresses
    """
    
    def __init__(self,
                 name,
                 cluster,
                 ip_addresses,
                 device_spec={},
                 createIfNotExists=False,
                 rack_name=None,
                 rack_position=None):
        """Initialize a Powershelf instance.
        
        Args:
            name: Name of the power shelf device
            cluster: Cluster object from Cluster()
            device_spec: Dictionary containing device specifications
            ip_addresses: Dictionary mapping interface names to their IP addresses
            createIfNotExists: Boolean to create the device if it doesn't exist
            category_name: Category name for the device
            rack_name: Rack name where the device is located
            rack_position: Rack position (int) for the device
        """
        if isinstance(device_spec, dict) and "powershelf" in device_spec:
            powershelf_spec = device_spec.get("powershelf")
        else:
            powershelf_spec = device_spec
        self.device_spec = powershelf_spec if powershelf_spec else {}
        super().__init__(name, cluster, self.device_spec.get('management_subnet', 'internalnet'), rack_name, rack_position)
        self.ip_addresses = ip_addresses
        
        if self.device is None and createIfNotExists:
            self.device = self.create()

    def create(self):
        """Create the power shelf device with its network interfaces."""
        if self.device is not None:
            print(f"Skip creating existing {self.__class__.__name__}: {self.name}")
            return self
        
        print(f"Creating {self.__class__.__name__}: {self.name} ips: {self.ip_addresses}")
        
        powershelf = PowerShelf(self.cluster,
                               hostname=self.name,
                               partition=self.partition)
        
        powershelf_spec = self.device_spec
        for interface_name, interface_config in powershelf_spec.get('interfaces', {}).items():
            if interface_name == powershelf_spec.get('bmc_interface'):
                itf = NetworkBmcInterface()
            else:
                itf = NetworkPhysicalInterface()
            itf.name = interface_name
            if interface_name in self.ip_addresses.keys():
                ip = self.ip_addresses[interface_name]
                itf.ip = ip
                itf.network = self.cluster.get_by_name(interface_config['subnet_name'], "Network")
                if interface_config['subnet_name'] == powershelf_spec.get('management_subnet'):
                    powershelf.provisioningInterface = itf
                    powershelf.managementNetwork = itf.network
            
            powershelf.interfaces.append(itf)
        
        if self.rackPosition is not None:
            powershelf.rackPosition = self.rackPosition
        
        powershelf.mac = generate_random_mac()
        
        result = powershelf.commit()
        
        if result.good:
            print(f"✅ Successfully created powershelf: {self.name}")
            self.device = self.cluster.get_by_name(self.name, "Device")
        else:
            os.makedirs('log', exist_ok=True)
            log_path = f"log/{self.name}.log"
            with open(log_path, 'w') as log_file:
                log_file.write(f"Failed to create powershelf: {self.name}\n")
                log_file.write(f"Timestamp: {datetime.now()}\n")
                log_file.write(f"Result: {result}\n")
                log_file.write(f"Debug - powershelf: {powershelf}, device_spec: {self.device_spec}\n")
            
            print(f"❌ Failed to create powershelf: {self.name}, please check log file {log_path}")
            return None
        
        return self

    def remove(self):
        """Remove the power shelf device from the cluster.
        
        Calls the parent remove method to handle device removal.
        """
        super().remove()
        return True
