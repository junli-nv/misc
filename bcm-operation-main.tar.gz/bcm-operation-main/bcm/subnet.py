from pythoncm.entity import Network
from pythoncm.entity.metadata.network import Network as NetworkMeta

class Subnet:
    def __init__(self, name, base_network_ip, netmaskBits, gateway, cluster, dynamic_start = None, dynamic_end = None, excludeFromSearchDomain = False):
        self.name = name
        self.base_network_ip = base_network_ip
        self.netmaskBits = int(netmaskBits)
        self.gateway = gateway
        self.cluster = cluster
        self.dynamic_start = dynamic_start
        self.dynamic_end = dynamic_end
        self.excludeFromSearchDomain = excludeFromSearchDomain
    
    def create(self):
        # Basic creation logic, create subnet if it doesn't exist
        print(f"🔍 Checking if subnet {self.name} exists...")
        # Logic to check if subnet exists should be implemented here
        # If it doesn't exist, create the subnet
        print(f"🚀 Creating Subnet {self.name} with base IP {self.base_network_ip}, netmaskbits {self.netmaskBits}, gateway {self.gateway}")
        subnet = Network(self.cluster, 
                        name=self.name, 
                        baseAddress=self.base_network_ip,
                        netmaskBits=self.netmaskBits,
                        gateway=self.gateway,
                        domainName=f"{self.name}.cluster",
                        lockDownDhcpd=True,
                        management=True,
                        bootable=True,
                        type=NetworkMeta.Type.INTERNAL,
                        excludeFromSearchDomain=self.excludeFromSearchDomain
                        )
        if self.dynamic_start:
            subnet.dynamicRangeStart = self.dynamic_start
        if self.dynamic_end:
            subnet.dynamicRangeEnd = self.dynamic_end
        commit_result = subnet.commit()
        if not commit_result.good:
            print(f"🟢 Subnet: {self.name} failed to be created")
            print(commit_result)
        else:
            print(f"🟢 Successfully created Subnet {self.name} with base IP {self.base_network_ip}, netmaskbits {self.netmaskBits}, gateway {self.gateway}")
        print(f"🟢 Subnet creation summary: {self.name} - {self.base_network_ip}/{self.netmaskBits}")
        return True
    
    def update(self, base_network_ip=None, netmaskBits=None, gateway=None):
        # Basic update logic, update information of existing subnet
        print(f"Updating subnet {self.name}...")
        # Update properties if new values are provided
        if base_network_ip is not None:
            self.base_network_ip = base_network_ip
        if netmaskBits is not None:
            self.netmaskBits = netmaskBits
        if gateway is not None:
            self.gateway = gateway
        # Actual subnet update logic should be implemented here
        print(f"Subnet {self.name} updated with base IP {self.base_network_ip}, prefix {self.netmaskBits}, gateway {self.gateway}")
        return True
    
    def remove(self):
        # Basic removal logic, remove subnet
        print(f"Removing subnet {self.name}...")
        # Call cluster.remove to remove subnet resources
        subnet = self.cluster.get_by_name(self.name, "Network")
        result = subnet.remove()
        print(f"Subnet {self.name} removed: {result} ")
        return True