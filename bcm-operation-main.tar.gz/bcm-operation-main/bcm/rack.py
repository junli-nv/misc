from pythoncm.entity import Rack as BCMRack

class Rack:
    def __init__(self, rack_name, cluster):
        self.rack_name = rack_name
        self.cluster = cluster
        # Additional rack-related properties can be added here

    def create(self):
        # Rack creation logic
        print(f"🚀 Creating rack: {self.rack_name}")
        # Actual rack creation code can be added here
        rack = self.cluster.get_by_name(self.rack_name, "Rack")
        if rack is None:
            rack = BCMRack(self.cluster,
                        name = self.rack_name)
            result = rack.commit()
            if  result.good:
                print(f"🟢 Successfully created rack: {self.rack_name}")
            else:
                print(f"🟢 Failed to create rack: {self.rack_name}")
                print(result)
        else:
            print(f"⚠️ Rack {self.rack_name} already exists")
        print(f"🟢 Rack creation summary: {self.rack_name}")
        return self

    def remove(self):
        # Rack removal logic
        rack = self.cluster.get_by_name(self.rack_name, "Rack")
        if rack is not None:
            print(f"🗑️ Removing rack: {self.rack_name}")
            result = rack.remove()
            if result:
                print(f"🟢 Successfully removed rack: {self.rack_name}")
            else:
                print(f"🟢 Failed to remove rack: {self.rack_name}")
        else:
            print(f"⚠️ Rack {self.rack_name} not found")
        return True
