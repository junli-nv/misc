from datetime import datetime
from pythoncm.entity import Switch
from pythoncm.entity import NetworkBmcInterface, NetworkPhysicalInterface
from pythoncm.entity.metadata.switch import Switch as SwitchMeta
from .device import Device
from utils import generate_random_mac


class NVSwitchTray(Device):
    """Represents an NVSwitch tray device in the cluster.
    
    Inherits from the base Device class and provides functionality for
    creating and managing NVSwitch tray devices with their network interfaces.
    
    Attributes:
        spec: Dictionary containing device specifications
        ip_addresses: Dictionary mapping interface names to IP addresses
    """
    
    def __init__(self,
                 name,
                 cluster,
                 ip_addresses,
                 device_spec={},
                 createIfNotExists=False,
                 rack_name=None,
                 rack_position=None):
        if isinstance(device_spec, dict) and "nvswitch_tray" in device_spec:
            nvswitch_spec = device_spec.get("nvswitch_tray")
        else:
            nvswitch_spec = device_spec
        self.device_spec = nvswitch_spec if nvswitch_spec else {}
        super().__init__(name, cluster, self.device_spec.get('management_subnet', 'internalnet'), rack_name, rack_position)
        self.ip_addresses = ip_addresses
        
        if self.device is None and createIfNotExists:
            self.device = self.create()

    def create(self):
        """Create the NVSwitch tray device with its network interfaces."""
        if self.device is not None:
            print(f"Skip creating existing {self.__class__.__name__}: {self.name}")
            return self
        
        print(f"Creating {self.__class__.__name__}: {self.name} ips: {self.ip_addresses}")
        
        switch = Switch(self.cluster,
                       hostname=self.name,
                       partition=self.partition)
        
        nvswitch_spec = self.device_spec
        for interface_name, interface_config in nvswitch_spec.get('interfaces', {}).items():
            if interface_name == nvswitch_spec.get('bmc_interface'):
                itf = NetworkBmcInterface()
            else:
                itf = NetworkPhysicalInterface()
            itf.name = interface_name
            if interface_name in self.ip_addresses.keys():
                ip = self.ip_addresses[interface_name]
                itf.ip = ip
                itf.network = self.cluster.get_by_name(interface_config['subnet_name'], "Network")
                if interface_config['subnet_name'] == nvswitch_spec.get('management_subnet'):
                    switch.provisioningInterface = itf
                    switch.managementNetwork = itf.network
            
            switch.interfaces.append(itf)
        
        if self.rackPosition is not None:
            switch.rackPosition = self.rackPosition
        
        switch.powerControl = nvswitch_spec.get('bmc_interface')
        switch.kind = SwitchMeta.Kind.NVLINK
        
        switch.mac = generate_random_mac()
        
        result = switch.commit()
        
        if result.good:
            print(f"✅ Successfully created NVSwitch tray: {self.name}")
            self.device = self.cluster.get_by_name(self.name, "Device")
        else:
            import os
            os.makedirs('log', exist_ok=True)
            log_path = f"log/{self.name}.log"
            with open(log_path, 'w') as log_file:
                log_file.write(f"Failed to create NVSwitch tray: {self.name}\n")
                log_file.write(f"Timestamp: {datetime.now()}\n")
                log_file.write(f"Result: {result}\n")
                log_file.write(f"Debug - switch: {switch}, device_spec: {self.device_spec}\n")
            
            print(f"❌ Failed to create NVSwitch tray: {self.name}, please check log file {log_path}")
            return None
        
        return self

    def remove(self):
        super().remove()
        return True
