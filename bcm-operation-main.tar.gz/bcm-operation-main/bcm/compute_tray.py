from datetime import datetime
import os
from pythoncm.entity import PhysicalNode
from pythoncm.entity import NetworkBmcInterface,NetworkPhysicalInterface,NetworkBondInterface
from .device import Device
from utils import generate_random_mac


class ComputeTray(Device):
    """Represents a compute tray device in the cluster.
    
    Inherits from the base Device class and provides functionality for
    creating and managing compute tray devices with their network interfaces.
    
    Attributes:
        category: The category of the device (e.g., "compute")
        spec: Dictionary containing device specifications
        ips: Dictionary mapping interface names to their IP addresses
        bootif: The boot interface for the device
    """

    def __init__(self,
                 name,
                 cluster,
                 ip_addresses,
                 device_spec={},
                 createIfNotExists = False,
                 category_name = "default",
                 rack_name = None,
                 rack_position = None):
        """Initialize a ComputeTray instance.
        
        Args:
            name: Name of the compute tray device
            cluster: Cluster object from Cluster()
            device_spec: Dictionary containing device specifications
            ip_addresses: Dictionary mapping interface names to their IP addresses (e.g., {"bond0": "1.1.1.1"})
            createIfNotExists: Boolean to create the device if it doesn't exist
            category: Category of the device (required if createIfNotExists=True)
            rack: Rack Name where the device is located
            rack_position: Rack position (int) for the device
        """
        # Call the parent Device.__init__ method
        #pdb.set_trace()
        super().__init__(name, cluster, device_spec.get('management_subnet', 'internalnet'), rack_name, rack_position)
        
        # Set up instance attributes
        self.category = self.cluster.get_by_name(category_name, "Category")
        self.device_spec = device_spec
        self.ip_addresses = ip_addresses  # Dictionary mapping interfaces to IP addresses
                
        # Create the device if it doesn't exist and createIfNotExists is True
        if self.device is None and createIfNotExists:
            self.device = self.create()


    def create(self):
        """Create the compute tray device with its network interfaces.
        
        Creates a PhysicalNode and configures all network interfaces based on the spec.
        Handles BMC interfaces, physical interfaces, and bond interfaces (identified by slave_interfaces).
        Sets up the provisioning interface and management network.
        """
        if self.device is not None:
            print (f"Skip creating a existed {self.__class__.__name__}: {self.name}")
            return
        print(f"Creating {self.__class__.__name__}: {self.name} ips: {self.ip_addresses}")
        
        # Create the physical node
        node = PhysicalNode(self.cluster,
                    hostname = self.name,
                    partition = self.partition,
                    category = self.category
        )

        # Configure all interfaces from the spec
        compute_node_spec = self.device_spec.get('compute_node', {})
        interfaces_dict = compute_node_spec.get('interfaces', {})
        
        # Handle both list format and dict format for interfaces
        if isinstance(interfaces_dict, list):
            # Convert list to dict format
            interfaces = {name: {} for name in interfaces_dict}
        else:
            interfaces = interfaces_dict
        
        slave_interfaces = []
        for interface_name, interface_config in interfaces.items():
            if interface_name == compute_node_spec.get('bmc_interface'):
                # Create BMC interface
                itf = NetworkBmcInterface()
                itf.name = interface_name
                if interface_name in self.ip_addresses.keys():
                    ip = self.ip_addresses[interface_name]
                    itf.ip = ip
                    itf.network = self.cluster.get_by_name(interface_config.get('subnet_name'), "Network")
            else:
                itf = None
                if isinstance(interface_config, dict) and 'slave_interfaces' in interface_config:
                    itf = NetworkBondInterface()
                    itf.interfaces = interface_config['slave_interfaces']  # Set the slave interfaces
                    if 'bonding_mode' in interface_config:
                        itf.mode = interface_config['bonding_mode']
                    itf.options = "miimon=100"
                    slave_interfaces.extend(interface_config['slave_interfaces'])
                else:
                    itf = NetworkPhysicalInterface()
                itf.name = interface_name
                if interface_name in self.ip_addresses.keys():
                    ip = self.ip_addresses[interface_name]
                    itf.ip = ip
                    if isinstance(interface_config, dict):
                        itf.network = self.cluster.get_by_name(interface_config.get('subnet_name'), "Network")
                        if interface_config.get('subnet_name') == compute_node_spec.get('management_subnet'):
                            node.provisioningInterface = itf
                            node.managementNetwork = itf.network 

            # Add the interface to the node
            node.interfaces.append(itf)

        # Create NetworkPhysicalInterface for slave interfaces that are not already defined as top-level interfaces
        defined_interfaces = list(compute_node_spec.get('interfaces', {}).keys())
        for slave_name in slave_interfaces:
            if slave_name not in defined_interfaces:
                slave_itf = NetworkPhysicalInterface()
                slave_itf.name = slave_name
                node.interfaces.append(slave_itf)

        # Set rack position if available
        if self.rackPosition is not None:
            node.rackPosition = self.rackPosition
            
        # Set power control interface if available
        node.powerControl = compute_node_spec.get('bmc_interface')

        # Set random MAC address for the node (BCM feature)
        node.mac = generate_random_mac()
            
        # Commit the changes to create the node
        result = node.commit()

        if not result.good:
            log_path = f"log/{self.name}.log"
            
            # Ensure log directory exists
            os.makedirs("log", exist_ok=True)
            
            # Dump result to log file
            with open(log_path, 'w') as log_file:
                log_file.write(f"Failed to create compute tray: {self.name}\n")
                log_file.write(f"Timestamp: {datetime.now()}\n")
                log_file.write(f"Result: {result}\n")
                log_file.write(f"Debug - node: {node}, device_spec: {self.device_spec}\n")
            
            print(f"❌ Failed to create compute tray: {self.name}, please check log file {log_path}")
            return None
        else:
            print(f"✅ Successfully created compute tray: {self.name}")
            self.device = self.cluster.get_by_name(self.name, "Device")
        return self


    def remove(self):
        """Remove the compute tray device from the cluster.
        
        Calls the parent remove method to handle device removal.
        """
        super().remove()


    def update_macs_by_redfish(self, bmc_username, bmc_password, regex_config=None, pxe_reboot=False, update_bootorder=False, verbose=False):
        """Retrieve MAC addresses via Redfish and update the BCM device.
        
        Args:
            bmc_username: Username for BMC authentication
            bmc_password: Password for BMC authentication
            regex_config: Dictionary with regex patterns for each interface
            pxe_reboot: Reboot to PXE after updating MAC
            update_bootorder: Update boot order after updating MAC
            verbose: Enable verbose logging
            
        Returns:
            Dictionary mapping interface names to their MAC addresses
        """
        print(f"  📡 update_macs_by_redfish: Starting for device {self.name}")
        print(f"  📡 BMC Username: {bmc_username}")
        print(f"  📡 PXE Reboot: {pxe_reboot}, Update Bootorder: {update_bootorder}")

        bmc_ip = None

        # Find the BMC IP address
        powercontrol = getattr(self.device, 'powerControl', None)
        print(f"  📡 Power Control Interface: {powercontrol}")

        if powercontrol and hasattr(self.device, 'interfaces'):
            for interface in self.device.interfaces:
                if interface.name == powercontrol:
                    bmc_ip = interface.ip
                    print(f"  📡 Found BMC IP: {bmc_ip}")
                    break

        if bmc_ip is None:
            print(f"  ⚠️ Power control interface {powercontrol} not found or ip not configured")
            return {}

        from hardware import get_mac, oem_get_mac, update_bootorder as do_update_bootorder, pxe_reboot as do_pxe_reboot

        oem = regex_config.get('oem', '').lower() if regex_config else ''

        if oem == 'giga':
            macs = oem_get_mac(
                bmc_ip=bmc_ip,
                bmc_username=bmc_username,
                bmc_password=bmc_password,
                regex_config=regex_config,
                verbose=verbose,
                device_name=self.name,
            )
            ordered_bootoptions = []
            uefiDevicePath_arrs = []
            redfish_obj = None
        else:
            macs, ordered_bootoptions, uefiDevicePath_arrs, redfish_obj = get_mac(
                bmc_ip=bmc_ip,
                bmc_username=bmc_username,
                bmc_password=bmc_password,
                regex_config=regex_config,
                verbose=verbose,
                device_name=self.name,
            )

            if redfish_obj is not None:
                if update_bootorder and macs:
                    do_update_bootorder(redfish_obj, regex_config, ordered_bootoptions, uefiDevicePath_arrs, verbose)
                if pxe_reboot:
                    do_pxe_reboot(redfish_obj, regex_config, verbose)

        if macs:
            print(f"  📡 Updating device MACs: {macs}")
            for interface in self.device.interfaces:
                if interface.name in macs:
                    interface.mac = macs[interface.name]
            if macs:
                first_interface_mac = next(iter(macs.values()))
                self.device.mac = first_interface_mac
                print(f"  📡 Set device MAC to: {first_interface_mac}")
            result = self.device.commit()
            if result and result.good:
                print(f"  ✅ MAC address update via Redfish completed for {self.name}")
            else:
                print(f"  ❌ MAC address commit failed for {self.name}: {result}")
                return {}
        else:
            print("  ❌ No MAC addresses found, skipping MAC update")
            print(f"  ❌ MAC address update via Redfish failed for {self.name}")

        return macs
