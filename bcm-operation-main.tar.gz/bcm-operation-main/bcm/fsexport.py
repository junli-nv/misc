from pythoncm.entity import FSExport


def format_mac_address(mac_str):
    """
    Convert a 12-character hex string MAC address to the standard XX:XX:XX:XX:XX:XX format.
    Args:
        mac_str (str): A 12-character hex string representing a MAC address (e.g., "E09D7389CB2B")
    Returns:
        str: The MAC address in standard format (e.g., "E0:9D:73:89:CB:2B")
    """
    if len(mac_str) != 12:
        raise ValueError(f"MAC address must be 12 characters long, got {len(mac_str)}")
    # Split the string into 2-character chunks and join with colons
    return ':'.join(mac_str[i:i+2] for i in range(0, 12, 2))

def add_fsexport_entry(path, 
                        name,
                        cluster,
                        master, 
                        subnet_name,
                        write,
                        disabled):
    new_fsexport = FSExport()
    new_fsexport.path = path
    new_fsexport.name = name
    new_fsexport.network = cluster.get_by_name (subnet_name, "Network")
    new_fsexport.allowWrite = write
    new_fsexport.disabled = disabled

    master.fsexports.append(new_fsexport)
    result = master.commit()
    if result.good:
        print (f"Successfully add fsexport {new_fsexport.name}")
    else:
        print (f"Failed to add fsexport {new_fsexport.name}: {result}")


def clone_fsexport_entries(cluster, subnet_name):
    master = cluster.active_head_node()
    all_fsexports_name = [fsexport.name for fsexport in master.fsexports]
    for fsexport in master.fsexports:
        fsname = f'{fsexport.path}@{subnet_name}'
        if fsname in all_fsexports_name:
            print (f"Skip add fsexport {fsname}: already existed")
            continue
        if "internalnet" in fsexport.name:
            add_fsexport_entry(fsexport.path, fsname, cluster, master, subnet_name, fsexport.allowWrite, fsexport.disabled)

    passive = cluster.passive_head_node()
    if passive is None:
        print("No passive head node found, skipping fsexport clone for passive")
        return
    passive_all_fsexports_name = [fsexport.name for fsexport in passive.fsexports]
    for fsexport in master.fsexports:
        fsname = f'{fsexport.path}@{subnet_name}'
        if fsname in passive_all_fsexports_name:
            print(f"Skip add fsexport {fsname}: already existed on passive")
            continue
        if "internalnet" in fsexport.name:
            add_fsexport_entry(fsexport.path, fsname, cluster, passive, subnet_name, fsexport.allowWrite, fsexport.disabled)
