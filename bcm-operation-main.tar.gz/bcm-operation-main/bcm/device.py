from uu import Error
from pythoncm.entity import RackPosition


class Device:
    """Base class for all rack devices (compute trays, power shelves, NVIDIA switch trays)."""
    def __init__(self, 
                name, 
                cluster,
                management_subnet_name = "internalnet",
                rack_name = None,
                rack_position = None):
        self.name = name
        self.cluster = cluster
        self.partition = self.cluster.get_by_name ("base", "Partition")
        self.device = self.cluster.get_by_name(self.name, "Device")
        self.management_subnet = self.cluster.get_by_name(management_subnet_name, "Network")
        if self.management_subnet is None:
            raise Error(f"Management subnet {management_subnet_name} not found")
        if rack_name is not None:
            self.rack = self.cluster.get_by_name(rack_name, "Rack")
            if self.rack is None:
                print (f"Rack {rack_name} not existed, skip rack configuration for {self.__class__.__name__}: {self.name}")
                self.rackPosition = None
            elif  rack_position is not None:
                self.rackPosition = RackPosition(self.cluster,
                                            rack=self.rack,
                                            position=rack_position)

    def update_mac(self, mac_dict):
        for interface in self.device.interfaces:
            if interface.name in mac_dict:
                interface.mac = mac_dict[interface.name]
        result = self.device.commit()
        if not result or not result.good:
            print(f"Failed to commit MAC updates for {self.name}: {result}")
            return False
        return True

    def remove(self):
        print(f"Removing {self.__class__.__name__}: {self.name}")
        if self.device is not None:
            self.device.close()
            self.device.remove()
        return True

