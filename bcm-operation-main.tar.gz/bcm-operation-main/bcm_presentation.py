#!/usr/bin/env python3
import re
from pathlib import Path
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN

def set_title_style(paragraph, font_size=32, bold=True):
    paragraph.font.size = Pt(font_size)
    paragraph.font.bold = bold

def add_bullet_text(text_frame, text, level=0, font_size=14, bold=False):
    p = text_frame.add_paragraph()
    p.text = text
    p.level = level
    p.font.size = Pt(font_size)
    p.font.bold = bold
    p.space_after = Pt(6)
    return p

def create_title_slide(prs, title, subtitle):
    slide_layout = prs.slide_layouts[6]
    slide = prs.slides.add_slide(slide_layout)

    left = Inches(0.5)
    top = Inches(2.5)
    width = Inches(9)
    height = Inches(2)

    title_box = slide.shapes.add_textbox(left, top, width, height)
    tf = title_box.text_frame
    p = tf.paragraphs[0]
    p.text = title
    p.font.size = Pt(44)
    p.font.bold = True
    p.alignment = PP_ALIGN.CENTER

    subtitle_box = slide.shapes.add_textbox(left, top + Inches(1.5), width, Inches(1))
    tf = subtitle_box.text_frame
    p = tf.paragraphs[0]
    p.text = subtitle
    p.font.size = Pt(24)
    p.alignment = PP_ALIGN.CENTER
    return slide

def create_content_slide(prs, title, bullets, sub_bullets=None):
    slide_layout = prs.slide_layouts[6]
    slide = prs.slides.add_slide(slide_layout)

    title_box = slide.shapes.add_textbox(Inches(0.5), Inches(0.3), Inches(9), Inches(0.8))
    tf = title_box.text_frame
    p = tf.paragraphs[0]
    p.text = title
    p.font.size = Pt(32)
    p.font.bold = True

    content_box = slide.shapes.add_textbox(Inches(0.5), Inches(1.3), Inches(9), Inches(5.5))
    tf = content_box.text_frame
    tf.word_wrap = True

    for bullet in bullets:
        add_bullet_text(tf, bullet, font_size=18)

    if sub_bullets:
        for sub in sub_bullets:
            add_bullet_text(tf, sub, level=1, font_size=14)
    return slide

def create_code_slide(prs, title, code_text):
    slide_layout = prs.slide_layouts[6]
    slide = prs.slides.add_slide(slide_layout)

    title_box = slide.shapes.add_textbox(Inches(0.5), Inches(0.3), Inches(9), Inches(0.8))
    tf = title_box.text_frame
    p = tf.paragraphs[0]
    p.text = title
    p.font.size = Pt(28)
    p.font.bold = True

    code_box = slide.shapes.add_textbox(Inches(0.3), Inches(1.2), Inches(9.4), Inches(5.5))
    tf = code_box.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.text = code_text
    p.font.name = "Courier New"
    p.font.size = Pt(11)
    return slide

def create_two_column_slide(prs, title, left_title, left_items, right_title, right_items):
    slide_layout = prs.slide_layouts[6]
    slide = prs.slides.add_slide(slide_layout)

    title_box = slide.shapes.add_textbox(Inches(0.5), Inches(0.3), Inches(9), Inches(0.8))
    tf = title_box.text_frame
    p = tf.paragraphs[0]
    p.text = title
    p.font.size = Pt(28)
    p.font.bold = True

    left_box = slide.shapes.add_textbox(Inches(0.3), Inches(1.2), Inches(4.5), Inches(5.5))
    tf = left_box.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.text = left_title
    p.font.size = Pt(18)
    p.font.bold = True
    for item in left_items:
        add_bullet_text(tf, item, font_size=14)

    right_box = slide.shapes.add_textbox(Inches(5), Inches(1.2), Inches(4.5), Inches(5.5))
    tf = right_box.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.text = right_title
    p.font.size = Pt(18)
    p.font.bold = True
    for item in right_items:
        add_bullet_text(tf, item, font_size=14)

    return slide

def create_presentation():
    prs = Presentation()
    prs.slide_width = Inches(10)
    prs.slide_height = Inches(7.5)

    create_title_slide(prs,
        "BCM Operation Tool",
        "Bulk Cluster Management & Node Provisioning")

    create_content_slide(prs, "What is BCM Operation?",
        [
            "BCM Operation is a command-line tool for managing NVIDIA GPU clusters",
            "Provides automation for subnet, device, and rack management",
            "Streamlines DGX/HGX infrastructure deployment",
            "Supports multiple GPU platforms: GB200, GB300, H100, B300"
        ])

    create_content_slide(prs, "Key Features",
        [
            "Subnet Management",
            "Device Type & Definition Creation",
            "Rack Configuration",
            "MAC Address Management",
            "DHCP Configuration Generation",
            "IPMI User Management",
            "NVSwitch Tray Configuration"
        ])

    create_content_slide(prs, "Why Automate Cluster Creation?",
        [
            "Scale: Deploy 100s of nodes with single commands",
            "Consistency: Eliminate manual configuration errors",
            "Speed: Reduce deployment time from days to hours",
            "Repeatability: Same result every time",
            "Auditability: All changes are command-driven"
        ])

    create_content_slide(prs, "Advantages of Node Provisioning",
        [
            "Centralized Management: Control entire cluster from BCM",
            "Network Isolation: Separate inband/oob/ipoib networks",
            "Automated IP Allocation: No manual IP conflicts",
            "Hardware Tracking: Know every device MAC and location",
            "Remote Management: IPMI integration for out-of-band control"
        ])

    create_two_column_slide(prs, "Supported GPU Platforms",
        "NVIDIA DGX Systems",
        ["DGX GB200 (NVL72)", "DGX H100", "DGX B300"],
        "NVIDIA HGX Systems",
        ["HGX GB300", "HGX B300", "Custom configs"])

    create_content_slide(prs, "Prerequisites",
        [
            "BCM (BMC) API access and credentials",
            "Python 3 with bcm_operation.py",
            "Valid IP allocation spreadsheets",
            "Device specification files (JSON)"
        ])

    create_code_slide(prs, "Setup: Load Python Module",
        """# Load Python environment
module load python3

# Verify bcm_operation.py is available
python3 bcm_operation.py --help""")

    create_code_slide(prs, "Step 1: Create Racks (Bulk)",
        """# Create 8 racks at once
for i in $(seq -w 01 08); do
    python3 bcm_operation.py create_rack --rack_name p1-r$i
done""")

    create_code_slide(prs, "Step 2: Create Inband Subnet",
        """# Create subnet for Humain project
python3 bcm_operation.py create_subnet \\
    --subnet_name hm-inband \\
    --network 10.0.1.0 \\
    --netmaskbits 24 \\
    --gateway 10.0.1.254 \\
    --dynamic_start 10.0.1.240 \\
    --dynamic_end 10.0.1.250 \\
    --add-fs-export""")

    create_code_slide(prs, "Step 2: Create OOB & IPOIB Subnets",
        """# Out-of-band management subnet
python3 bcm_operation.py create_subnet \\
    --subnet_name hm-oob \\
    --network 10.0.9.0 \\
    --netmaskbits 24 \\
    --gateway 10.0.9.254 \\
    --dynamic_start 10.0.9.240 \\
    --dynamic_end 10.0.9.250

# IPOIB backbone network
python3 bcm_operation.py create_subnet \\
    --subnet_name hm-ipoib \\
    --network 192.168.0.0 \\
    --netmaskbits 16 \\
    --gateway 0.0.0.0 \\
    --dynamic_start 0.0.0.0 \\
    --dynamic_end 0.0.0.0""")

    create_code_slide(prs, "Bulk Subnet Creation (Inband)",
        """# Prepare CSV: inband_subnet
inband-rack01,10.135.0.0,26,10.135.0.62,10.135.0.51,10.135.0.61
inband-rack02,10.135.0.64,26,10.135.0.126,10.135.0.116,10.135.0.126
...

# Bulk create
for i in $(cat inband_subnet); do
    IFS=',' read subnet_name subnet bits gw start end <<< $(echo $i)
    python3 bcm_operation.py create_subnet \\
        --subnet_name $subnet_name \\
        --network $subnet \\
        --netmaskbits $bits \\
        --gateway $gw \\
        --dynamic_start $start \\
        --dynamic_end $end \\
        --add-fs-export
done""")

    create_code_slide(prs, "Bulk Subnet Creation (OOB)",
        """# Prepare CSV: oob_subnet
oob-rack01,10.135.32.0,25,10.135.32.126,10.135.32.100,10.135.32.110
oob-rack02,10.135.32.128,25,10.135.32.254,10.135.32.220,10.135.32.230
...

# Bulk create
for i in $(cat oob_subnet); do
    IFS=',' read subnet_name subnet bits gw start end <<< $(echo $i)
    python3 bcm_operation.py create_subnet \\
        --subnet_name $subnet_name \\
        --network $subnet \\
        --netmaskbits $bits \\
        --gateway $gw \\
        --dynamic_start $start \\
        --dynamic_end $end
done""")

    create_code_slide(prs, "Step 3: Create Device Type (GB200)",
        """python3 bcm_operation.py create_device_type \\
    --device_type dgx-gb200  \\
    --nvl_rack \\
    --compute_node_interfaces enP22p3s0f0np0,enP22p3s0f0np1,\\
        enP5p9s0,enP6p3s0f0np0,enP6p3s0f0np1,ibP16p3s0,\\
        ibP18p3s0,ibP2p3s0,ibp3s0 \\
    --compute_node_bmc_interface rf0 \\
    --nvswitch_tray_interfaces eth0,eth1 \\
    --nvswitch_tray_bmc_interface rf0 \\
    --powershelf_interfaces eth0 \\
    --bonding-spec "bond0:enP22p3s0f0np0|enP6p3s0f0np0,\\
                   bond1:enP22p3s0f0np1|enP6p3s0f0np1" \\
    --provisioning_interface bond0""")

    create_code_slide(prs, "Step 3: Create Device Type (HGX-B300)",
        """python3 bcm_operation.py create_device_type \\
        --device_type dgx-b300 \\
        --compute_node_interfaces ipmi0,enp170s0f1np1,\\
            enp41s0f1np1,ibp154s0,ibp170s0f0,ibp192s0,\\
            ibp206s0,ibp220s0,ibp24s0,ibp41s0f0,ibp64s0,\\
            ibp79s0,ibp94s0 \\
        --compute_node_bmc_interface ipmi0 \\
        --bonding-spec "bond0:enp170s0f1np1|enp41s0f1np1" \\
        --provisioning_interface bond0""")

    create_code_slide(prs, "Step 4: Create Device (GB200 Rack)",
        """# Create 8 devices
for i in $(seq -w 01 08); do
    if [ $i -le 04 ]; then
        powershelf="powershelf1"
    else
        powershelf="powershelf2"
    fi
    python3 bcm_operation.py create_device \\
        --device_name p1-r$i \\
        --nvl_rack \\
        --compute_node_interfaces_subnets bond0:inband-rack$i,\\
            ibP16p3s0:ipoib,ibP18p3s0:ipoib,ibP2p3s0:ipoib,\\
            ibp3s0:ipoib,rf0:oob-rack$i \\
        --compute_node_management_subnet inband-rack$i \\
        --compute_node_category straitdeer \\
        --nvswitch_tray_interfaces_subnets rf0:oob-rack$i,\\
            eth0:oob-rack$i,eth1:oob-rack$i \\
        --nvswitch_management_subnet oob-rack$i \\
        --powershelf_interface_subnet eth0:$powershelf \\
        --device_spec spec/dgx-gb200.json \\
        --ip_allocation_file ip-allocation.csv
done""")

    create_code_slide(prs, "Step 4: Create Device (HGX B300)",
        """# Bulk create from IP allocation file
while IFS=',' read -r device_name _ _; do
    python3 bcm_operation.py create_device \\
        --device_name $device_name \\
        --compute_node_interfaces_subnets ipmi0:hm-oob,\\
            bond0:hm-inband \\
        --compute_node_management_subnet hm-inband \\
        --compute_node_category hm \\
        --device_spec spec/dgx-b300.json \\
        --ip_allocation_file ip-allocation-hm.csv
done < ip-allocation-hm.csv""")

    create_code_slide(prs, "Step 5: Update MAC Addresses",
        """python3 bcm_operation.py update_mac \\
    --nvl_rack \\
    --device_name p1-r01 \\
    --mac_file mac_address.p1-r01 \\
    --compute_tray_interfaces_list rf0 \\
    --nvswitch_tray_interfaces_list rf0,eth0 \\
    --powershelf_interfaces_list eth0""")

    create_code_slide(prs, "Step 6: Create IPMI Users",
        """# Batch create IPMI users
while IFS=',' read -r device_name pw; do
  python3 bcm_operation.py create_ipmi_user \\
    --device_name $device_name \\
    --current_bmc_user admin \\
    --current_bmc_pw $pw \\
    --new_bmc_user bright \\
    --new_bmc_pw V1sionBay@2026 \\
    --new_bmc_user_id 6 \\
    --bmc_interface ipmi0
done < oob_pw""")

    create_code_slide(prs, "Additional: DHCP Config Generation",
        """# Generate DHCP config from IP allocation
python3 bcm_operation.py create_dhcp_conf \\
    --ip_allocation_file su1_su2/bf3-bmc-ip-alloc""")

    create_content_slide(prs, "Workflow Summary",
        [
            "1. Create Racks",
            "2. Create Subnets (Inband, OOB, IPOIB)",
            "3. Define Device Types",
            "4. Create Devices & assign IPs",
            "5. Update MAC addresses",
            "6. Configure IPMI users",
            "7. Generate DHCP configs"
        ])

    create_content_slide(prs, "Key Benefits",
        [
            "Single tool manages entire cluster lifecycle",
            "Bulk operations scale to 100s of nodes",
            "Standardized, repeatable deployments",
            "Integration with NVIDIA GPU platforms",
            "Automated network and security configuration"
        ],
        [
            "BMC API integration",
            "IPMI for remote management",
            "DHCP for dynamic IP allocation"
        ])

    create_title_slide(prs, "Questions?", "BCM Operation Tool - Bulk Cluster Management")

    prs.save("BCM_Operation_Guide.pptx")
    print("Created: BCM_Operation_Guide.pptx")

if __name__ == "__main__":
    create_presentation()
