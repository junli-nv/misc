---
name: pptx
description: Create and edit PowerPoint presentations using python-pptx. Use when user asks to create, modify, or work with .pptx files.
---

# PowerPoint (PPTX) Skill

This skill enables creating and editing Microsoft PowerPoint presentations using the `python-pptx` library.

## Prerequisites

- `python-pptx` package: `pip install python-pptx`

## Key Operations

- Create a new presentation
- Add slides with titles and content
- Insert images, tables, and shapes
- Format text, paragraphs, and slides
- Save presentations to .pptx format

## Usage

Create Python scripts to generate PowerPoint files. Example workflow:

```python
from pptx import Presentation
from pptx.util import Inches, Pt

prs = Presentation()
slide = prs.slides.add_slide(prs.slide_layouts[1])  # Title and Content
title = slide.shapes.title
title.text = "My Title"
prs.save('output.pptx')
```

## Notes

- Always use `prs.save()` to persist changes
- Slide layouts vary (title only, title+content, blank, etc.)
- Images must be in valid image formats (PNG, JPG, etc.)
