

NUM_OF_COMPUTE_TRAY_PER_RACK=18
NUM_OF_SWITCH_TRAY_PER_RACK=9
NUM_OF_POWERSHELF_PER_RACK=8
COMPUTE_TRAY_POSITIONS = [11,12,13,14,15,17,16,18,28,29,30,31,32,33,34,35,36,37]
NVSW_TRAY_POSITIONS = [19,20,21,22,23,24,25,26,27]
POWERSHELF_POSITIONS = [6,7,8,9,39,40,41,42]

def get_compute_tray_name(rack_name, tray_index):
    return f"{rack_name}-ct{tray_index:02d}"

def get_nvswitch_tray_name(rack_name, tray_index):
    return f"{rack_name}-nvsw{tray_index:02d}"

def get_powershelf_name(rack_name, shelf_index):
    return f"{rack_name}-pwr{shelf_index:02d}"

def get_rack_compute_trays(rack_name):
    return [get_compute_tray_name(rack_name, i) for i in range(1, NUM_OF_COMPUTE_TRAY_PER_RACK + 1)]

def get_rack_nvswitch_trays(rack_name):
    return [get_nvswitch_tray_name(rack_name, i) for i in range(1, NUM_OF_SWITCH_TRAY_PER_RACK + 1)]

def get_rack_powershelfs(rack_name):
    return [get_powershelf_name(rack_name, i) for i in range(1, NUM_OF_POWERSHELF_PER_RACK + 1)]


def generate_random_mac():
    """Generate a random MAC address."""
    import random
    mac = [random.randint(0x00, 0xff) for _ in range(6)]
    return ':'.join(f'{x:02x}' for x in mac)

