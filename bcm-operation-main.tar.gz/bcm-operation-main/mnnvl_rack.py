from utils import COMPUTE_TRAY_POSITIONS, get_rack_compute_trays, NVSW_TRAY_POSITIONS, get_rack_nvswitch_trays, POWERSHELF_POSITIONS, get_rack_powershelfs
from bcm.compute_tray import ComputeTray
from bcm.nvswitch_tray import NVSwitchTray
from bcm.powershelf import Powershelf


def create_mnnvl_rack(cluster, device_spec, ip_addresses, createIfNotExists=False, category_name="default", rack_name=None):
    """
    Create NUM_OF_COMPUTE_TRAY_PER_RACK compute trays, NUM_OF_SWITCH_TRAY_PER_RACK NVSwitch trays,
    and NUM_OF_POWERSHELF_PER_RACK power shelves in the rack.

    Args:
        cluster: Cluster object
        device_spec: Dictionary containing device specifications
        ip_addresses: Dictionary mapping tray names/indices to their IP addresses
        createIfNotExists: Boolean to create the device if it doesn't exist
        category_name: Category of the device
        rack_name: Rack Name where the device is located

    Returns:
        Tuple of (List of ComputeTray instances, List of NVSwitchTray instances, List of Powershelf instances)
    """
    compute_trays = []
    nvswitch_trays = []
    powershelfs = []

    if rack_name is None:
        raise ValueError("rack_name is required")

    compute_tray_names = get_rack_compute_trays(rack_name)
    for idx, tray_name in enumerate(compute_tray_names):
        rack_position = COMPUTE_TRAY_POSITIONS[idx]

        tray_ip_addresses = ip_addresses.get(tray_name, {})
        if not tray_ip_addresses:
            print(f"⚠️  Skipping compute tray {tray_name}: no IP addresses configured")
            continue

        tray = ComputeTray(
            name=tray_name,
            cluster=cluster,
            device_spec=device_spec,
            ip_addresses=tray_ip_addresses,
            createIfNotExists=createIfNotExists,
            category_name=category_name,
            rack_name=rack_name,
            rack_position=rack_position
        )
        compute_trays.append(tray)

    nvswitch_tray_names = get_rack_nvswitch_trays(rack_name)
    for idx, tray_name in enumerate(nvswitch_tray_names):
        rack_position = NVSW_TRAY_POSITIONS[idx]

        tray_ip_addresses = ip_addresses.get(tray_name, {})
        if not tray_ip_addresses:
            print(f"⚠️  Skipping NVSwitch tray {tray_name}: no IP addresses configured")
            continue

        tray = NVSwitchTray(
            name=tray_name,
            cluster=cluster,
            device_spec=device_spec,
            ip_addresses=tray_ip_addresses,
            createIfNotExists=createIfNotExists,
            rack_name=rack_name,
            rack_position=rack_position
        )
        nvswitch_trays.append(tray)

    powershelf_names = get_rack_powershelfs(rack_name)
    for idx, shelf_name in enumerate(powershelf_names):
        rack_position = POWERSHELF_POSITIONS[idx]

        shelf_ip_addresses = ip_addresses.get(shelf_name, {})
        if not shelf_ip_addresses:
            print(f"⚠️  Skipping powershelf {shelf_name}: no IP addresses configured")
            continue

        shelf = Powershelf(
            name=shelf_name,
            cluster=cluster,
            device_spec=device_spec,
            ip_addresses=shelf_ip_addresses,
            createIfNotExists=createIfNotExists,
            rack_name=rack_name,
            rack_position=rack_position
        )
        powershelfs.append(shelf)

    return compute_trays, nvswitch_trays, powershelfs
