#!/usr/bin/python3
import argparse


def create_argument_parser():
    parser = argparse.ArgumentParser(description='BCM Operation - Subnet and Device Management')

    subparsers = parser.add_subparsers(dest='mode', help='Operation mode')
    subparsers.required = True

    dhcp_conf_parser = subparsers.add_parser('create_dhcp_conf', help='Create DHCP configuration files from IP allocation data')
    dhcp_conf_parser.add_argument('--ip_allocation_file', required=True, help='IP allocation file (format: hostname,MAC,IP,subnet)')
    dhcp_conf_parser.set_defaults(func='create_dhcp_conf')

    subnet_parser = subparsers.add_parser('create_subnet', help='Create a new subnet specification')
    subnet_parser.add_argument('--subnet_name', required=True, help='Name of the subnet')
    subnet_parser.add_argument('--network', required=True, help='Network address (e.g., 192.168.1.0)')
    subnet_parser.add_argument('--netmaskbits', required=True, type=int, help='Netmask bits (e.g., 24 for 255.255.255.0)')
    subnet_parser.add_argument('--gateway', required=True, help='Gateway address')
    subnet_parser.add_argument('--dynamic_start', help='Start of dynamic IP range (e.g., 192.168.1.100)')
    subnet_parser.add_argument('--dynamic_end', help='End of dynamic IP range (e.g., 192.168.1.200)')
    subnet_parser.add_argument('--exclude-from-search-domain', action='store_true', help='Exclude this subnet from search domain')
    subnet_parser.add_argument('--add-fs-export', action='store_true', help='Add filesystem export entries for this subnet')
    subnet_parser.set_defaults(func='create_subnet')

    device_type_parser = subparsers.add_parser('create_device_type', help='Create device specification with interface list')
    device_type_parser.add_argument('--device_type', required=True, choices=['dgx-h200', 'dgx-b200', 'dgx-b300', 'dgx-gb200', 'dgx-gb300'], help='Device type')
    device_type_parser.add_argument('--compute_node_interfaces', required=True, help='List of compute_node interfaces separated by a delimiter')
    device_type_parser.add_argument('--compute_node_bmc_interface', default="rf0", help='Compute node BMC interface')
    device_type_parser.add_argument('--provisioning_interface', required=True, help='Provisioning interface for compute node')
    device_type_parser.add_argument('--nvswitch_tray_interfaces', help='List of nvswitch_tray interfaces separated by a delimiter')
    device_type_parser.add_argument('--nvswitch_tray_bmc_interface', default="rf0", help='NVSwitch tray BMC interface')
    device_type_parser.add_argument('--powershelf_interfaces', help='List of powershelf interfaces separated by a delimiter')
    device_type_parser.add_argument('--nvl_rack', action='store_true', help='Enable NVL rack mode (requires nvswitch_tray_interfaces and powershelf_interfaces)')
    device_type_parser.add_argument('--bonding-spec', '-b', help='Bonding specification in format: bond0:eth0|eth1,bond1:eth2|eth3')
    device_type_parser.add_argument('--delimiter', default=',', help='Delimiter used to separate interfaces (default: comma)')
    device_type_parser.set_defaults(func='create_device_type')

    device_parser = subparsers.add_parser('create_device', help='Create device specification with subnet mapping')
    device_parser.add_argument('--device_name', required=True, help='Device name')
    device_parser.add_argument('--nvl_rack', action='store_true', help='Whether it is NVL rack')
    device_parser.add_argument('--compute_node_interfaces_subnets', help='List of compute_node interfaces subnets in format: interface:subnet_name,interface:subnet_name')
    device_parser.add_argument('--compute_node_management_subnet', help='Compute node management subnet')
    device_parser.add_argument('--compute_node_category', default='default', help='Compute node category (default: default)')
    device_parser.add_argument('--nvswitch_tray_interfaces_subnets', help='List of nvswitch_tray interfaces subnets in format: interface:subnet_name,interface:subnet_name')
    device_parser.add_argument('--nvswitch_management_subnet', help='NVSwitch management subnet')
    device_parser.add_argument('--powershelf_interface_subnet', help='Powershelf interface subnet in format: interface:subnet_name')
    device_parser.add_argument('--device_spec', required=True, help='Device specification')
    device_parser.add_argument('--ip_allocation_file', required=True, help='IP allocation file containing device_name: IP addresses')
    device_parser.add_argument('--delimiter', default=',', help='Delimiter used to separate subnets (default: comma)')
    device_parser.add_argument('--output', '-o', default=None, help='Output file name (default: device name + .json)')
    device_parser.set_defaults(func='create_device')

    rack_parser = subparsers.add_parser('create_rack', help='Create rack specification')
    rack_parser.add_argument('--rack_name', required=True, help='Name of the rack')
    rack_parser.set_defaults(func='create_rack')

    update_mac_parser = subparsers.add_parser('update_mac', help='Update MAC addresses for devices')
    update_mac_parser.add_argument('--device_name', required=True, help='Device name (or rack name for nvl_rack mode)')
    update_mac_parser.add_argument('--nvl_rack', action='store_true', help='Update MACs for all devices in the rack')
    update_mac_parser.add_argument('--compute_tray_interfaces_list', required=True, help='Comma-separated list of compute tray interface names')
    update_mac_parser.add_argument('--nvswitch_tray_interfaces_list', help='Comma-separated list of nvswitch tray interface names')
    update_mac_parser.add_argument('--powershelf_interfaces_list', help='Comma-separated list of powershelf interface names')
    update_mac_parser.add_argument('--mac_file', required=True, help='MAC address file (format: device_name,mac1,mac2,...)')
    update_mac_parser.set_defaults(func='update_mac')

    update_mac_rf_parser = subparsers.add_parser('update_mac_via_redfish', help='Update MAC addresses via Redfish')
    update_mac_rf_parser.add_argument('--nvl_rack', action='store_true', help='Update MACs for all compute trays in the rack')
    update_mac_rf_parser.add_argument('--device_name', required=True, help='Device name (or rack name for nvl_rack mode)')
    update_mac_rf_parser.add_argument('--bmc_user', required=True, help='BMC username')
    update_mac_rf_parser.add_argument('--bmc_pw', required=True, help='BMC password')
    update_mac_rf_parser.add_argument('--regex_config_file', required=True, help='JSON file with regex patterns for each interface (format: {"eth0":"pattern", "eth1":"pattern"})')
    update_mac_rf_parser.add_argument('--verbose', action='store_true', help='Enable verbose logging')
    update_mac_rf_parser.set_defaults(func='update_mac_via_redfish')

    create_ipmi_user_parser = subparsers.add_parser('create_ipmi_user', help='Create IPMI user via Redfish')
    create_ipmi_user_parser.add_argument('--device_name', required=True, help='Device name')
    create_ipmi_user_parser.add_argument('--current_bmc_user', required=True, help='Current BMC username')
    create_ipmi_user_parser.add_argument('--current_bmc_pw', required=True, help='Current BMC password')
    create_ipmi_user_parser.add_argument('--new_bmc_user', required=True, help='New BMC username to create')
    create_ipmi_user_parser.add_argument('--new_bmc_pw', required=True, help='New BMC password')
    create_ipmi_user_parser.add_argument('--new_bmc_user_id', required=True, type=int, help='New BMC user ID')
    create_ipmi_user_parser.add_argument('--bmc_interface', required=True, help='BMC interface name (e.g., rf0)')
    create_ipmi_user_parser.set_defaults(func='create_ipmi_user')

    swap_node_nodedef_parser = subparsers.add_parser('swap_node_nodedef', help='Swap node definitions (MAC addresses) between two devices')
    swap_node_nodedef_parser.add_argument('--device_a_name', required=True, help='Name of device A')
    swap_node_nodedef_parser.add_argument('--device_b_name', required=True, help='Name of device B')
    swap_node_nodedef_parser.set_defaults(func='swap_node_nodedef')

    set_bios_parser = subparsers.add_parser('set_bios', help='Apply BIOS settings via Redfish')
    set_bios_parser.add_argument('--device_name', required=True, help='Device name (or rack name for nvl_rack mode)')
    set_bios_parser.add_argument('--nvl_rack', action='store_true', help='Apply BIOS settings to all compute trays in the rack')
    set_bios_parser.add_argument('--bmc_user', required=True, help='BMC username')
    set_bios_parser.add_argument('--bmc_password', required=True, help='BMC password')
    set_bios_parser.add_argument('--bios_setting', required=True, help='JSON file containing BIOS settings to apply')
    set_bios_parser.add_argument('--api_interface', required=True, help='Redfish API path for BIOS settings (e.g., /redfish/v1/Systems/Self/Bios/SD)')
    set_bios_parser.set_defaults(func='set_bios')

    slurm_parser = subparsers.add_parser('slurm_post_install', help='Slurm post-install configuration for DGX images')
    slurm_parser.add_argument('--dgx_image', required=True, help='DGX image name')
    slurm_parser.add_argument('--slogin_image', required=True, help='Slogin image name')
    slurm_parser.add_argument('--cross_arch', action='store_true', help='Use cross-architecture shared path')
    slurm_parser.add_argument('--raid_mntpt', default='/raid', help='Raid mount point path')
    slurm_parser.add_argument('--nvl_rack', action='store_true', help='Create IMEX mount file for NVL rack')
    slurm_parser.set_defaults(func='slurm_post_install')

    ipmi_power_op_parser = subparsers.add_parser('ipmi_power_op', help='Reboot device to PXE')
    ipmi_power_op_parser.add_argument('--device_name', required=True, help='Device name')
    ipmi_power_op_parser.add_argument('--nvl_rack', action='store_true', help='Whether it is NVL rack')
    ipmi_power_op_parser.add_argument('--bmc_user', default='bright', help='BMC username (default: bright)')
    ipmi_power_op_parser.add_argument('--bmc_password', required=True, help='BMC password')
    ipmi_power_op_parser.add_argument('--bmc_interface', default='rf0', help='BMC interface name (default: rf0)')
    ipmi_power_op_parser.add_argument('--action', choices=['status','off', 'on', 'reset', 'cycle'], required=True, help='Action to perform: off, on, reset, or cycle')
    ipmi_power_op_parser.add_argument('--bootdev', choices=['pxe', 'bios'], default=None, help='Set boot device before power operation (pxe: chassis bootdev pxe options=persistent, bios: chassis bootdev bios)')
    ipmi_power_op_parser.set_defaults(func='ipmi_power_op')

    return parser


def main():
    from bcm_operation import (
        create_subnet, create_device_type, create_device, create_rack,
        update_mac, update_mac_via_redfish, create_ipmi_user, swap_node_nodedef,
        set_bios, create_dhcp_conf, slurm_post_install, ipmi_power_op
    )

    func_map = {
        'create_subnet': create_subnet,
        'create_device_type': create_device_type,
        'create_device': create_device,
        'create_rack': create_rack,
        'update_mac': update_mac,
        'update_mac_via_redfish': update_mac_via_redfish,
        'create_ipmi_user': create_ipmi_user,
        'swap_node_nodedef': swap_node_nodedef,
        'set_bios': set_bios,
        'create_dhcp_conf': create_dhcp_conf,
        'slurm_post_install': slurm_post_install,
        'ipmi_power_op': ipmi_power_op,
    }

    parser = create_argument_parser()
    args = parser.parse_args()
    func_name = args.func if hasattr(args, 'func') else None

    if func_name and func_name in func_map:
        func_map[func_name](args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
