#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

cm-wlm-setup
# Setup (Express)
# Slurm
# Save config & deploy

cm-wlm-setup
# Add Pyxis to Slurm cluster
# Leave Enroot settings untouched

# rm -rf /cm/shared/apps/slurm/statesave/slurm/*

#echo 'SLURMDBD_OPTIONS=-vvv' > /etc/default/slurmdbd
usermod -a -G syslog,root slurm
chmod 775 /run
sed -i.ori -e 's:Type=.*:Type=simple:g' -e 's:\(ExecStart=.*\):\1 -D:g' /lib/systemd/system/slurmdbd.service
systemctl daemon-reload
systemctl restart slurmdbd.service
systemctl status slurmdbd.service
sleep 5
systemctl restart slurmctld.service
systemctl status slurmctld.service


# Option 1: Rebuild GRES with NVML autodetect
# If you want BCM to rediscover the 4 GPUs automatically, use:
cmsh -c '
wlm;
set gpuautodetect nvml;
commit;
configurationoverlay;
use slurm-client;
roles;
use slurmclient;
set gpuautodetect nvml;
commit;
genericresources;
foreach * (remove);
commit;
add autodetected-gpus;
set name gpu;
set count 4;
set addtogresconfig yes;
commit
'
# That is the BCM-supported pattern for automatic GPU configuration; the NVIS KB shows the same flow with gpuautodetect nvml, clearing old generic resources, and adding autodetected-gpus with addtogresconfig yes. 
# After the BCM commit, re-read Slurm config:
scontrol reconfigure
# Then verify:
grep $(hostname) /cm/shared/apps/slurm/etc/slurm/slurm.conf
grep $(hostname) /cm/shared/apps/slurm/etc/slurm/gres.conf
scontrol show node $(hostname)
# You want to see:
# slurm.conf host entry with Gres=gpu:b300:4
# gres.conf entries for the node
# scontrol show node showing Gres=gpu:b300:4 and CfgTRES including gres/gpu=4,gres/gpu:b300=4
