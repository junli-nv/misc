#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

# mlxfwmanager -d mlx5_0 | grep -e PSID: -e Type: 
#  Device Type:      ConnectX8
#  PSID:             NVD0000000072
#URL: https://network.nvidia.com/support/firmware/connectx8/
#URL: https://www.mellanox.com/downloads/firmware/fw-ConnectX8-rel-40_48_1000-P6612_Ax-UEFI-14.41.14-FlexBoot-3.9.101.signed.bin.zip
export BIN=/home/cmsupport/workspace/fw/fw-ConnectX8-rel-40_48_1000-P6612_Ax-UEFI-14.41.14-FlexBoot-3.9.101.signed.bin

hcas=($(lspci -D | grep Infiniband.*ConnectX-8|awk '{print $1}'|xargs -I {} bash -c 'ls -l /sys/class/infiniband|grep -o {}/.*|cut -d"/" -f3'))

# Enable advanced PCI settings
for i in ${hcas[@]}; do
  mlxconfig -d $i -e -y set ADVANCED_PCI_SETTINGS=1
done

# Upgrade firmware
pids=()
for i in ${hcas[@]}; do
  flint -d $i -i $BIN -y b & pids+=($!)
done
wait ${pids[@]}

for i in ${hcas[@]}; do
  echo "$i $(flint -d ${i} q | grep Version|paste -s -d ' ' | tr '\t' ' ' | tr -s ' ')"
done

# Power cycle server to take effect
echo "INFO: Power Cycle Server to take effect - ipmitool power cycle"

# Check advanced PCI settings
# for i in $(lspci -D | grep Infiniband.*ConnectX-8|awk '{print $1}'|xargs -I {} bash -c 'ls -l /sys/class/infiniband|grep -o {}/.*|cut -d"/" -f3'); do mlxconfig -d $i -e q ADVANCED_PCI_SETTINGS|grep -e Device: -e ADVANCED_PCI_SETTINGS|paste -s -d ' ' | tr '\t' ' ' | tr -s ' '; done
