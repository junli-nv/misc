#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

## Download aarch64 images on X86 BCM head node
## https://catalog.ngc.nvidia.com/orgs/nvidia/-/containers/nemo/-/tags

topdir=/home/cmsupport/workspace
mkdir -p ${topdir}
cd ${topdir}

export ENROOT_TEMP_PATH=/tmp

## HPC benchmark Image
#enroot import \
# --arch aarch64 \
# --output ${topdir}/hpc-benchmarks-25.04.sqsh \
# 'docker://nvcr.io/nvidia/hpc-benchmarks:25.04'

enroot import \
 --arch aarch64 \
 --output ${topdir}/hpc-benchmarks-25.09.sqsh \
 'docker://nvcr.io/nvidia/hpc-benchmarks:25.09'

## Nemo Image
#enroot import \
# --arch aarch64 \
# --output ${topdir}/nemo-25.04.rc2.sqsh \
# 'docker://nvcr.io/nvidian/nemo:25.04.rc2'

enroot import \
  --arch aarch64 \
  --output ${topdir}/nemo-25.11.01.sqsh \
  'docker://nvcr.io/nvidia/nemo:25.11.01'

#enroot import \
#  --arch aarch64 \
#  --output ${topdir}/nemo-26.06.rc3.sqsh \
#  'docker://nvcr.io/nvidian/nemo:26.06.rc3'

enroot import \
  --arch aarch64 \
  --output ${topdir}/nemo-26.06.01.sqsh \
  'docker://nvcr.io/nvidia/nemo:26.06.01'

rm -rf $HOME/.config/enroot
rm -rf $HOME/.cache/enroot
