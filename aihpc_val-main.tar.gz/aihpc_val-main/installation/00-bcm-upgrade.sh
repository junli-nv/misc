#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

##https://nvbugspro.nvidia.com/bug/6130494
#Workaround for CVE-2026-31431 - Copy Fail
echo -e 'install algif_aead /bin/false\nblacklist algif_aead' > /etc/modprobe.d/disable-algif-aead.conf
modprobe -r algif_aead
find /lib/modules/ -iname 'algif_aead.ko*' | xargs -I{} mv {} {}.disabled
find /cm/images/ -iname 'algif_aead.ko*' | xargs -I{} mv {} {}.disabled
for i in /cm/images/*; do mkdir -p ${i}/etc/modprobe.d; echo "install algif_aead /bin/false" > ${i}/etc/modprobe.d/disable-algif-aead.conf; done

grep '^[a-z]' /etc/cm-install-release
#date:       Jul 16 2025 09:38AM +0000
#medium:     ISO
#release:    11.25.05
#installer:  baremetal

apt update
apt --yes --assume-yes --allow-unauthenticated -o Dpkg::Options::="--force-confold" upgrade
sudo apt purge -y unattended-upgrades
rm -f /var/log/apt/*
rm -rf /tmp/*

##https://nvbugspro.nvidia.com/bug/6130494
modprobe -r algif_aead esp4 esp6 rxrpc
#Workaround for CVE-2026-31431 - Copy Fail
echo -e 'install algif_aead /bin/false\nblacklist algif_aead' > /etc/modprobe.d/disable-algif-aead.conf
#Workaround for Dirty Frag
printf 'install esp4 /bin/false\ninstall esp6 /bin/false\ninstall rxrpc /bin/false\n' > /etc/modprobe.d/dirtyfrag.conf

apt install -y ipmitool nmap dos2unix sipcalc gnuplot-nox nmon cm-docker lftp pdsh clustershell

find /cm/ -name node-installer.conf | while read f; do
  sed -i.ori \
    -e 's:setupBmc.*=.*:setupBmc = false:g' \
    -e 's:failOnMissingBmc.*=.*:failOnMissingBmc = false:' \
    -e 's:strictBmcUserId.*=.*:strictBmcUserId = false:' \
    -e 's:failOnFailedBmcCommand.*=.*:failOnFailedBmcCommand = false:' \
    ${f}
done

#Higher the sshd limits for rsync
sed -i -e 's#\(SSHD_OPTS=.*\)#SSHD_OPTS="-o MaxStartups=100:30:200 -o MaxSessions=100"#g' /etc/default/ssh
systemctl restart sshd && sshd -T | egrep 'maxstartups|maxsessions'

#Add /raid to exclude list
cmsh <<- EOF
home
category
use default
append excludelistsyncinstall "\n- /raid/*"
append excludelistgrab "\n- /raid/*"
append excludelistupdate "\n- /raid/*"
append excludelistgrabnew "\n- /raid/*"
commit
EOF

mkdir -p /var/www/html/isos
cd /var/www/html/isos/
wget -c https://download.rockylinux.org/pub/rocky/10/isos/x86_64/Rocky-10.2-x86_64-minimal.iso

# Change /usr/lib/systemd/system/tftpd.service, add "--no-windowsize", like which will make pxe be stable.
sed -i.ori -e 's:\(ExecStart=.*\) /tftpboot:\1 --no-windowsize /tftpboot:g'  /usr/lib/systemd/system/tftpd.service
systemctl daemon-reload
systemctl restart tftpd.service
# systemctl status tftpd.service

cmsh <<- EOF
partition
use base
set nameservers 8.8.8.8 223.5.5.5
commit
EOF

## Set MTU to 9000 for all interfaces and configure bond0 options
# cmsh <<- EOF
# home
# network
# foreach * (set mtu 9000)
# commit
# home
# device
# foreach * (interfaces; use bond0; set options "miimon=100 lacp_rate=fast xmit_hash_policy=layer3+4")
# commit
# EOF

truncate -s 0 /etc/machine-id
truncate -s 0 /root/.bash_history

reboot

