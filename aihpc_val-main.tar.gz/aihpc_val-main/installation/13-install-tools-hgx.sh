#!/bin/bash

topdir=/home/cmsupport/workspace
cd $topdir

## Install cuda toolkits
# https://developer.nvidia.com/cuda-toolkit-archive
## CUDA 13
wget -c https://developer.download.nvidia.com/compute/cuda/13.0.3/local_installers/cuda_13.0.3_580.126.20_linux.run
bash cuda_13.0.3_580.126.20_linux.run --silent --toolkit --no-opengl-libs --no-drm --installpath=${topdir}/cuda13
ln -sf ${topdir}/cuda13 ${topdir}/cuda
cat > ${topdir}/cuda/env.sh <<- EOF
#!/bin/bash
export CUDA_HOME=${topdir}/cuda
export PATH=\${CUDA_HOME}/bin:\$PATH
export LD_LIBRARY_PATH=\${CUDA_HOME}/lib64:\${LD_LIBRARY_PATH}
EOF
chmod +x ${topdir}/cuda/env.sh

## Install HPCX
# https://developer.nvidia.com/networking/hpc-x
## CUDA 13
wget https://content.mellanox.com/hpc/hpc-x/v2.26_cuda13/hpcx-v2.26-gcc-doca_ofed-ubuntu24.04-cuda13-x86_64.tbz
tar -xjf hpcx-v2.26-gcc-doca_ofed-ubuntu24.04-cuda13-x86_64.tbz

## Install NCCL
source ${topdir}/hpcx-v2.26-gcc-doca_ofed-ubuntu24.04-cuda13-x86_64/hpcx-mt-init-ompi.sh
hpcx_load
source ${topdir}/cuda/env.sh
## Compile NCCL
git clone https://github.com/NVIDIA/nccl.git
cd nccl/
git checkout v2.28.9-1
#git checkout v2.30.3-1
make -j src.build
git clone https://github.com/NVIDIA/nccl-tests.git
cd nccl-tests
make -j MPI=1 MPI_HOME=${OMPI_HOME} NCCL_HOME=$PWD/../build
cp -arv build/ ../bins
cd ../bins/
rm -fr *.o verifiable
cp -arv ../build/lib/libnccl*so* .

## Donwload Nemo image

## Nemo Image
## https://catalog.ngc.nvidia.com/orgs/nvidia/containers/nemo/tags?version=26.04.00
enroot import \
  --arch x86_64 \
  --output ${topdir}/nemo-25.11.01.sqsh \
  'docker://nvcr.io/nvidia/nemo:25.11.01'

enroot import \
  --arch x86_64 \
  --output ${topdir}/nemo-26.04.sqsh \
  'docker://nvcr.io/nvidia/nemo:26.04'

rm -rf $HOME/.config/enroot
rm -rf $HOME/.cache/enroot
