#!/bin/bash

# https://docs.nvidia.com/dgx/dgx-os-7-user-guide/release_notes.html#latest-release

image_name=hgx-image-u2404

cmsh -c "softwareimage; clone default-image ${image_name}; commit"
cmsh -c "watch -n 3 task list"

################################################################################################

cm-chroot-sw-img /cm/images/${image_name}

## Clean up
rm -rf /var/lib/command-not-found /var/cache/swcatalog
apt purge -y command-not-found appstream update-notifier-common
dpkg -l|grep -E 'command-not-found|appstream|update-notifier-common'
## Remove nvidia driver installed in base image
apt purge $(dpkg -l|grep -e 570.[0-9] -e 580.[0-9] |awk '{print $2,$3}'|sed 's#:amd64##'|tr ' ' '=')

## Add nvidia dgx repositories
## https://docs.nvidia.com/dgx/dgx-os-7-user-guide/installing_on_ubuntu.html#installing-dgx-system-configurations-and-tools
curl https://repo.download.nvidia.com/baseos/ubuntu/noble/x86_64/dgx-repo-files.tgz | tar xzf - -C /
mv /etc/apt/sources.list.d/cm-cuda-ubuntu2404-x86_64.list /etc/apt/sources.list.d/cm-cuda-ubuntu2404-x86_64.list.disabled
mv /etc/apt/sources.list.d/doca-bos8-latest.sources /etc/apt/sources.list.d/doca-bos8-latest.sources.disabled

# Use version of https://docs.nvidia.com/networking/nvidia-quantum-x800-xdr-clusters/index.html as reference
## https://developer.nvidia.com/doca-downloads?deployment_platform=Host-Server&deployment_package=DOCA-Host&target_os=Linux&Architecture=x86_64&Profile=doca-all&Distribution=Ubuntu&version=24.04&installer_type=deb_online
cat > /etc/apt/sources.list.d/doca.sources << 'EOF'
Types: deb
# URIs: https://linux.mellanox.com/public/repo/doca/3.2.1-044413/ubuntu24.04/x86_64/
# URIs: https://linux.mellanox.com/public/repo/doca/3.3.0/ubuntu24.04/x86_64
URIs: https://linux.mellanox.com/public/repo/doca/3.4.0/ubuntu24.04/x86_64/
Suites: /
Signed-By: /usr/share/keyrings/GPG-KEY-Mellanox.gpg /usr/share/keyrings/nvidia-doca-debian-gpg-public-key.gpg
EOF
#Disable dgx packages
cat > /etc/apt/preferences.d/black.pref << 'EOF'
Package: dgx*
Pin: release *
Pin-Priority: -1
EOF

#rm -f /dev/null; mknod -m 666 /dev/null c 1 3
apt update
#some of mlx5_ib symbols depends on linux-modules-extra
kernel_version="6.8.0-106-generic"
apt-get install -y \
  linux-headers-${kernel_version} \
  linux-image-${kernel_version} \
  linux-modules-${kernel_version} \
  linux-tools-${kernel_version} \
  linux-modules-extra-${kernel_version}
dkms status

apt-mark hold linux-image-generic linux-headers-generic linux-generic \
  linux-headers-${kernel_version} linux-image-${kernel_version} linux-modules-${kernel_version} linux-tools-${kernel_version} linux-modules-extra-${kernel_version}
apt-mark showhold

apt-get install -y wget numactl ipmitool lldpd needrestart

## DGX packages: apt depends nvidia-system-core
apt install -y \
  nv-grubmenu nv-grubserial ipmitool msecli nv-common-apis nv-cpu-governor nv-env-paths nv-iommu nv-ipmi-devintf nv-limits nv-update-disable nvgpu-services-list nvidia-acs-disable nvidia-disable-init-on-alloc nvidia-disable-numa-balancing nvidia-earlycon nvidia-enable-power-meter-cap nvidia-esm-hook-epilogue nvidia-fs-loader nvidia-kernel-defaults nvidia-nvme-options nvidia-pci-bridge-power nvidia-pci-realloc nvidia-raid-config nvidia-relaxed-ordering-gpu nvidia-redfish-config nvidia-relaxed-ordering-nvme nvme-cli nvidia-repo-keys nvidia-ipmisol tpm2-tools # cuda-compute-repo hpc-sdk-repo dgx-release dgx-repo nvidia-crashdump nvidia-mig-manager

## DGX packages: apt depends nvidia-system-utils
apt install -y \
  nv-persistence-mode nvidia-container-toolkit nvidia-fs-loader nvidia-logrotate nvidia-conf-cachefilesd #nvidia-modprobe nvsm nvidia-motd
systemctl disable nvsm.service

## DGX packages: apt depends nvidia-system-extra
apt install -y \
  automake bash-completion bison build-essential chrpath cifs-utils cmake cryptsetup cryptsetup-initramfs curl docker-ce ethtool flex fping gdb gdisk git htop iperf libelf-dev libltdl-dev lsof lsscsi m4 mdadm net-tools nfs-common nv-docker-options openssh-server parted pciutils perftest pm-utils powercap-utils quota rasdaemon samba-common samba-libs sg3-utils shim-signed smartmontools sosreport ssh ssh-import-id swig sysstat udev vim vlan witalian wngerman wogerman wportuguese wspanish wswiss xserver-xorg #command-not-found

## DOCA
apt install -y doca-all
systemctl disable srp_daemon.service srptools.service
systemctl enable openibd
apt install -y mft netplan.io 
ln -sf /usr/lib/mft /usr/lib64/mft
## nvidia-peermem provided in GPU driver needs ofa_kernel-dkms
ls /usr/src/ofa_kernel-dkms/$(uname -m)/${kernel_version}/Module.symvers

## GPU Driver: !!! It's important to make sure the all the nvidia.*5 packages' version the same !!!
dpkg -l|grep 'nvidia.*5[0-9][0-9]' 
# As GPU driver packages already been installed in base image, if all the packages align each other, then no action needed.
# If not, uninstall the current ones
apt purge -y $(dpkg -l|grep 'nvidia.*5[0-9][0-9]'|awk '{print $2}')
# Then install GPU driver from nvidia repo ONLY!!! The better to set the version explicitly.
mv /etc/apt/sources.list.d/ai-workbench-desktop.sources /etc/apt/sources.list.d/ai-workbench-desktop.sources.disabled
apt update
apt-cache madison nvidia-driver-580-open | grep developer.download.nvidia.com
ver=580.173.02
target_pkgs=(
libnvidia-nscq
nvidia-fabricmanager
nvidia-driver-580-open
nvidia-dkms-580-open
nvidia-settings
libxnvctrl0
nvidia-modprobe
nvidia-kernel-source-580-open
nvidia-kernel-common-580
libnvidia-gl-580
libnvidia-extra-580
libnvidia-decode-580
libnvidia-encode-580
xserver-xorg-video-nvidia-580
libnvidia-cfg1-580
libnvidia-fbc1-580
libnvidia-common-580
nvidia-firmware-580
libnvidia-gpucomp-580
libnvidia-compute-580
nvidia-persistenced
)
pkgs=(
$(
for i in ${target_pkgs[*]}; do
  apt-cache madison $i | grep ${ver}-.*developer.download.nvidia.com
done|awk '{print $1"="$3}'
)
nvlsm
)

apt install --allow-downgrades -y ${pkgs[@]}
# Check the driver installation
dpkg -l|grep 'nvidia.*5[0-9][0-9]'

## Fix the slurm can't detect NVML issue
cd /usr/lib/x86_64-linux-gnu/
ln -sf libnvidia-ml.so.1 libnvidia-ml.so
cd /root

## If GPU driver before DOCA, the nvidia_peermem module may not work properly. This can be fixed by reinstalling the GPU driver after DOCA installation, or manually reinstalling the nvidia_peermem module via dkms.
# dkms status|grep nvidia|tr ',' ' '|awk '{print $1,$2}'|while read module_version kernel_version; do dkms remove -m $module_version -k $kernel_version; dkms install -m $module_version -k $kernel_version; done
apt install -y nvidia-peermem-loader

apt install -y \
  libnvidia-container-tools libnvidia-container1 nvidia-container-toolkit nvidia-container-toolkit-base
apt install -y \
  datacenter-gpu-manager-4-core datacenter-gpu-manager-exporter \
  datacenter-gpu-manager-4-cuda13 datacenter-gpu-manager-4-multinode-cuda13
systemctl enable nvidia-persistenced nvidia-dcgm nvidia-fabricmanager #nvidia-imex
mkdir -p /var/run/nvidia-fabricmanager
chmod 755 /var/run/nvidia-fabricmanager

## CUDA
apt install -y cuda-nvml-dev-13-0 #cuda-toolkit-13-0

## GDRCOPY #packages from dgx
apt install -y gdrdrv-dkms gdrcopy gdrcopy-tests libgdrapi

## For Lustre
cat >> /etc/sysctl.conf <<- EOF
### Recommended baseline for multi‑NIC same‑subnet RoCE
## 1) ARP behaviour
#sysctl -w net.ipv4.conf.all.arp_filter=0
#sysctl -w net.ipv4.conf.all.arp_ignore=1
#sysctl -w net.ipv4.conf.all.arp_announce=2
#sysctl -w net.ipv4.conf.all.accept_local=1
#sysctl -w net.ipv4.conf.default.arp_filter=0
#sysctl -w net.ipv4.conf.default.arp_ignore=1
#sysctl -w net.ipv4.conf.default.arp_announce=2
#sysctl -w net.ipv4.conf.default.accept_local=1
## 2) Reverse‑path filtering
#sysctl -w net.ipv4.conf.all.rp_filter=2
#sysctl -w net.ipv4.conf.default.rp_filter=2
###################################################
### Enable Magic SysRq
kernel.sysrq=1
EOF

## Enable NV Profiling for normal users
cat > /etc/modprobe.d/nvprofiling.conf <<- EOF
options nvidia NVreg_RestrictProfilingToAdminUsers=0
EOF

#Issue: With uvm_disable_hmm=N, simple CUDA failed with cudaGetDeviceCount -> 3 (initialization error)
#https://nvbugspro.nvidia.com/bug/5550341
#Disable HMM for UVM
cat > /etc/modprobe.d/uvm.conf <<- EOF
options nvidia_uvm uvm_disable_hmm=1
EOF
#Check HMM status
#cat /sys/module/nvidia_uvm/parameters/uvm_disable_hmm
#
#Disable KASLR to workaround: add "nokaslr" to the kernel boot parameters
#
#Option	        Best for	                                    Tradeoff
#Disable HMM	  Fastest, least disruptive fix on your node	  HMM stays off
#Disable KASLR	Cleaner workaround if you need HMM	          Host boot change + reboot
#
#KASLR = Kernel Address Space Layout Randomization.
#KASLR enabled → kernel address layout changes → HMM / device-memory mapping can fail on affected kernels → nvidia_uvm init breaks → CUDA init fails.

systemctl set-default multi-user.target
echo 'root:123456'|chpasswd
rm -rf /var/lib/command-not-found /var/cache/swcatalog
apt purge -y command-not-found appstream update-notifier-common
dpkg -l|grep -E 'command-not-found|appstream|update-notifier-common'

apt purge -y unattended-upgrades

sed -i.ori -e 's#next unless "$tag" ne "";#next unless defined $tag and "$tag" ne "";#g' /usr/bin/dshbak

apt install -y irqbalance; systemctl disable irqbalance.service

#Fix pyxis issue
apt update
apt download pyxis-sources
dpkg -i ./$(ls -1 pyxis-sources_*.deb)
rm -f pyxis-sources_*.deb
find /cm/local/apps/slurm -name spank.h
CFLAGS=-I/cm/local/apps/slurm/current/include /cm/local/apps/slurm/current/scripts/install-pyxis.sh
ls -l /cm/local/apps/slurm/current/lib64/slurm/spank_pyxis.so

systemctl mask rdma-ndd.service
mv /usr/lib/udev/rules.d/60-rdma-ndd.rules /usr/lib/udev/rules.d/60-rdma-ndd.rules.disabled

cat > /etc/lldpd.d/startup_lldp.conf <<- 'EOF'
configure system hostname .
configure lldp portidsubtype ifname
configure system interface pattern eth*,eno*,enp*,ens*,enP*
EOF
systemctl enable lldpd

#Workaround for CVE-2026-31431 - Copy Fail
echo -e 'install algif_aead /bin/false\nblacklist algif_aead' > /etc/modprobe.d/disable-algif-aead.conf
#Workaround for Dirty Frag
printf 'install esp4 /bin/false\ninstall esp6 /bin/false\ninstall rxrpc /bin/false\n' > /etc/modprobe.d/dirtyfrag.conf

cat > /etc/rc.local <<- 'EOF'
#!/bin/bash
export PATH=/usr/sbin:/usr/bin:/sbin:/bin:/usr/local/sbin:/usr/local/bin:$PATH

##https://nvbugspro.nvidia.com/bug/6130494
modprobe -r algif_aead
find /lib/modules/$(uname -r) -iname 'algif_aead.ko*' -delete || true
rmmod esp4 esp6 rxrpc 2>/dev/null; # echo 3 > /proc/sys/vm/drop_caches

nics=($(lspci -D | grep -i eth|awk '{print $1}'|while read i; do basename $(ls -l /sys/class/net/|grep -o ${i}/.*); done))
for i in ${nics[*]}; do ip link set ${i} up; done
lldpcli configure system hostname .
lldpcli configure lldp portidsubtype ifname
lldpcli configure system interface pattern eth*,eno*,enp*,ens*,enP*
# lldpcli show running-configuration
lldpcli update
# lldpcli show neighbors

start_rdma-ndd(){
  while : ; do
    if [[ $(lsmod | grep mlx5_ib | wc -l) -ne 0 && $(grep -r HCA- /sys/class/infiniband/*/node_desc|wc -l) -ne 0 ]]; then
      break
    else
      sleep 10
    fi
  done
  pkill -9 rdma-ndd &>/dev/null
  sleep 10
  export RDMA_NDD_ND_FORMAT="%h %d"
  nohup /usr/sbin/rdma-ndd  -f --debug &
}
export -f start_rdma-ndd
nohup bash -c "start_rdma-ndd" &>/tmp/rdma-ndd.txt &

#ipmitool raw 0x3c 0x74 100 &>/dev/null

#echo performance > /sys/module/pcie_aspm/parameters/policy

## Set the Mellanox/NVIDIA HCAs' MaxReadReq to 4K
lspci -d 15b3: -nn|awk '{print $1}'|awk '{print $1}'|xargs -I {} setpci -v -s {} cap_exp+8.w=5000:7000
#lspci -d 15b3: -nn|awk '{print $1}'|xargs -I {} lspci -s {} -vvv|grep -o MaxReadReq.*|sort|uniq -c

## Enable SysRq key
sysctl -w kernel.sysrq=1
echo 8 > /proc/sysrq-trigger
## Trigger sysrq via SOL over IPMI:
# 1. Press Enter+~B+8 to set log level to debug if sysrq-trigger not been set
# 2. Press Enter+~B+m to dump memory information
# 3. Press Enter+~B+0 to set log level back to previous level
## Trigger sysrq via SOL over SSH:
# Replace break signal generated with Enter+~~B, then follow the same steps as above.

## Set the IRQ affinity for Mellanox/NVIDIA HCAs to the local CPU cores
systemctl stop irqbalance &>/dev/null; systemctl disable irqbalance &>/dev/null
lspci -D|grep -e Infiniband.*ConnectX-8 -e Ethernet.*Mellanox|awk '{print $1}'|xargs -I {} bash -c 'ls -l /sys/class/net|grep -o {}/.*'|cut -f3 -d'/'|while read i; do
  set_irq_affinity_cpulist.sh $(</sys/class/net/${i}/device/local_cpulist) $i &>/dev/null
done
lspci -D|grep -e Infiniband.*ConnectX-8 -e Ethernet.*Mellanox|awk '{print $1}'|xargs -I {} bash -c 'ls -l /sys/class/net|grep -o {}/.*'|cut -f3 -d'/'|while read i; do
  echo "${i}: $(show_irq_affinity.sh $i show_cpu_number | awk -F'cpu #' '{print $2}' | awk -F')' '{print $1}'|paste -s -d',' -)"
done

## Set the NVMe Interrupt Coalescing
for i in $(ls /sys/class/nvme/|sort); do
 echo $i,$(nvme set-feature /dev/${i} -f 8 --value 0x00000107) 
done

## CPU tunning
cpupower -c all frequency-set -g performance &>/dev/null
x86_energy_perf_policy performance &>/dev/null
sudo sysctl -w kernel.perf_event_paranoid=2 &>/dev/null ## for nsight
cpupower -c all idle-set -D 5 &>/dev/null # Enable Poll/C0/C1/C1E by default
# cpupower monitor | tail -n +7 | awk -F '|' '($11>=4000){print $1,$2,$3,$11}' #PCT

exit 0
EOF
chmod 755 /etc/rc.local

## Workaround for /usr and /etc permission changed during image creation
#chown -R root:root /usr/ /etc/

apt-mark unhold linux-image-generic linux-headers-generic linux-generic \
  linux-headers-${kernel_version} linux-image-${kernel_version} linux-modules-${kernel_version} linux-tools-${kernel_version} linux-modules-extra-${kernel_version}

## Workaround for massive nodes otherwise meet prolog issue often
## By default, CMD will
## ln -sf /cm/local/apps/cmd/scripts/wlm-pre-job-validation /cm/local/apps/slurm/var/prologs/01-wlm-pre-job-validation
## And save pre/post logs in /cm/local/apps/slurm/var/pre-post-job-logs/
mv /cm/local/apps/cmd/scripts/wlm-pre-job-validation /cm/local/apps/cmd/scripts/wlm-pre-job-validation.disabled
echo -e '#!/bin/bash\nexit 0' > /cm/local/apps/cmd/scripts/wlm-pre-job-validation
chmod 755 /cm/local/apps/cmd/scripts/wlm-pre-job-validation

#Higher the sshd limits for rsync
cat > /etc/ssh/sshd_config.d/90-rsync.conf <<- EOF
MaxStartups 100:30:200
MaxSessions 100
EOF
#systemctl reload sshd && sshd -T | egrep 'maxstartups|maxsessions'

systemctl disable cachefilesd
rm -f /var/log/apt/*
rm -rf /tmp/*
truncate -s 0 /etc/machine-id
truncate -s 0 /root/.bash_history
history -c
exit 0

# umount /cm/images/${image_name}/sys/firmware/efi/efivars 
# umount /cm/images/${image_name}/sys

################################# Image Change
apt install -y bcm-post-install

image_name=hgx-image-u2404

cm-chroot-sw-img /cm/images/${image_name} <<- '__END__'
ln -sf /cm/shared/apps/slurm/var/cm/prolog-enroot.sh /cm/local/apps/slurm/var/prologs/50-prolog-enroot.sh
ln -sf /cm/shared/apps/slurm/var/cm/epilog-enroot.sh /cm/local/apps/slurm/var/epilogs/50-epilog-enroot.sh
__END__

#Load Slurm module at login
echo "module load -s slurm" > /cm/images/${image_name}/etc/profile.d/zz-slurm-module.sh

#Add enroot directories in DGX image
mkdir -p  /cm/images/${image_name}/raid/local/containers/{enroot-runtime,enroot-cache,enroot-data}
chmod 777 /cm/images/${image_name}/raid/local/containers/{enroot-runtime,enroot-cache,enroot-data}

#Enroot PyTorch hook
cp /cm/local/apps/bcm-post-install/etc/slurm_pytorch_hook /cm/images/${image_name}/etc/enroot/hooks.d/50-slurm-pytorch.sh
chmod 755 /cm/images/${image_name}/etc/enroot/hooks.d/50-slurm-pytorch.sh

#Slurm PMIX profile
cp /cm/local/apps/bcm-post-install/etc/slurm_pmix /cm/images/${image_name}/etc/profile.d/pmix.sh
chmod 755 /cm/images/${image_name}/etc/profile.d/pmix.sh

#Enroot MLNX profile. 
cp /cm/local/apps/bcm-post-install/etc/enroot_mlnx_env /cm/images/${image_name}/etc/enroot/environ.d/20-mlx.env
chmod 755 /cm/images/${image_name}/etc/enroot/environ.d/20-mlx.env
sed -i \
  -e 's:^MELLANOX_VISIBLE_DEVICES=.*:MELLANOX_VISIBLE_DEVICES=all:g' \
  -e 's:\(^OMPI_MCA_btl_tcp_if_include=.*\):#\1:g' \
  /cm/images/${image_name}/etc/enroot/environ.d/20-mlx.env

#Slurmd config
cat > /cm/images/${image_name}/etc/sysconfig/slurmd << EOF
PMIX_MCA_ptl=^usock
PMIX_MCA_psec=none
PMIX_SYSTEM_TMPDIR=/var/empty
PMIX_MCA_gds=hash
EOF

cat > /cm/images/${image_name}/etc/sudoers.d/cmsupport << EOF
# Allow members of group cmsupport to execute any command
#%cmsupport ALL=(ALL:ALL) ALL
%cmsupport ALL=NOPASSWD: ALL
EOF

sed -i.ori -e "s:131072:$[1024*1024]:g" /cm/images/${image_name}/etc/security/limits.d/91-cm-limits.conf
sed -i.ori -e "s:131072:$[1024*1024*1024]:g" /cm/images/${image_name}/etc/sysctl.d/90-cm-sysctl.conf

image_name=hgx-image-u2404
#kvers=($(ls -1 /cm/images/${image_name}/lib/modules|sort -n))
kvers=6.8.0-106-generic

#Make sure don't add ast.modeset=0 otherwise nodeinstaller can't output to tty0 
#SuperMicro: ttyS1, other vendors: ttyS0
#Latency favor: intel_idle.max_cstate=0 processor.max_cstate=0 intel_pstate=disable
#MoE LLM favor: use intel_pstate driver + intel_idle.max_cstate=9 + echo 0 | sudo tee /sys/devices/system/cpu/cpu*/cpuidle/state3/disable
#Disable CPU enter deep sleep: intel_idle.max_cstate=0 processor.max_cstate=0
#Enable CPU enter deep sleep: remove the max_cstate or intel_idle.max_cstate=9
cmsh <<- __END__
softwareimage
use ${image_name}
set kernelversion ${kvers[0]}
set kernelparameters "rd.driver.blacklist=nouveau nouveau.modeset=0 namespace.unpriv_enable=1 user_namespace.enable=1 systemd.unified_cgroup_hierarchy=1 systemd.legacy_systemd_cgroup_controller=0 cgroup_no_v1=all nvme_core.multipath=n pci=realloc=off earlyprintk=serial,ttyS1,115200,keep numa_balancing=disable transparent_hugepage=madvise intremap=no_x2apic_optout pciehp.pciehp_debug=y intel_iommu=on iommu=pt intel_idle.max_cstate=9 nohz=on"
set enablesol yes
set solport ttyS1
set solflowcontrol no
set kerneloutputconsole ttyS1,115200n8r
commit
kernelmodules
add bonding; add ib_umad; add mlx5_core; add raid0; add raid1
commit
__END__

cmsh -c 'watch task list'

## Check the initrd and vmlinuz used for tftp
ls -l /cm/images/${image_name}/{initrd.img,vmlinuz}  /tftpboot/images/${image_name}/

## Cleanup mounts
umount /cm/images/${image_name}/{/run/systemd/resolve/resolv.conf,/dev/pts,/dev,/proc,/sys/firmware/efi/efivars,/sys,/run}

## Example of how to fix the mlx5 naming issue(Optional): 
image_name=hgx-image-u2404
cm-chroot-sw-img /cm/images/${image_name}/ <<-'__END__'
mv /lib/udev/rules.d/60-rdma-persistent-naming.rules /lib/udev/rules.d/60-rdma-persistent-naming.rules.disabled &>/dev/null || true
declare -A mlx5_dev_map
mlx5_dev_map=(
[0000:0d:00.0]=mlx5_0  #CX8
[0000:35:00.0]=mlx5_1  #CX8
[0000:5b:00.0]=mlx5_2  #CX8
[0000:6e:00.0]=mlx5_3  #CX8
[0000:8d:00.0]=mlx5_4  #CX8
[0000:a3:00.0]=mlx5_5  #CX7 for NVSwitch
[0000:a3:00.1]=mlx5_6  #CX7 for NVSwitch
[0000:a3:00.2]=mlx5_7  #CX7 for NVSwitch
[0000:a3:00.3]=mlx5_8  #CX7 for NVSwitch
[0000:b6:00.0]=mlx5_9  #CX8
[0000:da:00.0]=mlx5_10 #CX8
[0000:ec:00.0]=mlx5_11 #CX8
[0000:48:00.0]=mlx5_12 #CX6
[0000:48:00.1]=mlx5_13 #CX6
[0000:c8:00.0]=mlx5_14 #CX6
[0000:c8:00.1]=mlx5_15 #CX6
)
for i in ${!mlx5_dev_map[@]}; do
  cat <<- EOF
ACTION=="add", KERNELS=="$i", SUBSYSTEM=="infiniband", PROGRAM="rdma_rename %k NAME_FIXED ${mlx5_dev_map[$i]}"
EOF
done | sort | tee /etc/udev/rules.d/60-rdma-persistent-naming.rules
chmod 644 /etc/udev/rules.d/60-rdma-persistent-naming.rules
exit
__END__