#!/bin/bash

## Recommended baseline for multi‑NIC same‑subnet RoCE
# 1) ARP behaviour
sysctl -w net.ipv4.conf.all.arp_filter=0
sysctl -w net.ipv4.conf.all.arp_ignore=1
sysctl -w net.ipv4.conf.all.arp_announce=2
sysctl -w net.ipv4.conf.all.accept_local=1
sysctl -w net.ipv4.conf.default.arp_filter=0
sysctl -w net.ipv4.conf.default.arp_ignore=1
sysctl -w net.ipv4.conf.default.arp_announce=2
sysctl -w net.ipv4.conf.default.accept_local=1
# 2) Reverse‑path filtering
sysctl -w net.ipv4.conf.all.rp_filter=2
sysctl -w net.ipv4.conf.default.rp_filter=2

## net.ipv4.conf.*.arp_ignore decides when the host will answer ARP requests for its local IPs on a given interface. 
#  0 (default) – reply for any local IP, on any interface.
#  1 – reply only if the target IP is configured on the incoming interface. This is the main knob that prevents ARP flux (wrong NIC answering for another NIC’s IP) when you have multiple fabric interfaces in the same subnet.
#  2 – like 1, but also requires that sender/target be in same subnet on that interface.
#
## net.ipv4.conf.*.arp_announce controls which source IP the host uses in ARP requests / replies sent out an interface.
#  0 (default) – may use any local IP as the ARP sender address.
#  1 – avoid using IPs that are not in the target subnet.
#  2 – be strict: always use the “best” local IP for that interface (i.e., an IP actually configured on that NIC). Remote peers’ ARP caches then map IP → MAC of the correct rail, so RDMA/TCP sessions to that IP always go to the right NIC.
#
## net.ipv4.conf.*.arp_filter further refines which interface is allowed to respond to ARP, based on routing decisions. 
#  0 (your setting) – do not tie ARP replies to the FIB’s “best route”; any interface may reply (subject to arp_ignore).
#  1 – only respond on the interface that the routing table would use to reach the sender.
#
## net.ipv4.conf.*.accept_local decides whether to accept packets whose source IP is local to the host (loopback‑style or health‑check traffic).
#  1 - Allows packets that appear to come “from myself” over the fabric (e.g., Lustre or other self‑health checks using local addresses) to be accepted rather than dropped as spoofed.
#
## net.ipv4.conf.*.rp_filter is the reverse‑path filter: it checks whether the source IP of an incoming packet is reachable according to the routing table.
#  0 – disabled.
#  1 – strict: incoming packet must arrive on the interface that the kernel’s “best reverse path” uses, or it is dropped.
#  2 – loose: drop only if the source is unreachable via any interface.
#  With multi‑NIC + policy routing, strict mode (1) will often drop legitimate packets because the “best” reverse path in the main table doesn’t match your source‑based policy tables.
#  Loose mode (2) keeps anti‑spoofing (drop sources that aren’t routable anywhere) but allows asymmetric/policy‑based paths, which is what we want for multi‑rail fabrics.
#
# net.ipv4.conf.all.* – affects all existing interfaces (subject to some precedence rules).
# net.ipv4.conf.default.* – template for future interfaces (applied at interface creation).
# By setting both:
# All current NICs (including the fabric NICs) get these values.
# Any new NIC or IPoIB device that appears later inherits the same behavior automatically.
# In some designs we also add per‑interface overrides (e.g. net.ipv4.conf.ibp41s0f0.*) for the fabric rails, but your global settings are aligned with the tested DGX / Lustre / RoCE recommendations.

## ！！！！！！！ Do not rely on arp_filter to enforce per‑interface ARP; instead rely on:  ！！！！！！！
# arp_ignore=1 to make only the owning NIC reply, and
# policy routing (ip rule/ip route) to pick the correct egress NIC.
# This is exactly what NVIDIA’s RoCE / multi‑rail guidance recommends: arp_filter=0 plus arp_ignore=1 + arp_announce=2 + source‑based routing.

### Policy route:
#
# Policy‑based (source‑based) rules are needed because Linux’s normal routing logic can’t, by itself, keep “one IP → one interface” when you have multiple interfaces on the same subnet (your compute fabric case).
#
# Concretely:
# 
# Default routing only looks at destination, not source.
# With multiple 10.129.129.x addresses on different NICs in the same /17, the kernel’s main table has several equal‑cost routes to the same subnet. It will pick one “best” interface for egress (often the first), regardless of which source # IP the application uses. 
# 
# That breaks symmetry and RDMA.
# A packet may leave on NIC A with source IP of NIC B. Return traffic can arrive on the “wrong” NIC, fail rp_filter checks, or confuse ARP/ND and RDMA connection setup (ARP Flux). You can see this described for RoCE / IPoIB multi‑rail # hosts: you need source‑based routing + sysctls together to avoid wrong interface selection. 
# 
# Sysctls fix ARP behavior, not route choice.
# arp_ignore/arp_announce/arp_filter/rp_filter/accept_local control when and how the host answers ARP and accepts packets, but they do not force packets with source 10.129.129.140 to always go out via the NIC that owns 10.129.129.140. 
# 
# Policy rules tie each source IP to its own table/NIC.
# Rules like ip rule add from 10.129.129.140 table 200 plus ip route add 10.129.128.0/17 dev ethX src 10.129.129.140 table 200 mean:
# 
# Any packet whose source is 10.129.129.140 uses table 200,
# Table 200 has a route that forces it out ethX with src 10.129.129.140.
# That guarantees per‑IP, per‑interface consistency and is the recommended pattern for multi‑rail DGX / IPoIB / RoCE / Lustre configurations. 
# So, the policy rules are needed to pin traffic from each fabric IP to its correct NIC and route, while the ARP/rp_filter sysctls ensure ARP replies and ingress checking are consistent with that routing.
# Example:
#  ip rule add from 10.129.129.X table N
#  ip route add 10.129.128.0/17 dev <iface> src 10.129.129.X table N
# ensure that any packet with source IP X uses interface X’s routing table, so the IP used at ARP time, the NIC that answers ARP, and the NIC that actually forwards packets are all consistent. This combination is what avoids ARP flux and routing asymmetry in multi‑interface, single‑subnet fabrics. 
#
# root@rtx-3sf-04-12:~# ip rule list
# 0:      from all lookup local
# 32763:  from 10.129.129.142 lookup 202
# 32764:  from 10.129.129.141 lookup 201
# 32765:  from 10.129.129.140 lookup 200
# 32766:  from all lookup main
# 32767:  from all lookup default
# root@rtx-3sf-04-12:~# ip route show table 202
# 10.129.128.0/17 dev ens5008f0np0 scope link src 10.129.129.142
# root@rtx-3sf-04-12:~# ip route show table 201
# 10.129.128.0/17 dev ens4013f0np0 scope link src 10.129.129.141
# root@rtx-3sf-04-12:~# ip route show table 200
# 10.129.128.0/17 dev ens2005f0np0 scope link src 10.129.129.140
# root@rtx-3sf-04-12:~# ip r sh
# default via 10.129.0.1 dev bond0 onlink
# 10.129.0.0/17 dev bond0 proto kernel scope link src 10.129.0.107
# 10.129.128.0/17 dev ens1006f0np0 proto kernel scope link src 10.129.129.139
# 10.129.128.0/17 dev ens2005f0np0 proto kernel scope link src 10.129.129.140
# 10.129.128.0/17 dev ens4013f0np0 proto kernel scope link src 10.129.129.141
# 10.129.128.0/17 dev ens5008f0np0 proto kernel scope link src 10.129.129.142

cat > setup_routing_tables.sh <<- 'EOF'
#!/bin/bash
# Simple policy-based routing setup for 10.129.129.x fabric

set -euo pipefail

NETWORK="10.129.128.0/17"
BASE_TABLE=200   # 10.129.129.140 -> 200, 141 -> 201, etc.

# Return 0 if rule "from <src> lookup <table>" exists
rule_exists() {
    local src_ip=$1
    local table=$2
    ip rule list | grep -q "from ${src_ip} lookup ${table}"
}

# Return 0 if route "<NETWORK> dev <iface> src <src> table <table>" exists
route_exists() {
    local network=$1
    local iface=$2
    local src_ip=$3
    local table=$4
    ip route show table "$table" | grep -q "^${network} dev ${iface} .* src ${src_ip}"
}

setup_interface_routing() {
    local iface=$1
    local ip_addr=$2
    local table_num=$3

    # Add rule if missing
    if ! rule_exists "$ip_addr" "$table_num"; then
        ip rule add from "$ip_addr" table "$table_num"
    fi

    # Add route if missing
    if ! route_exists "$NETWORK" "$iface" "$ip_addr" "$table_num"; then
        ip route add "$NETWORK" dev "$iface" src "$ip_addr" table "$table_num"
    fi
}

main() {
    if [ "$(id -u)" -ne 0 ]; then
        echo "ERROR: must be run as root" >&2
        exit 1
    fi

    # Give network some time to come up
    sleep 5

    # Find all 10.129.129.x IPv4 addresses
    # Produces lines: "<iface> <ip/prefix>"
    while read -r iface cidr; do
        ip_addr=${cidr%%/*}
        [ -z "$iface" ] || [ -z "$ip_addr" ] && continue

        last_octet=$(echo "$ip_addr" | awk -F'.' '{print $4}')
        table_num=$((BASE_TABLE + last_octet - 140))

        # Only use tables 200–252
        if [ "$table_num" -ge 200 ] && [ "$table_num" -le 252 ]; then
            setup_interface_routing "$iface" "$ip_addr" "$table_num"
        fi
    done < <(ip -4 addr show | grep -E "inet 10\.129\.129\." | awk '{print $NF, $2}')

    # Optional: show current policy rules in the 200–299 range
    ip rule list | grep -E "lookup 2[0-9]{2}" || true
}

main "$@"
EOF


# If you move to:
# Each fabric NIC on a /31 P2P,
# Different subnet on each NIC,
# then:
# Each IP is naturally bound to one interface by the subnet,
# ARP flux cannot occur (no two NICs share a subnet),
# Standard routing (single main table) is usually enough, and you can use default ARP settings.
#
# But you can keep both the ARP sysctls and the policy‑based routing even if you move to /31 per NIC; they’re not inherently incompatible. The effect just changes:
# ARP / rp_filter sysctls
# These are generally safe and commonly used even when each NIC has its own subnet:
# arp_ignore=1, arp_announce=2 – still valid; they just won’t be “fixing” ARP flux anymore because the /31 layout already prevents it.
# arp_filter=0 – fine; routing isn’t ambiguous with /31s.
# rp_filter=2 – still reasonable for fabrics where asymmetric paths or policy rules may exist.
# accept_local=1 – OK if you still want self‑health checks or local‑source traffic to be accepted; otherwise you could turn it off, but it won’t hurt.
# So: you can safely leave the ARP/rp_filter settings in place with /31s.
#
# With per‑NIC /31 subnets, the main routing table alone can already distinguish which NIC to use, because each subnet is unique. Your ip rule from X table N + ip route ... table N will still work, but they’re now mostly redundant: they re‑encode information that the main table already knows. So functionally: yes, you can keep the rules and script, but in a clean /31‑per‑NIC design they aren’t required for correctness, only for very explicit per‑source control. Many people would simplify and rely on standard routing in that case.

# Policy (source‑based) routing is what makes Linux use the “right NIC for a given source IP” when destination‑based routing alone is ambiguous. In multi‑NIC, single‑subnet fabrics (like your compute fabric case), that’s critical.
#
# 1. How Linux normally routes (without policy rules)
# By default Linux:
#   Ignores the source IP for route lookup.
#   Looks at the destination IP in the main table: ip route show
#   Chooses the “best” route (longest prefix, lowest metric; if equal, usually first entry).
# In your kind of setup, you might have:
#   # main table
#   10.129.128.0/17 dev ib0  proto kernel  scope link  src 10.129.129.140
#   10.129.128.0/17 dev ib1  proto kernel  scope link  src 10.129.129.141
# Both interfaces are in the same /17 subnet. When you send to 10.129.129.200, the kernel:
#   Sees two equal routes.
#   Picks one (often the first – say ib0), regardless of whether the packet’s source is 10.129.129.140 or 10.129.129.141.
# So even if an app binds to 10.129.129.141, the packet might go out ib0 if the main table says so. That’s the root of the problem.
#
# 2. Why this breaks multi‑rail / RDMA / RoCE
# On a multi‑rail host with multiple IPs on the same subnet:
#   ARP fixes (arp_ignore/arp_announce) make sure each IP maps to the correct MAC/NIC in ARP.
#   But routing might still send traffic for that IP out the wrong interface.
# Typical failure modes documented in NVIDIA RoCE and IPoIB guidance:
#   Application opens a connection using “rail 1” IP, but Linux sends the TCP/RDMA handshake on rail 0 because the main table chooses that interface.
#   Remote side learns a consistent ARP mapping, but the return traffic and forward traffic don’t use the same rail, which can:
#      Fail RDMA CM validations (wrong path / GID / interface).
#      Trip rp_filter if strict mode were used.
#      Make ping/ssh “sometimes work, sometimes not” depending on which IP/rail pair is involved.
# NVIDIA’s RoCE / multi‑NIC article is explicit: ARP tuning alone is not enough; you also need source‑based routing.
#
# 3. What policy routing actually does
# Policy routing = multiple routing tables + rules that say which table to use for which traffic.
# You:
# Create per‑interface (or per‑IP) tables:
#   # /etc/iproute2/rt_tables
#   200 ib0
#   201 ib1
# Populate each table with a route that pins that IP to its NIC:
#   ip route add 10.129.128.0/17 dev ib0 src 10.129.129.140 table 200
#   ip route add 10.129.128.0/17 dev ib1 src 10.129.129.141 table 201
# Add rules that select tables based on source IP:
#   ip rule add from 10.129.129.140 table 200
#   ip rule add from 10.129.129.141 table 201
# Now Linux routing logic becomes:
#  “If packet source is 10.129.129.140 → use table 200 → always send via ib0.”
#  “If packet source is 10.129.129.141 → use table 201 → always send via ib1.”
# Destination is still considered inside each table, but source decides which table.
# This is exactly the pattern NVIDIA uses in DGX multi‑rail storage and RoCE documents: per‑interface tables + ip rule from <source IP> table <N>.
#
# 4. Why it matters even if ARP is tuned
# With your sysctls:
#   arp_ignore=1 → only the NIC that owns an IP replies to ARP on that NIC.
#   arp_announce=2 → ARP requests from a NIC use that NIC’s IP.
#   rp_filter=2 → loose mode, doesn’t block asymmetric but invalid paths.
# These solve:
#   “Which NIC answers ARP for IP X?”
#   “What IP do I put in my ARP packets?”
#   “Do I drop packets whose source is unroutable anywhere?”
# They do not solve:
#  “When sending from IP X, which NIC do I actually transmit on?”
# Without policy routing, Linux might still:
#  Send packets with source 10.129.129.141 out ib0, if ib0 happens to be the preferred route in the main table.
#  That breaks the assumption that “IP X ↔ NIC X” for traffic flows, even if ARP looks clean.
# NVIDIA’s internal/external docs emphasize this exact point: to really fix ARP flux and RoCE issues in multi‑NIC same‑subnet hosts, you need both:
#  Correct ARP / rp_filter sysctls, and
#  Source‑based (policy) routing per interface or per IP.
#
# 5. Benefits specific to your compute fabric
# For a compute / storage fabric like yours, policy routing gives you:
#   Deterministic rail selection
#     Each fabric IP is hard‑bound to “its” NIC.
#     ip route get <dst> from <src> will always show the same interface, which is critical for debugging and for RDMA CM.
#   Symmetric paths
#     Combined with ARP settings, the same rail is used in both directions.
#     Reduces odd cases where requests and replies cross rails and confuse applications or load balancers.
# Better resiliency semantics
#     If rail A fails, only the IPs / tables for that rail are affected.
#     You can fail over by changing specific routes or rules instead of reshaping a big ambiguous main table.
# Cleaner interaction with rp_filter
#     With rp_filter=2, as you’re using, valid fabric traffic from any rail is accepted as long as it’s reachable somewhere.
#     Source‑based routing ensures that reverse lookups also see a consistent path, minimizing edge cases where return packets look “spoofed”.
#
# 6. When you don’t strictly need policy routing
# As you already reasoned:
#   If each NIC is on its own subnet (for example, dedicated /31 per link), then the main table has distinct prefixes per NIC, and there’s no ambiguity.
#   In that clean design, policy routing becomes optional; it adds clarity but not correctness.
# But in multi‑NIC, single‑subnet fabrics (the original design you showed), policy routing is the piece that makes Linux obey the intended “one source IP → one interface” invariant. That’s why NVIDIA’s DGX / RoCE / multi‑rail docs call out source‑based (policy) routing + ARP tuning together as the recommended solution.
