#!/bin/bash
## Author: Junli Zhang<junliz@nvidia.com>

###### 01: Start LLDP on Hosts and make sure the SPX switch can discover the host interfaces
NODELIST=br-chl2-b300-tlv1-[01-32]
pdsh -R ssh -w $NODELIST <<- 'EOF'
for i in $(lspci -D | grep -i eth|awk '{print $1}'|while read i; do basename $(ls -l /sys/class/net/|grep -o ${i}/.*); done); do ip link set ${i} up; done
#lldpcli configure system hostname .
lldpcli configure system hostname "$(hostname -f)"
lldpcli configure lldp portidsubtype ifname
lldpcli configure system interface pattern eth*,eno*,enp*,ens*,enP*
lldpcli update
EOF

###### 02: Query SPX switch information
export ibswitch_os_user='cumulus'
export ibswitch_os_pass='newNet0ps!'
# SPX spine: 10.1.0.{151..182}
# SPX leaf: 10.1.0.{183..222}
for ibswitch_ip in 10.1.0.{183..222}; do
sshpass -p ${ibswitch_os_pass} \
  /usr/bin/ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=quiet -o CheckHostIP=no \
  ${ibswitch_os_user}@${ibswitch_ip} nv show interface | grep -e .cm.cluster
done | tee /home/cmsupport/workspace/node-nic-gw-mapping.txt

###### 03: Make netplan config for Hosts
#
## Using the mapping to configure host SPX network
# /home/cmsupport/workspace/node-nic-gw-mapping.txt
# swp1s0 up up 400G 9216 swp br-chl2-b300-tlv1-01.cm.cluster eth_p0_r0 IPv4 Address: 172.16.0.0/31
#
# IP allocation for IB switch and hosts: 
# Table: https://docs.google.com/spreadsheets/d/1QL1e1bFatby4TeIYi8OkHtpQx5k709M-/edit?gid=836964054#gid=836964054
#       Node Name	      Interface Name	  IP	           Peer IP
# br-chl2-b300-tlv1-01	C1/1	          172.16.0.1/31	   172.16.0.0/31	
## E.g: route for the 1st rail
# sipcalc 172.16.0.0/21
# Network range - 172.16.0.0 - 172.16.7.255 => can cover 172.16.0.1 ~ 172.16.4.63 in the table <= route1: cover the same 1st rail
# sipcalc 172.16.0.0/13
# Network range	- 172.16.0.0 - 172.23.255.255 => can cover 172.16.0.1 ~ 172.21.196.63 in the table <= route2: cover all the 8 rails
#
# In boostrun case, they chose 
# 172.16.0.0/18(172.16.0.0 - 172.16.63.255): cover only the 1st port of the 1st rail.
# 172.16.0.0/14(172.16.0.0 - 172.19.255.255): cover all the 8 ports of the first 4 rails.

cat <<- '__END__' > /home/cmsupport/workspace/spx-ip-config.sh
#!/bin/bash
cat > /etc/netplan/01-netcfg.yaml <<- 'EOF'
network:
  version: 2
  renderer: networkd
  ethernets:
EOF
#
while read node iface gw; do 
  ip="$(echo ${gw%%/31}|awk '{split($0,a,"."); print a[1]"."a[2]"."a[3]"."a[4]+1;}')/31"
  gateway=${gw%%/31}
  net0="$(echo $ip|cut -d'.' -f1-3).0/21"
  net1="$(echo $ip|cut -d'.' -f1-2).0.0/13"
  hostname=${node/tl1/tlv1}
  if [ $(hostname) == ${hostname%%.cm.cluster} ]; then
    #echo $node x $iface x $ip x $gw x $net0 x $net1 x
    ip addr flush dev ${iface}
    ip route flush dev ${iface}
    cat >> /etc/netplan/01-netcfg.yaml <<- EOF
   ${iface}:
     ignore-carrier: true
     addresses: [${ip}]
     routes:
     - to: ${net0}
       via: ${gateway}
     - to: ${net1}
       via: ${gateway}
     mtu: 9216
EOF
  fi
done < <(cat /home/cmsupport/workspace/node-nic-gw-mapping.txt|awk '{print $7,$8,$NF}'|sort)
# cat /etc/netplan/01-netcfg.yaml
chmod 700 /etc/netplan/01-netcfg.yaml
systemctl unmask systemd-networkd
systemctl restart systemd-networkd
netplan apply
__END__

###### 04: Apply the netplan config on hosts
pdsh -R ssh -w br-chl2-b300-tlv1-[01-32] <<- 'EOF'
nohup bash /home/cmsupport/workspace/spx-ip-config.sh 2>&1 &
EOF
