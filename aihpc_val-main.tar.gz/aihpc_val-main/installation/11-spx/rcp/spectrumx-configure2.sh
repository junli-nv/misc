#!/usr/bin/env  -S  bash -xuo pipefail

# SPDX-FileCopyrightText: Copyright (c) 2023-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.

killall -s SIGINT doca_spcx_cc

set -e

source /etc/rcp/rcp-cx8.conf

CC_CONF_FILE="/etc/rcp/cc_params.conf"


IFS=', ' read -r -a INTERFACES_LIST <<< "$INTERFACES"

MELLANOX=0x15b3
MAX_RETRIES_FOR_LINKUP=25

if [ "${OVERLAY}" ==  "none" ]; then
    IPG=0x00000019  #Pure L3
else
    IPG=0x00000021  #Routed EVPN(L3EVPN)
fi

if [ "$HCA_TYPE" == "ConnectX-8" ]; then
    TOTAL_BW=800
else
    TOTAL_BW=400
fi
BW_G=$((TOTAL_BW / CX_BREAKOUT))
if [ "${IS_SIMULATION}" ==  "false" ]; then
for interface in ${INTERFACES_LIST[@]} ; do

        vendor_id=`/usr/bin/cat /sys/class/net/$interface/device/vendor`
        if [ "$vendor_id" != "$MELLANOX" ]; then
            /usr/bin/echo "skipping not nvidia interface $interface"
            continue
        fi

        device_id=`/usr/bin/cat /sys/class/net/$interface/device/device`
        if [ "$device_id" != "$DEVICE_ID" ]; then
            /usr/bin/echo "skipping not $HCA_TYPE interface $interface"
            continue
        fi

        RDMA_DEVICE=`/usr/bin/ls /sys/class/net/$interface/device/infiniband/ -AU | /usr/bin/head -1`
        PCI_ADDRESS=`/usr/bin/cat /sys/class/net/$interface/device/uevent | /usr/bin/grep PCI_SLOT_NAME | /usr/bin/cut -d'=' -f 2`

        /usr/bin/echo "setting interface: $interface"
        /usr/bin/echo "RDMA device: $RDMA_DEVICE"
        /usr/bin/echo "PCI address: $PCI_ADDRESS"

        # 5.6.1 - https://apps.nvidia.com/pid/contentlibraries/detail?id=1153253
        # set IPG if not already set
        if /usr/bin/mlxreg -d $PCI_ADDRESS --get --reg_name PIPG --indexes "local_port=1,lp_msb=0,ipg_cap_index=0" | grep 'ipg *|' | grep -q $IPG ; then
            /usr/bin/echo "Enable Inter Packet Gap already configured for $interface"
        else
            /usr/bin/echo "Enable Inter Packet Gap for $interface"
            # set IPG
            /usr/bin/mlxreg -d $PCI_ADDRESS --set "ipg=$IPG" --reg_name PIPG --indexes "local_port=1,lp_msb=0,ipg_cap_index=0" -y
            sleep 1
            # link down:
            /usr/bin/mlxreg -d $PCI_ADDRESS --reg_id 0x5006 --set "0x0.8:4=2,0x0.16:8=1,0x4.8:1=1,0x4.31:1=1" --reg_len 16 -y
            # link up:
            /usr/bin/mlxreg -d $PCI_ADDRESS --reg_id 0x5006 --set "0x0.8:4=1,0x0.16:8=1,0x4.8:1=1,0x4.31:1=1" --reg_len 16 -y
            # wait for link up:
            for i in $(seq 1 $MAX_RETRIES_FOR_LINKUP); do
                sleep 2
                state=$(/usr/bin/mlxlink -d $PCI_ADDRESS | awk -F ':' '/^State[[:space:]]*:/ {print $2}' | sed 's/\x1b\[[0-9;]*m//g' | tr -d '[:space:]')
                if [ "$state" = "Active" ]; then
                    /usr/bin/echo "Link is Active."
                    break
                else
                    /usr/bin/echo "Pending link to become active, attempt $i"
                fi
            done
        fi
        if /usr/bin/mlxreg -d $PCI_ADDRESS --get --reg_name PIPG --indexes "local_port=1,lp_msb=0,ipg_cap_index=0" | grep 'ipg *|' | grep -q $IPG ; then
            /usr/bin/echo "Enable Inter Packet Gap Successfully configured $interface"
        else
            /usr/bin/echo "Failed to Inter Packet Gap"
            #exit 1
        fi

        # 5.5.1 - https://apps.nvidia.com/pid/contentlibraries/detail?id=1153253
        /usr/bin/echo  "Enable DOCA SPCX CC"
        nohup /opt/mellanox/doca/tools/doca_spcx_cc -d $RDMA_DEVICE  2>&1 | logger -t doca_spcx_cc_$RDMA_DEVICE &
        sleep 3

        # 5.5.3.1 - https://apps.nvidia.com/pid/contentlibraries/detail?id=1153253
        /usr/bin/echo  "Disable DCQCN on $interface"
        /usr/bin/mlxreg -d $PCI_ADDRESS -y --set "cmd_type=2" --reg_name PPCC --indexes "local_port=1,pnat=0,lp_msb=0,algo_slot=15,algo_param_index=0"

        # 5.5.2.1 - https://apps.nvidia.com/pid/contentlibraries/detail?id=1153253
        /usr/bin/echo  "Enable SPCX CC with Counters slot0 on $interface"
        /usr/bin/mlxreg -d $PCI_ADDRESS -y --set "cmd_type=1,counter_en=1" --reg_name PPCC --indexes "local_port=1,pnat=0,lp_msb=0,algo_slot=0,algo_param_index=0"
        #Verify: counter_en - 0x00000001
        # /usr/bin/mlxreg -d $PCI_ADDRESS -y --get --reg_name PPCC --indexes "local_port=1,pnat=0,lp_msb=0,algo_slot=0,algo_param_index=0" | grep counter_en

        /usr/bin/echo  "Disable DCQCN on $interface"
        /usr/bin/mlxreg -d $PCI_ADDRESS -y --set "cmd_type=2" --reg_name PPCC --indexes "local_port=1,pnat=0,lp_msb=0,algo_slot=15,algo_param_index=0"
        #Verify: value - 0x00000000
        # /usr/bin/mlxreg -d $PCI_ADDRESS -y --set "cmd_type=3" --reg_name PPCC --indexes "local_port=1,pnat=0,lp_msb=0,algo_slot=15,algo_param_index=0" | grep -w value

        /usr/bin/echo  "Enable BW_G on $interface"
        /usr/bin/mlxreg -d $PCI_ADDRESS -y --set "cmd_type=8,value=$BW_G" --reg_name PPCC --indexes "local_port=1,pnat=0,lp_msb=0,algo_slot=0,algo_param_index=0"

        # Function to extract parameter name and value by index
        get_conf_param() {
            local index=$1
            awk -F'[][]' -v key="algo_param_index_${index}" '$0 ~ "^"key"=" { print $2 }' "$CC_CONF_FILE"
        }

        # Extract all indexes dynamically from the config file
        indexes=$(grep -v "#" /etc/rcp/cc_params.conf | grep -oP 'algo_param_index_\K[0-9]+' | sort -n | uniq)

        # Loop through indices
        for index in $indexes; do
            param=$(get_conf_param "$index")
            if [[ -n "$param" ]]; then
                name=$(cut -d',' -f1 <<< "$param" | xargs)
                value=$(cut -d',' -f2 <<< "$param" | xargs)
                /usr/bin/echo "Configuring $name (index=$index) to value=$value on $interface"
                /usr/bin/mlxreg -d "$PCI_ADDRESS" -y --set "cmd_type=8,value=$value" \
                    --reg_name PPCC --indexes "local_port=1,pnat=0,lp_msb=0,algo_slot=0,algo_param_index=$index"
            else
                echo "Skipping index=$index (no config found)"
            fi
        done

        /usr/bin/echo "Interface $interface configured successfully"
done
fi
if [ "$IP_VERSION" == "ipv6" ]; then
    # Delete rule with priorities 0 and 32766 if it exists
    if ip -6 rule show | grep -q "^0:"; then
        ip -6 rule del priority 0
    fi
    if ip -6 rule show | grep -q "^32766:"; then
        ip -6 rule del priority 32766
    fi
fi

