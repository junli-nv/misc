#!/bin/bash
cat > /etc/udev/rules.d/60-rdma-persistent-naming-rcp.rules <<- '__END__'
ACTION=="add", KERNELS=="0000:73:00.0", SUBSYSTEM=="infiniband", PROGRAM="rdma_rename %k NAME_FIXED roce_p0_r0"
ACTION=="add", KERNELS=="0000:73:00.1", SUBSYSTEM=="infiniband", PROGRAM="rdma_rename %k NAME_FIXED roce_p1_r0"
ACTION=="add", KERNELS=="0000:17:00.0", SUBSYSTEM=="infiniband", PROGRAM="rdma_rename %k NAME_FIXED roce_p0_r1"
ACTION=="add", KERNELS=="0000:17:00.1", SUBSYSTEM=="infiniband", PROGRAM="rdma_rename %k NAME_FIXED roce_p1_r1"
ACTION=="add", KERNELS=="0000:24:00.0", SUBSYSTEM=="infiniband", PROGRAM="rdma_rename %k NAME_FIXED roce_p0_r2"
ACTION=="add", KERNELS=="0000:24:00.1", SUBSYSTEM=="infiniband", PROGRAM="rdma_rename %k NAME_FIXED roce_p1_r2"
ACTION=="add", KERNELS=="0000:7a:00.0", SUBSYSTEM=="infiniband", PROGRAM="rdma_rename %k NAME_FIXED roce_p0_r3"
ACTION=="add", KERNELS=="0000:7a:00.1", SUBSYSTEM=="infiniband", PROGRAM="rdma_rename %k NAME_FIXED roce_p1_r3"
ACTION=="add", KERNELS=="0000:97:00.0", SUBSYSTEM=="infiniband", PROGRAM="rdma_rename %k NAME_FIXED roce_p0_r4"
ACTION=="add", KERNELS=="0000:97:00.1", SUBSYSTEM=="infiniband", PROGRAM="rdma_rename %k NAME_FIXED roce_p1_r4"
ACTION=="add", KERNELS=="0000:f0:00.0", SUBSYSTEM=="infiniband", PROGRAM="rdma_rename %k NAME_FIXED roce_p0_r5"
ACTION=="add", KERNELS=="0000:f0:00.1", SUBSYSTEM=="infiniband", PROGRAM="rdma_rename %k NAME_FIXED roce_p1_r5"
ACTION=="add", KERNELS=="0000:f7:00.0", SUBSYSTEM=="infiniband", PROGRAM="rdma_rename %k NAME_FIXED roce_p0_r6"
ACTION=="add", KERNELS=="0000:f7:00.1", SUBSYSTEM=="infiniband", PROGRAM="rdma_rename %k NAME_FIXED roce_p1_r6"
ACTION=="add", KERNELS=="0000:a3:00.0", SUBSYSTEM=="infiniband", PROGRAM="rdma_rename %k NAME_FIXED roce_p0_r7"
ACTION=="add", KERNELS=="0000:a3:00.1", SUBSYSTEM=="infiniband", PROGRAM="rdma_rename %k NAME_FIXED roce_p1_r7"
__END__
cat > /etc/udev/rules.d/70-persistent-net-rcp.rules <<- '__END__'
ACTION=="add", KERNELS=="0000:73:00.0", SUBSYSTEM=="net", NAME="eth_p0_r0"
ACTION=="add", KERNELS=="0000:73:00.1", SUBSYSTEM=="net", NAME="eth_p1_r0"
ACTION=="add", KERNELS=="0000:17:00.0", SUBSYSTEM=="net", NAME="eth_p0_r1"
ACTION=="add", KERNELS=="0000:17:00.1", SUBSYSTEM=="net", NAME="eth_p1_r1"
ACTION=="add", KERNELS=="0000:24:00.0", SUBSYSTEM=="net", NAME="eth_p0_r2"
ACTION=="add", KERNELS=="0000:24:00.1", SUBSYSTEM=="net", NAME="eth_p1_r2"
ACTION=="add", KERNELS=="0000:7a:00.0", SUBSYSTEM=="net", NAME="eth_p0_r3"
ACTION=="add", KERNELS=="0000:7a:00.1", SUBSYSTEM=="net", NAME="eth_p1_r3"
ACTION=="add", KERNELS=="0000:97:00.0", SUBSYSTEM=="net", NAME="eth_p0_r4"
ACTION=="add", KERNELS=="0000:97:00.1", SUBSYSTEM=="net", NAME="eth_p1_r4"
ACTION=="add", KERNELS=="0000:f0:00.0", SUBSYSTEM=="net", NAME="eth_p0_r5"
ACTION=="add", KERNELS=="0000:f0:00.1", SUBSYSTEM=="net", NAME="eth_p1_r5"
ACTION=="add", KERNELS=="0000:f7:00.0", SUBSYSTEM=="net", NAME="eth_p0_r6"
ACTION=="add", KERNELS=="0000:f7:00.1", SUBSYSTEM=="net", NAME="eth_p1_r6"
ACTION=="add", KERNELS=="0000:a3:00.0", SUBSYSTEM=="net", NAME="eth_p0_r7"
ACTION=="add", KERNELS=="0000:a3:00.1", SUBSYSTEM=="net", NAME="eth_p1_r7"
__END__
chmod 644 /etc/udev/rules.d/60-rdma-persistent-naming-rcp.rules
chmod 644 /etc/udev/rules.d/70-persistent-net-rcp.rules
udevadm control --reload-rules && udevadm trigger --subsystem-match=infiniband --action=add

cat > /usr/libexec/sxtool/sxtool-fix-net-names <<- '__END__'
#!/bin/sh
# Managed by spectrum-x-tool — do not edit manually.
# Fixes UDEV NAME= race condition by verifying and correcting interface
# names after udev-settle. Uses two-step rename via temporary names to
# break circular dependencies.

set -u
LOG=/var/log/sxtool-fix-net-names.log
STAMP="$(date -Is 2>/dev/null || date)"
log() { echo "[$STAMP] $*" >> "$LOG" 2>/dev/null || true; }
log "sxtool-fix-net-names: starting"

# Authoritative PCI=desired_name mapping (from profile).
# Format: PCI_ADDR=IFACE_NAME (= delimiter; PCI contains colons).
MAPPING="0000:73:00.0=eth_p0_r0 0000:73:00.1=eth_p1_r0 0000:17:00.0=eth_p0_r1 0000:17:00.1=eth_p1_r1 0000:24:00.0=eth_p0_r2 0000:24:00.1=eth_p1_r2 0000:7a:00.0=eth_p0_r3 0000:7a:00.1=eth_p1_r3 0000:97:00.0=eth_p0_r4 0000:97:00.1=eth_p1_r4 0000:f0:00.0=eth_p0_r5 0000:f0:00.1=eth_p1_r5 0000:f7:00.0=eth_p0_r6 0000:f7:00.1=eth_p1_r6 0000:a3:00.0=eth_p0_r7 0000:a3:00.1=eth_p1_r7"

MISMATCHES=0
FIXES=""

for entry in $MAPPING; do
    PCI="${entry%%=*}"
    WANT="${entry##*=}"
    SYSFS="/sys/bus/pci/devices/$PCI/net"

    if [ ! -d "$SYSFS" ]; then
        log "SKIP $PCI: no net device in sysfs (NIC not probed or no driver)"
        continue
    fi

    GOT=$(ls "$SYSFS" 2>/dev/null | head -1)
    if [ -z "$GOT" ]; then
        log "SKIP $PCI: sysfs net dir exists but empty"
        continue
    fi

    if [ "$GOT" = "$WANT" ]; then
        continue
    fi

    log "MISMATCH $PCI: have=$GOT want=$WANT"
    MISMATCHES=$((MISMATCHES + 1))
    FIXES="$FIXES $GOT=$WANT"
done

if [ "$MISMATCHES" -eq 0 ]; then
    log "sxtool-fix-net-names: all interfaces correct, nothing to do"
    exit 0
fi

log "sxtool-fix-net-names: $MISMATCHES mismatches found, performing two-step rename"

# Step 1: rename all mismatched interfaces to temporary names.
# This breaks any circular dependency (A->B, B->A).
IDX=0
for fix in $FIXES; do
    GOT="${fix%%=*}"
    TMPNAME="_sxtmp_$IDX"
    ip link set dev "$GOT" down 2>/dev/null || true
    if ip link set dev "$GOT" name "$TMPNAME" 2>>"$LOG"; then
        log "  step1: $GOT -> $TMPNAME"
    else
        log "  step1: FAILED $GOT -> $TMPNAME"
    fi
    IDX=$((IDX + 1))
done

# Step 2: rename from temporary names to final desired names.
IDX=0
for fix in $FIXES; do
    WANT="${fix##*=}"
    TMPNAME="_sxtmp_$IDX"
    if ip link set dev "$TMPNAME" name "$WANT" 2>>"$LOG"; then
        log "  step2: $TMPNAME -> $WANT (OK)"
        ip link set dev "$WANT" up 2>/dev/null || true
    else
        log "  step2: FAILED $TMPNAME -> $WANT"
    fi
    IDX=$((IDX + 1))
done

log "sxtool-fix-net-names: done ($MISMATCHES fixes attempted)"
exit 0
__END__
chmod 755 /usr/libexec/sxtool/sxtool-fix-net-names
cat > /etc/systemd/system/sxtool-fix-net-names.service <<- '__END__'
# Managed by spectrum-x-tool — do not edit manually.
# Corrects interface names after UDEV race condition during boot.
[Unit]
Description=sxtool fix network interface names (UDEV race workaround)
After=systemd-udev-settle.service
Before=network-pre.target
Wants=systemd-udev-settle.service

[Service]
Type=oneshot
ExecStart=/usr/libexec/sxtool/sxtool-fix-net-names
RemainAfterExit=yes
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
__END__
systemctl enable sxtool-fix-net-names.service