#!/usr/bin/env -S bash -xuo pipefail

# SPDX-FileCopyrightText: Copyright (c) 2023-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.

set -e

function log_and_exit {
    local ifc_name="$1"
    local exit_code="$2"
    if [[ $exit_code -ne 0 ]]; then
      echo "$ifc_name" >> /tmp/rcp_networkd_spectrum_x_failed_devices
    fi
    exit $exit_code
}

source /etc/rcp/rcp-cx8.conf

MELLANOX=0x15b3
RDMA_TIMEOUT=5

IFS=', ' read -r -a INTERFACES_LIST <<< "$INTERFACES"

for interface in ${INTERFACES_LIST[@]} ; do
    IFACE=$interface
    /usr/bin/echo "IFACE is $IFACE"
    if [ "$IFACE" == "$interface" ]; then
        vendor_id=`/usr/bin/cat /sys/class/net/$IFACE/device/vendor`
        if [ "$vendor_id" != "$MELLANOX" ]; then
            /usr/bin/echo "skipping not nvidia interface $IFACE"
            continue
        fi

        device_id=`/usr/bin/cat /sys/class/net/$IFACE/device/device`
        if [ "$device_id" != "$DEVICE_ID" ]; then
            /usr/bin/echo "skipping not $HCA_TYPE interface $IFACE"
            continue
        fi

        trap 'log_and_exit $interface $?' EXIT

        set +e
        TIMEOUT=0
        /usr/bin/ls /sys/class/net/$IFACE/device/infiniband/
        while [[ $? -ne 0 || $TIMEOUT == $RDMA_TIMEOUT ]]; do
            /usr/bin/sleep 1
            TIMEOUT += 1
            /usr/bin/ls /sys/class/net/$IFACE/device/infiniband/
        done

        if [[ $TIMEOUT == $RDMA_TIMEOUT ]]; then
            /usr/bin/echo "RDMA timeout RDMA device not exist"
            #exit 1
        fi
        set -e

        RDMA_DEVICE=`/usr/bin/ls /sys/class/net/$IFACE/device/infiniband/ -AU | /usr/bin/head -1`
        PCI_ADDRESS=`/usr/bin/cat /sys/class/net/$IFACE/device/uevent | /usr/bin/grep PCI_SLOT_NAME | /usr/bin/cut -d'=' -f 2`

        /usr/bin/echo "setting interface: $IFACE"
        /usr/bin/echo "RDMA device: $RDMA_DEVICE"
        /usr/bin/echo "PCI address: $PCI_ADDRESS"

        # 5.4.1.1 - https://apps.nvidia.com/pid/contentlibraries/detail?id=1153253
        /usr/bin/echo  "RoCE Configuration"
        /usr/bin/mlnx_qos -i $IFACE --pfc=0,0,0,1,0,0,0,0 --trust=dscp
        /usr/sbin/cma_roce_tos -d $RDMA_DEVICE -t 96
        /usr/bin/echo 96 > /sys/class/infiniband/$RDMA_DEVICE/tc/1/traffic_class
        /usr/bin/echo 48 > /sys/class/net/$IFACE/ecn/roce_np/cnp_dscp

        /usr/bin/echo "Enable Congestion Control"
        for point in "rp" "np" ; do
            for i in {0..7} ; do
                echo 1 > /sys/class/net/$interface/ecn/roce_${point}/enable/${i}
            done
        done

        # 5.4.2.1 - https://apps.nvidia.com/pid/contentlibraries/detail?id=1153253
        /usr/bin/echo "Enable RoCE Accelerations"
        MLXREG_FIELDS="roce_adp_retrans_en=0x1,roce_tx_window_en=0x1,roce_slow_restart_en=0x0,roce_slow_restart_idle_en=0x0,adaptive_routing_forced_en=0x1"
        /usr/bin/mlxreg -d $PCI_ADDRESS --reg_name ROCE_ACCL --set $MLXREG_FIELDS --yes
        if /usr/bin/mlxreg -d $PCI_ADDRESS --get --reg_name ROCE_ACCL | grep adaptive_routing_forced_en | grep -q 0x00000001 ; then
            /usr/bin/echo "RoCE Accelerations Successfully configured $interface"
        else
            if [ "$HCA_TYPE" == "ConnectX-8" ]; then
                /usr/bin/echo "Failed to configure RoCE Accelerations, make sure DPU with Spectrum-X enabled"
            else
                /usr/bin/echo "Failed to configure RoCE Accelerations, make sure Super-NIC with Spectrum-X enabled"
            fi
#            exit 1
        fi

        /usr/bin/echo "Interface $IFACE configured successfully"
###        exit 0
    fi
done
/usr/bin/echo "Skipping Interface $IFACE"

/usr/bin/echo "RoCE AR enable done."
sleep 5
exit 0


