#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

# RA ref: https://apps.nvidia.com/PID/ContentLibraries/Detail/1155985
#

# killall -s SIGINT doca_spcx_cc
pkill -9 doca_spcx_cc
sleep 3

export PATH=/usr/sbin:/sbin:/usr/bin:/bin:/usr/local/sbin:/usr/local/bin

declare -A algo_param_index
## https://nvidia.atlassian.net/wiki/spaces/SW/pages/2899554761/MoE+training+performance+improvement+New+CC+without+TX_DEC
# Default CC profile
algo_param_index[0]="BW_G,200"                                 #bandwidth
algo_param_index[1]="ALPHA,6553"                               #Alpha
algo_param_index[2]="MAX_DEC,63570"                            #Maximum Decrease Factor
algo_param_index[3]="MAX_INC,69468"                            #Maximum Increase Factor
algo_param_index[4]="AI,36"                                    #Additive Increase Step Size
algo_param_index[5]="HAI,1200"                                 #High Addictive Increase Step Size
algo_param_index[6]="HAI_PERIOD_NS,7000000"                    #High Addictive Increase Interval Period
algo_param_index[7]="ZTR_CC_CONGESTION_DELAY_THRESHOLD,15000"  #Congestion Delay Threshold
algo_param_index[8]="MAX_DELAY,250000"                         #Maximum Queing Delay
algo_param_index[9]="RATE_ON_FIRST_CONGESTION,524288"          #Rate on First Congestion
algo_param_index[10]="DELAY_ONLY,0"                            #Delay Only
algo_param_index[11]="CNP_VLD_RTT,1"                           #CNP Validity
algo_param_index[12]="TX_DEC,0"                                #Transmit Rate Decrement
algo_param_index[13]="FIXED_RATE,0"                            #Fixed Rate
algo_param_index[14]="FAST_SCHED,2097152"                      #Fast Scheduling Factor
algo_param_index[15]="TOPOLOGY_AWARE,1"                        #Topology Awareness
algo_param_index[16]="ADVANCED_FEATURES_EN,1"                  #Advanced Features
algo_param_index[17]="TRACER_EN,0"                             #Disable TRACER_EN Troubleshooting Capabilities
algo_param_index[18]="CC_FIXED_CWND,0"                         #Disable FIXED_CWND Troubleshooting Capabilities
algo_param_index[22]="CC_PLANE_FAILURE_DETECTION_EN,1"         #Plane Failure Detection EN
algo_param_index[23]="CC_PLANE_FAILURE_THRESHOLD,3"            #Plane Failure Threshold
algo_param_index[24]="CC_PLANE_RECOVERY_THRESHOLD,1"           #Plane Recovery Threshold
# MoE CC profile
# algo_param_index[4]="AI,96"                                    #Additive Increase Step Size
# algo_param_index[5]="HAI,1700"                                 #High Addictive Increase Step Size
# algo_param_index[6]="HAI_PERIOD_NS,200000"                     #High Addictive Increase Interval Period
# algo_param_index[7]="ZTR_CC_CONGESTION_DELAY_THRESHOLD,13000"  #Congestion Delay Threshold
# algo_param_index[12]="TX_DEC,1"                                #Transmit Rate Decrement

#GDE : most fabrics are configured for multi-tenancy : L3EVPN : IPG=...21
#pure L3 ( single BRF ) : IPG=....19
#IPG=0x00000019
IPG=0x00000021
MELLANOX=0x15b3
CONNECTX_8=0x1023

cx8_nics_pfs=($(lspci -D|grep "Ethernet controller.*ConnectX-8"|awk '{print $1}'|xargs -I {} bash -c 'ls -l /sys/class/net|grep -o {}/.*|cut -f3 -d"/"'|xargs -I {} bash -c '[ -d /sys/class/net/{}/ecn ] && echo {}'))

for interface in ${cx8_nics_pfs[@]} ; do
  vendor_id=$(cat /sys/class/net/$interface/device/vendor)
  if [ "$vendor_id" != "$MELLANOX" ]; then
    echo "[WARN] skipping not nvidia interface $interface"
    continue
  fi
  device_id=$(cat /sys/class/net/$interface/device/device)
  if [ "$device_id" != "$CONNECTX_8" ]; then
    echo "[WARN] skipping not Connect-X 8 interface $interface"
    continue
  fi

  RDMA_DEVICE=$(ls /sys/class/net/$interface/device/infiniband/ -AU 2>/dev/null | /usr/bin/head -1)
  PCI_ADDRESS=$(cat /sys/class/net/$interface/device/uevent | grep PCI_SLOT_NAME | cut -d'=' -f 2)
  echo "[INFO] $interface, RDMA device: $RDMA_DEVICE, PCI address: $PCI_ADDRESS"

  # 5.7.2	Adaptive Routing
  echo "[INFO] Enable AR on all master PF RDMA"
  # set RoCE Accelerations 1 if not already set 0x1
  mlxreg -d $PCI_ADDRESS --reg_name ROCE_ACCL --set roce_adp_retrans_en=0x1,roce_tx_window_en=0x1,adaptive_routing_forced_en=0x1,cc_per_plane_en=0x1,cc_probe_mp_mode=0x1 --yes &>/dev/null
  if ! mlxreg -d $PCI_ADDRESS --get --reg_name ROCE_ACCL | egrep 'adaptive_routing_forced_en_field_select|cc_per_plane_en_field_select|cc_probe_mp_mode_field_select|roce_adp_retrans_en|roce_tx_window_en|adaptive_routing_forced_en|cc_per_plane_en|cc_probe_mp_mode' | grep -q 0x00000000 ; then
    echo "[INFO] RoCE Accelerations 1 Successfully configured $interface"
  else
    state=$(mlxlink -d $PCI_ADDRESS | grep -e '^State' -e '^Recommendation'|tr '\t' ' '|tr -s ' '|paste -s -d',' -)
    echo "[ERROR] Failed to configure RoCE Accelerations 1: $interface, $PCI_ADDRESS, $state"
  fi
  # set RoCE Accelerations 2 if not already set 0x0
  mlxreg -d $PCI_ADDRESS --reg_name ROCE_ACCL --set roce_slow_restart_en=0x0,roce_slow_restart_idle_en=0x0 --yes &>/dev/null
  if ! mlxreg -d $PCI_ADDRESS --get --reg_name ROCE_ACCL | egrep 'roce_slow_restart_en|roce_slow_restart_idle_en' | grep -q 0x00000001 ; then
    echo "[INFO] RoCE Accelerations 2 Successfully configured $interface"
  else
    state=$(mlxlink -d $PCI_ADDRESS | grep -e '^State' -e '^Recommendation'|tr '\t' ' '|tr -s ' '|paste -s -d',' -)
    echo "[ERROR] Failed to configure RoCE Accelerations 2: $interface, $PCI_ADDRESS, $state"
  fi

  # 5.8.2.1 Spectrum-X CC Algorithm Algorithm Tuning
  # Tune the SPCX-CC algorithm on each SuperNIC using its master RDMA (MST) device PCI address
  if [ "X${RDMA_DEVICE}X" == "XX" ]; then
    echo "[INFO] Bypass the non-master PF device: $interface"
  else
    echo "[INFO] Applying CC to master PF device: $interface"
    
    echo "[INFO] Start DOCA SPC-X Congestion Control daemon"
    nohup /opt/mellanox/doca/tools/doca_spcx_cc -d $RDMA_DEVICE 2>&1 | logger -t doca_spcx_cc_$RDMA_DEVICE &
    sleep 3

    echo  "Disable DCQCN on $interface"
    mlxreg -d $PCI_ADDRESS -y --set "cmd_type=2" --reg_name PPCC --indexes "local_port=1,pnat=0,lp_msb=0,algo_slot=15,algo_param_index=0" &>/dev/null
    mlxreg -d $PCI_ADDRESS -y --set "cmd_type=3" --reg_name PPCC --indexes "local_port=1,pnat=0,lp_msb=0,algo_slot=15,algo_param_index=0" | grep value| grep -qw 0x00000000 && echo "[INFO] Disable DCQCN Successfully configured $interface" || echo "[ERROR] Failed to Disable DCQCN on $interface"

    echo  "Enable SPCX CC with Counters slot0 on $interface"
    mlxreg -d $PCI_ADDRESS -y --set "cmd_type=1,counter_en=1" --reg_name PPCC --indexes "local_port=1,pnat=0,lp_msb=0,algo_slot=0,algo_param_index=0" &>/dev/null
    mlxreg -d $PCI_ADDRESS -y --get --reg_name PPCC --indexes "local_port=1,pnat=0,lp_msb=0,algo_slot=0,algo_param_index=0" | grep counter_en| grep -qw 0x00000001 && echo "[INFO] Enable SPCX CC with Counters slot0 Successfully configured $interface" || echo "[ERROR] Failed to Enable SPCX CC with Counters slot0 on $interface"

    echo  "Enable SPCX CC Profile on $interface"
    for index in $(echo ${!algo_param_index[@]}|tr ' ' '\n'|sort -n); do
      name=$(echo ${algo_param_index[${index}]} | cut -d',' -f1)
      value=$(echo ${algo_param_index[${index}]} | cut -d',' -f2)
      echo "Applying ${name} on interface"
      mlxreg -d $PCI_ADDRESS -y --set "cmd_type=8,value=${value}" --reg_name PPCC --indexes "local_port=1,pnat=0,lp_msb=0,algo_slot=0,algo_param_index=${index}" &>/dev/null
    done

    # set IPG if not already set
    if mlxreg -d $PCI_ADDRESS --get --reg_name PIPG --indexes "local_port=1,lp_msb=0,ipg_cap_index=0" | grep 'ipg *|' | grep -q $IPG ; then
      echo "Enable Inter Packet Gap already configured for $interface"
    else
      echo "Enable Inter Packet Gap for $interface"
      # set IPG
      mlxreg -d $PCI_ADDRESS --set "ipg=$IPG" --reg_name PIPG --indexes "local_port=1,lp_msb=0,ipg_cap_index=0" -y
      sleep 1
      # link down:
      mlxreg -d $PCI_ADDRESS --reg_id 0x5006 --set "0x0.8:4=2,0x0.16:8=1,0x4.8:1=1,0x4.31:1=1" --reg_len 16 -y
      # link up:
      mlxreg -d $PCI_ADDRESS --reg_id 0x5006 --set "0x0.8:4=1,0x0.16:8=1,0x4.8:1=1,0x4.31:1=1" --reg_len 16 -y
    fi
    sleep 3
  fi
  echo "Interface $interface configured successfully"
done

# wait 10s for link up
sleep 10
cx8_nics_master_pfs=($(lspci -D|grep "\.0 Ethernet controller.*ConnectX-8"|awk '{print $1}'|xargs -I {} bash -c 'ls -l /sys/class/net|grep -o {}/.*|cut -f3 -d"/"'|xargs -I {} bash -c '[ -d /sys/class/net/{}/ecn ] && echo {}'))
#for interface in ${cx8_nics_master_pfs[@]} ; do
for interface in ${cx8_nics_pfs[@]} ; do
  PCI_ADDRESS=$(cat /sys/class/net/$interface/device/uevent | grep PCI_SLOT_NAME | cut -d'=' -f 2)
  state=$(mlxlink -d $PCI_ADDRESS | awk -F ':' '/^State[[:space:]]*:/ {print $2}' | sed 's/\x1b\[[0-9;]*m//g' | tr -d '[:space:]')
  echo "[INFO] $interface, $PCI_ADDRESS, $state"
done

ps -ef|grep doca_spcx_cc|grep -v grep|grep -v logger|grep -o /opt.*|sort|uniq

echo "[INFO] DONE"
