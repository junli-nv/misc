#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

# RA ref: https://apps.nvidia.com/PID/ContentLibraries/Detail/1155985
#

export PATH=/usr/sbin:/sbin:/usr/bin:/bin:/usr/local/sbin:/usr/local/bin

# 5.6.1	OVS Initialization
echo "[INFO] OVS Initialization"
systemctl disable openvswitch-switch #disable OVS service auto start
timeout 300 systemctl stop openvswitch-switch
timeout 300 systemctl start openvswitch-switch
[ $? -ne 0 ] && echo "[ERROR] Can't start OVS service" && exit 1
sleep 10
[ $(systemctl is-active openvswitch-switch) != "active" ] && echo "[ERROR] OVS service is not active"

echo "[INFO] enable hardware offload and doca-eswitch-max"
ovs-vsctl set Open_vSwitch . other_config:doca-init=true
ovs-vsctl set Open_vSwitch . other_config:hw-offload=true
ovs-vsctl set Open_vSwitch . other_config:hw-offload-ct-size=0
ovs-vsctl set Open_vSwitch . other_config:max-idle=300000
ovs-vsctl set Open_vSwitch . other_config:doca-eswitch-max=4
timeout 300 systemctl stop openvswitch-switch
timeout 300 systemctl start openvswitch-switch
[ $? -ne 0 ] && echo "[ERROR] Can't restart OVS service" && exit 1
sleep 10
[ $(systemctl is-active openvswitch-switch) != "active" ] && echo "[ERROR] OVS service is not active"

echo "[INFO] Create OVS Bridge"
for rail in {0..3}; do
  echo "[INFO] Applying rail${rail}"

  ovs-vsctl --may-exist add-br br-rail${rail} -- set br br-rail${rail} fail-mode=secure datapath_type=netdev
  # ovs-vsctl list-br|grep br-rail${rail}

  ip link set dev br-rail${rail} mtu 9216 up
  for port in {0..3}; do
    interface="eth_r${rail}_p${port}"
    ovs-vsctl --may-exist add-port br-rail${rail} $interface -- set int $interface mtu_request=9216 type=dpdk
  done
  ovs-vsctl --may-exist add-port br-rail${rail} eth_vf_rep_r${rail} -- set int eth_vf_rep_r${rail} mtu_request=9216 type=dpdk
  for port in {0..3}; do
    interface="eth_r${rail}_p${port}"
    ovs-vsctl set int $interface mtu_request=9216
  done
  ovs-vsctl set int eth_vf_rep_r${rail} mtu_request=9216
  # ovs-vsctl list-ports br-rail${rail}
  # ovs-vsctl show

  echo "OVS Rules for rail${rail}"
  ovs-ofctl del-flows br-rail${rail}

  # 5.6.2.1.1	Non-RoCE Traffic
  echo "Non-RoCE Traffic Configuration for rail${rail}"
  ECMP_GROUP_ID_ALL_PFS=10
  ovs-ofctl mod-group --may-create br-rail${rail} \
    "group_id=${ECMP_GROUP_ID_ALL_PFS},type=select,selection_method=hash,bucket=watch_port=eth_r${rail}_p0,actions=output:eth_r${rail}_p0,bucket=watch_port=eth_r${rail}_p1,actions=output:eth_r${rail}_p1,bucket=watch_port=eth_r${rail}_p2,actions=output:eth_r${rail}_p2,bucket=watch_port=eth_r${rail}_p3,actions=output:eth_r${rail}_p3"
  
  # 5.6.2.1.2 RoCE Traffic
  echo "RoCE Traffic Configuration for rail${rail}"
  ROCE_GROUP_ID_PLANE_0=20
  ROCE_GROUP_ID_PLANE_1=21
  ROCE_GROUP_ID_PLANE_2=22
  ROCE_GROUP_ID_PLANE_3=23
  ovs-ofctl mod-group --may-create br-rail${rail} "group_id=${ROCE_GROUP_ID_PLANE_0},type=fast_failover,bucket=watch_port=eth_r${rail}_p0,actions=output:eth_r${rail}_p0,bucket=watch_group=${ECMP_GROUP_ID_ALL_PFS},actions=group:${ECMP_GROUP_ID_ALL_PFS}"
  ovs-ofctl mod-group --may-create br-rail${rail} "group_id=${ROCE_GROUP_ID_PLANE_1},type=fast_failover,bucket=watch_port=eth_r${rail}_p1,actions=output:eth_r${rail}_p1,bucket=watch_group=${ECMP_GROUP_ID_ALL_PFS},actions=group:${ECMP_GROUP_ID_ALL_PFS}"
  ovs-ofctl mod-group --may-create br-rail${rail} "group_id=${ROCE_GROUP_ID_PLANE_2},type=fast_failover,bucket=watch_port=eth_r${rail}_p2,actions=output:eth_r${rail}_p2,bucket=watch_group=${ECMP_GROUP_ID_ALL_PFS},actions=group:${ECMP_GROUP_ID_ALL_PFS}"
  ovs-ofctl mod-group --may-create br-rail${rail} "group_id=${ROCE_GROUP_ID_PLANE_3},type=fast_failover,bucket=watch_port=eth_r${rail}_p3,actions=output:eth_r${rail}_p3,bucket=watch_group=${ECMP_GROUP_ID_ALL_PFS},actions=group:${ECMP_GROUP_ID_ALL_PFS}"

  # 5.6.2.1.3 RoCE RTT Probes
  echo "RoCE RTT Probes Group Configuration for rail${rail}"
  ROCE_RTT_GROUP_ID_PLANE_0=30
  ROCE_RTT_GROUP_ID_PLANE_1=31
  ROCE_RTT_GROUP_ID_PLANE_2=32
  ROCE_RTT_GROUP_ID_PLANE_3=33
  ovs-ofctl mod-group --may-create br-rail${rail} "group_id=${ROCE_RTT_GROUP_ID_PLANE_0},type=fast_failover,bucket=watch_port=eth_r${rail}_p0,actions=output:eth_r${rail}_p0"
  ovs-ofctl mod-group --may-create br-rail${rail} "group_id=${ROCE_RTT_GROUP_ID_PLANE_1},type=fast_failover,bucket=watch_port=eth_r${rail}_p1,actions=output:eth_r${rail}_p1"
  ovs-ofctl mod-group --may-create br-rail${rail} "group_id=${ROCE_RTT_GROUP_ID_PLANE_2},type=fast_failover,bucket=watch_port=eth_r${rail}_p2,actions=output:eth_r${rail}_p2"
  ovs-ofctl mod-group --may-create br-rail${rail} "group_id=${ROCE_RTT_GROUP_ID_PLANE_3},type=fast_failover,bucket=watch_port=eth_r${rail}_p3,actions=output:eth_r${rail}_p3"

  # 5.6.2.2.1	OVS Flows All traffic
  echo "OVS Flows All traffic for rail${rail}"
  ovs-ofctl add-flow br-rail${rail} "priority=250,table=0,in_port=eth_r${rail}_p0,actions=output:eth_vf_rep_r${rail}"
  ovs-ofctl add-flow br-rail${rail} "priority=250,table=0,in_port=eth_r${rail}_p1,actions=output:eth_vf_rep_r${rail}"
  ovs-ofctl add-flow br-rail${rail} "priority=250,table=0,in_port=eth_r${rail}_p2,actions=output:eth_vf_rep_r${rail}"
  ovs-ofctl add-flow br-rail${rail} "priority=250,table=0,in_port=eth_r${rail}_p3,actions=output:eth_vf_rep_r${rail}"
  ovs-ofctl -O OpenFlow13 add-flow br-rail${rail} "priority=0,table=0,in_port=eth_vf_rep_r${rail},actions=resubmit(,1)"
  
  # 5.6.2.2.2	OVS Flows Non-RoCE traffic
  echo "OVS Flow Non-RoCE traffic for rail${rail}"
  ovs-ofctl add-flow br-rail${rail} "priority=100,table=1,in_port=eth_vf_rep_r${rail},nv_mp_preferred=0,actions=group:${ECMP_GROUP_ID_ALL_PFS}"

  # 5.6.2.2.3	OVS Flows RoCE traffic
  echo "OVS Flow RoCE traffic for rail${rail}"
  ROCE_GROUP_ID_PLANE_0=20
  ROCE_GROUP_ID_PLANE_1=21
  ROCE_GROUP_ID_PLANE_2=22
  ROCE_GROUP_ID_PLANE_3=23
  ovs-ofctl add-flow br-rail${rail} "priority=100,table=1,in_port=eth_vf_rep_r${rail},nv_mp_pid=0,nv_mp_strict=0,nv_mp_preferred=1,actions=group:${ROCE_GROUP_ID_PLANE_0}"
  ovs-ofctl add-flow br-rail${rail} "priority=100,table=1,in_port=eth_vf_rep_r${rail},nv_mp_pid=1,nv_mp_strict=0,nv_mp_preferred=1,actions=group:${ROCE_GROUP_ID_PLANE_1}"
  ovs-ofctl add-flow br-rail${rail} "priority=100,table=1,in_port=eth_vf_rep_r${rail},nv_mp_pid=2,nv_mp_strict=0,nv_mp_preferred=1,actions=group:${ROCE_GROUP_ID_PLANE_2}"
  ovs-ofctl add-flow br-rail${rail} "priority=100,table=1,in_port=eth_vf_rep_r${rail},nv_mp_pid=3,nv_mp_strict=0,nv_mp_preferred=1,actions=group:${ROCE_GROUP_ID_PLANE_3}"

  # 5.6.2.2.4	OVS Flows RoCE RTT Probes
  echo "OVS Flow RoCE RTT Probes for rail${rail}"
  ROCE_RTT_GROUP_ID_PLANE_0=30
  ROCE_RTT_GROUP_ID_PLANE_1=31
  ROCE_RTT_GROUP_ID_PLANE_2=32
  ROCE_RTT_GROUP_ID_PLANE_3=33
  ovs-ofctl add-flow br-rail${rail} "priority=100,table=1,in_port=eth_vf_rep_r${rail},nv_mp_pid=0,nv_mp_strict=1,actions=group:${ROCE_RTT_GROUP_ID_PLANE_0}"
  ovs-ofctl add-flow br-rail${rail} "priority=100,table=1,in_port=eth_vf_rep_r${rail},nv_mp_pid=1,nv_mp_strict=1,actions=group:${ROCE_RTT_GROUP_ID_PLANE_1}"
  ovs-ofctl add-flow br-rail${rail} "priority=100,table=1,in_port=eth_vf_rep_r${rail},nv_mp_pid=2,nv_mp_strict=1,actions=group:${ROCE_RTT_GROUP_ID_PLANE_2}"
  ovs-ofctl add-flow br-rail${rail} "priority=100,table=1,in_port=eth_vf_rep_r${rail},nv_mp_pid=3,nv_mp_strict=1,actions=group:${ROCE_RTT_GROUP_ID_PLANE_3}"

  # 5.6.2.2.5	OVS Flows Control Traffic
  echo "OVS Flow Control Traffic for rail${rail}"
  ###IPV4 Configuration
  ovs-ofctl add-flow br-rail${rail} "priority=300,table=0,in_port=eth_vf_rep_r${rail},arp,actions=output:eth_r${rail}_p0,output:eth_r${rail}_p1,output:eth_r${rail}_p2,output:eth_r${rail}_p3"
  sleep 3
done
