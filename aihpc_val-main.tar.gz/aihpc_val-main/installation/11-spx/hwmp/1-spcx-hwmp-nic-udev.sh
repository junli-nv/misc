#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

# RA ref: https://apps.nvidia.com/PID/ContentLibraries/Detail/1155985
#
export PATH=/usr/sbin:/sbin:/usr/bin:/bin:/usr/local/sbin:/usr/local/bin

### CX8 PCI addresses
# 0000:03:00.0 Ethernet controller: Mellanox Technologies CX8 Family [ConnectX-8]
# 0000:03:00.1 Ethernet controller: Mellanox Technologies CX8 Family [ConnectX-8]
# 0000:03:00.2 Ethernet controller: Mellanox Technologies CX8 Family [ConnectX-8]
# 0000:03:00.3 Ethernet controller: Mellanox Technologies CX8 Family [ConnectX-8]
# 0000:03:00.4 Ethernet controller: Mellanox Technologies ConnectX Family mlx5Gen Virtual Function
# 0002:03:00.0 Ethernet controller: Mellanox Technologies CX8 Family [ConnectX-8]
# 0002:03:00.1 Ethernet controller: Mellanox Technologies CX8 Family [ConnectX-8]
# 0002:03:00.2 Ethernet controller: Mellanox Technologies CX8 Family [ConnectX-8]
# 0002:03:00.3 Ethernet controller: Mellanox Technologies CX8 Family [ConnectX-8]
# 0002:03:00.4 Ethernet controller: Mellanox Technologies ConnectX Family mlx5Gen Virtual Function
# 0010:03:00.0 Ethernet controller: Mellanox Technologies CX8 Family [ConnectX-8]
# 0010:03:00.1 Ethernet controller: Mellanox Technologies CX8 Family [ConnectX-8]
# 0010:03:00.2 Ethernet controller: Mellanox Technologies CX8 Family [ConnectX-8]
# 0010:03:00.3 Ethernet controller: Mellanox Technologies CX8 Family [ConnectX-8]
# 0010:03:00.4 Ethernet controller: Mellanox Technologies ConnectX Family mlx5Gen Virtual Function
# 0012:03:00.0 Ethernet controller: Mellanox Technologies CX8 Family [ConnectX-8]
# 0012:03:00.1 Ethernet controller: Mellanox Technologies CX8 Family [ConnectX-8]
# 0012:03:00.2 Ethernet controller: Mellanox Technologies CX8 Family [ConnectX-8]
# 0012:03:00.3 Ethernet controller: Mellanox Technologies CX8 Family [ConnectX-8]
# 0012:03:00.4 Ethernet controller: Mellanox Technologies ConnectX Family mlx5Gen Virtual Function
# 0016:01:00.0 Ethernet controller: Mellanox Technologies MT43244 BlueField-3 integrated ConnectX-7 network controller (rev 01)
# 0016:01:00.1 Ethernet controller: Mellanox Technologies MT43244 BlueField-3 integrated ConnectX-7 network controller (rev 01)

cat > /etc/udev/rules.d/60-rdma-persistent-naming.rules <<- EOF
ACTION=="add", KERNELS=="0000:03:00.0", SUBSYSTEM=="infiniband", PROGRAM="rdma_rename %k NAME_FIXED roce_r0"
ACTION=="add", KERNELS=="0000:03:00.4", SUBSYSTEM=="infiniband", PROGRAM="rdma_rename %k NAME_FIXED roce_vf_r0"

ACTION=="add", KERNELS=="0002:03:00.0", SUBSYSTEM=="infiniband", PROGRAM="rdma_rename %k NAME_FIXED roce_r1"
ACTION=="add", KERNELS=="0002:03:00.4", SUBSYSTEM=="infiniband", PROGRAM="rdma_rename %k NAME_FIXED roce_vf_r1"

ACTION=="add", KERNELS=="0010:03:00.0", SUBSYSTEM=="infiniband", PROGRAM="rdma_rename %k NAME_FIXED roce_r2"
ACTION=="add", KERNELS=="0010:03:00.4", SUBSYSTEM=="infiniband", PROGRAM="rdma_rename %k NAME_FIXED roce_vf_r2"

ACTION=="add", KERNELS=="0012:03:00.0", SUBSYSTEM=="infiniband", PROGRAM="rdma_rename %k NAME_FIXED roce_r3"
ACTION=="add", KERNELS=="0012:03:00.4", SUBSYSTEM=="infiniband", PROGRAM="rdma_rename %k NAME_FIXED roce_vf_r3"
EOF

cat > /etc/udev/rules.d/70-net-persistent-naming.rules <<- EOF
ACTION=="add", KERNELS=="0000:03:00.0", SUBSYSTEM=="net", NAME="eth_r0_p0"
ACTION=="add", KERNELS=="0000:03:00.1", SUBSYSTEM=="net", NAME="eth_r0_p1"
ACTION=="add", KERNELS=="0000:03:00.2", SUBSYSTEM=="net", NAME="eth_r0_p2"
ACTION=="add", KERNELS=="0000:03:00.3", SUBSYSTEM=="net", NAME="eth_r0_p3"
ACTION=="add", KERNELS=="0000:03:00.4", SUBSYSTEM=="net", NAME="eth_vf_r0"

ACTION=="add", KERNELS=="0002:03:00.0", SUBSYSTEM=="net", NAME="eth_r1_p0"
ACTION=="add", KERNELS=="0002:03:00.1", SUBSYSTEM=="net", NAME="eth_r1_p1"
ACTION=="add", KERNELS=="0002:03:00.2", SUBSYSTEM=="net", NAME="eth_r1_p2"
ACTION=="add", KERNELS=="0002:03:00.3", SUBSYSTEM=="net", NAME="eth_r1_p3"
ACTION=="add", KERNELS=="0002:03:00.4", SUBSYSTEM=="net", NAME="eth_vf_r1"

ACTION=="add", KERNELS=="0010:03:00.0", SUBSYSTEM=="net", NAME="eth_r2_p0"
ACTION=="add", KERNELS=="0010:03:00.1", SUBSYSTEM=="net", NAME="eth_r2_p1"
ACTION=="add", KERNELS=="0010:03:00.2", SUBSYSTEM=="net", NAME="eth_r2_p2"
ACTION=="add", KERNELS=="0010:03:00.3", SUBSYSTEM=="net", NAME="eth_r2_p3"
ACTION=="add", KERNELS=="0010:03:00.4", SUBSYSTEM=="net", NAME="eth_vf_r2"

ACTION=="add", KERNELS=="0012:03:00.0", SUBSYSTEM=="net", NAME="eth_r3_p0"
ACTION=="add", KERNELS=="0012:03:00.1", SUBSYSTEM=="net", NAME="eth_r3_p1"
ACTION=="add", KERNELS=="0012:03:00.2", SUBSYSTEM=="net", NAME="eth_r3_p2"
ACTION=="add", KERNELS=="0012:03:00.3", SUBSYSTEM=="net", NAME="eth_r3_p3"
ACTION=="add", KERNELS=="0012:03:00.4", SUBSYSTEM=="net", NAME="eth_vf_r3"

ACTION=="add", KERNELS=="0000:03:00.0", SUBSYSTEM=="net", NAME="eth_r0_p0"
ACTION=="add", KERNELS=="0000:03:00.1", SUBSYSTEM=="net", NAME="eth_r0_p1"
ACTION=="add", KERNELS=="0000:03:00.2", SUBSYSTEM=="net", NAME="eth_r0_p2"
ACTION=="add", KERNELS=="0000:03:00.3", SUBSYSTEM=="net", NAME="eth_r0_p3"
ACTION=="add", KERNELS=="0000:03:00.4", SUBSYSTEM=="net", NAME="eth_vf_r0"

ACTION=="add", KERNELS=="0002:03:00.0", SUBSYSTEM=="net", NAME="eth_r1_p0"
ACTION=="add", KERNELS=="0002:03:00.1", SUBSYSTEM=="net", NAME="eth_r1_p1"
ACTION=="add", KERNELS=="0002:03:00.2", SUBSYSTEM=="net", NAME="eth_r1_p2"
ACTION=="add", KERNELS=="0002:03:00.3", SUBSYSTEM=="net", NAME="eth_r1_p3"
ACTION=="add", KERNELS=="0002:03:00.4", SUBSYSTEM=="net", NAME="eth_vf_r1"

ACTION=="add", KERNELS=="0010:03:00.0", SUBSYSTEM=="net", NAME="eth_r2_p0"
ACTION=="add", KERNELS=="0010:03:00.1", SUBSYSTEM=="net", NAME="eth_r2_p1"
ACTION=="add", KERNELS=="0010:03:00.2", SUBSYSTEM=="net", NAME="eth_r2_p2"
ACTION=="add", KERNELS=="0010:03:00.3", SUBSYSTEM=="net", NAME="eth_r2_p3"
ACTION=="add", KERNELS=="0010:03:00.4", SUBSYSTEM=="net", NAME="eth_vf_r2"

ACTION=="add", KERNELS=="0012:03:00.0", SUBSYSTEM=="net", NAME="eth_r3_p0"
ACTION=="add", KERNELS=="0012:03:00.1", SUBSYSTEM=="net", NAME="eth_r3_p1"
ACTION=="add", KERNELS=="0012:03:00.2", SUBSYSTEM=="net", NAME="eth_r3_p2"
ACTION=="add", KERNELS=="0012:03:00.3", SUBSYSTEM=="net", NAME="eth_r3_p3"
ACTION=="add", KERNELS=="0012:03:00.4", SUBSYSTEM=="net", NAME="eth_vf_r3"
EOF

udevadm control --reload-rules
udevadm trigger --action=add --subsystem-match=infiniband
udevadm trigger --action=add --subsystem-match=net
udevadm settle --timeout=15