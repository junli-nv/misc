#!/usr/bin/env bash

set -u

OVS_PLANES=(0 1 2 3)
OVS_EXPECTED_GROUP_IDS=(10 20 21 22 23 30 31 32 33)

MST_CONNECTX8_OUTPUT=""
MST_CONFIG_DEVICES=()
PF_MST_DEVICES=()
PF_PCI_ADDRS=()
PF_NET_NAMES=()
MAIN_PCI_ADDRS=()
MAIN_NET_NAMES=()
MAIN_VF_REP_NAMES=()
RDMA_NAMES=()

LOG_FILE="${LOG_FILE:-combined_config_check.log}"
LOG_INITIALIZED=0

# Expected Current-column values for mlxconfig.
# Values are normalized before comparison:
#   0x1(1) -> 1
#   ETH(2) -> 2
#   PRE_ALLOCATION(1) -> 1
MLXCONFIG_CURRENT_EXPECTATIONS=(
    "MODULE_SPLIT_M0[0]=1"
    "MODULE_SPLIT_M0[1]=1"
    "MODULE_SPLIT_M0[2]=1"
    "MODULE_SPLIT_M0[3]=1"
    "MODULE_SPLIT_M0[4]=1"
    "MODULE_SPLIT_M0[5]=1"
    "MODULE_SPLIT_M0[6]=1"
    "MODULE_SPLIT_M0[7]=1"
    "LINK_TYPE_P1=2"
    "NUM_OF_PLANES_P1=4"
    "NUM_OF_PF=4"
    "LAG_RESOURCE_ALLOCATION=1"
)

PF_MLXCONFIG_PARAMS=(
    ROCE_ADAPTIVE_ROUTING_EN
    USER_PROGRAMMABLE_CC
    TX_SCHEDULER_LOCALITY_MODE
    ROCE_RTT_RESP_DSCP_P1
    ROCE_RTT_RESP_DSCP_MODE_P1
    ROCE_CC_STEERING_EXT
    RDE_DISABLE
    FLEX_PARSER_PROFILE_ENABLE
    VF_LOG_BAR_SIZE
    SRIOV_EN
    NUM_OF_VFS
)

# Expected Current-column values for per-PF mlxconfig checks.
# Values are normalized before comparison:
#   True(1) -> 1
#   ACCUMULATIVE(2) -> 2
#   ENABLED(2) -> 2
PF_MLXCONFIG_CURRENT_EXPECTATIONS=(
    "ROCE_ADAPTIVE_ROUTING_EN=1"
    "USER_PROGRAMMABLE_CC=1"
    "TX_SCHEDULER_LOCALITY_MODE=2"
    "ROCE_RTT_RESP_DSCP_P1=48"
    "ROCE_RTT_RESP_DSCP_MODE_P1=1"
    "ROCE_CC_STEERING_EXT=2"
    "RDE_DISABLE=1"
    "FLEX_PARSER_PROFILE_ENABLE=10"
    "VF_LOG_BAR_SIZE=5"
    "SRIOV_EN=1"
    "NUM_OF_VFS=1"
)

MLNX_QOS_EXPECTED_PRIORITY_TRUST="dscp"
MLNX_QOS_EXPECTED_PFC_ENABLED="0 0 0 1 0 0 0 0"
MLNX_QOS_EXPECTED_PFC_BUFFER="0 0 0 1 0 0 0 0"
MLNX_QOS_EXPECTED_ECN_ENABLE="1"

ROCE_ACCL_FIELDS='roce_adp_retrans_en|roce_tx_window_en|roce_slow_restart_en|roce_slow_restart_idle_en|adaptive_routing_forced_en|adaptive_routing_forced_en_field_select|cc_per_plane_en|cc_probe_mp_mode|cc_per_plane_en_field_select|cc_probe_mp_mode_field_select'
ROCE_ACCL_EXPECTATIONS=(
    "adaptive_routing_forced_en_field_select=1"
    "cc_per_plane_en_field_select=1"
    "cc_probe_mp_mode_field_select=1"
    "roce_adp_retrans_en=1"
    "roce_tx_window_en=1"
    "roce_slow_restart_en=0"
    "roce_slow_restart_idle_en=0"
    "adaptive_routing_forced_en=1"
    "cc_per_plane_en=1"
    "cc_probe_mp_mode=1"
)
PPCC_CMD6_PARAM_INDEXES=({0..18} 22 23 24)
PPCC_CMD3_ALGO_SLOTS=(0 15)
PPCC_CMD3_PARAM_INDEXES=(0 0)
PPCC_CMD3_EXPECTED_VALUES=(
    "0x00000001"
    "0x00000000"
)
PPCC_CMD6_EXPECTED_VALUES=(
    "0x000000c8"
    "0x00001999"
    "0x0000f852"
    "0x00010f5c"
    "0x00000024"
    "0x000004b0"
    "0x006acfc0"
    "0x00003a98"
    "0x0003d090"
    "0x00080000"
    "0x00000000"
    "0x00000001"
    "0x00000000"
    "0x00000000"
    "0x00200000"
    "0x00000001"
    "0x00000001"
    "0x00000000"
    "0x00000000"
    "0x00000001"
    "0x00000003"
    "0x00000001"
)
CHECK_FAILURES=0

usage() {
    cat <<'EOF'
Usage:
  ./combined_config_check.sh [all|mlxconfig|pf-mlxconfig|roce|devlink|vf|mlnx-qos|ovs|pcc]

Checks:
  all           Run all checks. This is the default.
  mlxconfig     Query mlxconfig settings on /dev/mst/mt4131_pciconf0..3.
  pf-mlxconfig  Query mlxconfig settings on all configured PFs.
  roce          Query ROCE_ACCL and PPCC settings on all configured PFs.
  devlink       Query switchdev and esw_multiport settings on all configured PFs.
  vf            Check virtfn0 net name is non-empty and PCI_SLOT_NAME is last PF + 1.
  mlnx-qos      Check QoS PFC/trust and ECN roce_rp/roce_np enable values.
  ovs           Show OVS config, groups, and flows for br-rail0..br-rail3.
  pcc           Check doca_spcx_cc process exists for each discovered RDMA bond.

Before running checks, the script runs:
  mst start
  mst status -v | grep ConnectX8

The ConnectX8 status output is parsed to discover MST devices, PCI addresses,
RDMA main PF addresses, and PF net names used by later checks.
EOF
}

init_logging() {
    if ! : > "$LOG_FILE"; then
        printf 'FAIL: cannot write log file: %s\n' "$LOG_FILE" >&2
        exit 1
    fi

    exec 3>&1
    exec >>"$LOG_FILE" 2>&1
    LOG_INITIALIZED=1

    printf '========== combined_config_check raw command log ==========\n'
    printf 'Log file: %s\n' "$LOG_FILE"
    printf 'Started at: %s\n' "$(date '+%Y-%m-%d %H:%M:%S %Z')"
}

section() {
    printf '\n========== %s ==========\n' "$1"
}

print_pass() {
    printf 'PASS: %s\n' "$*"
}

print_fail() {
    CHECK_FAILURES=$((CHECK_FAILURES + 1))
    printf 'FAIL: %s\n' "$*"
}

print_item_result() {
    local status="$1"
    local message="$2"

    printf '%s: %s\n' "$status" "$message"

    if [[ "$LOG_INITIALIZED" -eq 1 ]]; then
        printf '%s: %s\n' "$status" "$message" >&3
    fi
}

run_check_item() {
    local item_name="$1"
    shift

    local before_failures="$CHECK_FAILURES"
    local rc
    local item_failures

    "$@"
    rc=$?

    item_failures=$((CHECK_FAILURES - before_failures))
    if [[ "$rc" -ne 0 && "$item_failures" -eq 0 ]]; then
        print_fail "$item_name returned rc=$rc"
        item_failures=$((CHECK_FAILURES - before_failures))
    fi

    if [[ "$item_failures" -eq 0 ]]; then
        print_item_result "PASS" "$item_name"
    else
        print_item_result "FAIL" "$item_name failures=$item_failures"
    fi

    return "$rc"
}

extract_pf_net_name() {
    local line="$1"
    local token
    local item
    local names
    local name

    for token in $line; do
        [[ "$token" == net-* ]] || continue

        names="${token#net-}"
        IFS=',' read -ra item <<<"$names"

        for name in "${item[@]}"; do
            name="${name#net-}"
            if [[ "$name" =~ _p[0-9]+$ ]]; then
                printf '%s\n' "$name"
                return 0
            fi
        done

        name="${item[0]#net-}"
        if [[ -n "$name" ]]; then
            printf '%s\n' "$name"
            return 0
        fi
    done

    return 1
}

extract_vf_rep_net_name() {
    local line="$1"
    local token
    local item
    local names
    local name

    for token in $line; do
        [[ "$token" == net-* ]] || continue

        names="${token#net-}"
        IFS=',' read -ra item <<<"$names"

        for name in "${item[@]}"; do
            name="${name#net-}"
            if [[ "$name" == eth_vf_rep* ]]; then
                printf '%s\n' "$name"
                return 0
            fi
        done
    done

    return 1
}

parse_mst_connectx8_output() {
    local line
    local mst_dev
    local pci_addr
    local rdma_name
    local net_name
    local vf_rep_name

    MST_CONFIG_DEVICES=()
    PF_MST_DEVICES=()
    PF_PCI_ADDRS=()
    PF_NET_NAMES=()
    MAIN_PCI_ADDRS=()
    MAIN_NET_NAMES=()
    MAIN_VF_REP_NAMES=()
    RDMA_NAMES=()

    while IFS= read -r line; do
        [[ -n "$line" ]] || continue

        set -- $line
        mst_dev="${2:-}"
        pci_addr="${3:-}"
        rdma_name=""
        net_name=""
        vf_rep_name=""

        [[ -n "$mst_dev" && -n "$pci_addr" ]] || continue

        if [[ "$pci_addr" == *.0 && "${4:-}" != net-* ]]; then
            rdma_name="${4:-}"
        fi

        if ! net_name="$(extract_pf_net_name "$line")"; then
            net_name=""
        fi

        if ! vf_rep_name="$(extract_vf_rep_net_name "$line")"; then
            vf_rep_name=""
        fi

        PF_MST_DEVICES+=("$mst_dev")
        PF_PCI_ADDRS+=("$pci_addr")
        PF_NET_NAMES+=("$net_name")

        if [[ "$pci_addr" == *.0 ]]; then
            MST_CONFIG_DEVICES+=("$mst_dev")
            MAIN_PCI_ADDRS+=("$pci_addr")
            MAIN_NET_NAMES+=("$net_name")
            MAIN_VF_REP_NAMES+=("$vf_rep_name")
            RDMA_NAMES+=("$rdma_name")
        fi
    done <<<"$MST_CONNECTX8_OUTPUT"
}

discover_mst_devices() {
    local output
    local status_output
    local idx

    section "MST discovery"

    printf '[mst start]\n'
    if ! output="$(mst start 2>&1)"; then
        printf '%s\n' "$output"
        print_fail "mst start failed"
    else
        printf '%s\n' "$output"
    fi

    printf '\n[mst status -v | grep ConnectX8]\n'
    if ! status_output="$(mst status -v 2>&1)"; then
        printf '%s\n' "$status_output"
        print_fail "mst status -v failed"
        return 1
    fi

    MST_CONNECTX8_OUTPUT="$(printf '%s\n' "$status_output" | grep 'ConnectX8' || true)"

    if [[ -z "$MST_CONNECTX8_OUTPUT" ]]; then
        print_fail "no ConnectX8 devices found in mst status output"
        return 1
    fi

    printf '%s\n' "$MST_CONNECTX8_OUTPUT"
    parse_mst_connectx8_output

    printf '\nDiscovered main MST devices:\n'
    for idx in "${!MST_CONFIG_DEVICES[@]}"; do
        printf '  %s  pci=%s  rdma=%s  net=%s\n' \
            "${MST_CONFIG_DEVICES[$idx]}" \
            "${MAIN_PCI_ADDRS[$idx]:-}" \
            "${RDMA_NAMES[$idx]:-}" \
            "${MAIN_NET_NAMES[$idx]:-}"
        printf '    vf_rep=%s\n' "${MAIN_VF_REP_NAMES[$idx]:-}"
    done

    printf '\nDiscovered PFs:\n'
    for idx in "${!PF_PCI_ADDRS[@]}"; do
        printf '  %s  mst=%s  net=%s\n' \
            "${PF_PCI_ADDRS[$idx]}" \
            "${PF_MST_DEVICES[$idx]:-}" \
            "${PF_NET_NAMES[$idx]:-}"
    done
}

normalize_mlxconfig_value() {
    local value="$1"
    local normalized

    value="${value%$'\r'}"

    if [[ "$value" == *"("*")"* ]]; then
        normalized="${value##*(}"
        normalized="${normalized%%)*}"
        printf '%s\n' "$normalized"
    else
        printf '%s\n' "$value"
    fi
}

get_mlxconfig_current_value() {
    local key="$1"

    awk -v key="$key" '
        $1 == "*" && $2 == key {
            print $4
            found = 1
            exit
        }
        $1 == key {
            print $3
            found = 1
            exit
        }
        END {
            if (!found) {
                exit 1
            }
        }
    '
}

check_mlxconfig_expectations() {
    local dev="$1"
    local output="$2"
    shift 2

    local expectations=("$@")
    local expectation
    local key
    local expected
    local actual
    local actual_normalized
    local expected_normalized

    if [[ "${#expectations[@]}" -eq 0 ]]; then
        return 0
    fi

    printf '\n[%s] Checking mlxconfig Current column\n' "$dev"

    for expectation in "${expectations[@]}"; do
        key="${expectation%%=*}"
        expected="${expectation#*=}"

        if ! actual="$(get_mlxconfig_current_value "$key" <<<"$output")"; then
            print_fail "$dev $key missing from mlxconfig output"
            continue
        fi

        actual_normalized="$(normalize_mlxconfig_value "$actual")"
        expected_normalized="$(normalize_mlxconfig_value "$expected")"

        if [[ "$actual_normalized" == "$expected_normalized" ]]; then
            print_pass "$dev $key current=$actual expected=$expected"
        else
            print_fail "$dev $key current=$actual expected=$expected"
        fi
    done
}

check_mlxconfig() {
    section "mlxconfig"

    local dev
    local output
    local rc

    for dev in "${MST_CONFIG_DEVICES[@]}"; do
        printf '\n----- %s -----\n' "$dev"
        output="$(mlxconfig -d "$dev" -e q \
            "MODULE_SPLIT_M0[0..7]" \
            LINK_TYPE_P1 \
            NUM_OF_PLANES_P1 \
            NUM_OF_PF \
            LAG_RESOURCE_ALLOCATION 2>&1)"
        rc=$?

        printf '%s\n' "$output"

        if [[ "$rc" -ne 0 ]]; then
            print_fail "$dev mlxconfig command failed with rc=$rc"
            continue
        fi

        check_mlxconfig_expectations "$dev" "$output" "${MLXCONFIG_CURRENT_EXPECTATIONS[@]}"
    done
}

check_pf_mlxconfig() {
    section "PF mlxconfig"

    local pf
    local output
    local rc

    for pf in "${PF_PCI_ADDRS[@]}"; do
        printf '\n----- %s -----\n' "$pf"

        output="$(mlxconfig -d "$pf" -e q "${PF_MLXCONFIG_PARAMS[@]}" 2>&1)"
        rc=$?

        printf '%s\n' "$output"

        if [[ "$rc" -ne 0 ]]; then
            print_fail "$pf pf mlxconfig command failed with rc=$rc"
            continue
        fi

        check_mlxconfig_expectations "$pf" "$output" "${PF_MLXCONFIG_CURRENT_EXPECTATIONS[@]}"
    done
}

get_pipe_value() {
    local output="$1"
    local key="$2"

    awk -F '|' -v key="$key" '
        {
            left = $1
            right = $2
            gsub(/^[ \t]+|[ \t]+$/, "", left)
            gsub(/^[ \t]+|[ \t]+$/, "", right)
            if (left == key) {
                print right
                found = 1
                exit
            }
        }
        END {
            if (!found) {
                exit 1
            }
        }
    ' <<<"$output"
}

normalize_numeric_value() {
    local value="$1"
    local hex_value

    value="${value%%,*}"
    value="${value%%;*}"
    value="${value%%)*}"
    value="${value##*(}"
    value="${value%%[[:space:]]*}"

    case "$value" in
        0x*|0X*)
            hex_value="${value#0x}"
            hex_value="${hex_value#0X}"
            printf '%d\n' "$((16#$hex_value))"
            ;;
        "")
            printf '\n'
            ;;
        *[!0-9]*)
            printf '%s\n' "$value"
            ;;
        *)
            printf '%d\n' "$((10#$value))"
            ;;
    esac
}

check_roce_accl_output() {
    local pf="$1"
    local output="$2"
    local expectation
    local key
    local expected
    local actual
    local actual_normalized
    local expected_normalized

    printf '\n[%s] Checking ROCE_ACCL values\n' "$pf"

    for expectation in "${ROCE_ACCL_EXPECTATIONS[@]}"; do
        key="${expectation%%=*}"
        expected="${expectation#*=}"

        if ! actual="$(get_pipe_value "$output" "$key")"; then
            print_fail "$pf ROCE_ACCL $key missing"
            continue
        fi

        actual_normalized="$(normalize_numeric_value "$actual")"
        expected_normalized="$(normalize_numeric_value "$expected")"

        if [[ "$actual_normalized" == "$expected_normalized" ]]; then
            print_pass "$pf ROCE_ACCL $key raw=$actual decimal=$actual_normalized expected_decimal=$expected_normalized"
        else
            print_fail "$pf ROCE_ACCL $key raw=$actual decimal=$actual_normalized expected_decimal=$expected_normalized"
        fi
    done
}

run_ppcc_value_check() {
    local pf="$1"
    local cmd_type="$2"
    local algo_slot="$3"
    local algo_param_index="$4"
    local expected="$5"
    local label
    local raw_output
    local value_output
    local actual
    local actual_normalized
    local expected_normalized
    local rc

    label="PPCC cmd_type=${cmd_type} algo_slot=${algo_slot} algo_param_index=${algo_param_index}"
    printf '\n[%s]\n' "$label"

    raw_output="$(mlxreg -d "$pf" -y --set "cmd_type=${cmd_type}" --reg_name PPCC \
        --indexes "local_port=1,pnat=0,lp_msb=0,algo_slot=${algo_slot},algo_param_index=${algo_param_index}" 2>&1)"
    rc=$?
    value_output="$(grep "value " <<<"$raw_output" || true)"

    if [[ -n "$value_output" ]]; then
        printf '%s\n' "$value_output"
    else
        printf '%s\n' "$raw_output"
    fi

    if [[ "$rc" -ne 0 ]]; then
        print_fail "$pf $label command failed with rc=$rc"
        return
    fi

    if [[ -z "$value_output" ]]; then
        print_fail "$pf $label missing value output"
        return
    fi

    if ! actual="$(get_pipe_value "$value_output" "value")"; then
        print_fail "$pf $label cannot parse value output"
        return
    fi

    actual_normalized="$(normalize_numeric_value "$actual")"
    expected_normalized="$(normalize_numeric_value "$expected")"

    if [[ "$actual_normalized" == "$expected_normalized" ]]; then
        print_pass "$pf $label raw=$actual decimal=$actual_normalized expected_raw=$expected expected_decimal=$expected_normalized"
    else
        print_fail "$pf $label raw=$actual decimal=$actual_normalized expected_raw=$expected expected_decimal=$expected_normalized"
    fi
}

check_roce_and_ppcc() {
    section "ROCE_ACCL and PPCC"

    local pf
    local idx
    local check_idx
    local roce_accl_output
    local rc

    if [[ "${#PPCC_CMD3_ALGO_SLOTS[@]}" -ne "${#PPCC_CMD3_EXPECTED_VALUES[@]}" ]] ||
        [[ "${#PPCC_CMD3_PARAM_INDEXES[@]}" -ne "${#PPCC_CMD3_EXPECTED_VALUES[@]}" ]]; then
        print_fail "PPCC cmd_type=3 expectation array length mismatch"
        return
    fi

    if [[ "${#PPCC_CMD6_PARAM_INDEXES[@]}" -ne "${#PPCC_CMD6_EXPECTED_VALUES[@]}" ]]; then
        print_fail "PPCC cmd_type=6 expectation array length mismatch"
        return
    fi

    for pf in "${PF_PCI_ADDRS[@]}"; do
        printf '\n----- %s -----\n' "$pf"

        roce_accl_output="$(mlxreg -d "$pf" --get --reg_name ROCE_ACCL 2>&1 | grep -E "$ROCE_ACCL_FIELDS")"
        rc=$?
        printf '%s\n' "$roce_accl_output"

        if [[ "$rc" -ne 0 ]]; then
            print_fail "$pf ROCE_ACCL query failed or returned no matching fields"
        else
            check_roce_accl_output "$pf" "$roce_accl_output"
        fi

        for check_idx in "${!PPCC_CMD3_ALGO_SLOTS[@]}"; do
            run_ppcc_value_check \
                "$pf" \
                3 \
                "${PPCC_CMD3_ALGO_SLOTS[$check_idx]}" \
                "${PPCC_CMD3_PARAM_INDEXES[$check_idx]}" \
                "${PPCC_CMD3_EXPECTED_VALUES[$check_idx]}"
        done

        for check_idx in "${!PPCC_CMD6_PARAM_INDEXES[@]}"; do
            idx="${PPCC_CMD6_PARAM_INDEXES[$check_idx]}"
            run_ppcc_value_check \
                "$pf" \
                6 \
                0 \
                "$idx" \
                "${PPCC_CMD6_EXPECTED_VALUES[$check_idx]}"
        done
    done
}

check_devlink() {
    section "devlink"

    local pf

    for pf in "${PF_PCI_ADDRS[@]}"; do
        printf '\n[%s] switchdev setting\n' "$pf"
        devlink dev eswitch show "pci/${pf}"

        printf '[%s] esw_multiport setting\n' "$pf"
        devlink dev param show "pci/${pf}" name esw_multiport
    done
}

normalize_space_list() {
    local value="$1"

    awk '{$1=$1; print}' <<<"$value"
}

extract_mlnx_qos_priority_trust() {
    local output="$1"

    awk -F ':' '
        /^[[:space:]]*Priority trust state:/ {
            value = $2
            gsub(/^[ \t]+|[ \t]+$/, "", value)
            print value
            exit
        }
    ' <<<"$output"
}

extract_mlnx_qos_pfc_row() {
    local output="$1"
    local row_name="$2"

    awk -v row_name="$row_name" '
        /^[[:space:]]*PFC configuration:/ {
            in_pfc = 1
            next
        }
        in_pfc && $1 == row_name {
            for (idx = 2; idx <= NF; idx++) {
                values = values (values ? " " : "") $idx
            }
            print values
            exit
        }
        in_pfc && NF == 0 {
            exit
        }
    ' <<<"$output"
}

check_sysfs_value() {
    local path="$1"
    local expected="$2"
    local label="$3"
    local output
    local rc
    local actual

    output="$(cat "$path" 2>&1)"
    rc=$?
    printf '%s\n' "$output"

    if [[ "$rc" -ne 0 ]]; then
        print_fail "$label read failed from $path with rc=$rc"
        return 1
    fi

    actual="$(normalize_space_list "$output")"

    if [[ "$actual" == "$expected" ]]; then
        print_pass "$label=$actual expected=$expected"
        return 0
    fi

    print_fail "$label=$actual expected=$expected path=$path"
    return 1
}

check_mlnx_qos() {
    section "mlnx_qos"

    local net_iface
    local output
    local rc
    local priority_trust
    local pfc_enabled
    local pfc_buffer
    local expected_pfc_enabled
    local expected_pfc_buffer
    local point
    local tc
    local path
    local label

    for net_iface in "${PF_NET_NAMES[@]}"; do
        [[ -n "$net_iface" ]] || continue

        printf '\n----- %s -----\n' "$net_iface"
        output="$(mlnx_qos -i "$net_iface" 2>&1)"
        rc=$?

        printf '%s\n' "$output"

        if [[ "$rc" -ne 0 ]]; then
            print_fail "$net_iface mlnx_qos command failed with rc=$rc"
            continue
        fi

        priority_trust="$(extract_mlnx_qos_priority_trust "$output")"
        if [[ "$priority_trust" == "$MLNX_QOS_EXPECTED_PRIORITY_TRUST" ]]; then
            print_pass "$net_iface Priority trust state=$priority_trust expected=$MLNX_QOS_EXPECTED_PRIORITY_TRUST"
        else
            print_fail "$net_iface Priority trust state=${priority_trust:-MISSING} expected=$MLNX_QOS_EXPECTED_PRIORITY_TRUST"
        fi

        pfc_enabled="$(normalize_space_list "$(extract_mlnx_qos_pfc_row "$output" enabled)")"
        expected_pfc_enabled="$(normalize_space_list "$MLNX_QOS_EXPECTED_PFC_ENABLED")"

        if [[ -z "$pfc_enabled" ]]; then
            print_fail "$net_iface PFC enabled row missing"
        elif [[ "$pfc_enabled" == "$expected_pfc_enabled" ]]; then
            print_pass "$net_iface PFC enabled=$pfc_enabled expected=$expected_pfc_enabled"
        else
            print_fail "$net_iface PFC enabled=$pfc_enabled expected=$expected_pfc_enabled"
        fi

        pfc_buffer="$(normalize_space_list "$(extract_mlnx_qos_pfc_row "$output" buffer)")"
        expected_pfc_buffer="$(normalize_space_list "$MLNX_QOS_EXPECTED_PFC_BUFFER")"

        if [[ -z "$pfc_buffer" ]]; then
            print_fail "$net_iface PFC buffer row missing"
        elif [[ "$pfc_buffer" == "$expected_pfc_buffer" ]]; then
            print_pass "$net_iface PFC buffer=$pfc_buffer expected=$expected_pfc_buffer"
        else
            print_fail "$net_iface PFC buffer=$pfc_buffer expected=$expected_pfc_buffer"
        fi

        for point in rp np; do
            for tc in 0 1 2 3 4 5 6 7; do
                path="/sys/class/net/${net_iface}/ecn/roce_${point}/enable/${tc}"
                label="${net_iface} ECN roce_${point}/enable/${tc}"
                check_sysfs_value "$path" "$MLNX_QOS_EXPECTED_ECN_ENABLE" "$label"
            done
        done
    done
}

expected_vf_pci_addr() {
    local main_pci="$1"
    local base="${main_pci%.*}"
    local pf
    local pf_base
    local fn
    local max_fn=-1

    for pf in "${PF_PCI_ADDRS[@]}"; do
        pf_base="${pf%.*}"
        fn="${pf##*.}"

        [[ "$pf_base" == "$base" ]] || continue
        [[ "$fn" =~ ^[0-9]+$ ]] || continue

        if (( 10#$fn > max_fn )); then
            max_fn=$((10#$fn))
        fi
    done

    if (( max_fn < 0 )); then
        return 1
    fi

    printf '%s.%s\n' "$base" "$((max_fn + 1))"
}

check_vf_mapping() {
    section "VF mapping"

    local idx
    local net_iface
    local main_pci
    local expected_pci
    local vf_net_output
    local pci_slot_output
    local actual_pci
    local rc

    for idx in "${!MAIN_NET_NAMES[@]}"; do
        net_iface="${MAIN_NET_NAMES[$idx]}"
        main_pci="${MAIN_PCI_ADDRS[$idx]:-}"
        [[ -n "$net_iface" ]] || continue

        printf '\n----- %s -----\n' "$net_iface"

        vf_net_output="$(ls "/sys/class/net/${net_iface}/device/virtfn0/net" 2>&1)"
        rc=$?
        printf '%s\n' "$vf_net_output"

        if [[ "$rc" -ne 0 ]]; then
            print_fail "$net_iface virtfn0 net lookup failed with rc=$rc"
        elif [[ -n "${vf_net_output//[[:space:]]/}" ]]; then
            print_pass "$net_iface vf net name is not empty: $vf_net_output"
        else
            print_fail "$net_iface vf net name is empty"
        fi

        pci_slot_output="$(grep '^PCI_SLOT_NAME=' "/sys/class/net/${net_iface}/device/virtfn0/uevent" 2>&1)"
        rc=$?
        printf '%s\n' "$pci_slot_output"

        if [[ "$rc" -ne 0 ]]; then
            print_fail "$net_iface PCI_SLOT_NAME lookup failed with rc=$rc"
            continue
        fi

        actual_pci="${pci_slot_output#PCI_SLOT_NAME=}"

        if ! expected_pci="$(expected_vf_pci_addr "$main_pci")"; then
            print_fail "$net_iface cannot calculate expected VF PCI from main PF PCI $main_pci"
            continue
        fi

        if [[ "$actual_pci" == "$expected_pci" ]]; then
            print_pass "$net_iface vf PCI_SLOT_NAME=$actual_pci expected=$expected_pci"
        else
            print_fail "$net_iface vf PCI_SLOT_NAME=$actual_pci expected=$expected_pci"
        fi
    done
}

get_rail_from_net_name() {
    local net_name="$1"

    if [[ "$net_name" =~ _r([0-9]+)_p[0-9]+$ ]]; then
        printf '%s\n' "${BASH_REMATCH[1]}"
        return 0
    fi

    if [[ "$net_name" =~ eth_vf_rep_r([0-9]+)$ ]]; then
        printf '%s\n' "${BASH_REMATCH[1]}"
        return 0
    fi

    return 1
}

ovs_bridge_exists() {
    local output="$1"
    local bridge="$2"

    awk -v bridge="$bridge" '$1 == "Bridge" && $2 == bridge {found = 1} END {exit found ? 0 : 1}' <<<"$output"
}

extract_ovs_bridge_block() {
    local output="$1"
    local bridge="$2"

    awk -v bridge="$bridge" '
        $1 == "Bridge" && $2 == bridge {
            in_bridge = 1
            print
            next
        }
        in_bridge && $1 == "Bridge" {
            exit
        }
        in_bridge {
            print
        }
    ' <<<"$output"
}

check_ovs_bridge_datapath() {
    local bridge="$1"
    local block="$2"
    local datapath_type

    datapath_type="$(awk '$1 == "datapath_type:" {print $2; exit}' <<<"$block")"

    if [[ "$datapath_type" == "netdev" ]]; then
        print_pass "$bridge datapath_type=$datapath_type expected=netdev"
    else
        print_fail "$bridge datapath_type=${datapath_type:-MISSING} expected=netdev"
    fi
}

check_ovs_dpdk_interface() {
    local bridge="$1"
    local block="$2"
    local iface="$3"
    local iface_type

    iface_type="$(awk -v iface="$iface" '
        $1 == "Port" && $2 == iface {
            in_port = 1
            next
        }
        in_port && $1 == "Port" {
            exit
        }
        in_port && $1 == "Interface" && $2 == iface {
            in_interface = 1
            next
        }
        in_interface && $1 == "type:" {
            print $2
            exit
        }
    ' <<<"$block")"

    if [[ "$iface_type" == "dpdk" ]]; then
        print_pass "$bridge interface $iface type=$iface_type expected=dpdk"
    elif [[ -z "$iface_type" ]]; then
        print_fail "$bridge interface $iface missing or type missing; expected=dpdk"
    else
        print_fail "$bridge interface $iface type=$iface_type expected=dpdk"
    fi
}

check_ovs_show_output() {
    local output="$1"
    local plane
    local bridge
    local block
    local pf_name
    local rail
    local vf_rep
    local pf_count

    for plane in "${OVS_PLANES[@]}"; do
        bridge="br-rail${plane}"
        pf_count=0

        if ! ovs_bridge_exists "$output" "$bridge"; then
            print_fail "$bridge missing from ovs-vsctl show output"
            continue
        fi

        print_pass "$bridge exists in ovs-vsctl show output"
        block="$(extract_ovs_bridge_block "$output" "$bridge")"
        check_ovs_bridge_datapath "$bridge" "$block"

        for pf_name in "${PF_NET_NAMES[@]}"; do
            [[ -n "$pf_name" ]] || continue
            if rail="$(get_rail_from_net_name "$pf_name")" && [[ "$rail" == "$plane" ]]; then
                pf_count=$((pf_count + 1))
                check_ovs_dpdk_interface "$bridge" "$block" "$pf_name"
            fi
        done

        if [[ "$pf_count" -eq 4 ]]; then
            print_pass "$bridge discovered PF interface count=$pf_count expected=4"
        else
            print_fail "$bridge discovered PF interface count=$pf_count expected=4"
        fi

        vf_rep=""
        for pf_name in "${MAIN_VF_REP_NAMES[@]}"; do
            [[ -n "$pf_name" ]] || continue
            if rail="$(get_rail_from_net_name "$pf_name")" && [[ "$rail" == "$plane" ]]; then
                vf_rep="$pf_name"
                break
            fi
        done

        if [[ -n "$vf_rep" ]]; then
            check_ovs_dpdk_interface "$bridge" "$block" "$vf_rep"
        else
            print_fail "$bridge vf_rep interface not discovered from mst status"
        fi
    done
}

check_ovs_group_output() {
    local bridge="$1"
    local output="$2"
    local group_id

    for group_id in "${OVS_EXPECTED_GROUP_IDS[@]}"; do
        if grep -Eq "(^|[[:space:]])group_id=${group_id}([,[:space:]]|$)" <<<"$output"; then
            print_pass "$bridge group_id=$group_id exists"
        else
            print_fail "$bridge group_id=$group_id missing"
        fi
    done
}

check_ovs_arp_flow() {
    local bridge="$1"
    local output="$2"
    local vf_rep="$3"
    shift 3

    local pf_names=("$@")
    local arp_line
    local pf_name

    arp_line="$(awk -v vf_rep="$vf_rep" '
        /arp/ && index($0, "in_port=\"" vf_rep "\"") && index($0, "actions=") {
            print
            exit
        }
    ' <<<"$output")"

    if [[ -z "$arp_line" ]]; then
        print_fail "$bridge ARP flow from $vf_rep missing"
        return
    fi

    print_pass "$bridge ARP flow from $vf_rep exists"

    for pf_name in "${pf_names[@]}"; do
        if [[ "$arp_line" == *"output:\"${pf_name}\""* ]]; then
            print_pass "$bridge ARP flow outputs to $pf_name"
        else
            print_fail "$bridge ARP flow missing output to $pf_name"
        fi
    done
}

check_ovs_flow_groups() {
    local bridge="$1"
    local output="$2"
    local vf_rep="$3"
    local group_id
    local flow_line
    local expected_pid
    local expected_strict

    for group_id in "${OVS_EXPECTED_GROUP_IDS[@]}"; do
        flow_line="$(awk -v vf_rep="$vf_rep" -v group_id="$group_id" '
            index($0, "in_port=\"" vf_rep "\"") && index($0, "actions=group:" group_id) {
                print
                exit
            }
        ' <<<"$output")"

        if [[ -n "$flow_line" ]]; then
            print_pass "$bridge flow actions=group:$group_id exists"
        else
            print_fail "$bridge flow actions=group:$group_id missing"
            continue
        fi

        if (( group_id >= 20 && group_id <= 23 )) || (( group_id >= 30 && group_id <= 33 )); then
            expected_pid=$((group_id % 10))

            if [[ "$flow_line" == *"nv_mp_pid=${expected_pid}"* ]]; then
                print_pass "$bridge flow group:$group_id nv_mp_pid=$expected_pid"
            else
                print_fail "$bridge flow group:$group_id missing nv_mp_pid=$expected_pid"
            fi

            if (( group_id >= 20 && group_id <= 23 )); then
                expected_strict=0
                if [[ "$flow_line" == *"nv_mp_preferred=1"* ]]; then
                    print_pass "$bridge flow group:$group_id nv_mp_preferred=1"
                else
                    print_fail "$bridge flow group:$group_id missing nv_mp_preferred=1"
                fi
            else
                expected_strict=1
            fi

            if [[ "$flow_line" == *"nv_mp_strict=${expected_strict}"* ]]; then
                print_pass "$bridge flow group:$group_id nv_mp_strict=$expected_strict"
            else
                print_fail "$bridge flow group:$group_id missing nv_mp_strict=$expected_strict"
            fi
        fi
    done
}

check_ovs_flow_output() {
    local bridge="$1"
    local output="$2"
    local plane="$3"
    local pf_name
    local rail
    local vf_rep
    local pf_names=()

    for pf_name in "${PF_NET_NAMES[@]}"; do
        [[ -n "$pf_name" ]] || continue
        if rail="$(get_rail_from_net_name "$pf_name")" && [[ "$rail" == "$plane" ]]; then
            pf_names+=("$pf_name")
        fi
    done

    vf_rep=""
    for pf_name in "${MAIN_VF_REP_NAMES[@]}"; do
        [[ -n "$pf_name" ]] || continue
        if rail="$(get_rail_from_net_name "$pf_name")" && [[ "$rail" == "$plane" ]]; then
            vf_rep="$pf_name"
            break
        fi
    done

    if [[ -z "$vf_rep" ]]; then
        print_fail "$bridge vf_rep interface not discovered; cannot check flows"
        return
    fi

    if [[ "${#pf_names[@]}" -ne 4 ]]; then
        print_fail "$bridge discovered PF interface count=${#pf_names[@]} expected=4; flow check may be incomplete"
    fi

    check_ovs_arp_flow "$bridge" "$output" "$vf_rep" "${pf_names[@]}"
    check_ovs_flow_groups "$bridge" "$output" "$vf_rep"
}

check_ovs() {
    section "OVS"

    local plane
    local ovs_bridge
    local output
    local group_output
    local flow_output
    local rc

    output="$(ovs-vsctl show 2>&1)"
    rc=$?
    printf '%s\n' "$output"

    if [[ "$rc" -ne 0 ]]; then
        print_fail "ovs-vsctl show failed with rc=$rc"
    else
        check_ovs_show_output "$output"
    fi

    for plane in "${OVS_PLANES[@]}"; do
        ovs_bridge="br-rail${plane}"
        printf '\n----- %s -----\n' "$ovs_bridge"
        echo "====== OVS Groups ======"
        group_output="$(ovs-ofctl --names dump-groups "$ovs_bridge" 2>&1)"
        rc=$?
        printf '%s\n' "$group_output"

        if [[ "$rc" -ne 0 ]]; then
            print_fail "$ovs_bridge ovs-ofctl dump-groups failed with rc=$rc"
        else
            check_ovs_group_output "$ovs_bridge" "$group_output"
        fi

        echo "====== OVS Flows ======"
        flow_output="$(ovs-ofctl --names dump-flows "$ovs_bridge" 2>&1)"
        rc=$?
        printf '%s\n' "$flow_output"

        if [[ "$rc" -ne 0 ]]; then
            print_fail "$ovs_bridge ovs-ofctl dump-flows failed with rc=$rc"
        else
            check_ovs_flow_output "$ovs_bridge" "$flow_output" "$plane"
        fi
    done
}

check_pcc_processes() {
    section "CX8 PCC"

    local output
    local rc
    local rdma_name

    output="$(ps -ef | grep spcx_cc 2>&1)"
    rc=$?
    printf '%s\n' "$output"

    if [[ "$rc" -ne 0 ]]; then
        print_fail "ps -ef | grep spcx_cc failed with rc=$rc"
        return
    fi

    for rdma_name in "${RDMA_NAMES[@]}"; do
        if [[ -z "$rdma_name" ]]; then
            print_fail "empty RDMA bond name discovered from mst status"
            continue
        fi

        if awk -v rdma_name="$rdma_name" '
            index($0, "/opt/mellanox/doca/tools/doca_spcx_cc") &&
            index($0, "-d " rdma_name) &&
            $0 !~ /grep/ {
                found = 1
                exit
            }
            END {
                exit found ? 0 : 1
            }
        ' <<<"$output"; then
            print_pass "doca_spcx_cc process exists for $rdma_name"
        else
            print_fail "doca_spcx_cc process missing for $rdma_name"
        fi
    done
}

main() {
    local target="${1:-all}"

    case "$target" in
        -h|--help|help)
            usage
            exit 0
            ;;
        all|mlxconfig|pf-mlxconfig|roce|devlink|vf|mlnx-qos|ovs|pcc)
            ;;
        *)
            printf 'FAIL: unknown check target: %s\n\n' "$target" >&2
            usage >&2
            exit 2
            ;;
    esac

    init_logging
    if ! run_check_item "MST discovery" discover_mst_devices; then
        print_item_result "FAIL" "total failures=$CHECK_FAILURES"
        exit 1
    fi

    case "$target" in
        all)
            run_check_item "mlxconfig" check_mlxconfig
            run_check_item "PF mlxconfig" check_pf_mlxconfig
            run_check_item "ROCE_ACCL and PPCC" check_roce_and_ppcc
            run_check_item "devlink" check_devlink
            run_check_item "VF mapping" check_vf_mapping
            run_check_item "mlnx_qos" check_mlnx_qos
            run_check_item "OVS" check_ovs
            run_check_item "CX8 PCC" check_pcc_processes
            ;;
        mlxconfig)
            run_check_item "mlxconfig" check_mlxconfig
            ;;
        pf-mlxconfig)
            run_check_item "PF mlxconfig" check_pf_mlxconfig
            ;;
        roce)
            run_check_item "ROCE_ACCL and PPCC" check_roce_and_ppcc
            ;;
        devlink)
            run_check_item "devlink" check_devlink
            ;;
        vf)
            run_check_item "VF mapping" check_vf_mapping
            ;;
        mlnx-qos)
            run_check_item "mlnx_qos" check_mlnx_qos
            ;;
        ovs)
            run_check_item "OVS" check_ovs
            ;;
        pcc)
            run_check_item "CX8 PCC" check_pcc_processes
            ;;
    esac

    if [[ "$CHECK_FAILURES" -gt 0 ]]; then
        print_item_result "FAIL" "total failures=$CHECK_FAILURES"
        exit 1
    fi

    print_item_result "PASS" "all checks passed"
}

main "$@"
