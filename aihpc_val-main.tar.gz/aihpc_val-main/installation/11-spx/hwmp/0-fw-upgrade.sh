#!/bin/bash

main(){

export BIN=/home/cmsupport/workspace/fw/fw-ConnectX8-rel-40_48_1126-900-9X86E-00CX-ST0_Ax-UEFI-14.41.14-FlexBoot-3.9.101.signed.bin

mst start
hcas=($(lspci -D|grep -e "\.0.*Ethernet controller.*ConnectX-8" -e "\.0.*Infiniband controller.*ConnectX-8" |awk '{print $1}'|xargs -I {} bash -c 'ls -l /sys/class/infiniband|grep -o {}/.*|cut -f3 -d"/"'))

# Upgrade firmware
for i in ${hcas[@]}; do
  set -x
  flint -d $i -i $BIN -y b
  set +x
done

# Power cycle server to take effect
echo "INFO: Power Cycle Server to take effect - ipmitool power cycle"
}
export -f main
