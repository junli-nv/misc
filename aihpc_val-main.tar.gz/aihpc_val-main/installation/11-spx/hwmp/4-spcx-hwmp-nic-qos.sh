#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

# RA ref: https://apps.nvidia.com/PID/ContentLibraries/Detail/1155985
#

export PATH=/usr/sbin:/sbin:/usr/bin:/bin:/usr/local/sbin:/usr/local/bin

cx8_rdma_vfs=($(lspci -D|grep "Ethernet controller.*ConnectX.*Virtual Function"|awk '{print $1}'|xargs -I {} bash -c 'ls -l /sys/class/infiniband|grep -o {}/.*|cut -f3 -d"/"'))

# 5.7.1.1	Configure all SuperNICs to lossless RoCE mode with PFC and ECN

echo "[INFO] ToS to TC Mapping - ${cx8_rdma_vfs[@]}"
for i in ${cx8_rdma_vfs[@]}; do
  cma_roce_tos -d $i | egrep -qw 96 || cma_roce_tos -d $i -t 96
done
for i in ${cx8_rdma_vfs[@]}; do
  egrep -q "=96$" /sys/class/infiniband/$i/tc/1/traffic_class || echo 96 > /sys/class/infiniband/$i/tc/1/traffic_class
done
for i in ${cx8_rdma_vfs[@]}; do
  grep -H -r . /sys/class/infiniband/$i/tc/1/traffic_class
done

cx8_nics_pfs=($(lspci -D|grep "Ethernet controller.*ConnectX-8"|awk '{print $1}'|xargs -I {} bash -c 'ls -l /sys/class/net|grep -o {}/.*|cut -f3 -d"/"'|xargs -I {} bash -c '[ -d /sys/class/net/{}/ecn ] && echo {}'))

echo "[INFO] PFC and DSCP-based Classification - ${cx8_nics_pfs[@]}"
for i in ${cx8_nics_pfs[@]}; do
  mlnx_qos -i $i | egrep -q "enabled 0 0 0 1 0 0 0 0" \
    || mlnx_qos -i $i --pfc=0,0,0,1,0,0,0,0 --trust=dscp
done
for i in ${cx8_nics_pfs[@]}; do
  mlnx_qos -i $i | egrep -q "Priority trust state: dscp" \
    || mlnx_qos -i $i --pfc=0,0,0,1,0,0,0,0 --trust=dscp
done
for i in ${cx8_nics_pfs[@]}; do
  echo "========${i}========"
  mlnx_qos -i $i | egrep -e "Priority trust state: dscp" -e "enabled"
done

echo "[INFO] Enable ECN for RoCE traffic on all PFs and set the CNP packets DSCP value to 48"
for interface in ${cx8_nics_pfs[@]}; do
  for point in "rp" "np" ; do
    for i in {0..7} ; do
      echo 1 > /sys/class/net/$interface/ecn/roce_${point}/enable/${i}
    done
  done
  echo 48 > /sys/class/net/$interface/ecn/roce_np/cnp_dscp
done
for interface in ${cx8_nics_pfs[@]}; do
  echo ${interface} $(grep -h -r . /sys/class/net/$interface/ecn/roce_*/enable) $(grep -h . /sys/class/net/$interface/ecn/roce_np/cnp_dscp)
done

