#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

# RA ref: https://apps.nvidia.com/PID/ContentLibraries/Detail/1155985
#
export FORCE_REBIND_PFS=${FORCE_REBIND_PFS:-0}

export PATH=/usr/sbin:/sbin:/usr/bin:/bin:/usr/local/sbin:/usr/local/bin
mst start &>/dev/null

cx8_nics=($(lspci -D|grep "Ethernet controller.*ConnectX-8"|awk '{print $1}'))
if [ ${#cx8_nics[@]} -ne 16 ]; then
  echo "[ERROR][CRITICAL] The CX8 PFs count is not 16. Details: $(echo ${cx8_nics[@]}|tr ' ' '\n'|sed 's:\.[0-9]::g'|sort|uniq -c|paste -s -d',' -|tr -s ' ')"
else
  echo "[INFO] 16 PFs all found."
fi

cx8_nicx_netdev=($(lspci -D|grep "Ethernet controller.*ConnectX-8"|awk '{print $1}'|xargs -I {} bash -c 'ls -l /sys/class/net|grep -o {}/.*|cut -f3 -d"/"'|xargs -I {} bash -c '[ -d /sys/class/net/{}/ecn ] && echo {}'))

if [[ $FORCE_REBIND_PFS -eq 1 || ${#cx8_nicx_netdev[@]} -ne 16 ]]; then
  [ ${#cx8_nicx_netdev[@]} -ne 16 ] && echo "[DEBUG]: Found ${#cx8_nicx_netdev[@]} PFs with netdevice, expected 16."
  echo "[INFO] Unbind All PFs"
  for PCI_ADDRESS in "${cx8_nics[@]}"; do
    echo $PCI_ADDRESS
    echo $PCI_ADDRESS > /sys/bus/pci/drivers/mlx5_core/unbind
  done
  max_tries=5
  while [ $max_tries -gt 0 ]; do
    ret=$(lspci -D|grep "Ethernet controller.*ConnectX-8"|awk '{print $1}'|xargs -I {} bash -c 'ls -l /sys/class/net/|grep -o {}/.*'|  wc -l)
    if [ $ret -eq 0 ]; then
      break
    fi
    echo "[INFO] Waiting for all PFs to be unbound from the driver, current count: $ret"
    sleep 5
    max_tries=$((max_tries-1))
  done

  ## Master PFs Configuration
  echo "[INFO] Bind All PFs"
  lspci -D|grep "\.0 Ethernet controller.*ConnectX-8"|awk '{print $1}'|while read PCI_ADDRESS; do
    echo $PCI_ADDRESS
    echo $PCI_ADDRESS > /sys/bus/pci/drivers/mlx5_core/bind
  done
  max_tries=5
  while [ $max_tries -gt 0 ]; do
    ret=$(lspci -D|grep "\.0 Ethernet controller.*ConnectX-8"|awk '{print $1}'|xargs -I {} bash -c 'ls -l /sys/class/net/|grep -o {}/.*'|wc -l)
    if [ $ret -eq 4 ]; then
      break
    fi
    echo "[INFO] Waiting for all 4 master PFs to be bound to the driver, current count: $ret"
    sleep 5
    max_tries=$((max_tries-1))
  done
  
  ## Non-Master PFs Configuration
  echo "[INFO] Bind non-master PFs"
  lspci -D|grep "Ethernet controller.*ConnectX-8"|grep -v '.0 Ethernet'|awk '{print $1}'|while read PCI_ADDRESS; do
    echo $PCI_ADDRESS
    echo $PCI_ADDRESS > /sys/bus/pci/drivers/mlx5_core/bind
  done
  max_tries=5
  while [ $max_tries -gt 0 ]; do
    ret=$(lspci -D|grep "Ethernet controller.*ConnectX-8"|grep -v '.0 Ethernet'|awk '{print $1}'|xargs -I {} bash -c 'ls -l /sys/class/net/|grep -o {}/.*'|wc -l)
    if [ $ret -eq 12 ]; then
      break
    fi
    echo "[INFO] Waiting for all 12 non-master PFs to be bound to the driver, current count: $ret"
    sleep 5
    max_tries=$((max_tries-1))
  done
fi

cx8_nics_master_pfs=($(lspci -D|grep "\.0 Ethernet controller.*ConnectX-8"|awk '{print $1}'|xargs -I {} bash -c 'ls -l /sys/class/net|grep -o {}/.*|cut -f3 -d"/"'|xargs -I {} bash -c '[ -d /sys/class/net/{}/ecn ] && echo {}'))
if [ ${#cx8_nics_master_pfs[@]} -eq 4 ]; then
  echo "[INFO] Found 4 Master PFs: ${cx8_nics_master_pfs[@]}"
else
  echo "[ERROR] Found ${#cx8_nics_master_pfs[@]} Master PFs: ${cx8_nics_master_pfs[@]}, expected 4"
fi

cx8_nics_pfs=($(lspci -D|grep "Ethernet controller.*ConnectX-8"|awk '{print $1}'|xargs -I {} bash -c 'ls -l /sys/class/net|grep -o {}/.*|cut -f3 -d"/"'|xargs -I {} bash -c '[ -d /sys/class/net/{}/ecn ] && echo {}'))
if [ ${#cx8_nics_pfs[@]} -eq 16 ]; then
  echo "[INFO] Found 16 PFs: ${cx8_nics_pfs[@]}"
else
  echo "[ERROR] Found ${#cx8_nics_pfs[@]} PFs: ${cx8_nics_pfs[@]}, expected 16"
fi

# 5.3 eSwitch Configuration
echo "[INFO] reset all PFs on the NIC to legacy first"
for interface in "${cx8_nics_pfs[@]}"; do
   PCI_ADDRESS=$(cat /sys/class/net/$interface/device/uevent | grep PCI_SLOT_NAME | cut -d'=' -f 2)
   echo "mode legacy - $interface"
   devlink dev eswitch set pci/$PCI_ADDRESS mode legacy
done
sleep 10
echo "[INFO] set steering mode first (platform dependent; docs show dmfs or hmfs)"
for interface in "${cx8_nics_pfs[@]}"; do
   PCI_ADDRESS=$(cat /sys/class/net/$interface/device/uevent | grep PCI_SLOT_NAME | cut -d'=' -f 2)
   echo "set steering mode - $interface"
   devlink dev param set pci/$PCI_ADDRESS name flow_steering_mode value hmfs cmode runtime
done
sleep 10
echo "[INFO] set switchdev on all PFs"
for interface in "${cx8_nics_pfs[@]}"; do
   PCI_ADDRESS=$(cat /sys/class/net/$interface/device/uevent | grep PCI_SLOT_NAME | cut -d'=' -f 2)
   echo "set switchdev mode - $interface"
   devlink dev eswitch set pci/$PCI_ADDRESS mode switchdev
done
sleep 10
echo "[INFO] set multiport on all PFs"
for interface in "${cx8_nics_pfs[@]}"; do 
   PCI_ADDRESS=$(cat /sys/class/net/$interface/device/uevent | grep PCI_SLOT_NAME | cut -d'=' -f 2)
   echo "set multiport - $interface"
   devlink dev param set pci/$PCI_ADDRESS name esw_multiport value 1 cmode runtime
   ret=$?
   echo "[DEBUG] Check multiport - $interface - expected: $ret"
done
sleep 10
udevadm control --reload-rules
udevadm trigger --action=add --subsystem-match=infiniband
udevadm trigger --action=add --subsystem-match=net
udevadm settle --timeout=15

ret=$(grep PCI_SLOT_NAME $(for interface in "${cx8_nics_pfs[@]}"; do echo /sys/class/net/$interface/device/uevent; done)|wc -l)
if [ $ret -ne 16 ]; then
  echo "[INFO] Waiting for multiport on all 16 PFs, current count: $ret"
  echo "[INFO] Bind the PFs lost netdevices to the driver"
  a=($(lspci -D | grep Ethernet.*Mellanox.*ConnectX-8|awk '{print $1}'|while read i; do ls -l /sys/class/net/|grep -o ${i}/.* &>/dev/null || echo $i; done))
  echo "[DEBUG] Unbind and Bind $PCI_ADDRESS"
  for PCI_ADDRESS in ${a[@]}; do
    echo $PCI_ADDRESS > /sys/bus/pci/drivers/mlx5_core/unbind
    echo $PCI_ADDRESS > /sys/bus/pci/drivers/mlx5_core/bind
  done
  sleep 10
  echo "[INFO] set multiport on the lost PFs again"
  for PCI_ADDRESS in ${a[@]}; do
    echo "[DEBUG] set multiport $PCI_ADDRESS"
    devlink dev eswitch set pci/$PCI_ADDRESS mode legacy
    devlink dev param set pci/$PCI_ADDRESS name flow_steering_mode value hmfs cmode runtime
    devlink dev eswitch set pci/$PCI_ADDRESS mode switchdev
    devlink dev param set pci/$PCI_ADDRESS name esw_multiport value 1 cmode runtime
    sleep 10
  done
fi

echo "[INFO] eSwitch Configuration Check"
for interface in "${cx8_nics_pfs[@]}"; do
   PCI_ADDRESS=$(cat /sys/class/net/$interface/device/uevent | grep PCI_SLOT_NAME | cut -d'=' -f 2)
   (
   echo ${interface}
   devlink dev eswitch show pci/$PCI_ADDRESS
   devlink dev param show pci/$PCI_ADDRESS name flow_steering_mode|grep cmode #hmfs
   devlink dev param show pci/$PCI_ADDRESS name esw_multiport|grep cmode #true
   ) | paste -s -d',' -
done

## Create Virtual Functions
echo "[INFO] Configure Virtual Functions"
for interface in "${cx8_nics_master_pfs[@]}"; do
  echo "[INFO] Applying VF for $interface"
  echo 1 > /sys/class/net/$interface/device/sriov_numvfs
done
max_tries=5
while [ $max_tries -gt 0 ]; do
  ret=$(lspci | grep Ethernet.*ConnectX.*Virtual|wc -l)
  if [ $ret -eq 4 ]; then
    break
  fi
  echo "[INFO] Waiting for all 4 Virtual Functions to be bound to the driver, current count: $ret"
  sleep 5
  max_tries=$((max_tries-1))
done

echo "[INFO] Check Virtual Functions"
for interface in "${cx8_nics_master_pfs[@]}"; do
  PF_PCI_ADDRESS=$(cat /sys/class/net/$interface/device/uevent | grep PCI_SLOT_NAME | cut -d'=' -f 2)
  VF_PCI_ADDRESS=$(cat /sys/class/net/$interface/device/virtfn0/uevent | grep PCI_SLOT_NAME | cut -d'=' -f 2)
  echo ${interface} ${PF_PCI_ADDRESS} sriov_numvfs=$(</sys/class/net/$interface/device/sriov_numvfs) VF_${VF_PCI_ADDRESS}
done

# echo "[INFO] Unbind and Bind Virtual Functions"
# for interface in "${cx8_nics_master_pfs[@]}"; do
#   PF_PCI_ADDRESS=$(cat /sys/class/net/$interface/device/uevent | grep PCI_SLOT_NAME | cut -d'=' -f 2)
#   VF_PCI_ADDRESS=$(cat /sys/class/net/$interface/device/virtfn0/uevent | grep PCI_SLOT_NAME | cut -d'=' -f 2)
#   VF_NAME=$(ls -l /sys/class/net/|grep -o ${VF_PCI_ADDRESS}/.*|cut -f3 -d'/')
#   echo $VF_PCI_ADDRESS > /sys/bus/pci/drivers/mlx5_core/unbind
#   sleep 2
#   echo $VF_PCI_ADDRESS > /sys/bus/pci/drivers/mlx5_core/bind
# done
# max_tries=5
# while [ $max_tries -gt 0 ]; do
#  ret=$(lspci -D|grep "Ethernet.*ConnectX.*Virtual"|awk '{print $1}'|xargs -I {} bash -c 'ls -l /sys/class/net/|grep -o {}/.*'|wc -l)
#  if [ $ret -eq 4 ]; then
#    break
#  fi
#  echo "[INFO] Waiting for all 4 Virtual Functions to be bound to the driver, current count: $ret"
#  sleep 5
#  max_tries=$((max_tries-1))
# done

cx8_nics_vfs=($(lspci -D|grep "Ethernet controller.*ConnectX.*Virtual Function"|awk '{print $1}'|xargs -I {} bash -c 'ls -l /sys/class/net|grep -o {}/.*|cut -f3 -d"/"'))
if [ ${#cx8_nics_vfs[@]} -eq 4 ]; then
  echo "[INFO] Found 4 VFs: ${cx8_nics_vfs[@]}"
else
  echo "[ERROR] Found ${#cx8_nics_vfs[@]} VFs: ${cx8_nics_vfs[@]}, expected 4"
fi

#### Virtual Functions GDR Configuration 
## Ref: https://docs.nvidia.com/multi-node-nvlink-systems/grace-blackwell-cx8-gpudirect-rdma-guide/gpudirect_rdma_testing.html#using-nic-virtual-function-and-enabling-data-direct-feature
echo "[INFO] Virtual Functions GDR Configuration"
# devlink port show | grep pcivf
type doca_mgmt_data_direct &>/dev/null; ret=$?
if [ $ret -ne 0 ]; then
  echo "[DEBUG] Build doca_mgmt_data_direct..."
  apt install -y doca-samples libdoca-sdk-mgmt-dev libdoca-sdk-argp-dev meson
  cd /opt/mellanox/doca/samples/doca_mgmt/mgmt_data_direct
  meson setup build
  meson compile -C build
  echo "[DEBUG] doca_mgmt_data_direct done"
  install -m 755 \
    /opt/mellanox/doca/samples/doca_mgmt/mgmt_data_direct/build/doca_mgmt_data_direct \
    /usr/local/bin/doca_mgmt_data_direct
  type doca_mgmt_data_direct
fi

cx8_nics_vfs_pcis=($(lspci | grep -i Ethernet | grep 'mlx5Gen Virtual Function' | awk '{print $1}'))
echo "[INFO] Ubind the VFs from the driver"
for i in ${cx8_nics_vfs_pcis[@]}; do
  echo ${i} | tee /sys/bus/pci/devices/${i}/driver/unbind
done
sleep 5
echo "[INFO] set data-direct on the VFs(expected: Data direct: ENABLED)"
for i in ${cx8_nics_vfs_pcis[@]}; do
  echo ${i}
  doca_mgmt_data_direct set --rep pci/${i%%.*}.0,pf0vf0 --enabled true
done
sleep 5
echo "[INFO] Check data-direct on the VFs(expected: Data direct: ENABLED)"
for i in ${cx8_nics_vfs_pcis[@]}; do
  doca_mgmt_data_direct get --rep pci/${i%%.*}.0,pf0vf0
done
sleep 5
echo "[INFO] Bind the VFs to the driver"
for i in ${cx8_nics_vfs_pcis[@]}; do
  echo ${i} | tee  /sys/bus/pci/drivers/mlx5_core/bind
done
max_tries=6
while [ $max_tries -gt 0 ]; do
  ret=$(lspci -D|grep "Ethernet.*ConnectX.*Virtual"|awk '{print $1}'|xargs -I {} bash -c 'ls -l /sys/class/net/|grep -o {}/.*'|wc -l)
  if [ $ret -eq 4 ]; then
    break
  fi
  echo "[INFO] Waiting for all 4 Virtual Functions to be bound to the driver, current count: $ret"
  sleep 5
  max_tries=$((max_tries-1))
done

cx8_nics_vfs=($(lspci -D|grep "Ethernet controller.*ConnectX.*Virtual Function"|awk '{print $1}'|xargs -I {} bash -c 'ls -l /sys/class/net|grep -o {}/.*|cut -f3 -d"/"'))
if [ ${#cx8_nics_vfs[@]} -eq 4 ]; then
  echo "[INFO] Found 4 VFs: ${cx8_nics_vfs[@]}"
else
  echo "[ERROR] Found ${#cx8_nics_vfs[@]} VFs: ${cx8_nics_vfs[@]}, expected 4"
fi

## 5.4 Virtual Functions
echo "[INFO] set VFs' mtu to 9216"
for interface in "${cx8_nics_master_pfs[@]}"; do
  PF_PCI_ADDRESS=$(cat /sys/class/net/$interface/device/uevent | grep PCI_SLOT_NAME | cut -d'=' -f 2)
  VF_PCI_ADDRESS=$(cat /sys/class/net/$interface/device/virtfn0/uevent | grep PCI_SLOT_NAME | cut -d'=' -f 2)
  VF_NAME=$(ls -l /sys/class/net/|grep -o ${VF_PCI_ADDRESS}/.*|cut -f3 -d'/')
  VF_REP=$(devlink port show | grep pcivf | grep -o ${PF_PCI_ADDRESS}/.*pcivf|awk '{print $(NF-2)}')
  ip link set dev $VF_NAME up
  ip link set dev $VF_NAME mtu 9216
  ip link set dev $VF_REP up
  ip link set dev $VF_REP mtu 9216
done
echo "[INFO] Check VFs' mtu"
for interface in "${cx8_nics_master_pfs[@]}"; do
  PF_PCI_ADDRESS=$(cat /sys/class/net/$interface/device/uevent | grep PCI_SLOT_NAME | cut -d'=' -f 2)
  VF_PCI_ADDRESS=$(cat /sys/class/net/$interface/device/virtfn0/uevent | grep PCI_SLOT_NAME | cut -d'=' -f 2)
  VF_NAME=$(ls -l /sys/class/net/|grep -o ${VF_PCI_ADDRESS}/.*|cut -f3 -d'/')
  VF_REP=$(devlink port show | grep pcivf | grep -o ${PF_PCI_ADDRESS}/.*pcivf|awk '{print $(NF-2)}') 
  echo ${VF_NAME}:$(cat /sys/class/net/$VF_NAME/mtu)
  echo ${VF_REP}:$(cat /sys/class/net/$VF_REP/mtu)
done | paste -s -d',' -

# 5.5	SuperNIC Interfaces Renaming
echo '#' > /etc/udev/rules.d/70-net-persistent-vf.rules
for interface in "${cx8_nics_master_pfs[@]}"; do
  PF_PCI_ADDRESS=$(cat /sys/class/net/$interface/device/uevent | grep PCI_SLOT_NAME | cut -d'=' -f 2)
  VF_PCI_ADDRESS=$(cat /sys/class/net/$interface/device/virtfn0/uevent | grep PCI_SLOT_NAME | cut -d'=' -f 2)
  VF_NAME=$(ls -l /sys/class/net/|grep -o ${VF_PCI_ADDRESS}/.*|cut -f3 -d'/')
  VF_REP=$(devlink port show | grep pcivf | grep -o ${PF_PCI_ADDRESS}/.*pcivf|awk '{print $(NF-2)}') 
  #echo $VF_NAME $VF_REP
  VF_REP_DEFAULT_NAME=$(ls -l /sys/class/net|grep -o $PF_PCI_ADDRESS/.* | cut -f3 -d'/'|while read i; do [ -d /sys/class/net/$i/ecn ] && continue || echo $i; done)
  if [ -f /sys/class/net/${VF_REP}/phys_switch_id ]; then
        VF_REP_PORT_NAME=$(cat /sys/class/net/${VF_REP}/phys_port_name)
        VF_REP_SWITCH_ID=$(cat /sys/class/net/${VF_REP}/phys_switch_id)
  else
        VF_REP_PORT_NAME=$(cat /sys/class/net/${VF_REP_DEFAULT_NAME}/phys_port_name)
        VF_REP_SWITCH_ID=$(cat /sys/class/net/${VF_REP_DEFAULT_NAME}/phys_switch_id)
  fi
  #echo $VF_REP_PORT_NAME $VF_REP_SWITCH_ID
  VF_REP_RENAME=$(echo ${VF_NAME}|sed 's:vf_:vf_rep_:g')
  [ "X${VF_REP_RENAME}X" == "X${VF_NAME}X" ] && VF_REP_RENAME=${VF_NAME}_rep #in case the VF name does not contain vf_
  cat <<- EOF | tee -a /etc/udev/rules.d/70-net-persistent-vf.rules
ACTION=="add", ATTR{phys_switch_id}=="${VF_REP_SWITCH_ID}", ATTR{phys_port_name}=="${VF_REP_PORT_NAME}", SUBSYSTEM=="net", NAME="${VF_REP_RENAME}"
EOF
done
udevadm control --reload-rules
udevadm trigger --action=add --subsystem-match=infiniband
udevadm trigger --action=add --subsystem-match=net
udevadm settle --timeout=15

grep NAME /etc/udev/rules.d/70-net-persistent-vf.rules|awk -F'"' '{print $(NF-1)}'|while read i; do
  if [ -d /sys/class/net/${i} ]; then
    echo "[INFO] Found VF Rep: ${i}"
  else
    echo "[ERROR] Not Found VF Rep: ${i}"
  fi
done

# 5.2.3	Interfaces State and MTU Settings - Netplan
## Recommendation: 
## Done on HeadNode: /bin/cp -farv /cm/shared-ubuntu2404-aarch64/spectrum-x/netplan/ /cm/images/gb300-image-spx2.1.3-hwmp-00/opt/
## Done during OS boot: /bin/cp -f /opt/netplan/$(hostname).yaml /etc/netplan/$(hostname).yaml
mount /cm/shared
rm -f /etc/netplan/*.yaml
/bin/cp -f /cm/shared/spectrum-x/netplan/$(hostname).yaml /etc/netplan/$(hostname).yaml
systemctl unmask systemd-networkd.service
systemctl enable systemd-networkd.service
echo "[INFO] Start systemd-networkd.service"
systemctl restart systemd-networkd.service
rm -f /etc/netplan/02-bmc_redfish0-netcfg.yaml
chmod 600 /etc/netplan/*.yaml
netplan generate
netplan apply
sleep 5
#
for interface in "${cx8_nics_vfs[@]}"; do
  ret=$(ip r sh | grep $interface | wc -l)
  if [ $ret -ne 3 ]; then
    echo "[ERROR] Lack of route for $interface"
  else
    echo "[INFO] Found 3 routes(one for in rail, two for cross rail) for $interface"
  fi
done
echo "[INFO] Check mtu"
for interface in "${cx8_nics_pfs[@]}"; do
  echo ${interface}:$(cat /sys/class/net/$interface/mtu)
done
