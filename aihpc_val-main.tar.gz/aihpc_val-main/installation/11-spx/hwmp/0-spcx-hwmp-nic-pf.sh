#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

# RA ref: https://apps.nvidia.com/PID/ContentLibraries/Detail/1155985

export PATH=/usr/sbin:/sbin:/usr/bin:/bin:/usr/local/sbin:/usr/local/bin

cx8_nics=($(lspci -D|grep -e "\.0.*Ethernet controller.*ConnectX-8" -e "\.0.*Infiniband controller.*ConnectX-8" |awk '{print $1}'|xargs -I {} bash -c 'ls -l /sys/class/infiniband|grep -o {}/.*|cut -f3 -d"/"'))

echo "[INFO] SPC-X MLXCONFIG Configuration"
echo "[INFO] Quad Plane Interface Configuration"
mst start &>/dev/null

for interface in "${cx8_nics[@]}"; do
   PCI_ADDRESS=`cat /sys/class/infiniband/$interface/device/uevent | /usr/bin/grep PCI_SLOT_NAME | /usr/bin/cut -d'=' -f 2`
   echo "[INFO] Setting interface: $interface, PCI address: $PCI_ADDRESS"

   #5.1.5.2	NIC Breakout
   mlxconfig -d $PCI_ADDRESS -y set NUM_OF_PLANES_P1=4 NUM_OF_PF=4 MODULE_SPLIT_M0[0..7]=1 MODULE_SPLIT_M0[8..15]=FF
   
   #5.2.1.1	Linux Commands
   mlxconfig -d $PCI_ADDRESS -y set \
     LINK_TYPE_P1=2 \
     ROCE_ADAPTIVE_ROUTING_EN=1 \
     USER_PROGRAMMABLE_CC=1 \
     TX_SCHEDULER_LOCALITY_MODE=2 \
     ROCE_CC_STEERING_EXT=2 \
     ROCE_RTT_RESP_DSCP_P1=48 \
     ROCE_RTT_RESP_DSCP_MODE_P1=1 \
     VF_LOG_BAR_SIZE=5 \
     RDE_DISABLE=1 \
     FLEX_PARSER_PROFILE_ENABLE=10 \
     LAG_RESOURCE_ALLOCATION=1 \
     SRIOV_EN=1 \
     NUM_OF_VFS=1
done

for interface in "${cx8_nics[@]}"; do
   PCI_ADDRESS=`cat /sys/class/infiniband/$interface/device/uevent | /usr/bin/grep PCI_SLOT_NAME | /usr/bin/cut -d'=' -f 2`
   echo "[INFO] Setting interface: $interface, PCI address: $PCI_ADDRESS"
   mlxconfig -d $PCI_ADDRESS -e query \
     NUM_OF_PLANES_P1 \
     NUM_OF_PF \
     MODULE_SPLIT_M0[0..7] \
     MODULE_SPLIT_M0[8..15] \
     LINK_TYPE_P1 \
     ROCE_ADAPTIVE_ROUTING_EN \
     USER_PROGRAMMABLE_CC \
     TX_SCHEDULER_LOCALITY_MODE \
     ROCE_CC_STEERING_EXT \
     ROCE_RTT_RESP_DSCP_P1 \
     ROCE_RTT_RESP_DSCP_MODE_P1 \
     VF_LOG_BAR_SIZE \
     RDE_DISABLE \
     FLEX_PARSER_PROFILE_ENABLE \
     LAG_RESOURCE_ALLOCATION \
     SRIOV_EN \
     NUM_OF_VFS
done

echo "[INFO] One Time Configuration done. Reboot the system to apply the changes."
