#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

if [ -d /cm/images/default-image ]; then
  echo "[INFO] DO NOT RUN ON BCM HEAD NODE. MUST RUN ON COMPUTE NODE, EXITING..."
  exit 1
fi

## Delete all disk UEFI boot entries
efibootmgr|grep -v -e IPv6 -e IPv4 -e Built-in | grep UEFI|awk '{print $1}'|sed -e 's:\*::g' -e 's:Boot::g'|xargs -I {} efibootmgr -b {} --delete-bootnum &>/dev/null
efibootmgr|grep -v -e IPv6 -e IPv4 -e Built-in | grep UEFI|awk '{print $1}'

## Change nic's UEFI boot entries at the highest priority
nics=(
  enP22s22f0np0
  enP22s22f1np1
)
macs=($(
for i in ${nics[@]}; do ip a sh ${i}|grep -o permaddr.*|awk '{print $NF}'; done
))
new_boots=($(
for i in ${macs[@]}; do
  efibootmgr | grep -i IPv4.*${i}|awk '{print $1}'|sed -e 's:\*::g' -e 's:Boot::g'
done
))
efibootmgr --bootorder $(echo ${new_boots[@]}|tr ' ' ',') &>/dev/null
efibootmgr | grep BootOrder

## Remove bootloader from the boot disk
root_dev=$(mount|grep -w /|awk '{print $1}'|sed 's:p[0-9]::g')
dd if=/dev/zero of=${root_dev} bs=1M count=1024 oflag=direct status=progress
