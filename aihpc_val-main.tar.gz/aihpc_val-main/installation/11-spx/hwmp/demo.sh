
#!/bin/bash
#

cd /home/cmsupport/workspace/spx/hwmp/   # put all the scripts under this directory

cat > run.sh <<- '__END__'
#!/bin/bash
set -x
#bash 0-spcx-hwmp-nic-pf.sh
bash 1-spcx-hwmp-nic-udev.sh
bash 2-spcx-hwmp-nic-vf.sh
bash 3-spcx-hwmp-nic-ovs.sh
bash 4-spcx-hwmp-nic-qos.sh
bash 5-spcx-hwmp-nic-ifcfg.sh
rm -f /root/combined_config_check.log
LOG_FILE=/root/combined_config_check.log bash spcx_conf_check.sh all
__END__

cat > a.sh <<- '__END__'
#!/bin/bash

NODELIST=MEL01-HC06-SVR-CN[011215,011218,011233,011236]

pdsh -R ssh -w $NODELIST <<- 'EOF'
cd /home/cmsupport/workspace/spx/hwmp; mkdir -p logs; nohup bash run.sh &> logs/$(hostname).txt &
EOF
__END__

cat > b.sh <<- '__END__'
#!/bin/bash

NODELIST=MEL01-HC06-SVR-CN[011215,011218,011233,011236]

pdsh -R ssh -w $NODELIST <<- 'EOF'
mst start &>/dev/null; mkdir -p /home/cmsupport/workspace/spx/hwmp/chk/$(hostname); cd /home/cmsupport/workspace/spx/hwmp/chk/$(hostname); nohup bash /home/cmsupport/workspace/spx/hwmp/spcx_conf_check.sh all &> $(hostname).log &
EOF
__END__
