#!/bin/bash

## Install the Fleetintelligence agent
# Ref: 
#  https://docs.nvidia.com/fleet-intel/agent/install-deb/
#  https://github.com/dsx-ai-factory/fleet-intelligence-agent/releases

image_name=hgx-image-u2404
cm-chroot-sw-img /cm/images/${image_name} <<- '__END__'
wget -c https://github.com/dsx-ai-factory/fleet-intelligence-agent/releases/download/v1.4.0/fleetint_1.4.0_amd64.deb
apt install ./fleetint_1.4.0_amd64.deb
systemctl enable fleetintd
rm -f ./fleetint_1.4.0_amd64.deb
__END__

## Add fleetint files to BCM category exclude list
cmsh <<- EOF
home
category
use default
append excludelistsyncinstall "\n- /etc/default/fleetint/*\n- /var/lib/fleetint/*"
append excludelistgrab "\n- /etc/default/fleetint/*\n- /var/lib/fleetint/*"
append excludelistupdate "\n- /etc/default/fleetint/*\n- /var/lib/fleetint/*"
append excludelistgrabnew "\n- /etc/default/fleetint/*\n- /var/lib/fleetint/*"
commit
EOF

cat > /dev/null <<- '__README__'
### 1. 基本安装检查
  sudo fleetint --version
  sudo systemctl status fleetintd --no-pager
  sudo journalctl -u fleetintd -n 100 --no-pager
  日志中如果只有连接 data.fleet-intelligence.nvidia.com 失败，在无 Internet 环境下是预期现象；重点检查是否存在 DCGM、驱动、权限或组件初始化错误。

### 2. 检查 GPU 和 Agent 看到的硬件
  nvidia-smi
  sudo fleetint precheck
  sudo fleetint machine-info
  sudo fleetint scan
  sudo fleetint status
  其中：
  - precheck：检查安装及运行前提；网络项失败可以暂时忽略。
  - machine-info：验证 CPU、GPU、驱动、CUDA、网卡和机器 UUID 是否能正确采集。
  - scan：执行本地快速健康扫描。
  - status：检查各监控组件状态。
  这些也是 NVIDIA 官方推荐的排障命令：Fleet Intelligence Troubleshooting。

### 3. 测试本地 API
默认 Agent 通过 Unix socket 提供 API：
sudo curl -s --unix-socket /run/fleetint/fleetint.sock http://localhost/healthz
  正常应返回类似：
  {
    "status": "ok",
    "version": "v1"
  }
还可以查询机器信息：
sudo curl -s --unix-socket /run/fleetint/fleetint.sock http://localhost/machine-info | jq
  如果 socket 不存在：
  sudo systemctl restart fleetintd
  sudo journalctl -u fleetintd -n 100 --no-pager
  
### 4. 使用官方离线采集模式
  为了避免和正在运行的服务同时访问本地状态，先暂时停止服务：
  output_dir="/tmp/fleetint-offline-$(date +%Y%m%d-%H%M%S)"
  sudo systemctl stop fleetintd
  sudo fleetint run \
    --offline-mode \
    --path="$output_dir" \
    --duration=00:05:00 \
    --format=json
  sudo systemctl start fleetintd
  find "$output_dir" -maxdepth 2 -type f -ls
  验证输出 JSON 是否完整：
  find "$output_dir" -type f -name '*.json' -print0 |
      xargs -0 -r -n1 jq empty
  也可以输出 CSV：
  sudo fleetint run \
    --offline-mode \
    --path=/tmp/fleetint-csv-test \
    --duration=00:05:00 \
    --format=csv
  这是 Fleet Intelligence 官方提供的无网络采集方式：Agent Usage / Offline Data Collection。

### 5. 等 Internet 开通后做端到端测试
  Agent需要访问：
  https://data.fleet-intelligence.nvidia.com
  测试方法：
  getent hosts data.fleet-intelligence.nvidia.com
  curl -I -m 30 \
    https://data.fleet-intelligence.nvidia.com/test
  正常情况下第二条命令应快速返回 HTTP 404；这里的 404 表明 DNS、TCP 443 和 TLS 都已成功，路径不存在反而是预期结果。超时或无法解析才表示网络有问题。
  如果节点不能直接上网但允许使用代理，可以在 /etc/default/fleetint 配置：
  HTTPS_PROXY="http://proxy.example.com:3128"
  然后：
  sudo systemctl restart fleetintd
  sudo journalctl -f -u fleetintd
  代理配置是 Fleet Intelligence 官方支持的：Agent Configuration。
  结论：离线模式可以完整验证“本地采集链路”，但无法验证 enrollment、远程上传、云端告警和 Dashboard；这些必须至少允许 Agent 通过 HTTPS 访问 Fleet Intelligence 服务。
__README__
