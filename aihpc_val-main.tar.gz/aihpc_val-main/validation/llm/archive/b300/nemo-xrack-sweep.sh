#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

# echo 'set -g mouse off' > ~/.tmux.conf && tmux -f ~/.tmux.conf new -s junli

export PDSH_SSH_ARGS_APPEND="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=quiet -o CheckHostIP=no -o PreferredAuthentications=publickey"

need_validate_nodes=(
HGX[001-144]
#HGX[001-072]
#HGX[073-144]
)

known_bad_nodes=(
##MEM, can't boot
#HGX046
##GPU, can't detect GPU
HGX[094,119]
##IB DOWN
#HGX008
##ETH
#HGX085
##FAN
#HGX136
##PSU
#HGX076
#HGX079
## HGX019
#HGX010
#HGX022
## HGX136
#NVSwitch
## HGX127
##OS - grep Xid /var/log/syslog|grep PCI||true
#HGX073: WARN: Xid shown in dmesg: Xid:149
#HGX127: WARN: LnkCap!=LnkSta - 48:00.0 48:00.1
#HGX034: WARN: Xid shown in dmesg: Xid:149
##IB mis-wired
#HGX080
#HGX085
#HGX104
#HGX105
)

nodelist=$(
  #scontrol show hostname $(echo ${need_validate_nodes[@]}|tr ' ' ','),$(echo ${known_bad_nodes[@]}|tr ' ' ',')|sort|uniq -c|awk '($1==1){print $NF}'|paste -s -d','
  comm -23 \
    <(scontrol show hostname $(echo ${need_validate_nodes[@]}|tr ' ' ',')|sort) \
    <(scontrol show hostname $(echo ${known_bad_nodes[@]}|tr ' ' ',')|sort) \
  | paste -s -d','
)

# Set FAN speed to 100% for all nodes in advance !!!
#(cd /home/cmsupport/workspace/aihpc_val/tools/hc/nodetools && ./nodefan.dell $nodelist max && sleep 10 && ./nodefan.dell $nodelist)
pdsh -t 5 -u 30 -f 36 -R ssh -w $(scontrol show hostname $(echo ${a[*]}|tr ' ' ',')|paste -s -d ',') <<- 'EOF' | tee /tmp/fans.txt
ipmitool sdr|grep RPM|awk '{print $3}'|paste -s -d ' '
EOF
sort -k2 -nr /tmp/fans.txt|tail -n 20

pdsh -f 100 -R ssh -w $nodelist <<- 'EOF'|dshbak -c
sudo kill -9 $(nvidia-smi --query-compute-apps=pid -format=csv,noheader,nounits) &>/dev/null || true
find /cm/local/apps/slurm/var/pre-post-job-logs -type f -exec rm -f {} \;
bash /home/cmsupport/workspace/aihpc_val/tools/hc/ibcounter.sh clear
EOF
pdsh -f 100 -R ssh -w $nodelist <<- 'EOF'
bash /home/cmsupport/workspace/aihpc_val/tools/hc/checker-B300.sh -e 1 | grep -v PASS||true
EOF
bash /home/cmsupport/workspace/aihpc_val/tools/hc/sysinfo.sh $nodelist 2>&1 | tee sysinfo-$(date +%Y%m%d).log

pdsh -f 100 -R ssh -w $nodelist <<- 'EOF'|dshbak -c
ls -l /raid/nemo-25.11.01.sqsh|grep -v /raid||true
EOF
pdsh -f 32 -R ssh -w $nodelist <<- 'EOF'
rsync -P /home/cmsupport/workspace/nemo-25.11.01.sqsh /raid
EOF

pdsh -f 100 -R ssh -w $nodelist <<- 'EOF'|dshbak -c
uname -r
cat /proc/cmdline | tr ' ' '\n'|grep -v -E 'ip=|BOOT' | sort | paste -s -d ' '
EOF

a=(
$(echo $nodelist|sed 's:],:] :g')
)

scontrol show node $(echo ${a[*]}|tr ' ' ',') |grep -E 'NodeName|CfgTRES='|paste - -|sed -e 's# Arch=#:Arch=#g' -e 's#NodeName=##g' |dshbak -c

#scontrol update nodename=$(echo ${a[*]}|tr ' ' ',') stat=undrain
scontrol show node $(echo ${a[*]}|tr ' ' ',') |grep -E 'NodeName|State'|paste - -|grep -o State.*|sort|uniq -c

## 1N test
for i in $(scontrol show hostname $(echo ${a[*]}|tr ' ' ',')); do
  sbatch \
    -N 1 \
    -w $i \
    -t 30:00 \
    --job-name=NEMO-1N \
    --output=${USER}-NEMO-1N-%N-%j.txt \
    nemo-nemotron5h_56b-mbridge-26.xx.sh
    #nemo-nemotron5h_56b-mbridge-fp8.sh
done

## Step Test
#scancel -u $USER
b=($(scontrol show hostname ${a[*]}))
step=; for step in 2 8 16 32 64 128 ${#b[*]}; do
  i=0; while [ $i -lt ${#b[*]} ]; do
    s0=$[i+1]
    s1=$[i+step]
    hosts=($(scontrol show hostname $(echo ${b[*]} ${b[*]}|cut -f${s0}-${s1} -d ' '|tr ' ' ',')))
    postfix=$(echo ${hosts[*]}|/home/cmsupport/workspace/aihpc_val/tools/hc/nodetools/python3-hostlist/hostlist -c -)
    #cat <<- EOF
    sbatch \
        -N ${#hosts[*]} \
        -w $(echo "${hosts[*]}"|tr ' ' ',') \
        -t 1:00:00 \
        --job-name=NEMO-${step}N \
        --output=${USER}-NEMO-${#hosts[*]}N-${postfix}-%j.txt \
        nemo-nemotron5h_56b-mbridge-26.xx.sh
        #nemo-nemotron5h_56b-mbridge-fp8.sh
#EOF
    i=${s1}
  done
done

## For debug scalability issue
#scancel -u $USER
b=($(scontrol show hostname ${a[*]}))
step=; for step in 8 16 32 64 128; do
  i=0; while [ $i -lt ${#b[*]} ]; do
    s0=$[i+1]
    s1=$[i+step]
    hosts=($(scontrol show hostname $(echo ${b[*]} ${b[*]}|cut -f${s0}-${s1} -d ' '|tr ' ' ',')))
    postfix=$(echo ${hosts[*]}|/home/cmsupport/workspace/aihpc_val/tools/hc/nodetools/python3-hostlist/hostlist -c -)
    #cat <<- EOF
    sbatch \
        -N ${#hosts[*]} \
        -w $(echo "${hosts[*]}"|tr ' ' ',') \
        -t 1:00:00 \
        --job-name=NEMO-${step}N \
        --output=${USER}-NEMO4_340B-${#hosts[*]}N-${postfix}-%j.txt \
        nemo-nemotron4_340b.sh
#EOF
    i=${s1}
  done
done

b=($(scontrol show hostname ${a[*]}))
step=; for step in 16 32 64 128; do
  i=0; while [ $i -lt ${#b[*]} ]; do
    s0=$[i+1]
    s1=$[i+step]
    hosts=($(scontrol show hostname $(echo ${b[*]} ${b[*]}|cut -f${s0}-${s1} -d ' '|tr ' ' ',')))
    postfix=$(echo ${hosts[*]}|/home/cmsupport/workspace/aihpc_val/tools/hc/nodetools/python3-hostlist/hostlist -c -)
    #cat <<- EOF
    sbatch \
        -N ${#hosts[*]} \
        -w $(echo "${hosts[*]}"|tr ' ' ',') \
        -t 1:00:00 \
        --job-name=NEMO-${step}N \
        --output=${USER}-LLAMA31_405B-${#hosts[*]}N-${postfix}-%j.txt \
        nemo-llma31_405b-mbridge.sh
#EOF
    i=${s1}
  done
done

b=($(scontrol show hostname ${a[*]}))
step=; for step in 16 32; do
  i=0; while [ $i -lt ${#b[*]} ]; do
    s0=$[i+1]
    s1=$[i+step]
    hosts=($(scontrol show hostname $(echo ${b[*]} ${b[*]}|cut -f${s0}-${s1} -d ' '|tr ' ' ',')))
    postfix=$(echo ${hosts[*]}|/home/cmsupport/workspace/aihpc_val/tools/hc/nodetools/python3-hostlist/hostlist -c -)
    #cat <<- EOF
    sbatch \
        -N ${#hosts[*]} \
        -w $(echo "${hosts[*]}"|tr ' ' ',') \
        -t 1:00:00 \
        --job-name=NEMO-${step}N \
        --output=${USER}-DEEPSEEKV3-${#hosts[*]}N-${postfix}-%j.txt \
        nemo-deepseekv3-mbridge-26.xx.sh
#EOF
    i=${s1}
  done
done


b=($(scontrol show hostname ${a[*]}))
step=; for step in 16 32; do
  i=0; while [ $i -lt ${#b[*]} ]; do
    s0=$[i+1]
    s1=$[i+step]
    hosts=($(scontrol show hostname $(echo ${b[*]} ${b[*]}|cut -f${s0}-${s1} -d ' '|tr ' ' ',')))
    postfix=$(echo ${hosts[*]}|/home/cmsupport/workspace/aihpc_val/tools/hc/nodetools/python3-hostlist/hostlist -c -)
    #cat <<- EOF
    sbatch \
        -N ${#hosts[*]} \
        -w $(echo "${hosts[*]}"|tr ' ' ',') \
        -t 1:00:00 \
        --job-name=NEMO-${step}N \
        --output=${USER}-QWEN3-${#hosts[*]}N-${postfix}-%j.txt \
        nemo-qwen3-mbridge-26.xx.sh
#EOF
    i=${s1}
  done
done

for i in ${b[@]}; do
  sbatch -w $i -N 1 -o NCCL-LOOPBACK-DEBUG-%N-%j.txt ./nccl-loopback.sbatch
done

for i in $(ls -1rth NCCL-LOOPBACK-DEBUG-*.txt); do
  printf "%30s%20s%10s\n" $i $(grep 17179869184.*float $i|awk '{print $8}') $(grep 'Out of bounds values' $i|awk '{print $NF}')
done|sort -k2nr|tee nccl-loopback-1n.log

####### Balance nodes by pods, each pod has 72 nodes, and we can only test up to 64 nodes, so we can get 64 nodes from each pod, then do the scalability test. This is a workaround for the unbalanced node issue.

declare -A pods=()
for i in $(scontrol show hostname ${a[*]}); do
  n=$(expr `echo ${i##HGX} + 0`)
  pn=$(((n-1)/72))
  pods[$pn]="${pods[$pn]} $i"
done
hosts=($(
max=64; for i in ${!pods[@]}; do
  if [ ${#pods[$i]} -ge ${max} ]; then
    echo ${pods[$i]} | cut -f1-${max} -d' '
  fi
done
))
echo ${#hosts[*]}
echo ${hosts[*]}
postfix=$(echo ${hosts[*]}|/home/cmsupport/workspace/aihpc_val/tools/hc/nodetools/python3-hostlist/hostlist -c -)
sbatch \
  -N ${#hosts[*]} \
  -w $(echo "${hosts[*]}"|tr ' ' ',') \
  -t 1:00:00 \
  --job-name=NEMO-${step}N \
  --output=${USER}-NEMO-${#hosts[*]}N-${postfix}-%j.txt \
  nemo-nemotron5h_56b-mbridge-fp8.sh
