#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

## B300 HGX setup: 2xIntel 6776P(64C/128T, HT=ON, SNC=OFF) + 32x128GB DIMM + 8xB300 + 8xConnectX-8
#SBATCH -p defq
#SBATCH --exclusive
#SBATCH --mem=0
#SBATCH --ntasks-per-node=8
#SBATCH --cpus-per-task=32
#SBATCH --gpus-per-node=8
#SBATCH -N 16

CONT=/raid/nemo-26.08.00.sqsh
HUGGINGFACE_CACHE=/home/cmsupport/workspace/huggingface

module load slurm
cd ${SLURM_SUBMIT_DIR}

echo
echo "NODELIST: ${SLURM_JOB_NODELIST}"
echo

s_time=$(date +%s)
echo "INFO: cleaning work begin"
pdsh -f 64 -R ssh -w ${SLURM_JOB_NODELIST} <<- 'EOF'|dshbak -c
pkill -9 python &>/dev/null || true
ps -ef|grep python|grep -E 'torch|nemo'|grep -v grep || true
enroot list -f|grep pyxis && enroot remove -f $(enroot list -f|grep pyxis) || true
rm -f /var/lib/systemd/coredump/* &>/dev/null || true
EOF
echo "INFO: cleaning work done"

echo "INFO: checking hardware status"
timeout 100 bash /home/cmsupport/workspace/aihpc_val/tools/hc/sysinfo.sh 2>&1

set -x
ns_nic=bond0
ew_nics=($(lspci -D|grep Infiniband.*ConnectX-8|awk '{print $1}'|while read i; do ls -l /sys/class/infiniband|grep -o ${i}/.*|awk -F'/' '{print $NF}'; done))
export MELLANOX_VISIBLE_DEVICES=all
export PMIX_MCA_gds=hash
#
export UCX_TLS=tcp UCX_NET_DEVICES=${ns_nic}
#export UCX_TLS=rc UCX_NET_DEVICES="$(echo ${ew_nics[@]}|tr ' ' '\n'|xargs -I {} echo {}:1|paste -s -d',')"
export NCCL_IB_HCA="=$(echo ${ew_nics[@]}|tr ' ' '\n'|xargs -I {} echo {}|paste -s -d',')"
#
export NCCL_SOCKET_IFNAME=${ns_nic}
export MCA_btl_tcp_if_include=${ns_nic}
export MCA_oob_tcp_if_include=${ns_nic}
export NVTE_UB_SOCKET_IFNAME=${ns_nic}
export GLOO_SOCKET_IFNAME=${ns_nic}
#
export OMPI_ALLOW_RUN_AS_ROOT=1
export OMPI_ALLOW_RUN_AS_ROOT_CONFIRM=1
export OMPI_MCA_btl_openib_warn_default_gid_prefix=0
export OMPI_MCA_coll_hcoll_enable=0
export SLURM_CPU_BIND=none
## Minimize the impact of IB link flapping
export NCCL_IB_TIMEOUT=25 #Timeout 2.3min
export NCCL_IB_RETRY_CNT=7 #7x2.3=16min
export NCCL_IB_RESILIENCY_PORT_RECOVERY=1
export NCCL_IB_RESILIENCY_PORT_FAILOVER=1
export NCCL_NVLS_ENABLE=0

########  NOTE: 
#  Deepseek V3 variation 2 can't work with named container well(leading to error like "GIL xxx"), 
#  so we have to use unnamed container for it.
########  ENDNOTE

########  nccl test
# cat > /dev/null <<- '__COMMENT__'
export NCCL_DEBUG=WARN
export NCCL_GDRCOPY_ENABLE=1 NCCL_GDRCOPY_SYNC_ENABLE=1
timeout 300 \
srun --export=ALL --cpu-bind=none --mpi=pmix \
--container-writable \
--container-image=$CONT \
--container-mounts=/dev:/dev \
alltoall_perf_mpi -d uint8 -b 8 -f 2 -g 1 -e 16G --iters 20 -R 0
exitcode=$?
if [ $exitcode -ne 0 ]; then
  echo "*********************************************"
  echo "* ERROR: NCCL failed to run!!!              *"
  echo "*********************************************"
  exit 1
fi
## As GDRCOPY boost nccl 2.30.4's alltoall performance a lot, but may cause instability for nemo test, disable it for safety.
unset NCCL_GDRCOPY_ENABLE NCCL_GDRCOPY_SYNC_ENABLE 
sleep 10
#__COMMENT__

########  nemo test
#
### Parameters Reference:
# To find out which branch is used to build the container, refer 
#      https://docs.nvidia.com/nemo/megatron-bridge/latest/releases/software-versions.html#software-component-versions
# Args: https://github.com/NVIDIA-NeMo/Megatron-Bridge/tree/main/scripts/performance
#
GPU_TYPE=${GPU_TYPE:-b300}
DTYPE=${DTYPE:-nvfp4}
#
## Workaround for unstable or not robust enough NVLINK:
# It's usually better than turning off tp_comm_overlap entirely, but worse than full multicast on a healthy, supported fabric.
# UB_SKIPMC: UserBuffers Skip Multicast
# UB = UserBuffers (the TP-overlap communication backend in TransformerEngine)
# SKIPMC = skip multicast (don't use CUDA/NVLS multicast for UB collectives)
## export NCCL_NVLS_ENABLE=0
## export UB_SKIPMC=1
export NCCL_DEBUG=INFO
export TRANSFORMERS_OFFLINE=1
export TOKENIZERS_PARALLELISM=False
export HF_HUB_OFFLINE=1
export NCCL_NVLS_ENABLE=0
export TORCH_NCCL_HIGH_PRIORITY=1
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True,graph_capture_record_stream_reuse:True
export NCCL_GRAPH_REGISTER=0
export CUDA_DEVICE_MAX_CONNECTIONS=32
export NVTE_FWD_LAYERNORM_SM_MARGIN=20
export NVTE_BWD_LAYERNORM_SM_MARGIN=20
export NUM_OF_TOKENS_PER_CHUNK_COMBINE_API=128
export NVTE_ALLOW_NONDETERMINISTIC_ALGO=0
export NVTE_CUTEDSL_FUSED_GROUPED_MLP=1
export CUDNNFE_CLUSTER_OVERLAP_MARGIN=8
export NVTE_NORM_FWD_USE_CUDNN=1
export NVTE_NORM_BWD_USE_CUDNN=1
case "${GPU_TYPE}" in
  gb200)
    export TORCH_NCCL_AVOID_RECORD_STREAMS=0
    export NUM_OF_HYBRID_EP_RANKS_PER_NVLINK_DOMAIN=64
    export NVLINK_DOMAIN_SIZE=72
    export USE_MNNVL=1
    unset NCCL_IGNORE_CPU_AFFINITY
    ;;
  gb300)
    export TORCH_NCCL_AVOID_RECORD_STREAMS=0
    export NUM_OF_HYBRID_EP_RANKS_PER_NVLINK_DOMAIN=32
    export NVLINK_DOMAIN_SIZE=72
    export USE_MNNVL=1
    unset NCCL_IGNORE_CPU_AFFINITY
    ;;
  b300)
    export TORCH_NCCL_AVOID_RECORD_STREAMS=1
    export NUM_OF_HYBRID_EP_RANKS_PER_NVLINK_DOMAIN=8
    export NVLINK_DOMAIN_SIZE=8
    export USE_MNNVL=0
    export NCCL_IGNORE_CPU_AFFINITY=1
    ;;
esac

if [[ $DTYPE == "fp8" ]]; then
    if [[ $GPU_TYPE == "h100" ]]; then
        FP8_RECIPE="sc"
    else
        FP8_RECIPE="mx"
    fi
    COMPUTE_TYPE=${DTYPE}_${FP8_RECIPE}
else
    COMPUTE_TYPE=${DTYPE}
fi

JOB_TOTAL_GPUS=$[8*${SLURM_NNODES}]
PROFILE_ENABLED=${ENABLE_PROFILE:-false}
PROFILE_ENABLED=${PROFILE_ENABLED,,}
PYTORCH_PROFILE_ENABLED=${ENABLE_PYTORCH_PROFILE:-false}
PYTORCH_PROFILE_ENABLED=${PYTORCH_PROFILE_ENABLED,,}
PROFILE_START_STEP=${PROFILE_START_STEP:-45}
PROFILE_STOP_STEP=${PROFILE_STOP_STEP:-50}
GPU_METRICS_ENABLED=${ENABLE_GPU_METRICS:-false}
GPU_METRICS_ENABLED=${GPU_METRICS_ENABLED,,}
ENABLE_VBOOST=${ENABLE_VBOOST:-false}
ENABLE_VBOOST=${ENABLE_VBOOST,,}
ENABLE_PCT_BINDING=${ENABLE_PCT_BINDING:-false}
ENABLE_PCT_BINDING=${ENABLE_PCT_BINDING,,}
IS_PROXY_WORKLOAD=${PROXY_WORKLOAD:-false}
IS_PROXY_WORKLOAD=${IS_PROXY_WORKLOAD,,}
CPU_PERF_PROXY=${CPU_PERF_PROXY:-false}
CPU_PERF_PROXY=${CPU_PERF_PROXY,,}
DISABLE_CG=${DISABLE_CG:-false}
DISABLE_CG=${DISABLE_CG,,}
MAX_STEPS=${MAX_STEPS:-110}

CONFIG_OVERRIDES=""

if [[ $PROFILE_ENABLED == "true" ]] && [[ $PYTORCH_PROFILE_ENABLED == "true" ]]; then
    echo "Error: ENABLE_PROFILE and ENABLE_PYTORCH_PROFILE are mutually exclusive." >&2
    exit 1
fi

if [[ $PROFILE_ENABLED == "true" ]]; then
    CONFIG_OVERRIDES+=" --enable_nsys "
    CONFIG_OVERRIDES+=" --profiling_start_step=$PROFILE_START_STEP "
    CONFIG_OVERRIDES+=" --profiling_stop_step=$PROFILE_STOP_STEP "
    PROFILE_RANKS=$(seq -s, 0 $((JOB_TOTAL_GPUS - 1)))
    CONFIG_OVERRIDES+=" --profiling_ranks=$PROFILE_RANKS"
    CONFIG_OVERRIDES+=" --nsys_trace=cuda "
    CONFIG_OVERRIDES+=" --nsys_extra_args=--nvtx-domain-include=NCCL "
    if [[ $GPU_METRICS_ENABLED == true ]]; then
        CONFIG_OVERRIDES+=" --profiling_gpu_metrics "
    fi
fi

if [[ $PYTORCH_PROFILE_ENABLED == "true" ]]; then
    CONFIG_OVERRIDES+=" --pytorch_profiler true "
fi

if [[ $ENABLE_VBOOST == true ]]; then
    CONFIG_OVERRIDES+=" --enable_vboost true "
fi

CONFIG_OVERRIDES+=" --enable_pct_binding $ENABLE_PCT_BINDING "

if [[ $GPU_TYPE == "gb300" ]] || [[ $GPU_TYPE == "gb200" ]]; then
    GPUS_PER_NODE=4
elif [[ $GPU_TYPE == "b300" ]] || [[ $GPU_TYPE == "b200" ]] || [[ $GPU_TYPE == "h100" ]]; then
    GPUS_PER_NODE=8
else
    echo "Error: Unsupported GPU_TYPE '$GPU_TYPE'. Expected one of: gb300, gb200, b300, b200, h100." >&2
    exit 1
fi

if [[ $GPU_TYPE == "gb300" ]] && [[ $JOB_TOTAL_GPUS -eq 128 ]]; then
    CONFIG_OVERRIDES+=" -pp 4 "
    CONFIG_OVERRIDES+=" -vp 4 "
    CONFIG_OVERRIDES+=" -ep 32 "
    CONFIG_OVERRIDES+=" --recompute_modules=mla_up_proj "
fi

if [[ $GPU_TYPE == "gb200" ]] && [[ $JOB_TOTAL_GPUS -eq 128 ]] && [[ $COMPUTE_TYPE == "fp8_mx" ]]; then
    CONFIG_OVERRIDES+=" -tp 2 "
    CONFIG_OVERRIDES+=" -pp 2 "
    CONFIG_OVERRIDES+=" -vp 8 "
    CONFIG_OVERRIDES+=" -ep 32 "
    CONFIG_OVERRIDES+=" --recompute_modules=mla_up_proj "
fi

if [[ $GPU_TYPE == "b300" ]] && [[ $JOB_TOTAL_GPUS -eq 128 ]]; then
    if [[ $COMPUTE_TYPE == "bf16" ]]; then
        CONFIG_OVERRIDES+=" --cuda_graph_impl none "
    elif [[ $COMPUTE_TYPE == "fp8_mx" ]]; then
        CONFIG_OVERRIDES+=" --recompute_modules=mla_up_proj,core_attn "
    fi
fi

if [[ $GPU_TYPE == "b200" ]] && [[ $JOB_TOTAL_GPUS -eq 128 ]] && [[ $COMPUTE_TYPE == "fp8_mx" ]]; then
    CONFIG_OVERRIDES+=" --cuda_graph_impl none "
    CONFIG_OVERRIDES+=" --recompute_modules=mla_up_proj,core_attn,moe "
fi

if [[ $IS_PROXY_WORKLOAD == true ]]; then
    if [[ $CPU_PERF_PROXY == false ]] && [[ $GPU_TYPE != "h100" ]]; then # Lower resource proxy workloads
        tp=1
        pp=1
        vp=None
        mb=1
        num_layers=31
        if [[ $GPU_TYPE == "gb300" || $GPU_TYPE == "gb200" ]]; then
            if ((JOB_TOTAL_GPUS % 72 == 0)); then
                ep=72
                num_moe_experts=144
            else
                ep=$JOB_TOTAL_GPUS
                num_moe_experts=$((JOB_TOTAL_GPUS * 2))
            fi
        elif [[ $GPU_TYPE == "b300" || $GPU_TYPE == "b200" ]]; then
            ep=8
            num_moe_experts=$((JOB_TOTAL_GPUS * 2))
            if [[ $JOB_TOTAL_GPUS -eq 64 ]]; then
                pp=2
                vp=4
                pipeline_model_parallel_layout="Et*4\|\(t*4\|\)*6t*3mL"
                CONFIG_OVERRIDES+=" --pipeline_model_parallel_layout=$pipeline_model_parallel_layout "
            fi
        fi
        if [[ $GPU_TYPE == "gb300" || $GPU_TYPE == "b300" ]]; then
            mb=2
        fi
        CONFIG_OVERRIDES+=" -tp $tp "
        CONFIG_OVERRIDES+=" -pp $pp "
        CONFIG_OVERRIDES+=" -vp $vp "
        CONFIG_OVERRIDES+=" -ep $ep "
        CONFIG_OVERRIDES+=" -mb $mb "
        CONFIG_OVERRIDES+=" --num_layers $num_layers "
        CONFIG_OVERRIDES+=" --num_moe_experts $num_moe_experts "
    elif [[ $CPU_PERF_PROXY == true ]] && [[ $GPU_TYPE != "h100" ]]; then # CPU proxy workloads
        if [[ $JOB_TOTAL_GPUS -eq $GPUS_PER_NODE ]]; then
            CONFIG_OVERRIDES+=" -ep $GPUS_PER_NODE "
        elif [[ $JOB_TOTAL_GPUS -eq 64 ]] && { [[ $GPU_TYPE == "gb200" ]] || [[ $GPU_TYPE == "gb300" ]]; }; then
            CONFIG_OVERRIDES+=" -ep 64 "
        else
            echo "Error: CPU proxy workloads are supported only for a single node (gb300/gb200/b300/b200) or 64 GPUs (gb200/gb300)."
            exit 1
        fi
        CONFIG_OVERRIDES+=" -tp 1 "
        CONFIG_OVERRIDES+=" -pp 1 "
        CONFIG_OVERRIDES+=" -vp None "
        CONFIG_OVERRIDES+=" -mb 1 "
        CONFIG_OVERRIDES+=" --num_layers 31 "
        CONFIG_OVERRIDES+=" --hidden_size 512 "
    fi
fi

if [[ $DISABLE_CG == true ]]; then
    CONFIG_OVERRIDES+=" --cuda_graph_impl none "
fi

export GPU_TYPE
export COMPUTE_TYPE
export JOB_TOTAL_GPUS
export GPUS_PER_NODE
export CONFIG_OVERRIDES
export MAX_STEPS
export OPENBLAS_NUM_THREADS=1

srun --export=ALL --cpu-bind=none --mpi=pmix \
--container-writable \
--container-image=${CONT} \
--container-mounts=/dev:/dev,${HUGGINGFACE_CACHE}:/root/.cache/huggingface \
--wait=600 --kill-on-bad-exit=1 --mpi=pmix \
bash <<- __END__
set -ex
export HF_HOME=/root/.cache/huggingface
export CPATH=/usr/local/cuda/include
export TRITON_PTXAS_PATH=/usr/local/cuda/bin/ptxas
export TRITON_LIB_DIR=/usr/local/cuda/lib64
export PYTHONPATH=/opt/Megatron-Bridge/scripts/performance:\$PYTHONPATH
export NEMORUN_HOME=/mnt/nemo
export NEMO_HOME=\${NEMORUN_HOME}/experiments
numactl --cpunodebind=\$[SLURM_LOCALID/4] --membind=\$[SLURM_LOCALID/4] \
python /opt/Megatron-Bridge/scripts/performance/run_script.py \
  --account root \
  --partition defq \
  --log_dir \${NEMORUN_HOME} \
  --compute_dtype ${COMPUTE_TYPE} \
  --gpu ${GPU_TYPE} \
  --num_gpus ${JOB_TOTAL_GPUS} \
  --gpus_per_node ${GPUS_PER_NODE} \
  --offline \
  --model_family_name deepseek \
  --model_recipe_name deepseek_v3 \
  ${CONFIG_OVERRIDES} \
  --max_steps ${MAX_STEPS} \
  --packager none \
  train.manual_gc=true train.manual_gc_interval=100
__END__

set +x

e_time=$(date +%s)
echo "INFO: timelimit=$[(SLURM_JOB_END_TIME-SLURM_JOB_START_TIME)](s), real_took=$[e_time-s_time](s)"

### If you want to check the parms used in the above script, you can use the following command to check(reference only):
cat > /dev/null <<- '__COMMENT__'
#!/bin/bash
export HUGGINGFACE_CACHE=/home/cmsupport/workspace/huggingface
export IMAGE=${IMAGE:-/raid/nemo-26.08.00.sqsh}
export COMPUTE_TYPE=${COMPUTE_TYPE:-nvfp4}
export GPU_TYPE=${GPU_TYPE:-b300}
export JOB_TOTAL_GPUS=${JOB_TOTAL_GPUS:-256}
export GPUS_PER_NODE=${GPUS_PER_NODE:-8}
export MAX_STEPS=${MAX_STEPS:-110}
export WORKSPACE=${WORKSPACE:-$PWD}
#
srun --export=ALL --cpu-bind=none --mpi=pmix \
--container-writable \
--container-image=${IMAGE} \
--container-mounts=/dev:/dev,${WORKSPACE}:${WORKSPACE},${HUGGINGFACE_CACHE}:/root/.cache/huggingface \
--wait=600 --kill-on-bad-exit=1 --mpi=pmix --gpus-per-node=1 \
bash <<- '__END__'
export PYTHONPATH=/opt/Megatron-Bridge/scripts/performance:$PYTHONPATH
cat > /usr/local/bin/sbatch <<- 'EOF'
#!/bin/bash
echo "sbatch $@"
EOF
chmod a+x /usr/local/bin/sbatch
export NEMORUN_HOME=${WORKSPACE}/${GPU_TYPE}
cd /opt/Megatron-Bridge
set -x
# https://github.com/NVIDIA-NeMo/Megatron-Bridge/tree/main/scripts/performance
python3 scripts/performance/setup_experiment.py \
  --account root \
  --partition defq \
  --container_image ${IMAGE} \
  --log_dir $NEMORUN_HOME \
  --compute_dtype ${COMPUTE_TYPE} \
  --gpu ${GPU_TYPE} \
  --num_gpus ${JOB_TOTAL_GPUS} \
  --gpus_per_node ${GPUS_PER_NODE} \
  --offline \
  --model_family_name deepseek \
  --model_recipe_name deepseek_v3 \
  --max_steps $MAX_STEPS \
  ${CONFIG_OVERRIDES}
__END__
__COMMENT__
