#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

log_files=($@)

min_iter=${min_iter:-70} #35
max_iter=${max_iter:-90} #44

log_parser(){
  file=$1
  if [ $(grep -o 'Step Time.*MODEL_TFLOP/s/GPU' $file|wc -l) -gt 0 ]; then
     grep -o 'Step Time.*MODEL_TFLOP/s/GPU' $file|sed -e 's:s GPU: s GPU:g' -e 's:MODEL_TFLOP: MODEL_TFLOP:g' \
       | awk -v min_iter=$min_iter -v max_iter=$max_iter -v fname=$file '
BEGIN{ct=0; ts=0; ps=0;}
{if(min_iter<=NR && NR<=max_iter){ct+=1; tv[ct]=$4; ts+=$4; pv[ct]=$8; ps+=$8;}}
END{
  if(ct>0){
    t_mean=ts/ct
    t_var=0
    for (i = 1; i <= ct; i++) t_var += (tv[i] - t_mean)^2
    t_std = (ct > 1 ? sqrt(t_var / (ct - 1)) : 0)

    p_mean=ps/ct
    p_var=0
    for (i = 1; i <= ct; i++) p_var += (pv[i] - p_mean)^2
    p_std = (ct > 1 ? sqrt(p_var / (ct - 1)) : 0)

    t_cv = (t_mean != 0 ? t_std / t_mean : 0)
    p_cv = (p_mean != 0 ? p_std / p_mean : 0)
    
    printf "%100s: Step[s]=%.2f perGPU[TFLOPs]=%.2f Sstd=%.5f Pstd=%.5f SCV=%.2f%% PCV=%.2f%%\n", fname, ts/ct, ps/ct, t_std, p_std, t_cv*100, p_cv*100
  }
}
'
  elif [ $(grep -o 'train_step_timing.*consumed_samples' $file|wc -l) -gt 0 ]; then
    grep -o 'train_step_timing.*consumed_samples' $file|tr '|' ' ' \
      | awk -v min_iter=$min_iter -v max_iter=$max_iter -v fname=$file '
BEGIN{ct=0; ts=0; ps=0;}
{if(min_iter<=NR && NR<=max_iter){ct+=1; tv[ct]=$4; ts+=$4; pv[ct]=$6; ps+=$6;}}
END{
  if(ct>0){
    t_mean=ts/ct
    t_var=0
    for (i = 1; i <= ct; i++) t_var += (tv[i] - t_mean)^2
    t_std = (ct > 1 ? sqrt(t_var / (ct - 1)) : 0)

    p_mean=ps/ct
    p_var=0
    for (i = 1; i <= ct; i++) p_var += (pv[i] - p_mean)^2
    p_std = (ct > 1 ? sqrt(p_var / (ct - 1)) : 0)

    t_cv = (t_mean != 0 ? t_std / t_mean : 0)
    p_cv = (p_mean != 0 ? p_std / p_mean : 0)
    
    printf "%100s: Step[s]=%.2f perGPU[TFLOPs]=%.2f Sstd=%.5f Pstd=%.5f SCV=%.2f%% PCV=%.2f%%\n", fname, ts/ct, ps/ct, t_std, p_std, t_cv*100, p_cv*100
  }
}
'
  else
    [[ $(grep 'srun:.*error:.*Exited' $file|wc -l) -gt 0 || $(grep 'error:.*SIGNAL' $file|wc -l) -gt 0 ]] && msg="FAILED" || msg="UNKNOWN"
    [[ $(grep 'Step Time.*MODEL_TFLOP/s/GPU' $file|wc -l) -gt 0 || $(grep 'train_step_timing.*consumed_samples' $file|wc -l) -gt 0 ]] && msg="Not reach $min_iter steps"
    printf "%100s: %s \n" $file $msg
  fi
}

plot_file(){
  file=$1
  echo $file
  if [ $(grep -o 'Step Time.*MODEL_TFLOP/s/GPU' $file|wc -l) -gt 0 ]; then
     grep -o 'Step Time.*MODEL_TFLOP/s/GPU' $file|sed -e 's:s GPU: s GPU:g' -e 's:MODEL_TFLOP: MODEL_TFLOP:g'|awk '{print $8}' \
    | gnuplot -e "set term dumb size 300,50; set yrange [0:]; plot '-' with linespoints" 2>/dev/null
  elif [ $(grep -o 'train_step_timing.*consumed_samples' $file|wc -l) -gt 0 ]; then
    grep -o 'train_step_timing.*consumed_samples' $file|tr '|' ' '|awk '{print $6}' \
      | gnuplot -e "set term dumb size 300,50; set yrange [0:]; plot '-' with linespoints" 2>/dev/null
  else
    echo "No TFLOPS_per_GPU info found in $file"
  fi
}

plot_file_ts(){
  file=$1
  echo $file
  if [ $(grep -o 'Step Time.*MODEL_TFLOP/s/GPU' $file|wc -l) -gt 0 ]; then
     grep -o 'Step Time.*MODEL_TFLOP/s/GPU' $file|sed -e 's:s GPU: s GPU:g' -e 's:MODEL_TFLOP: MODEL_TFLOP:g'|awk '{print $4}' \
       | gnuplot -e "set term dumb size 300,50; set yrange [0:15]; plot '-' with linespoints" 2>/dev/null
  elif [ $(grep -o 'train_step_timing.*consumed_samples' $file|wc -l) -gt 0 ]; then
    grep -o 'train_step_timing.*consumed_samples' $file|tr '|' ' '|awk '{print $4}' \
      | gnuplot -e "set term dumb size 300,50; set yrange [0:15]; plot '-' with linespoints" 2>/dev/null
  else
    echo "No Step Time info found in $file"
  fi
}

echo "==========NCCL PERF============"
for i in ${log_files[@]}; do
  printf "%100s: %s GB/s OOBV=%s\n" ${i} $(grep -e 1717.*float -e 1717.*uint8 $i|awk '{print $8}') $(grep 'Out of bounds values' $i|awk '{print $NF}')
done
echo "==========LLM  PERF============"
for i in ${log_files[@]}; do
 log_parser $i
done