#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

#SBATCH -p defq
#SBATCH --exclusive
#SBATCH --mem=0
#SBATCH --ntasks-per-node=8
#SBATCH --cpus-per-task=32
#SBATCH --gpus-per-node=8
#SBATCH -N 1

#CONT=/raid/nemo-25.11.01.sqsh
#CONT=/home/cmsupport/workspace/nemo-25.11.01.sqsh
CONT=/raid/nemo-25.11.01-m1.sqsh

module load slurm
cd ${SLURM_SUBMIT_DIR}

echo
echo "NODELIST: ${SLURM_JOB_NODELIST}"
echo

s_time=$(date +%s)
echo "INFO: cleaning work begin"
pdsh -f 64 -R ssh -w ${SLURM_JOB_NODELIST} <<- 'EOF'|dshbak -c
pkill -9 python &>/dev/null || true
ps -ef|grep python|grep -E 'torch|nemo'|grep -v grep || true
enroot list -f|grep pyxis && enroot remove -f $(enroot list -f|grep pyxis) || true
rm -f /var/lib/systemd/coredump/* &>/dev/null || true
EOF
echo "INFO: cleaning work done"

echo "INFO: clear IB counters"
pdsh -f 64 -R ssh -w ${SLURM_JOB_NODELIST} <<- 'EOF'|dshbak -c
/home/cmsupport/workspace/aihpc_val/tools/hc/ibcounter.sh clear
EOF

echo "INFO: checking hardware status"
timeout 100 bash /home/cmsupport/workspace/aihpc_val/tools/hc/sysinfo.sh 2>&1

set -x
ns_nic=bond0
ew_nics=($(lspci -D|grep Infiniband.*ConnectX-8|awk '{print $1}'|while read i; do ls -l /sys/class/infiniband|grep -o ${i}/.*|awk -F'/' '{print $NF}'; done))
export MELLANOX_VISIBLE_DEVICES=all
export PMIX_MCA_gds=hash
#
hosts=($(scontrol show hostname $SLURM_JOB_NODELIST))
if [ ${#hosts[*]} -gt 1 ]; then
  #Multiple NODEs/NVLDs connected with IB
  export UCX_TLS=rc
  export UCX_NET_DEVICES="$(echo ${ew_nics[@]}|tr ' ' '\n'|xargs -I {} echo {}:1|paste -s -d',')"
  export NCCL_IB_HCA="=$(echo ${ew_nics[@]}|tr ' ' '\n'|xargs -I {} echo {}|paste -s -d',')"
else
  #Single NODE/NVLD
  export UCX_TLS=tcp
  export UCX_NET_DEVICES=${ns_nic}
  export NCCL_IB_HCA=${ns_nic}
  export NCCL_IB_DISABLE=1
fi
#
eth_nic=bond0
export NCCL_SOCKET_IFNAME=${eth_nic}
export MCA_btl_tcp_if_include=${eth_nic}
export MCA_oob_tcp_if_include=${eth_nic}
export NVTE_UB_SOCKET_IFNAME=${eth_nic}
export GLOO_SOCKET_IFNAME=${eth_nic}
#
export OMPI_ALLOW_RUN_AS_ROOT=1
export OMPI_ALLOW_RUN_AS_ROOT_CONFIRM=1
export OMPI_MCA_btl_openib_warn_default_gid_prefix=0
export OMPI_MCA_coll_hcoll_enable=0
export SLURM_CPU_BIND=none

## For SPX
#export NCCL_IB_GID_INDEX=3
#export NCCL_IB_TC=96
#export NCCL_IB_TC=96
#export NCCL_IB_GID_INDEX=3

srun -N ${SLURM_NNODES} --ntasks-per-node=1 enroot remove -f pyxis_nemo &>/dev/null

## test nccl
export NCCL_DEBUG=WARN
export NCCL_NVLS_ENABLE=1
######### NOTES: The following params combination help NCCL but hurt nemo performance.
#if [ "X${UCX_TLS}" != "Xtcp" ]; then
#export NCCL_IB_ADAPTIVE_ROUTING=1
#export NCCL_IB_SL=1
#export NCCL_IB_QPS_PER_CONNECTION=8 #help raw bandwidth in nccl-tests but adds NIC-side overhead and queue depth/latency
#fi
#export NCCL_MIN_NCHANNELS=32 #increases the number of CUDA blocks/CTAs used for communication and therefore consumes more SMs
#export NCCL_MIN_CTAS=64 #The max is 64, forces NCCL to burn more SMs on comm will hurt real workloads (NeMo) by reducing compute/comm overlap or starving the model’s kernels
#export NCCL_P2P_LEVEL=NVL
######### END NOTES
export NCCL_IB_SL=1
export NCCL_MIN_NCHANNELS=32
export NCCL_NET_PLUGIN=none
export NCCL_IB_OOO_RQ=1
##
timeout 300 \
srun --export=ALL --cpu-bind=none --mpi=pmix \
--container-name=nemo \
--container-writable \
--container-image=$CONT \
--container-mounts=/dev:/dev \
all_reduce_perf_mpi -dfloat -b 8 -f 2 -g 1 -e 16G --iters 20
exitcode=$?
if [ $exitcode -ne 0 ]; then
  echo "*********************************************"
  echo "* ERROR: NCCL failed to run!!!              *"
  echo "*********************************************"
  srun -N ${SLURM_NNODES} --ntasks-per-node=1 enroot remove -f pyxis_nemo &>/dev/null
  exit 1
fi

sleep 10
## generate config files
### Rule: num_gpus % (ep * et * tp * pp) == 0
#python3 /opt/Megatron-Bridge/scripts/performance/setup_experiment.py ... ... #the same args with run_script.py
#
########  run nemo test
#
## Workaround for unstable or not robust enough NVLINK:
# With unstable or not robust enough NVLINK, you may encounter error like:
# RuntimeError: /opt/TransformerEngine/transformer_engine/common/comm_gemm_overlap/userbuffers/userbuffers-host.cpp:331 in function create_communicator_grouped2: CUDA Error: unknown error
# To workaround this issue, we can set UB_SKIPMC=1 to disables the NVSwitch/CUDA multicast path and makes Userbuffers fall back to a slower IPC-based scheme.
# It's usually better than turning off tp_comm_overlap entirely, but worse than full multicast on a healthy, supported fabric.
# UB_SKIPMC: UserBuffers Skip Multicast
# UB = UserBuffers (the TP-overlap communication backend in TransformerEngine)
# SKIPMC = skip multicast (don't use CUDA/NVLS multicast for UB collectives)
## export NCCL_NVLS_ENABLE=0
## export UB_SKIPMC=1
### For optimal performance, it's recommended to keep NVLS enabled and let UB use multicast if possible.
export NCCL_DEBUG=INFO
export NCCL_NVLS_ENABLE=1
export UB_SKIPMC=0
########## NOTES: The following params combination help NCCL but hurt nemo performance.
#unset NCCL_IB_ADAPTIVE_ROUTING #default: 1 on IB, 0 on SPX
#unset NCCL_IB_SL #defailt: 0
#unset NCCL_IB_QPS_PER_CONNECTION #defualt: 1
#unset NCCL_MIN_NCHANNELS #defualt: 32
#unset NCCL_MIN_CTAS #defualt: undefined, up to 32
#unset NCCL_P2P_LEVEL
########## END NOTES
#export NCCL_MIN_CTAS=16
## Minimize the impact of IB link flapping
export NCCL_IB_TIMEOUT=25 #Timeout 2.3min
export NCCL_IB_RETRY_CNT=7 #7x2.3=16min
#
# export MAX_STEPS=2010 #For stress test, you can set a large number for MAX_STEPS.
export MAX_STEPS=110
srun --export=ALL --cpu-bind=none --mpi=pmix \
--container-name=nemo \
--container-writable \
--container-image=$CONT \
--container-mounts=/dev:/dev \
bash <<- '__END__'
set -ex
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
export HF_HOME=/root/.cache/huggingface

export NEMORUN_HOME=/mnt/nemo
export CPATH=/usr/local/cuda/include
export TRITON_PTXAS_PATH=/usr/local/cuda/bin/ptxas
export TRITON_LIB_DIR=/usr/local/cuda/lib64
export TORCH_NCCL_AVOID_RECORD_STREAMS=1

export NVTE_FLASH_ATTN=1
export NVTE_FUSED_ATTN=1
export CUDA_DEVICE_MAX_CONNECTIONS=1
export NVTE_FWD_LAYERNORM_SM_MARGIN=16
export NVTE_BWD_LAYERNORM_SM_MARGIN=16
export NCCL_P2P_NET_CHUNKSIZE=2097152
export TORCH_NCCL_HIGH_PRIORITY=1
export PYTHONPATH=/opt/Megatron-Bridge/scripts/performance:$PYTHONPATH

## Rule: num_gpus % (ep * et * tp * pp) == 0
#With CUDA graphs, then expandable segments must be disabled by "unset PYTORCH_CUDA_ALLOC_CONF".
#For arguments explanation, please refer to
# https://github.com/NVIDIA-NeMo/Megatron-Bridge/blob/main/scripts/performance/argument_parser.py
#For model name and model size, please refer to
# https://github.com/NVIDIA-NeMo/Megatron-Bridge/blob/main/scripts/performance/configs/nemotronh/nemotronh_workload_base_configs.py
#
## Note: As DP=NUM_GPUS/(TP*PP*MB), smaller DP leads to better stability.
# TP=2,PP=1,MB1 lead better perf with smaller nodes(<=32 nodes),
# TP=4,PP=2,MB1 lead better perf with larger nodes(>32 nodes).
if [ ${SLURM_NNODES} -le 32 ]; then
  export TP=2
  export PP=1
else
  export TP=4
  export PP=2
fi
### For SeeGroup(B300+IB CX8), TP=4,PP=2 got worse perf than TP=2,PP=1,MB1, so we use TP=2,PP=1 for all scale.
#export TP=2
#export PP=1
numactl --cpunodebind=$[SLURM_LOCALID/4] --membind=$[SLURM_LOCALID/4] \
python /opt/Megatron-Bridge/scripts/performance/run_script.py \
  --account root \
  --partition defq \
  --log_dir ${NEMORUN_HOME} \
  --container_image ${NEMORUN_HOME}/nemo-25.11.01.sqsh \
  --nemo_home ${NEMORUN_HOME}/experiments \
  --gpu gb300 \
  --num_gpus $[8*${SLURM_NNODES}] \
  --gpus_per_node 8 \
  --compute_dtype fp8_cs \
  --model_name nemotronh --model_size 56b \
  --use_megatron_fsdp 0 \
  -tp ${TP} \
  -pp ${PP} \
  -cp 1 \
  -ep 1 \
  -mb 1 \
  -gb $[192*${SLURM_NNODES}/8] \
  --cuda_graph_impl transformer_engine --cuda_graph_scope mamba,attn \
  --max_steps ${MAX_STEPS} \
  train.manual_gc=true train.manual_gc_interval=100
__END__

srun -N ${SLURM_NNODES} --ntasks-per-node=1 enroot remove -f pyxis_nemo &>/dev/null
set +x

echo "INFO: Query IB counters"
pdsh -f 64 -R ssh -w ${SLURM_JOB_NODELIST} <<< /home/cmsupport/workspace/aihpc_val/tools/hc/ibcounter.sh | /home/cmsupport/workspace/aihpc_val/tools/hc/nodetools/python3-hostlist/pshbak -C

e_time=$(date +%s)
echo "INFO: timelimit=$[(SLURM_JOB_END_TIME-SLURM_JOB_START_TIME)](s), real_took=$[e_time-s_time](s)"
