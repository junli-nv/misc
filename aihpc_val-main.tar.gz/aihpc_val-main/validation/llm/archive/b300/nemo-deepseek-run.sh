#!/bin/bash

module load slurm

nodelist="HGX[174-245]"
hosts=($(scontrol show hostname $nodelist))

run(){
  nodelist=${nodelist:-$1}
  hosts=($(scontrol show hostname $nodelist))
  count=16
  nodes=($(printf '%s\n' "${hosts[@]}" | shuf -n "$count" ))
  echo ${nodes[@]}
  sbatch \
    -N ${count} \
    -w $(echo ${nodes[@]}|tr ' ' ',') \
    -o root-DEEPSEEK-${count}N-$(echo ${nodes[@]}|/home/cmsupport/workspace/aihpc_val/tools/hc/nodetools/python3-hostlist/hostlist -c   -)-%j.txt \
    nemo-deepseekv3-mbridge-26.08.00.sh
}

## https://github.com/NVIDIA/exemplar-performance/tree/main/deepseek_v3/pretrain/megatron_bridge

### 2. CPU Performance Debug Proxy - identify CPU issue
for i in ${hosts[@]}; do
  GPU_TYPE=b300 DTYPE=nvfp4 \
  PROXY_WORKLOAD=true DISABLE_CG=true CPU_PERF_PROXY=true MAX_STEPS=30 \
  sbatch -N 1 -w $i -o root-DEEPSEEK-1N-$i-%j-cpu.txt nemo-deepseekv3-mbridge-26.08.00.sh
done

### 1. Reduced GPU-Count Proxy

# Single Node test: 1N 
for i in ${hosts[@]}; do
  GPU_TYPE=b300 DTYPE=nvfp4 \
  PROXY_WORKLOAD=true CPU_PERF_PROXY=false MAX_STEPS=50 \
  sbatch -N 1 -w $i -o root-DEEPSEEK-1N-$i-%j.txt nemo-deepseekv3-mbridge-26.08.00.sh
done

# Step test: 
step=; for step in 2 4 8 16 32 64
do
  i=0; while [ $i -lt ${#hosts[@]} ]; do
    s0=$[i+1]
    s1=$[i+step]
    thosts=($(scontrol show hostname $(echo ${hosts[@]} ${hosts[@]}|cut -f${s0}-${s1} -d ' '|tr ' ' ',')))
    postfix=$(echo ${thosts[*]}|/home/cmsupport/workspace/aihpc_val/tools/hc/nodetools/python3-hostlist/hostlist -c -)
    #cat <<- EOF
    if [ $step -gt 8 ]; then
      unset  PROXY_WORKLOAD
      unset  CPU_PERF_PROXY
      export MAX_STEPS=50
    else
      export PROXY_WORKLOAD=true
      export CPU_PERF_PROXY=false
      export MAX_STEPS=50
    fi
    GPU_TYPE=b300 DTYPE=nvfp4 \
    sbatch \
        -N ${#thosts[*]} \
        -w $(echo "${thosts[*]}"|tr ' ' ',') \
        -t 1:00:00 \
        --job-name=DEEPSEEK-${step}N \
        --output=${USER}-DEEPSEEK-${#thosts[*]}N-${postfix}-%j.txt \
        nemo-deepseekv3-mbridge-26.08.00.sh
#EOF
    i=${s1}
  done
done

# Perf Ref: https://llmb.nvidia.com/beacon/baselines?releases=26.10.00&release=26.08.00&gpus=B300&models=deepseek-v3

#   root-DEEPSEEK-1N-HGX174-9677-cpu.txt: Step[s]=76.09 perGPU[TFLOPs]=238.58 Sstd=0.22175 Pstd=0.68658 SCV=0.29% PCV=0.29%
#       root-DEEPSEEK-1N-HGX174-9780.txt: Step[s]=44.03 perGPU[TFLOPs]=1665.50 Sstd=0.21782 Pstd=8.24061 SCV=0.49% PCV=0.49%
# root-DEEPSEEK-2N-HGX[174-175]-9883.txt: Step[s]=44.51 perGPU[TFLOPs]=1647.56 Sstd=0.41175 Pstd=14.97110 SCV=0.93% PCV=0.91%
# root-DEEPSEEK-4N-HGX[174-177]-9919.txt: Step[s]=45.50 perGPU[TFLOPs]=1611.78 Sstd=0.36576 Pstd=12.85227 SCV=0.80% PCV=0.80%
# root-DEEPSEEK-8N-HGX[174-181]-9937.txt: Step[s]=26.52 perGPU[TFLOPs]=1382.69 Sstd=0.38501 Pstd=19.71973 SCV=1.45% PCV=1.43%
#
#root-DEEPSEEK-16N-HGX[174-189]-9946.txt: Step[s]=15.63 perGPU[TFLOPs]=1093.03 Sstd=0.84130 Pstd=57.40107 SCV=5.38% PCV=5.25%
#root-DEEPSEEK-32N-HGX[174-205]-9951.txt: Step[s]=15.69 perGPU[TFLOPs]=1091.62 Sstd=1.19637 Pstd=72.46311 SCV=7.63% PCV=6.64%
#root-DEEPSEEK-64N-HGX[174-237]-9954.txt: Step[s]=15.75 perGPU[TFLOPs]=1084.37 Sstd=0.77120 Pstd=52.93030 SCV=4.90% PCV=4.88%
