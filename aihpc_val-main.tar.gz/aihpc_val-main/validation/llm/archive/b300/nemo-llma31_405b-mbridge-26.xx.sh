#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

## B300 HGX setup: 2xIntel 6776P(64C/128T, HT=ON, SNC=OFF) + 32x128GB DIMM + 8xB300 + 8xConnectX-8
#SBATCH -p defq
#SBATCH --exclusive
#SBATCH --mem=0
#SBATCH --ntasks-per-node=8
#SBATCH --cpus-per-task=32
#SBATCH --gpus-per-node=8
#SBATCH -N 16

#CONT=/raid/nemo-26.06.rc3.sqsh # NCCL: 2.30.4+CUDA13.2 # docker://nvcr.io/nvidian/nemo:26.06.rc3
CONT=/raid/nemo-26.06.00.sqsh 
HUGGINGFACE_CACHE=/home/cmsupport/workspace/huggingface

module load slurm
cd ${SLURM_SUBMIT_DIR}

echo
echo "NODELIST: ${SLURM_JOB_NODELIST}"
echo

s_time=$(date +%s)
echo "INFO: cleaning work begin"
pdsh -f 64 -R ssh -w ${SLURM_JOB_NODELIST} <<- 'EOF'|dshbak -c
pkill -9 python &>/dev/null || true
ps -ef|grep python|grep -E 'torch|nemo'|grep -v grep || true
enroot list -f|grep pyxis && enroot remove -f $(enroot list -f|grep pyxis) || true
rm -f /var/lib/systemd/coredump/* &>/dev/null || true
EOF
echo "INFO: cleaning work done"

echo "INFO: checking hardware status"
timeout 100 bash /home/cmsupport/workspace/aihpc_val/tools/hc/sysinfo.sh 2>&1

set -x
ns_nic=bond0
ew_nics=($(lspci -D|grep Infiniband.*ConnectX-8|awk '{print $1}'|while read i; do ls -l /sys/class/infiniband|grep -o ${i}/.*|awk -F'/' '{print $NF}'; done))
export MELLANOX_VISIBLE_DEVICES=all
export PMIX_MCA_gds=hash
#
export UCX_TLS=tcp UCX_NET_DEVICES=${ns_nic}
#export UCX_TLS=rc UCX_NET_DEVICES="$(echo ${ew_nics[@]}|tr ' ' '\n'|xargs -I {} echo {}:1|paste -s -d',')"
export NCCL_IB_HCA="=$(echo ${ew_nics[@]}|tr ' ' '\n'|xargs -I {} echo {}|paste -s -d',')"
#
export NCCL_SOCKET_IFNAME=${ns_nic}
export MCA_btl_tcp_if_include=${ns_nic}
export MCA_oob_tcp_if_include=${ns_nic}
export NVTE_UB_SOCKET_IFNAME=${ns_nic}
export GLOO_SOCKET_IFNAME=${ns_nic}
#
export OMPI_ALLOW_RUN_AS_ROOT=1
export OMPI_ALLOW_RUN_AS_ROOT_CONFIRM=1
export OMPI_MCA_btl_openib_warn_default_gid_prefix=0
export OMPI_MCA_coll_hcoll_enable=0
export SLURM_CPU_BIND=none
#
## Minimize the impact of IB link flapping
export NCCL_IB_TIMEOUT=25 #Timeout 2.3min
export NCCL_IB_RETRY_CNT=7 #7x2.3=16min
export NCCL_IB_RESILIENCY_PORT_RECOVERY=1
export NCCL_IB_RESILIENCY_PORT_FAILOVER=1
export NCCL_NVLS_ENABLE=0

########  NOTE: 
#  Deepseek V3 variation 2 can't work with named container well(leading to error like "GIL xxx"), 
#  so we have to use unnamed container for it.
########  ENDNOTE

########  nccl test
# cat > /dev/null <<- '__COMMENT__'
export NCCL_DEBUG=WARN
export NCCL_IB_SL=1
export NCCL_MIN_NCHANNELS=32
export NCCL_NVLS_ENABLE=1
#export NCCL_NET_PLUGIN=none
export NCCL_IB_OOO_RQ=1
timeout 300 \
srun --export=ALL --cpu-bind=none --mpi=pmix \
--container-writable \
--container-image=$CONT \
--container-mounts=/dev:/dev \
all_reduce_perf_mpi -d float -b 8 -f 2 -g 1 -e 16G --iters 20 -R 0
exitcode=$?
if [ $exitcode -ne 0 ]; then
  echo "*********************************************"
  echo "* ERROR: NCCL failed to run!!!              *"
  echo "*********************************************"
  exit 1
fi
unset NCCL_IB_OOO_RQ
sleep 10
#__COMMENT__

########  nemo test
#
## Workaround for unstable or not robust enough NVLINK:
# With unstable or not robust enough NVLINK, you may encounter error like:
# RuntimeError: /opt/TransformerEngine/transformer_engine/common/comm_gemm_overlap/userbuffers/userbuffers-host.cpp:331 in function create_communicator_grouped2: CUDA Error: unknown error
# To workaround this issue, we can set UB_SKIPMC=1 to disables the NVSwitch/CUDA multicast path and makes Userbuffers fall back to a slower IPC-based scheme.
# It's usually better than turning off tp_comm_overlap entirely, but worse than full multicast on a healthy, supported fabric.
# UB_SKIPMC: UserBuffers Skip Multicast
# UB = UserBuffers (the TP-overlap communication backend in TransformerEngine)
# SKIPMC = skip multicast (don't use CUDA/NVLS multicast for UB collectives)
## export NCCL_NVLS_ENABLE=0
## export UB_SKIPMC=1
export NCCL_DEBUG=INFO
#
nodes=( $( scontrol show hostnames $SLURM_JOB_NODELIST ) )
nodes_array=($nodes)
head_node=${nodes_array[0]}
head_node_ip=$(srun --nodes=1 --ntasks=1 -w "$head_node" hostname --ip-address)
export PYTHONUNBUFFERED=1
export SLURM_UNBUFFEREDIO=1
export TORCHX_MAX_RETRIES=0
#
export TORCH_NCCL_AVOID_RECORD_STREAMS=1
export TRANSFORMERS_OFFLINE=1
export TOKENIZERS_PARALLELISM=False
export NCCL_NVLS_ENABLE=0
export TORCH_NCCL_HIGH_PRIORITY=1
export HF_HUB_OFFLINE=1
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export NCCL_GRAPH_REGISTER=0
export WANDB_RUN_ID=$(echo $RANDOM|md5sum|cut -c1-8)
export WANDB_RESUME=allow
export CUDA_DEVICE_MAX_CONNECTIONS=32
export NVTE_FWD_LAYERNORM_SM_MARGIN=16
export NVTE_BWD_LAYERNORM_SM_MARGIN=16
export NCCL_P2P_NET_CHUNKSIZE=2097152
#
### The above exported parameters should be set outside of the container, otherwise will lead to error.
#
### Parameters Reference:
# To find out which branch is used to build the container, refer 
#      https://docs.nvidia.com/nemo/megatron-bridge/latest/releases/software-versions.html#software-component-versions
# Args: https://github.com/NVIDIA-NeMo/Megatron-Bridge/tree/main/scripts/performance
#      LLAMA31_405B_PRETRAIN_CONFIG_B300_FP8_CS_V2: configs/llama/llama31_workload_base_configs.py
#
srun --export=ALL --cpu-bind=none --mpi=pmix \
--container-writable \
--container-image=${CONT} \
--container-mounts=/dev:/dev,${HUGGINGFACE_CACHE}:/root/.cache/huggingface \
--wait=600 --kill-on-bad-exit=1 --mpi=pmix \
bash <<- '__END__'
set -ex
export HF_HOME=/root/.cache/huggingface
export CPATH=/usr/local/cuda/include
export TRITON_PTXAS_PATH=/usr/local/cuda/bin/ptxas
export TRITON_LIB_DIR=/usr/local/cuda/lib64
export PYTHONPATH=/opt/Megatron-Bridge/scripts/performance:$PYTHONPATH
export NEMORUN_HOME=/mnt/nemo
export NEMO_HOME=${NEMORUN_HOME}/experiments
numactl --cpunodebind=$[SLURM_LOCALID/4] --membind=$[SLURM_LOCALID/4] \
python /opt/Megatron-Bridge/scripts/performance/run_script.py \
  --account root \
  --partition defq \
  --log_dir ${NEMORUN_HOME} \
  --compute_dtype fp8_cs \
  --gpu b300 \
  --num_gpus $[8*${SLURM_NNODES}] \
  --gpus_per_node 8 \
  --offline \
  --model_family_name llama \
  --model_recipe_name llama31_405b \
  --max_steps 50 \
  --packager none \
  train.manual_gc=true train.manual_gc_interval=100
__END__

set +x

e_time=$(date +%s)
echo "INFO: timelimit=$[(SLURM_JOB_END_TIME-SLURM_JOB_START_TIME)](s), real_took=$[e_time-s_time](s)"

### If you want to check the parms used in the above script, you can use the following command to check(reference only):
cat > /dev/null <<- '__COMMENT__'
#!/bin/bash
# pretrain_llama31_405b_fp8_cs_gpus256_tp4_pp8_cp1_vp4_ep1_etpNone_mbs1_gbs1536
export IMAGE=${IMAGE:-/raid/nemo-26.06.00.sqsh}
export COMPUTE_TYPE=${COMPUTE_TYPE:-fp8_cs}
export GPU_TYPE=${GPU_TYPE:-b300}
export JOB_TOTAL_GPUS=${JOB_TOTAL_GPUS:-128}
export GPUS_PER_NODE=${GPUS_PER_NODE:-8}
export MAX_STEPS=${MAX_STEPS:-50}
export WORKSPACE=${WORKSPACE:-$PWD}
#
srun --export=ALL --cpu-bind=none --mpi=pmix \
--container-writable \
--container-image=${IMAGE} \
--container-mounts=/dev:/dev,${WORKSPACE}:${WORKSPACE} \
--wait=600 --kill-on-bad-exit=1 --mpi=pmix --gpus-per-node=1 \
bash <<- '__END__'
export PYTHONPATH=/opt/Megatron-Bridge/scripts/performance:$PYTHONPATH
cat > /usr/local/bin/sbatch <<- 'EOF'
#!/bin/bash
echo "sbatch $@"
EOF
chmod a+x /usr/local/bin/sbatch
export NEMORUN_HOME=${WORKSPACE}/${GPU_TYPE}
cd /opt/Megatron-Bridge
set -x
# https://github.com/NVIDIA-NeMo/Megatron-Bridge/tree/main/scripts/performance
python3 scripts/performance/setup_experiment.py \
  --account root \
  --partition defq \
  --container_image ${IMAGE} \
  --log_dir $NEMORUN_HOME \
  --compute_dtype ${COMPUTE_TYPE} \
  --gpu ${GPU_TYPE} \
  --num_gpus ${JOB_TOTAL_GPUS} \
  --gpus_per_node ${GPUS_PER_NODE} \
  --offline \
  --model_family_name llama \
  --model_recipe_name llama31_405b \
  --max_steps $MAX_STEPS \
  --packager none \
  ${CONFIG_OVERRIDES}
__END__
__COMMENT__
