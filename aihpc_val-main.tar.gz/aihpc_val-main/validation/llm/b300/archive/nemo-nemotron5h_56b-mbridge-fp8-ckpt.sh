#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

#SBATCH -p defq
#SBATCH --exclusive
#SBATCH --ntasks-per-node=8
#SBATCH --cpus-per-task=32
#SBATCH --gpus-per-node=8
#SBATCH -N 1

#CONT=/raid/nemo-25.11.01.sqsh
#CONT=/home/cmsupport/workspace/nemo-25.11.01.sqsh
CONT=/raid/nemo-25.11.01-m1.sqsh

module load slurm
cd ${SLURM_SUBMIT_DIR}

echo
echo "NODELIST: ${SLURM_JOB_NODELIST}"
echo

s_time=$(date +%s)
echo "INFO: cleaning work begin"
pdsh -f 64 -R ssh -w ${SLURM_JOB_NODELIST} <<- 'EOF'|dshbak -c
pkill -9 python &>/dev/null || true
ps -ef|grep python|grep -E 'torch|nemo'|grep -v grep || true
enroot list -f|grep pyxis && enroot remove -f $(enroot list -f|grep pyxis) || true
rm -f /var/lib/systemd/coredump/* &>/dev/null || true
EOF
echo "INFO: cleaning work done"

echo "INFO: checking hardware status"
#timeout 100 bash /home/cmsupport/workspace/aihpc_val/tools/hc/sysinfo.sh 2>&1

set -x
ns_nic=bond0
ew_nics=($(lspci -D|grep Infiniband.*ConnectX-8|awk '{print $1}'|while read i; do ls -l /sys/class/infiniband|grep -o ${i}/.*|awk -F'/' '{print $NF}'; done))
export MELLANOX_VISIBLE_DEVICES=all
export PMIX_MCA_gds=hash
#
hosts=($(scontrol show hostname $SLURM_JOB_NODELIST))

export UCX_TLS=rc
export UCX_NET_DEVICES="$(echo ${ew_nics[@]}|tr ' ' '\n'|xargs -I {} echo {}:1|paste -s -d',')"
export NCCL_IB_HCA="=$(echo ${ew_nics[@]}|tr ' ' '\n'|xargs -I {} echo {}|paste -s -d',')"
eth_nic=bond0
export NCCL_SOCKET_IFNAME=${eth_nic}
export MCA_btl_tcp_if_include=${eth_nic}
export MCA_oob_tcp_if_include=${eth_nic}
export NVTE_UB_SOCKET_IFNAME=${eth_nic}
export GLOO_SOCKET_IFNAME=${eth_nic}
#
export OMPI_ALLOW_RUN_AS_ROOT=1
export OMPI_ALLOW_RUN_AS_ROOT_CONFIRM=1
export OMPI_MCA_btl_openib_warn_default_gid_prefix=0
export OMPI_MCA_coll_hcoll_enable=0
export SLURM_CPU_BIND=none

srun -N ${SLURM_NNODES} --ntasks-per-node=1 enroot remove -f pyxis_nemo &>/dev/null

export TORCH_NCCL_TRACE_BUFFER_SIZE=200000
export TORCH_NCCL_DUMP_ON_TIMEOUT=1
export NCCL_ASYNC_ERROR_HANDLING=1

export NCCL_NVLS_ENABLE=0
export UB_SKIPMC=1
export NCCL_DEBUG=INFO
export NCCL_IB_TIMEOUT=25 #Timeout 2.3min
export NCCL_IB_RETRY_CNT=7 #7x2.3=16min
#
# export MAX_STEPS=2010 #For stress test, you can set a large number for MAX_STEPS.
mkdir -p /home/cmsupport/workspace/results/nemotronh_56b/checkpoints
export MAX_STEPS=50
srun --export=ALL --cpu-bind=none --mpi=pmix \
--container-name=nemo \
--container-writable \
--container-image=$CONT \
--container-mounts=/dev:/dev,/home/cmsupport/workspace/results:/results \
bash <<- '__END__'
set -ex
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
export HF_HOME=/root/.cache/huggingface

export NEMORUN_HOME=/mnt/nemo
export CPATH=/usr/local/cuda/include
export TRITON_PTXAS_PATH=/usr/local/cuda/bin/ptxas
export TRITON_LIB_DIR=/usr/local/cuda/lib64
export TORCH_NCCL_AVOID_RECORD_STREAMS=1

export NVTE_FLASH_ATTN=1
export NVTE_FUSED_ATTN=1
export CUDA_DEVICE_MAX_CONNECTIONS=1
export NVTE_FWD_LAYERNORM_SM_MARGIN=16
export NVTE_BWD_LAYERNORM_SM_MARGIN=16
export NCCL_P2P_NET_CHUNKSIZE=2097152
export TORCH_NCCL_HIGH_PRIORITY=1
export PYTHONPATH=/opt/Megatron-Bridge/scripts/performance:$PYTHONPATH

numactl --cpunodebind=$[SLURM_LOCALID/4] --membind=$[SLURM_LOCALID/4] \
python /opt/Megatron-Bridge/scripts/performance/run_script.py \
  --account root \
  --partition defq \
  --log_dir ${NEMORUN_HOME} \
  --container_image ${NEMORUN_HOME}/nemo-25.11.01.sqsh \
  --nemo_home ${NEMORUN_HOME}/experiments \
  --gpu gb300 \
  --num_gpus $[8*${SLURM_NNODES}] \
  --gpus_per_node 8 \
  --compute_dtype fp8_cs \
  --model_name nemotronh --model_size 56b \
  --use_megatron_fsdp 0 \
  -tp 2 \
  -pp 1 \
  -cp 1 \
  -ep 1 \
  -mb 1 \
  -gb $[192*${SLURM_NNODES}/8] \
  --cuda_graph_impl none \
  --max_steps ${MAX_STEPS} \
  checkpoint.save=/results/nemotronh_56b/checkpoints \
  checkpoint.load=/results/nemotronh_56b/checkpoints \
  checkpoint.save_interval=30 \
  checkpoint.most_recent_k=5 \
  checkpoint.ckpt_format=torch_dist \
  checkpoint.fully_parallel_save=false \
  checkpoint.async_save=false \
  dist.distributed_timeout_minutes=120 \
  train.manual_gc=true train.manual_gc_interval=100
__END__

srun -N ${SLURM_NNODES} --ntasks-per-node=1 enroot remove -f pyxis_nemo &>/dev/null
set +x

e_time=$(date +%s)
echo "INFO: timelimit=$[(SLURM_JOB_END_TIME-SLURM_JOB_START_TIME)](s), real_took=$[e_time-s_time](s)"
