#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

export IMAGE=${IMAGE:-/raid/nemo-26.04-m1.sqsh}
export COMPUTE_TYPE=${COMPUTE_TYPE:-fp8_mx}
export GPU_TYPE=${GPU_TYPE:-b300}
export JOB_TOTAL_GPUS=${JOB_TOTAL_GPUS:-512}
export MAX_STEPS=${MAX_STEPS:-110}

# https://github.com/NVIDIA/dgxc-benchmarking/blob/main/deepseek_v3/pretrain/megatron_bridge/launch.sh
if [[ $GPU_TYPE == "gb300" ]] || [[ $GPU_TYPE == "gb200" ]]; then
    if [[ $GPU_TYPE == "gb300" ]] && [[ $JOB_TOTAL_GPUS -eq 128 ]]; then
        CONFIG_OVERRIDES+=" -pp 4 "
        CONFIG_OVERRIDES+=" -vp 4 "
        CONFIG_OVERRIDES+=" -ep 32 "
        CONFIG_OVERRIDES+=" --recompute_modules=mla_up_proj "
    fi
    if [[ $JOB_TOTAL_GPUS -eq 64 ]]; then
        CONFIG_OVERRIDES+=" -tp 1 "
        CONFIG_OVERRIDES+=" -pp 1 "
        CONFIG_OVERRIDES+=" -vp None "
        CONFIG_OVERRIDES+=" -ep 64 "
        CONFIG_OVERRIDES+=" --hidden_size 1024 "
    fi
    GPUS_PER_NODE=4
elif [[ $GPU_TYPE == "b300" ]] || [[ $GPU_TYPE == "b200" ]] || [[ $GPU_TYPE == "h100" ]]; then
    GPUS_PER_NODE=8
fi
export GPUS_PER_NODE CONFIG_OVERRIDES

# https://github.com/junli-nv/misc/raw/refs/heads/main/huggingface.squashfs
HF_HOME=/home/cmsupport/workspace/huggingface

srun --exclusive -N 1 --export=ALL \
--container-writable \
--container-image=$IMAGE \
--container-mounts=/dev:/dev,${HF_HOME}:/root/.cache/huggingface,$PWD:/mnt \
bash <<- '__END__'
export PYTHONPATH=/opt/Megatron-Bridge/scripts/performance:$PYTHONPATH
cat > /usr/local/bin/sbatch <<- 'EOF'
#!/bin/bash
echo "sbatch $@"
EOF
chmod a+x /usr/local/bin/sbatch
export NEMORUN_HOME=/mnt/${GPU_TYPE}
cd /opt/Megatron-Bridge
# https://github.com/NVIDIA-NeMo/Megatron-Bridge/tree/main/scripts/performance
python3 scripts/performance/setup_experiment.py \
  --container_image ${IMAGE} \
  --compute_dtype ${COMPUTE_TYPE} \
  --gpu ${GPU_TYPE} \
  --num_gpus ${JOB_TOTAL_GPUS} \
  --gpus_per_node ${GPUS_PER_NODE} \
  --offline \
  --model_family_name deepseek \
  --model_recipe_name deepseek_v3 \
  ${CONFIG_OVERRIDES} \
  --account root \
  --partition defq \
  --log_dir $NEMORUN_HOME \
  --max_steps $MAX_STEPS
__END__
