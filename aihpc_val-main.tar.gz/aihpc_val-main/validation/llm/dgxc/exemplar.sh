#!/bin/bash

sudo apt-get install -y git-lfs

topdir=/home/cmsupport/workspace/
LLMB_INSTALL=${topdir}/exemplar
mkdir -p $LLMB_INSTALL
cd $LLMB_INSTALL

## Without HF_TOKEN, download the prepackged huggingface cache
mkdir -p .cache
wget -c https://github.com/junli-nv/misc/raw/refs/heads/main/huggingface-v2.squashfs
unsquashfs -f -d .cache/huggingface huggingface-v2.squashfs

## Download the latest release of exemplar-performance
git clone https://github.com/NVIDIA/exemplar-performance
cd exemplar-performance/
git tag
git checkout v26.08.01
git status

## Hack for the images
mkdir -p $LLMB_INSTALL/images
for i in $(grep -r 'nvcr.io' .|grep metadata.yaml|grep -o  nvcr.io.*nemo:.*|sort|uniq|tr -d "'"|tr '/:' '+'|cut -f2 -d'#'); do
  touch $LLMB_INSTALL/images/$i.sqsh
done
ls -lh $LLMB_INSTALL/images

export UV_CACHE_DIR="$LLMB_INSTALL/.cache/uv"
export PIP_CACHE_DIR="$LLMB_INSTALL/.cache/pip"
export TMPDIR="$LLMB_INSTALL/.cache/tmp"
mkdir -p $UV_CACHE_DIR $PIP_CACHE_DIR $TMPDIR

## Install
rm -f $HOME/.config/llmb/system_config.yaml
./install.sh
# Enter installation directory path: /home/cmsupport/workspace/exemplar

## Hack for the images
ln -sf /raid/nemo-26.04.01.sqsh ${LLMB_INSTALL}/images/nvidia+nemo+26.04.01.sqsh
ln -sf /raid/nemo-26.06.01.sqsh ${LLMB_INSTALL}/images/nvidia+nemo+26.06.01.sqsh
ls -l ${LLMB_INSTALL}/images

## Run the deepseek-v3 benchmark
cd ${LLMB_INSTALL}

export PATH="$HOME/.local/bin:$PATH"
export LLMB_INSTALL=/home/cmsupport/workspace/exemplar
source ${LLMB_INSTALL}/llmb_venv/bin/activate
llmb-run  --install-completion
source $HOME/.bash_completions/llmb-run.sh

llmb-run --version
llmb-run submit -h

env_vars=(
  --env 'MELLANOX_VISIBLE_DEVICES=all'
  --env 'PMIX_MCA_gds=hash'
  --env 'UCX_TLS=tcp'
  --env 'UCX_NET_DEVICES=bond0'
  --env 'NCCL_IB_HCA==rdma_0,rdma_1,rdma_2,rdma_3,rdma_4,rdma_5,rdma_6,rdma_7'
  --env 'NCCL_SOCKET_IFNAME=bond0'
  --env 'OMPI_MCA_btl_tcp_if_include=bond0'
  --env 'OMPI_MCA_oob_tcp_if_include=bond0'
  --env 'NVTE_UB_SOCKET_IFNAME=bond0'
  --env 'GLOO_SOCKET_IFNAME=bond0'
  --env 'NCCL_IB_TIMEOUT=25'
  --env 'NCCL_IB_RETRY_CNT=7'
  --env 'NCCL_IB_RESILIENCY_PORT_RECOVERY=1'
  --env 'NCCL_IB_RESILIENCY_PORT_FAILOVER=1'
)
# echo "${env_vars[@]}"

## Longer the srun wait time from 60s to 300s
sed -i 's:wait=60:wait=300:g' $(grep wait=60 $(find ${LLMB_INSTALL} -name slurm.py)|cut -f 1 -d ':'|sort|uniq)
grep wait=300 $(find ${LLMB_INSTALL} -name slurm.py)

llmb-run list

nodelist="--nodelist HGX[174-245]"
llmb-run submit "${env_vars[@]}" $nodelist -w pretrain_deepseek-v3 -s 671b --dtype fp8   --scale 512
llmb-run submit "${env_vars[@]}" $nodelist -w pretrain_deepseek-v3 -s 671b --dtype nvfp4 --scale 512
llmb-run submit "${env_vars[@]}" $nodelist -w pretrain_llama3.1    -s 405b --dtype fp8   --scale 512
llmb-run submit "${env_vars[@]}" $nodelist -w pretrain_llama3.1    -s 405b --dtype nvfp4 --scale 512
llmb-run submit "${env_vars[@]}" $nodelist -w pretrain_qwen3       -s 235b --dtype fp8   --scale 512
llmb-run submit "${env_vars[@]}" $nodelist -w pretrain_nemotron_3  -s 120b --dtype bf16  --scale 512

llmb-run jobs list

llmb-run jobs show -h

llmb-run jobs log -h

# llmb-run jobs log -f $JOBID

#export ADDITIONAL_SLURM_PARAMS='nodelist=HGX[174-245];reservation=exemplar'
export ADDITIONAL_SLURM_PARAMS='nodelist=HGX[174-245]'
llmb-run exemplar -r 1

llmb-run archive

### https://github.com/NVIDIA/exemplar-performance/tree/main/deepseek_v3/pretrain/megatron_bridge
# Reduced GPU-Count Proxy
nodelist="--nodelist HGX246"
llmb-run submit -w pretrain_deepseek-v3 --dtype fp8 --scale 8 $nodelist --proxy
# CPU Performance Debug Proxy
# Run with Full CG enabled (single node)
CPU_PERF_PROXY=true llmb-run submit -w pretrain_deepseek-v3 --dtype fp8 --scale 8 $nodelist --proxy
# Run with Full CG disabled (single node)
CPU_PERF_PROXY=true DISABLE_CG=true llmb-run submit -w pretrain_deepseek-v3 --dtype fp8 --scale 8 $nodelist --proxy
