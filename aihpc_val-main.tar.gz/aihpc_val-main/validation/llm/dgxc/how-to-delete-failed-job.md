# 如何从 `llmb-run` 作业记录中移除失败的作业

## 查看作业记录

先查看目标作业的记录和配置文件路径：

```bash
llmb-run jobs show 8853
```

## 备份数据库并删除记录

确认已设置 `LLMB_INSTALL` 环境变量，然后定义数据库和备份文件路径：

```bash
: "${LLMB_INSTALL:?LLMB_INSTALL is not set}"

db="$LLMB_INSTALL/.llmb/jobs.sqlite3"
backup="${db}.bak.$(date +%Y%m%d-%H%M%S)"
```

确认目标记录：

```bash
sqlite3 -header -column "$db" \
  "SELECT job_id, workload_key, dtype, scale, slurm_state, llmb_config_path
   FROM jobs
   WHERE job_id = 8853;"
```

创建 SQLite 一致性备份：

```bash
sqlite3 "$db" ".backup '$backup'"
echo "Backup: $backup"
```

精确删除目标记录：

```bash
sqlite3 "$db" \
  "BEGIN IMMEDIATE;
   DELETE FROM jobs WHERE job_id = 8853;
   SELECT changes();
   COMMIT;"
```

如果输出以下内容，表示成功删除了一条记录：

```text
1
```

验证删除结果：

```bash
llmb-run jobs list
```

## 防止 `jobs rebuild` 恢复记录

`llmb-run jobs rebuild` 会扫描以下路径：

```text
$LLMB_INSTALL/workloads/**/llmb-config_*.yaml
```

因此，如果对应的 `llmb-config_8853.yaml` 仍然存在，该记录会重新出现。删除数据库记录前，可以获取配置文件路径：

```bash
config_path=$(
  sqlite3 "$db" \
    "SELECT llmb_config_path FROM jobs WHERE job_id = 8853;"
)

printf 'Config path: %s\n' "$config_path"
```

如果需要防止记录被重新导入，建议将配置文件移动到隔离目录，以便后续恢复：

```bash
quarantine="$LLMB_INSTALL/.llmb/removed-job-metadata/8853"
mkdir -p "$quarantine"
mv -- "$config_path" "$quarantine/"
```

> **注意：** 不要直接删除整个实验目录，其中可能还包含诊断日志。上述操作仅影响 LLMB 本地历史记录，不会删除 Slurm `sacct` 中作业 `8853` 的记录，也不会影响其他已完成或正在运行的作业。
