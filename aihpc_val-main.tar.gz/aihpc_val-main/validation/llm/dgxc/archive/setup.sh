#!/bin/bash

sudo apt-get install -y git-lfs

topdir=/home/cmsupport/workspace/
LLMB_INSTALL=${topdir}/llmb
mkdir -p $LLMB_INSTALL
cd $LLMB_INSTALL

## Without HF_TOKEN, download the prepackged huggingface cache
mkdir -p .cache
wget -c https://github.com/junli-nv/misc/raw/refs/heads/main/huggingface.squashfs
unsquashfs -f -d .cache/huggingface huggingface.squashfs

## Download the latest release of dgxc-benchmarking
git clone https://github.com/NVIDIA/dgxc-benchmarking
cd dgxc-benchmarking/
git tag
git checkout v26.06.01
git status

## Hack for the images
mkdir -p $LLMB_INSTALL/images
for i in $(grep -r 'nvcr.io' .|grep metadata.yaml|grep -o  nvcr.io.*nemo:.*|sort|uniq|tr -d "'"|tr '/:' '+'|cut -f2 -d'#'); do
  touch $LLMB_INSTALL/images/$i.sqsh
done
ls -l ${LLMB_INSTALL}/images

export UV_CACHE_DIR="$LLMB_INSTALL/.cache/uv"
export PIP_CACHE_DIR="$LLMB_INSTALL/.cache/pip"
export TMPDIR="$LLMB_INSTALL/.cache/tmp"
mkdir -p $UV_CACHE_DIR $PIP_CACHE_DIR $TMPDIR

## Install dgxc-benchmarking
./install.sh
# Enter installation directory path: /home/cmsupport/workspace/llmb

## Hack for the images
ln -sf /raid/nemo-26.02.01.sqsh ${LLMB_INSTALL}/images/nvidia+nemo+26.02.01.sqsh
ln -sf /raid/nemo-26.04.01.sqsh ${LLMB_INSTALL}/images/nvidia+nemo+26.04.01.sqsh
ls -l ${LLMB_INSTALL}/images

## Run the deepseek-v3 benchmark
cd ${LLMB_INSTALL}

export PATH="$HOME/.local/bin:$PATH"
export LLMB_INSTALL=/home/cmsupport/workspace/llmb
source ${LLMB_INSTALL}/llmb_venv/bin/activate
llmb-run  --install-completion
source $HOME/.bash_completions/llmb-run.sh

llmb-run --version
llmb-run submit -h

env_vars=(
  --env 'NCCL_IB_HCA==rdma_0,rdma_1,rdma_2,rdma_3,rdma_4,rdma_5,rdma_6,rdma_7'
  --env 'NCCL_SOCKET_IFNAME==bond0'
  --env 'OMPI_MCA_btl_tcp_if_include=bond0'
  --env 'OMPI_MCA_oob_tcp_if_include=bond0'
  --env 'NVTE_UB_SOCKET_IFNAME=bond0'
  --env 'GLOO_SOCKET_IFNAME=bond0'
  --env 'UCX_TLS=tcp'
  --env 'UCX_NET_DEVICES=bond0'
  --env 'MELLANOX_VISIBLE_DEVICES=all'
)
# echo "${env_vars[@]}"

llmb-run submit "${env_vars[@]}" --nodelist HGX[174-245] -w pretrain_deepseek-v3 --dtype fp8 --scale 256

llmb-run jobs list

llmb-run jobs show -h

llmb-run jobs log -h

# llmb-run jobs log -f $JOBID

llmb-run exemplar -r 1

### Sample: AVR B300
# (llmb_venv) root@bcm11-headnode:/home/cmsupport/workspace/llmb/dgxc-benchmarking# llmb-run jobs list
# Workload                    DType   Scale   Job ID   Profile   Submit Time        Slurm Status   Elapsed    s/iter   TFLOPS/GPU
# ───────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
# pretrain_deepseek-v3_671b   bf16      512     8841   -         2026-08-18 22:20   COMPLETED      00:32:53    21.79       781.91
# pretrain_deepseek-v3_671b   fp8       512     8842   -         2026-08-18 22:20   COMPLETED      00:30:35    18.64       914.09
# pretrain_deepseek-v3_671b   nvfp4     512     8843   -         2026-08-18 22:20   COMPLETED      00:28:45    16.40      1039.17
# pretrain_gpt_oss_120b       bf16      512     8844   -         2026-08-18 22:20   COMPLETED      00:09:06     4.74       469.47
# pretrain_kimi-k2_1t         fp8       512     8845   -         2026-08-18 22:20   COMPLETED      00:35:54    25.31       529.48
# pretrain_llama3.1_405b      fp8       512     8848   -         2026-08-18 22:20   COMPLETED      00:54:23    58.22      2130.89
# pretrain_llama3.1_405b      nvfp4     512     8849   -         2026-08-18 22:20   COMPLETED      00:36:15    38.11      3255.50
# pretrain_llama3.1_70b       fp8       512     8846   -         2026-08-18 22:20   COMPLETED      00:10:34     8.26      1781.08
# pretrain_llama3.1_70b       nvfp4     512     8847   -         2026-08-18 22:20   COMPLETED      00:08:14     5.45      2698.94
# pretrain_nemotron-h_56b     fp8       512     8850   -         2026-08-18 22:20   COMPLETED      00:09:32     4.92      1674.87
# pretrain_nemotron_3_120b    bf16      512     8851   -         2026-08-18 22:20   COMPLETED      00:12:44     7.78       713.80
# pretrain_qwen3_235b         bf16      512     8852   -         2026-08-18 22:21   COMPLETED      00:31:37    24.72       785.07

llmb-run archive
