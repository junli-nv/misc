#!/bin/bash

# https://github.com/mikefarah/yq/releases
curl -fL \
    https://github.com/mikefarah/yq/releases/latest/download/yq_linux_amd64 \
    -o /usr/local/bin/yq
chmod +x /usr/local/bin/yq

cd /home/cmsupport/workspace/exemplar

ns_nic=bond0
ew_nics=(
    $(echo rdma_{0..7})
)

export MELLANOX_VISIBLE_DEVICES=all
export PMIX_MCA_gds=hash
export UCX_TLS=tcp UCX_NET_DEVICES=${ns_nic}
#export UCX_TLS=rc UCX_NET_DEVICES="$(echo ${ew_nics[@]}|tr ' ' '\n'|xargs -I {} echo {}:1|paste -s -d',')"
export NCCL_IB_HCA="=$(echo ${ew_nics[@]}|tr ' ' '\n'|xargs -I {} echo {}|paste -s -d',')"
export NCCL_SOCKET_IFNAME=${ns_nic}
export OMPI_MCA_btl_tcp_if_include=${ns_nic}
export OMPI_MCA_oob_tcp_if_include=${ns_nic}
export NVTE_UB_SOCKET_IFNAME=${ns_nic}
export GLOO_SOCKET_IFNAME=${ns_nic}
export NCCL_IB_TIMEOUT=25 #Timeout 2.3min
export NCCL_IB_RETRY_CNT=7 #7x2.3=16min
export NCCL_IB_RESILIENCY_PORT_RECOVERY=1
export NCCL_IB_RESILIENCY_PORT_FAILOVER=1

timestamp=$(date +%Y%m%d%H%M%S)
cp ./cluster_config.yaml ./cluster_config.yaml.backup.$timestamp
yq eval '
    .environment = (.environment // {}) |
    .environment.MELLANOX_VISIBLE_DEVICES = "all" |
    .environment.PMIX_MCA_gds = "hash" |
    .environment.UCX_TLS = strenv(UCX_TLS) |
    .environment.UCX_NET_DEVICES = strenv(UCX_NET_DEVICES) |
    .environment.NCCL_IB_HCA = strenv(NCCL_IB_HCA) |
    .environment.NCCL_SOCKET_IFNAME = strenv(NCCL_SOCKET_IFNAME) |
    .environment.OMPI_MCA_btl_tcp_if_include = strenv(OMPI_MCA_btl_tcp_if_include) |
    .environment.OMPI_MCA_oob_tcp_if_include = strenv(OMPI_MCA_oob_tcp_if_include) |
    .environment.NVTE_UB_SOCKET_IFNAME = strenv(NVTE_UB_SOCKET_IFNAME) |
    .environment.GLOO_SOCKET_IFNAME = strenv(GLOO_SOCKET_IFNAME) |
    .environment.NCCL_IB_TIMEOUT = strenv(NCCL_IB_TIMEOUT) |
    .environment.NCCL_IB_RETRY_CNT = strenv(NCCL_IB_RETRY_CNT) |
    .environment.NCCL_IB_RESILIENCY_PORT_RECOVERY = strenv(NCCL_IB_RESILIENCY_PORT_RECOVERY) |
    .environment.NCCL_IB_RESILIENCY_PORT_FAILOVER = strenv(NCCL_IB_RESILIENCY_PORT_FAILOVER)
' ./cluster_config.yaml.backup.$timestamp > ./cluster_config.yaml

yq eval '.' ./cluster_config.yaml
