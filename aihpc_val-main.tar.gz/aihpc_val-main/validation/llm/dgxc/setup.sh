#!/bin/bash

sudo apt-get install -y git-lfs

topdir=/home/cmsupport/workspace/
LLMB_INSTALL=${topdir}/llmb
mkdir -p $LLMB_INSTALL
cd $LLMB_INSTALL

## Without HT_TOKEN, download the prepackged huggingface cache
mkdir -p .cache
wget -c https://github.com/junli-nv/misc/raw/refs/heads/main/huggingface.squashfs
unsquashfs -f -d .cache/huggingface huggingface.squashfs

## Download the latest release of dgxc-benchmarking
git clone https://github.com/NVIDIA/dgxc-benchmarking
cd dgxc-benchmarking/
git tag
git checkout v26.06.01
git status

## Hack for the images
mkdir -p $LLMB_INSTALL/images
for i in $(grep -r 'nvcr.io' .|grep metadata.yaml|grep -o  nvcr.io.*nemo:.*|sort|uniq|tr -d "'"|tr '/:' '+'|cut -f2 -d'#'); do
  touch $LLMB_INSTALL/images/$i.sqsh
done

## Install dgxc-benchmarking
./install.sh
# Enter installation directory path: /home/cmsupport/workspace/llmb

## Fine tune the cluster_config.yaml to use bond0 for all network traffic
python3 -m pip install ruamel.yaml
cat > patch_cluster_config.py << '__END__'
from pathlib import Path
from ruamel.yaml import YAML
from ruamel.yaml.comments import CommentedMap
from ruamel.yaml.scalarstring import DoubleQuotedScalarString as DQ

file_path = Path("cluster_config.yaml")

yaml = YAML()
yaml.preserve_quotes = True
yaml.indent(mapping=2, sequence=2, offset=2)

with file_path.open("r", encoding="utf-8") as f:
    data = yaml.load(f)

env_block = CommentedMap({
    "NCCL_IB_HCA": DQ("=mlx5_0,mlx5_1,mlx5_2,mlx5_3,mlx5_4,mlx5_9,mlx5_10,mlx5_11"),
    "NCCL_SOCKET_IFNAME": DQ("bond0"),
    "MCA_btl_tcp_if_include": DQ("bond0"),
    "MCA_oob_tcp_if_include": DQ("bond0"),
    "NVTE_UB_SOCKET_IFNAME": DQ("bond0"),
    "GLOO_SOCKET_IFNAME": DQ("bond0"),
    "NCCL_NVLS_ENABLE": DQ("0"),
    "UCX_TLS": DQ("tcp"),
    "UCX_NET_DEVICES": DQ("bond0"),
    "MELLANOX_VISIBLE_DEVICES": DQ("all"),
})

workload_cfg = data["workloads"]["config"]

for _, cfg in workload_cfg.items():
    cfg["environment"] = CommentedMap(env_block)

backup_path = file_path.with_suffix(file_path.suffix + ".bak")
backup_path.write_text(file_path.read_text(encoding="utf-8"), encoding="utf-8")

with file_path.open("w", encoding="utf-8") as f:
    yaml.dump(data, f)

print(f"Patched: {file_path}")
print(f"Backup : {backup_path}")
__END__
python3 patch_cluster_config.py

## Hack for the images
ln -sf /raid/nemo-26.06.01.sqsh ${LLMB_INSTALL}/images/nvidia+nemo+26.06.01.sqsh

## Run the deepseek-v3 benchmark
export PATH="$HOME/.local/bin:$PATH"
export LLMB_INSTALL=/home/cmsupport/workspace/llmb
source ${LLMB_INSTALL}/llmb_venv/bin/activate

llmb-run submit -w pretrain_deepseek-v3 --dtype fp8 --scale 128

