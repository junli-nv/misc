#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

## Purpose of this script: to narrow down the multicast issue in GBXX rack, and to verify the overlap of communication and computation in TE gemm kernel.
## https://github.com/NVIDIA/TransformerEngine/blame/main/transformer_engine/common/comm_gemm_overlap/userbuffers/userbuffers-host.cpp
## https://github.com/NVIDIA/TransformerEngine/commit/9eb982e7072bf15eace5248712d81af3d189a832

#SBATCH --exclusive
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=36
#SBATCH --gpus-per-node=4
#SBATCH -N 18  ### Focus on single GBXX rack, 1 nvlink domain

echo "INFO: checking hardware status"
timeout 100 bash /home/cmsupport/workspace/aihpc_val/tools/hc/sysinfo.sh 2>&1

# CONT=/raid/nemo-25.11.01-m1.sqsh # TE version: 2.9.0+70f53666
CONT=/raid/nemo-26.06.00.sqsh #TE version: 2.16.0+4220403e

echo NODELIST=$SLURM_JOB_NODELIST
cd $SLURM_SUBMIT_DIR

DEBUG=${DEBUG:-0}
if [ $DEBUG -eq 1 ]; then
## Use the following command to determine the version of TE installed in the container
srun --container-image "${CONT}" \
python - << 'PY'
import transformer_engine as te
import transformer_engine.pytorch.cpp_extensions.gemm as gemm
print("TE version:", te.__version__)
print("TE gemm module:", gemm.__file__)
print("has get_cublas_workspace_size_bytes:", hasattr(gemm, "get_cublas_workspace_size_bytes"))
PY
exit 0
fi
### Clone TransformerEngine
# git clone https://github.com/NVIDIA/TransformerEngine
# cd TransformerEngine
# git fetch --tags
# #git checkout v2.9
# git checkout v2.16

export NVTE_UB_SOCKET_IFNAME=bond0
export GLOO_SOCKET_IFNAME=bond0
export NCCL_SOCKET_IFNAME=bond0
export NCCL_DEBUG=INFO
export UB_SKIPMC=0
export NCCL_IB_DISABLE=1
export NCCL_NET_PLUGIN=none
export NCCL_NET=Socket
export NCCL_NVLS_ENABLE=1
export NCCL_MNNVL_ENABLE=1
export NVTE_UBDEBUG=1
export UB_SKIPMC=0

te_repo=$PWD/TransformerEngine
export OMP_NUM_THREADS=1

head_node=$(scontrol show hostnames "$SLURM_JOB_NODELIST" | head -n 1)
export MASTER_ADDR=$head_node
export MASTER_PORT=$((29000 + SLURM_JOB_ID % 1000))

srun --export=ALL --mpi=pmix \
  --container-image "${CONT}" \
  --container-mounts "${te_repo}:/opt/TransformerEngine" \
  bash -lc '
    torchrun \
      --nnodes="${SLURM_NNODES}" \
      --nproc_per_node="${SLURM_GPUS_PER_NODE}" \
      --node_rank="${SLURM_NODEID}" \
      --master_addr="${MASTER_ADDR}" \
      --master_port="${MASTER_PORT}" \
      /opt/TransformerEngine/tests/pytorch/distributed/run_gemm_with_overlap.py \
      --seed=1234 \
      --seq-length=4096 \
      --batch-size=1 \
      --num-heads=8 \
      --head-dim=128 \
      --comm-type=rs \
      --bulk-overlap \
      --timing-iters=100
  '