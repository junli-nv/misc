#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

# echo 'set -g mouse off' > ~/.tmux.conf && tmux -f ~/.tmux.conf new -s junli
module load slurm

export PDSH_SSH_ARGS_APPEND="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=quiet -o CheckHostIP=no -o PreferredAuthentications=publickey"

need_validate_nodes=(
HGX[246-303]
)

known_bad_nodes=(
##GPU
HGX260
HGX249
##Lost
HGX299
)

nodelist=$(
  #scontrol show hostname $(echo ${need_validate_nodes[@]}|tr ' ' ','),$(echo ${known_bad_nodes[@]}|tr ' ' ',')|sort|uniq -c|awk '($1==1){print $NF}'|paste -s -d','
  comm -23 \
    <(scontrol show hostname $(echo ${need_validate_nodes[@]}|tr ' ' ',')|sort) \
    <(scontrol show hostname $(echo ${known_bad_nodes[@]}|tr ' ' ',')|sort) \
  | paste -s -d','
)

# Set FAN speed to 100% for all nodes in advance !!!  IMPORTANT

pdsh -f 100 -R ssh -w $nodelist <<- 'EOF'|dshbak -c
sudo kill -9 $(nvidia-smi --query-compute-apps=pid -format=csv,noheader,nounits) &>/dev/null || true
find /cm/local/apps/slurm/var/pre-post-job-logs -type f -exec rm -f {} \;
bash /home/cmsupport/workspace/aihpc_val/tools/hc/ibcounter.sh clear
EOF
pdsh -f 100 -R ssh -w $nodelist <<- 'EOF'
bash /home/cmsupport/workspace/aihpc_val/tools/hc/checker-B300.sh -e 1 | grep -v PASS||true
EOF
bash /home/cmsupport/workspace/aihpc_val/tools/hc/sysinfo.sh $nodelist 2>&1 | tee sysinfo-$(date +%Y%m%d).log

pdsh -f 100 -R ssh -w $nodelist <<- 'EOF'|dshbak -c
ls -l /raid/nemo-26.08.00.sqsh &>/dev/null || echo NONE
EOF
pdsh -f 32 -R ssh -w $nodelist <<- 'EOF'
rsync -P /home/cmsupport/workspace/nemo-26.08.00.sqsh /raid
EOF

pdsh -f 100 -R ssh -w $nodelist <<- 'EOF'|dshbak -c
uname -r
cat /proc/cmdline | tr ' ' '\n'|grep -v -E 'ip=|BOOT' | sort | paste -s -d ' '
EOF

hosts=(
$(scontrol show hostname $nodelist)
)

scontrol show node $(echo ${hosts[*]}|tr ' ' ',') |grep -E 'NodeName|CfgTRES='|paste - -|sed -e 's# Arch=#:Arch=#g' -e 's#NodeName=##g' |dshbak -c

#scontrol update nodename=$(echo ${hosts[*]}|tr ' ' ',') stat=undrain
scontrol show node $(echo ${hosts[*]}|tr ' ' ',') |grep -E 'NodeName|State'|paste - -|grep -o State.*|sort|uniq -c

## https://github.com/NVIDIA/exemplar-performance/tree/main/deepseek_v3/pretrain/megatron_bridge

## Perf Ref: https://llmb.nvidia.com/beacon/baselines?release=26.08.00&gpus=B300&models=deepseek-v3

## 1N test: CPU Performance Debug Proxy - identify CPU issue - DEBUG only
for i in ${hosts[@]}; do
  export GPU_TYPE=b300 DTYPE=fp8
  PROXY_WORKLOAD=true DISABLE_CG=true CPU_PERF_PROXY=true MAX_STEPS=50 \
  sbatch -N 1 -w $i -o root-DEEPSEEK-1N-$i-%j-cpu-${GPU_TYPE}-${DTYPE}.txt nemo-deepseekv3-mbridge-26.08.00.sh
done

## 1N test: Reduced GPU-Count Proxy
for i in ${hosts[@]}; do
  export GPU_TYPE=b300 DTYPE=fp8
  PROXY_WORKLOAD=true CPU_PERF_PROXY=false MAX_STEPS=50 \
  sbatch -N 1 -w $i -o root-DEEPSEEK-1N-$i-%j-${GPU_TYPE}-${DTYPE}.txt nemo-deepseekv3-mbridge-26.08.00.sh
done

## Step Test - (2/4/8)N Reduced GPU-Count Proxy, (16/32/64)N Normal test
step=; for step in 2 4 8 16 32 64
do
  i=0; while [ $i -lt ${#hosts[@]} ]; do
    s0=$[i+1]
    s1=$[i+step]
    thosts=($(scontrol show hostname $(echo ${hosts[@]} ${hosts[@]}|cut -f${s0}-${s1} -d ' '|tr ' ' ',')))
    postfix=$(echo ${thosts[*]}|/home/cmsupport/workspace/aihpc_val/tools/hc/nodetools/python3-hostlist/hostlist -c -)
    #cat <<- EOF
    if [ $step -gt 8 ]; then
      unset  PROXY_WORKLOAD
      unset  CPU_PERF_PROXY
      export MAX_STEPS=50
      export GPU_TYPE=b300 DTYPE=fp8
    else
      export PROXY_WORKLOAD=true
      export CPU_PERF_PROXY=false
      export MAX_STEPS=50
      export GPU_TYPE=b300 DTYPE=fp8
    fi
    sbatch \
        -N ${#thosts[*]} \
        -w $(echo "${thosts[*]}"|tr ' ' ',') \
        -t 1:00:00 \
        --job-name=DEEPSEEK-${step}N \
        --output=${USER}-DEEPSEEK-${#thosts[*]}N-${postfix}-%j-${GPU_TYPE}-${DTYPE}.txt \
        nemo-deepseekv3-mbridge-26.08.00.sh
#EOF
    i=${s1}
  done
done

# echo ${a[@]}|tr ',' '\n'|sort|uniq|shuf -n 16 #Pick 16 random nodes for test

