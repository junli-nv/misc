#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

#SBATCH -p defq
#SBATCH --exclusive
#SBATCH --mem=0
#
## B300
#SBATCH --ntasks-per-node=8
#SBATCH --cpus-per-task=32
#SBATCH --gpus-per-node=8
#
## GB300
##SBATCH --ntasks-per-node=4
##SBATCH --cpus-per-task=36
##SBATCH --gpus-per-node=4

CONT=/raid/nemo-26.08.00.sqsh

module load slurm
cd ${SLURM_SUBMIT_DIR}

echo
echo "NODELIST: ${SLURM_JOB_NODELIST}"
echo

s_time=$(date +%s)
echo "INFO: cleaning work begin"
pdsh -f 64 -R ssh -w ${SLURM_JOB_NODELIST} <<- 'EOF'|dshbak -c
pkill -9 python &>/dev/null || true
ps -ef|grep python|grep -E 'torch|nemo'|grep -v grep || true
enroot list -f|grep pyxis && enroot remove -f $(enroot list -f|grep pyxis) || true
rm -f /var/lib/systemd/coredump/* &>/dev/null || true
EOF
echo "INFO: cleaning work done"

echo "INFO: checking hardware status"
timeout 100 bash /home/cmsupport/workspace/aihpc_val/tools/hc/sysinfo.sh 2>&1

set -x
ns_nic=bond0
#ew_nics=($(lspci -D|grep Infiniband.*ConnectX-8|awk '{print $1}'|while read i; do ls -l /sys/class/infiniband|grep -o ${i}/.*|awk -F'/' '{print $NF}'; done))
nvsw_mgmt_ib_prefix=$(lspci | grep Infiniband.*ConnectX-7|cut -f1 -d'.'|sort|uniq -c|grep -w ' 4'|awk '{print $NF}')
ew_nics=($(lspci | grep Infiniband.*ConnectX|grep -v ${nvsw_mgmt_ib_prefix}|awk '{print $1}'|while read i; do ls -l /sys/class/infiniband|grep -o ${i}/.*|awk -F'/' '{print $NF}'; done))
export MELLANOX_VISIBLE_DEVICES=all
export PMIX_MCA_gds=hash
#
export UCX_TLS=tcp UCX_NET_DEVICES=${ns_nic}
#export UCX_TLS=rc UCX_NET_DEVICES="$(echo ${ew_nics[@]}|tr ' ' '\n'|xargs -I {} echo {}:1|paste -s -d',')"
export NCCL_IB_HCA="=$(echo ${ew_nics[@]}|tr ' ' '\n'|xargs -I {} echo {}|paste -s -d',')"
#
export NCCL_SOCKET_IFNAME=${ns_nic}
export MCA_btl_tcp_if_include=${ns_nic}
export MCA_oob_tcp_if_include=${ns_nic}
export NVTE_UB_SOCKET_IFNAME=${ns_nic}
export GLOO_SOCKET_IFNAME=${ns_nic}
#
export OMPI_ALLOW_RUN_AS_ROOT=1
export OMPI_ALLOW_RUN_AS_ROOT_CONFIRM=1
export OMPI_MCA_btl_openib_warn_default_gid_prefix=0
export OMPI_MCA_coll_hcoll_enable=0
export SLURM_CPU_BIND=none
#
## Minimize the impact of IB link flapping
export NCCL_IB_TIMEOUT=25 #Timeout 2.3min
export NCCL_IB_RETRY_CNT=7 #7x2.3=16min
export NCCL_IB_RESILIENCY_PORT_RECOVERY=1
export NCCL_IB_RESILIENCY_PORT_FAILOVER=1
export NCCL_NVLS_ENABLE=0

########  nccl test
# cat > /dev/null <<- '__COMMENT__'
export NCCL_DEBUG=WARN
export NCCL_IB_SL=1
export NCCL_MIN_NCHANNELS=32
export NCCL_NVLS_ENABLE=1
export NCCL_IB_QPS_PER_CONNECTION=2
export NCCL_IB_SPLIT_DATA_ON_QPS=0
#export NCCL_NET_PLUGIN=none
#export NCCL_IB_OOO_RQ=1 #better for performance but may lead error in some cases
export NCCL_IGNORE_COLLNET_MISMATCH=1
timeout 300 \
srun --export=ALL --cpu-bind=none --mpi=pmix \
--container-writable \
--container-image=$CONT \
--container-mounts=/dev:/dev \
all_reduce_perf_mpi -d float -b 8 -f 2 -g 1 -e 16G --iters 20 -R 0
exitcode=$?
if [ $exitcode -ne 0 ]; then
  echo "*********************************************"
  echo "* ERROR: NCCL failed to run!!!              *"
  echo "*********************************************"
  exit 1
fi
#unset NCCL_IB_OOO_RQ
sleep 10
#__COMMENT__

########  nemo test
#
### Parameters Reference:
# To find out which branch is used to build the container, refer 
#      https://docs.nvidia.com/nemo/megatron-bridge/latest/releases/software-versions.html#software-component-versions
# Args: https://github.com/NVIDIA-NeMo/Megatron-Bridge/tree/main/scripts/performance
#      NEMOTRONH_56B_PRETRAIN_CONFIG_B300_FP8_CS_V1: configs/nemotronh/nemotronh_workload_base_configs.py
#
GPU_TYPE=${GPU_TYPE:-b300}
DTYPE=${DTYPE:-fp8}
DTYPE=${DTYPE,,}
#
## Workaround for unstable or not robust enough NVLINK:
# It's usually better than turning off tp_comm_overlap entirely, but worse than full multicast on a healthy, supported fabric.
# UB_SKIPMC: UserBuffers Skip Multicast
# UB = UserBuffers (the TP-overlap communication backend in TransformerEngine)
# SKIPMC = skip multicast (don't use CUDA/NVLS multicast for UB collectives)
## export NCCL_NVLS_ENABLE=0
## export UB_SKIPMC=1
export NCCL_DEBUG=INFO

export TORCH_NCCL_AVOID_RECORD_STREAMS=1
export TRANSFORMERS_OFFLINE=1
export TOKENIZERS_PARALLELISM=False
export NCCL_NVLS_ENABLE=0
export TORCH_NCCL_HIGH_PRIORITY=1
export HF_HUB_OFFLINE=1
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export NCCL_GRAPH_REGISTER=0
export WANDB_RUN_ID=$(echo $RANDOM|md5sum|cut -c1-8)
export WANDB_RESUME=allow
export CUDA_DEVICE_MAX_CONNECTIONS=32
export NVTE_FWD_LAYERNORM_SM_MARGIN=16
export NVTE_BWD_LAYERNORM_SM_MARGIN=16
export NCCL_IGNORE_CPU_AFFINITY=1

JOB_TOTAL_GPUS=$[${SLURM_GPUS_PER_NODE}*${SLURM_NNODES}]
FP8_RECIPE=${FP8_RECIPE:-cs}
FP8_RECIPE=${FP8_RECIPE,,}
COMPUTE_TYPE=${DTYPE}_${FP8_RECIPE}
MODEL_SIZE=${MODEL_SIZE:-56b}
MODEL_SIZE=${MODEL_SIZE,,}
PROFILE_ENABLED=${ENABLE_PROFILE:-false}
PROFILE_ENABLED=${PROFILE_ENABLED,,}
PYTORCH_PROFILE_ENABLED=${ENABLE_PYTORCH_PROFILE:-false}
PYTORCH_PROFILE_ENABLED=${PYTORCH_PROFILE_ENABLED,,}
PROFILE_START_STEP=${PROFILE_START_STEP:-45}
PROFILE_STOP_STEP=${PROFILE_STOP_STEP:-50}
GPU_METRICS_ENABLED=${ENABLE_GPU_METRICS:-false}
GPU_METRICS_ENABLED=${GPU_METRICS_ENABLED,,}
ENABLE_VBOOST=${ENABLE_VBOOST:-false}
ENABLE_VBOOST=${ENABLE_VBOOST,,}
ENABLE_PCT_BINDING=${ENABLE_PCT_BINDING:-false}
ENABLE_PCT_BINDING=${ENABLE_PCT_BINDING,,}
TP_COMM_OVERLAP=${TP_COMM_OVERLAP:-true}
TP_COMM_OVERLAP=${TP_COMM_OVERLAP,,}
MAX_STEPS=${MAX_STEPS:-110}

if [[ $DTYPE != "fp8" ]] || [[ $FP8_RECIPE != "cs" ]]; then
    echo "Error: Nemotron-H only supports fp8 with cs recipe."
    exit 1
fi

CONFIG_OVERRIDES=""
if [[ $PROFILE_ENABLED == "true" ]] && [[ $PYTORCH_PROFILE_ENABLED == "true" ]]; then
    echo "Error: ENABLE_PROFILE and ENABLE_PYTORCH_PROFILE are mutually exclusive." >&2
    exit 1
fi

if [[ $PROFILE_ENABLED == "true" ]]; then
    CONFIG_OVERRIDES+=" --enable_nsys "
    CONFIG_OVERRIDES+=" --profiling_start_step=$PROFILE_START_STEP "
    CONFIG_OVERRIDES+=" --profiling_stop_step=$PROFILE_STOP_STEP "
    PROFILE_RANKS=$(seq -s, 0 $((JOB_TOTAL_GPUS - 1)))
    CONFIG_OVERRIDES+=" --profiling_ranks=$PROFILE_RANKS"
    CONFIG_OVERRIDES+=" --nsys_trace=cuda "
    CONFIG_OVERRIDES+=" --nsys_extra_args=--nvtx-domain-include=NCCL "
    if [[ $GPU_METRICS_ENABLED == true ]]; then
        CONFIG_OVERRIDES+=" --profiling_gpu_metrics "
    fi
fi

if [[ $PYTORCH_PROFILE_ENABLED == "true" ]]; then
    CONFIG_OVERRIDES+=" --pytorch_profiler true "
fi

if [[ $ENABLE_VBOOST == true ]]; then
    CONFIG_OVERRIDES+=" --enable_vboost true "
fi

if [[ $GPU_TYPE == "gb300" ]] || [[ $GPU_TYPE == "gb200" ]]; then
    if [[ $GPU_TYPE == "gb200" ]] && [[ $JOB_TOTAL_GPUS -eq 32 ]]; then
        CONFIG_OVERRIDES+=" --cuda_graph_scope=mamba "
    fi
    GPUS_PER_NODE=4
elif [[ $GPU_TYPE == "b300" ]] || [[ $GPU_TYPE == "b200" ]] || [[ $GPU_TYPE == "h100" ]]; then
    if [[ $GPU_TYPE == "b200" ]] && [[ $JOB_TOTAL_GPUS -eq 32 ]]; then
        CONFIG_OVERRIDES+=" -tp 4 "
        CONFIG_OVERRIDES+=" -mb 2 "
    fi
    GPUS_PER_NODE=8
fi

if { [[ $GPU_TYPE == "gb300" ]] || [[ $GPU_TYPE == "gb200" ]] || [[ $GPU_TYPE == "b300" ]]; } && [[ $JOB_TOTAL_GPUS -ge 512 ]]; then
    export NCCL_IB_QPS_PER_CONNECTION=${NCCL_IB_QPS_PER_CONNECTION:-4}
fi

if [[ $TP_COMM_OVERLAP == "false" ]]; then
    CONFIG_OVERRIDES+=" comm_overlap.tp_comm_overlap=false comm_overlap.tp_comm_overlap_cfg=null "
fi

CONFIG_OVERRIDES+=" --enable_pct_binding $ENABLE_PCT_BINDING "
if [[ $ENABLE_PCT_BINDING == "true" ]]; then
    export NCCL_IGNORE_CPU_AFFINITY=1
fi

if [[ $GPU_TYPE == "b200" ]]; then
    if [[ $JOB_TOTAL_GPUS -lt 32 ]]; then
        CONFIG_OVERRIDES+=" -tp 4 "
        CONFIG_OVERRIDES+=" -pp 2 "
        CONFIG_OVERRIDES+=" -mb 1 "
        CONFIG_OVERRIDES+=" --cuda_graph_impl transformer_engine --cuda_graph_scope=mamba "
    fi
fi

if [[ $JOB_TOTAL_GPUS -gt 512 ]]; then
    CONFIG_OVERRIDES+=" -tp 4 "
    CONFIG_OVERRIDES+=" -pp 2 "
    CONFIG_OVERRIDES+=" -mb 1 "
fi

gbs=$[192/64*$JOB_TOTAL_GPUS]
CONFIG_OVERRIDES+=" -gb $gbs "
echo "INFO: CONFIG_OVERRIDES=$CONFIG_OVERRIDES"

export GPU_TYPE
export COMPUTE_TYPE
export JOB_TOTAL_GPUS
export GPUS_PER_NODE
export CONFIG_OVERRIDES
export MAX_STEPS
export OPENBLAS_NUM_THREADS=1
export ENABLE_PCT_BINDING

#
### The above exported parameters should be set outside of the container, otherwise will lead to error.
#
## Check the Priority Cores Turbo(PCT) for high frequency
# cpupower monitor | tail -n +7 | awk -F '|' '($11>=4000){print $1,$2,$3,$11}'
# pidof python|tr ' ' '\n'|xargs -I {} taskset -pc {}|cut -f2 -d':'|sort|uniq -c
# ps -e -o psr,cmd|grep python|grep -v grep|awk '{print $1}'|sort -n|uniq -c
# turbostat --show Package,Core,CPU,Busy%,Bzy_MHz,CoreTmp,PkgWatt --interval 1 --num_iterations 60 --quiet --out turbostat-llm.log

srun --export=ALL --cpu-bind=none --mpi=pmix \
--container-writable \
--container-image=${CONT} \
--container-mounts=/dev:/dev \
--wait=600 --kill-on-bad-exit=1 --mpi=pmix \
bash <<- '__END__'
if [[ $SLURM_PROCID -eq 0 ]]; then
  bash /opt/Megatron-Bridge/docker/common/print_sha.sh /tmp/repo_status.json
fi
set -ex
export HF_HOME=/root/.cache/huggingface
export CPATH=/usr/local/cuda/include
export TRITON_PTXAS_PATH=/usr/local/cuda/bin/ptxas
export TRITON_LIB_DIR=/usr/local/cuda/lib64
export PYTHONPATH=/opt/Megatron-Bridge/scripts/performance:$PYTHONPATH
export NEMORUN_HOME=/mnt/nemo
export NEMO_HOME=${NEMORUN_HOME}/experiments
if [[ $ENABLE_PCT_BINDING == "true" ]]; then
  numa_cmd="numactl -C $[SLURM_LOCALID*16],$[SLURM_LOCALID*16+1] --localalloc"
else
  numa_cmd="numactl --cpunodebind=$[SLURM_LOCALID*2/${GPUS_PER_NODE}] --membind=$[SLURM_LOCALID*2/${GPUS_PER_NODE}]"
fi
$numa_cmd \
python /opt/Megatron-Bridge/scripts/performance/run_script.py \
  --account root \
  --partition defq \
  --log_dir ${NEMORUN_HOME} \
  --compute_dtype ${COMPUTE_TYPE} --config_variant v1 \
  --gpu ${GPU_TYPE} \
  --num_gpus ${JOB_TOTAL_GPUS} \
  --gpus_per_node ${GPUS_PER_NODE} \
  --offline \
  --model_family_name nemotronh \
  --model_recipe_name nemotronh_56b \
  ${CONFIG_OVERRIDES} \
  --max_steps ${MAX_STEPS} \
  --packager none \
  train.manual_gc=true train.manual_gc_interval=100
__END__
set +x

e_time=$(date +%s)
echo "INFO: timelimit=$[(SLURM_JOB_END_TIME-SLURM_JOB_START_TIME)](s), real_took=$[e_time-s_time](s)"

### If you want to check the parms used in the above script, you can use the following command to check(reference only):
cat > /dev/null <<- '__COMMENT__'
#!/bin/bash
export IMAGE=${IMAGE:-/raid/nemo-26.06.01.sqsh}
export COMPUTE_TYPE=${COMPUTE_TYPE:-fp8_cs}
export GPU_TYPE=${GPU_TYPE:-b300}
export JOB_TOTAL_GPUS=${JOB_TOTAL_GPUS:-512}
export GPUS_PER_NODE=${GPUS_PER_NODE:-8}
export MAX_STEPS=${MAX_STEPS:-110}
export WORKSPACE=${WORKSPACE:-$PWD}
#
srun --export=ALL --cpu-bind=none --mpi=pmix \
--container-writable \
--container-image=${IMAGE} \
--container-mounts=/dev:/dev,${WORKSPACE}:${WORKSPACE} \
--wait=600 --kill-on-bad-exit=1 --mpi=pmix --gpus-per-node=1 \
bash <<- '__END__'
export PYTHONPATH=/opt/Megatron-Bridge/scripts/performance:$PYTHONPATH
cat > /usr/local/bin/sbatch <<- 'EOF'
#!/bin/bash
echo "sbatch $@"
EOF
chmod a+x /usr/local/bin/sbatch
export NEMORUN_HOME=${WORKSPACE}/${GPU_TYPE}
cd /opt/Megatron-Bridge
set -x
# https://github.com/NVIDIA-NeMo/Megatron-Bridge/tree/main/scripts/performance
python3 scripts/performance/setup_experiment.py \
  --account root \
  --partition defq \
  --container_image ${IMAGE} \
  --log_dir $NEMORUN_HOME \
  --compute_dtype ${COMPUTE_TYPE} \
  --config_variant v1 \
  --gpu ${GPU_TYPE} \
  --num_gpus ${JOB_TOTAL_GPUS} \
  --gpus_per_node ${GPUS_PER_NODE} \
  --offline \
  --model_family_name nemotronh \
  --model_recipe_name nemotronh_56b \
  --max_steps $MAX_STEPS \
  --packager none \
  ${CONFIG_OVERRIDES}
__END__
__COMMENT__

