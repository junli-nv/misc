#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

#SBATCH -p defq
#SBATCH --exclusive
#SBATCH --ntasks-per-node=1
#SBATCH --time=10:00
#SBATCH --cpu-freq=Performance

module load slurm
cd ${SLURM_SUBMIT_DIR}

NODELIST=$SLURM_JOB_NODELIST
hosts=($(scontrol show hostname $NODELIST))

ssh_passwd_less_check(){
  node=$1
  timeout 2 ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=quiet -o CheckHostIP=no ${node} : &>/dev/null
  ret=$?
  if [ $ret -ne 0 ]; then
    echo "ERROR: ${node} can't be reached without password"
  fi
  return $ret
}

run_cmd_remote(){
  node=$1
  shift
  ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=quiet -o CheckHostIP=no ${node} "$@"
  ret=$?
  return $ret
}

## Tune the bond0 interface for better performance
# ifconfig bond0 mtu 9000
# echo layer3+4 > /sys/class/net/bond0/bonding/xmit_hash_policy
# cat /proc/net/bonding/bond0 | grep "Transmit Hash Policy"
pdsh -f 100 -R ssh -w $NODELIST <<- EOF |dshbak -c
grep -r . /sys/class/net/bond0/mtu
cat /proc/net/bonding/bond0 | grep "Transmit Hash Policy"
EOF

if [ ${DEBUG} -eq 1 ]; then
pdsh -t 30 -u 30 -R ssh -w $NODELIST <<- 'EOF' | sort
lldpcli show neighbors ports $(lspci -D | grep -i Ethernet.*BlueField-3|awk '{print $1}'|xargs -I {} bash -c 'ls -l /sys/class/net|grep -o {}/.*|cut -f3 -d"/"'|paste -s -d ',' -) | grep -E 'Interface:|SysName:|PortID:'|awk '/Interface:/{print $2} /SysName:/{print $NF} /PortID:/{print $NF}'|tr ',' ' '|paste - - -|sort|paste -d ' ' - -|awk '{if(NF==6 && $3 != $6){print $0," <*>"}else{print $0}}'
EOF
fi

export roce_iface=${roce_iface:-mlx5_bond_0}

main(){
  srvr=$1
  clnt=$2
  ssh_passwd_less_check $srvr; ret=$?; [ $ret -ne 0 ] && return 1
  ssh_passwd_less_check $clnt; ret=$?; [ $ret -ne 0 ] && return 2
  run_cmd_remote $srvr "pkill -9 ib_write_bw; nohup numactl -N $(cat /sys/class/infiniband/${roce_iface}/device/numa_node) -m $(cat /sys/class/infiniband/${roce_iface}/device/numa_node) ib_write_bw -d ${roce_iface} -F --report_gbits --qp 8 &>/dev/null &"
  sleep 3
  ret=$(run_cmd_remote $clnt "pkill -9 ib_write_bw; nohup numactl -N $(cat /sys/class/infiniband/${roce_iface}/device/numa_node) -m $(cat /sys/class/infiniband/${roce_iface}/device/numa_node) ib_write_bw -d ${roce_iface} -F --report_gbits --qp 8 $srvr |& grep '65536 .* 40000'|awk '{print \$4}'")
  echo "INFO: ib_write_bw [s]${srvr} <- [c]${clnt} = ${ret} Gbps"
}
export -f main

echo "Start: NODELIST=$NODELIST"
## 从前往后取相邻的两个节点
echo "INFO: Start to run iperf3 between the adjacent nodes"
i=0; while [ $i -lt ${#hosts[@]} ]; do
  s0=$[i+1]
  s1=$[i+2]
  thosts=($(scontrol show hostname $(echo ${hosts[@]} ${hosts[@]}|cut -f${s0}-${s1} -d ' '|tr ' ' ',')))
  main ${thosts[@]} &
  i=${s1}
done
wait

## 从前半部和后半部各取一个节点
echo "INFO: Start to run iperf3 between the first half and the second half of the nodes"
i=0; j=$[${#hosts[@]}/2]; while [ $i -lt $[${#hosts[@]}/2] ]; do
  main ${hosts[$i]} ${hosts[$j]} &
  i=$[i+1]
  j=$[j+1]
done
wait

echo "Done."
