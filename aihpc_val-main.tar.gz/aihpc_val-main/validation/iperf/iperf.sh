#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

#SBATCH -p defq
#SBATCH --exclusive
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=32
#SBATCH --time=10:00
#SBATCH --cpu-freq=Performance

export PDSH_SSH_ARGS_APPEND="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=quiet -o CheckHostIP=no"
export PDSH_RCMD_TYPE=ssh
export FANOUT=${FANOUT:-100}
export DEBUG=${DEBUG:-0}

module load slurm
cd ${SLURM_SUBMIT_DIR}

NODELIST=$SLURM_JOB_NODELIST
hosts=($(scontrol show hostname $NODELIST))

ssh_passwd_less_check(){
  node=$1
  timeout 2 ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=quiet -o CheckHostIP=no ${node} : &>/dev/null
  ret=$?
  if [ $ret -ne 0 ]; then
    echo "ERROR: ${node} can't be reached without password"
  fi
  return $ret
}

run_cmd_remote(){
  node=$1
  shift
  ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=quiet -o CheckHostIP=no ${node} "$@"
  ret=$?
  return $ret
}

## Tune the bond0 interface for better performance
# ifconfig bond0 mtu 9000
# echo layer3+4 > /sys/class/net/bond0/bonding/xmit_hash_policy
# cat /proc/net/bonding/bond0 | grep "Transmit Hash Policy"
pdsh -f 100 -R ssh -w $NODELIST <<- 'EOF' |dshbak -c
[ -f /proc/net/bonding/bond0 ] && { for i in /proc/net/bonding/*; do { ethtool ${i##*/} | grep -e Speed -e Link; echo MTU: $(cat /sys/class/net/${i##*/}/mtu); echo '==DETAILS=='; grep -e 'Bonding Mode' -e 'Transmit Hash Policy' $i; for j in $(grep 'Slave Interface' $i |awk '{print $NF}'|sort); do grep -A7 "Slave Interface: $j" $i | grep -e 'Slave Interface' -e 'MII Status' -e 'Speed'  -e 'Aggregator ID' | paste -s -d' '; done; }| xargs -I {} echo "${i}: {}"; done; } || true
EOF

if [ ${DEBUG} -eq 1 ]; then
pdsh -t 30 -u 30 -R ssh -w $NODELIST <<- 'EOF' | sort
lldpcli show neighbors ports $(lspci -D | grep -i Ethernet.*BlueField-3|awk '{print $1}'|xargs -I {} bash -c 'ls -l /sys/class/net|grep -o {}/.*|cut -f3 -d"/"'|paste -s -d ',' -) | grep -E 'Interface:|SysName:|PortID:'|awk '/Interface:/{print $2} /SysName:/{print $NF} /PortID:/{print $NF}'|tr ',' ' '|paste - - -|sort|paste -d ' ' - -|awk '{if(NF==6 && $3 != $6){print $0," <*>"}else{print $0}}'
EOF
fi

main(){
  srvr=$1
  clnt=$2
  ssh_passwd_less_check $srvr; ret=$?; [ $ret -ne 0 ] && return 1
  ssh_passwd_less_check $clnt; ret=$?; [ $ret -ne 0 ] && return 2
  run_cmd_remote $srvr "export PATH=/home/cmsupport/workspace/iperf3/bin:\$PATH LD_LIBRARY_PATH=/home/cmsupport/workspace/iperf3/lib:\$LD_LIBRARY_PATH; pkill -9 iperf3; nohup iperf3 -s &>/dev/null &"
  ret=$(run_cmd_remote $clnt "export PATH=/home/cmsupport/workspace/iperf3/bin:\$PATH LD_LIBRARY_PATH=/home/cmsupport/workspace/iperf3/lib:\$LD_LIBRARY_PATH; iperf3 -c $srvr -P 64 -t 30 -O 2 -Z -J | jq -r '.end.sum_received.bits_per_second / 1e9 | round'")
  echo "INFO: iperf3 [s]${srvr} <- [c]${clnt} = ${ret} Gbps"
}
export -f main

echo 
echo "Start: NODELIST=$NODELIST"
## 从前往后取相邻的两个节点
echo "INFO: Start to run iperf3 between the adjacent nodes"
i=0; while [ $i -lt ${#hosts[@]} ]; do
  s0=$[i+1]
  s1=$[i+2]
  thosts=($(scontrol show hostname $(echo ${hosts[@]} ${hosts[@]}|cut -f${s0}-${s1} -d ' '|tr ' ' ',')))
  main ${thosts[@]} &
  i=${s1}
done
wait

## 从前半部和后半部各取一个节点
echo "INFO: Start to run iperf3 between the first half and the second half of the nodes"
i=0; j=$[${#hosts[@]}/2]; while [ $i -lt $[${#hosts[@]}/2] ]; do
  main ${hosts[$i]} ${hosts[$j]} &
  i=$[i+1]
  j=$[j+1]
done
wait

echo "Done."
