#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

topdir=/home/cmsupport/workspace
cd $topdir
wget -c https://github.com/esnet/iperf/releases/download/3.21/iperf-3.21.tar.gz
tar -xf iperf-3.21.tar.gz
cd iperf-3.21
./configure --prefix=$topdir/iperf3
make -j8 install

export PATH=/home/cmsupport/workspace/iperf3/bin:$PATH
export LD_LIBRARY_PATH=/home/cmsupport/workspace/iperf3/lib:$LD_LIBRARY_PATH
iperf3 -v
