#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

RESNAME="--reservation=junli_val"
nodelist=$(sinfo -al|grep 'reserved.*junli_val'|awk '{print $NF}')

module load slurm
hosts=(
$(scontrol show hostname $nodelist)
)
#echo ${hosts[*]}

for level in tol 4 #1 2 3 4 p30m p2h
do
  jobname=DCGMI-$(date +"%Y%m%d%H%M%S")-r${level}
  logdir=logs/${jobname}
  mkdir -p ${logdir}
  for h in ${hosts[*]}
  do
    sbatch ${RESNAME} \
      -N 1 \
      -w "${h}" \
      -t 2:00:00 \
      --job-name=${jobname} \
      --output=${logdir}/${USER}-${jobname}-${h}-r${level}-%j.txt \
      --export=LEVEL=${level} \
      dcgmi.sbatch
  done
done

# grep -i failed -r ./logs
