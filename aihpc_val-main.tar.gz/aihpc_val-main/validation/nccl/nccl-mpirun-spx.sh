#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

#SBATCH -p defq
#SBATCH --exclusive
#SBATCH --ntasks-per-node=8
#SBATCH --cpus-per-task=43
#SBATCH --gpus-per-node=8

echo NODELIST=$SLURM_JOB_NODELIST
cd $SLURM_SUBMIT_DIR
source /home/cmsupport/workspace/aihpc_val/validation/envs/global_env.sh
#timeout 300 bash /home/cmsupport/workspace/aihpc_val/tools/hc/sysinfo.sh 2>&1

hosts=($(scontrol show hostname $SLURM_JOB_NODELIST))

set -x
ldd `which all_reduce_perf`
ns_nic=bond0
ew_nics=(roce_p{0..1}_r{0..7})
#ew_nics=(roce_p0_r{0..7})
#ew_nics=(roce_p1_r{0..7})

mpirun --allow-run-as-root \
  --mca pml ucx --mca coll ^hcoll --mca btl ^openib,smcuda \
  --bind-to none \
  -x PATH=$PATH \
  -x LD_LIBRARY_PATH=$HPCX_DIR/nccl_spectrum-x_plugin/lib:$LD_LIBRARY_PATH \
\
  -x UCX_TLS=rc \
  -x UCX_NET_DEVICES="$(echo ${ew_nics[@]}|tr ' ' '\n'|xargs -I {} echo {}:1|paste -s -d',')" \
  -x NCCL_IB_HCA="$(echo ${ew_nics[@]}|tr ' ' '\n'|xargs -I {} echo {}|paste -s -d',')" \
  -x NCCL_SOCKET_IFNAME=${ns_nic} \
  -x OMPI_MCA_btl_tcp_if_include=${ns_nic} \
  -x OMPI_MCA_oob_tcp_if_include=${ns_nic} \
  -x OMPI_ALLOW_RUN_AS_ROOT=1 \
  -x OMPI_ALLOW_RUN_AS_ROOT_CONFIRM=1 \
  -x OMPI_MCA_btl_openib_warn_default_gid_prefix=0 \
  -x OMPI_MCA_coll_hcoll_enable=0 \
  -x SLURM_CPU_BIND=none \
  -x CUDA_MODULE_LOADING=EAGER \
\
  -x NCCL_DEBUG=INFO \
  -x NCCL_RUNTIME_CONNECT=0 \
\
  -x NCCL_NET_PLUGIN=spcx \
  -x NCCL_IB_GID_INDEX=3 \
  -x NCCL_IB_TC=96 \
  -x NCCL_IB_DYNAMIC_FLOW=1 \
  -x NCCL_NET_MERGE_LEVEL=PIX \
  -x NCCL_IB_FAILURE_RESILIENCY_RECOVERY=1 \
  -x NCCL_NCHANNELS_PER_NET_PEER=4 \
  -x NCCL_P2P_NET_CHUNKSIZE=262144 \
\
  -x NCCL_IB_QPS_PER_CONNECTION=2 \
  -x NCCL_NVLS_ENABLE=1 \
  -x NCCL_IB_ADAPTIVE_ROUTING=1 \
  -x NCCL_IB_SL=1 \
  -x NCCL_NET_MERGE_LEVEL=PIX \
\
  -H $(for i in ${hosts[*]}; do echo ${i}:8; done|paste -s -d ',') \
  -np $[8*${#hosts[*]}] \
  `which all_reduce_perf` -b 2 -f 2 -g 1 -e 32G --iters 20 #-R2
set +x
