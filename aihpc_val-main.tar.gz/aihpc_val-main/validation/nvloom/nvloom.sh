#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

#SBATCH -p defq
#SBATCH --exclusive
#SBATCH --ntasks-per-node=4
#SBATCH --cpus-per-task=36
#SBATCH --gpus-per-node=4

echo NODELIST=$SLURM_JOB_NODELIST
cd $SLURM_SUBMIT_DIR
source /home/cmsupport/workspace/aihpc_val/validation/envs/global_env.sh
timeout 100 bash /home/cmsupport/workspace/aihpc_val/tools/hc/sysinfo.sh 2>&1

hosts=($(scontrol show hostname $SLURM_JOB_NODELIST))

BIN=/home/cmsupport/workspace/nvloom/nvloom_cli
nic=bond0
set -x
mpirun --allow-run-as-root \
  --mca pml ucx --mca coll ^hcoll --mca btl ^openib,smcuda \
  --bind-to none \
  -x PATH=$PATH \
  -x LD_LIBRARY_PATH=$LD_LIBRARY_PATH \
  --mca btl_tcp_if_include ${nic} \
  --mca oob_tcp_if_include ${nic} \
  -x UCX_NET_DEVICES=${nic} \
  -x UCX_TLS=tcp \
\
  -H $(for i in ${hosts[*]}; do echo ${i}:4; done|paste -s -d ',') \
  -np $[4*${#hosts[*]}] \
  $BIN -s multicast
  #$BIN -t multicast_all_to_all_mc -b 512M -i 16 -c 1 -a reuse
set +x