#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

#SBATCH -p defq
#SBATCH --exclusive
#SBATCH --ntasks-per-node=1
#SBATCH -N 1
#SBATCH -o %u-ibutils-%N-%j.txt

export FULL_SWEEP=${FULL_SWEEP:-0}

nvsw_mgmt_ib_prefix=$(lspci | grep Infiniband.*ConnectX-7|cut -f1 -d'.'|sort|uniq -c|grep -w ' 4'|awk '{print $NF}')
ew_nics=($(lspci | grep Infiniband.*ConnectX|grep -v ${nvsw_mgmt_ib_prefix}|awk '{print $1}'|while read i; do ls -l /sys/class/infiniband|grep -o ${i}/.*|awk -F'/' '{print $NF}'; done))

if [ $FULL_SWEEP -eq 1 ]; then
  src_nics=(
    ${ew_nics[@]}
  )
else
  mid=$((${#ew_nics[@]}/2))
  src_nics=(
    ${ew_nics[0]}
    ${ew_nics[$mid]}
  )
fi
echo "[INFO] Testing begin:"
for i in ${src_nics[@]}; do
  for j in ${ew_nics[@]}; do
    if [ $i != $j ]; then
      inode=$(cat /sys/class/infiniband/${i}/device/numa_node)
      jnode=$(cat /sys/class/infiniband/${j}/device/numa_node)
      pkill -9 ib_write_bw &> /dev/null
      numactl -N $inode -m $inode ib_write_bw -d $i -F --report_gbits --qp 8 -b &> /dev/null &
      sleep 1
      ret=$(timeout 120 numactl -N $jnode -m $jnode ib_write_bw -d $j -F --report_gbits --qp 8 -b localhost 2>&1 | grep 65536 | awk '{print $4}')
      [ -z "$ret" ] && ret="N/A"
      echo "Testing $i <-> $j: $ret"
    fi
  done
done
echo "[INFO] Testing completed."
