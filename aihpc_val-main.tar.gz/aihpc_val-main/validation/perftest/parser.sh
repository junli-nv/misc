#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

log_files=($@)

log_parser(){
  file=$1
  awk '/<->/{print $NF}' $file \
    | awk -v fname=$file '
BEGIN{ct=0; ts=0; ti=99999; tx=0;}
{ct+=1; tv[ct]=$1; ts+=$1; ti=ti<$1?ti:$1; tx=tx>$1?tx:$1;}
END{
  if(ct>0){
    t_mean=ts/ct
    t_var=0
    for (i = 1; i <= ct; i++) t_var += (tv[i] - t_mean)^2
    t_std = (ct > 1 ? sqrt(t_var / (ct - 1)) : 0)
    t_cv = (t_mean != 0 ? t_std / t_mean : 0)
    printf "%50s: BW[GB/s]=%.2f BWstd=%.2f BWCV=%.2f%% BWmin=%.2f BWmax=%.2f\n", fname, ts/ct, t_std, t_cv*100, ti, tx
  }
}
'
}

plot_file(){
  file=$1
  echo $file
  awk '/<->/{print $NF}' $file \
    | gnuplot -e "set term dumb size 300,50; set yrange [0:]; plot '-' with linespoints" 2>/dev/null
}

echo "==========Performance============"
for i in ${log_files[@]}; do
  log_parser $i
  #plot_file $i
done