#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

#SBATCH -p defq
#SBATCH --exclusive
#SBATCH --ntasks-per-node=8
#SBATCH -N 1
#SBATCH -o %u-ibutils_gpu-%N-%j.txt

## Define the affinity: NIC<->CPU<->NUMA<->GPU
declare -a hca_name
hca_name=(
###################### B300 ######################
#Follow the "nvidia-smi topo -m" output to set the correct core, UCX_NET_DEVICES and CUDA_VISIBLE_DEVICES
#Bypass the 1st core leaving for OS.
#
###INDEX=HCA_NAME,GPU
  [0]="rdma_0,0"
  [1]="rdma_1,1"
  [2]="rdma_2,2"
  [3]="rdma_3,3"
  [4]="rdma_4,4"
  [5]="rdma_5,5"
  [6]="rdma_6,6"
  [7]="rdma_7,7"
)

export FULL_SWEEP=${FULL_SWEEP:-0}

nvsw_mgmt_ib_prefix=$(lspci | grep Infiniband.*ConnectX-7|cut -f1 -d'.'|sort|uniq -c|grep -w ' 4'|awk '{print $NF}')
ew_nics=($(lspci | grep Infiniband.*ConnectX|grep -v ${nvsw_mgmt_ib_prefix}|awk '{print $1}'|while read i; do ls -l /sys/class/infiniband|grep -o ${i}/.*|awk -F'/' '{print $NF}'; done))

if [ $FULL_SWEEP -eq 1 ]; then
  src_nics=(
    ${ew_nics[@]}
  )
else
  mid=$((${#ew_nics[@]}/2))
  src_nics=(
    ${ew_nics[0]}
    ${ew_nics[$mid]}
  )
fi
echo "[INFO] Testing begin:"
for i in ${src_nics[@]}; do
  for j in ${ew_nics[@]}; do
    if [ $i != $j ]; then
      inode=$(cat /sys/class/infiniband/${i}/device/numa_node)
      jnode=$(cat /sys/class/infiniband/${j}/device/numa_node)
      i_gid=$(echo ${hca_name[@]} |tr ' ' '\n'| grep ${i}, | cut -f2 -d',')
      j_gid=$(echo ${hca_name[@]} |tr ' ' '\n'| grep ${j}, | cut -f2 -d',')
      pkill -9 ib_write_bw &> /dev/null
      numactl -N $inode -m $inode ib_write_bw -d $i -F --report_gbits --qp 8 -b --use_cuda=${i_gid} --use_cuda_dmabuf &> /dev/null &
      sleep 1
      ret=$(timeout 120 numactl -N $jnode -m $jnode ib_write_bw -d $j -F --report_gbits --qp 8 -b localhost --use_cuda=${j_gid} --use_cuda_dmabuf 2>&1 | grep 65536 | awk '{print $4}')
      [ -z "$ret" ] && ret="N/A"
      echo "Testing ${i}[G${i_gid}] <-> ${j}[G${j_gid}]: $ret"
    fi
  done
done
echo "[INFO] Testing completed."
