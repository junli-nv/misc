#!/bin/bash
nodelist=${nodelist:-1}
scontrol show hostname $nodelist | xargs -I {} sbatch -N 1 -w {} -o root-perftest-DEBUG-1N-%N-%j.txt ./ibutils_gpu.sh
# grep 'N/A' *.txt
