#!/bin/bash

# https://docs.nvidia.com/multi-node-nvlink-systems/grace-blackwell-cx8-gpudirect-rdma-guide/gpudirect_rdma_testing.html#using-nic-virtual-function-and-enabling-data-direct-feature

### 1. Install doca_mgmt_data_direct
if [ ! -f /usr/local/bin/doca_mgmt_data_direct ]; then
  apt install -y doca-samples libdoca-sdk-mgmt-dev libdoca-sdk-argp-dev
  cd /opt/mellanox/doca/samples/doca_mgmt/mgmt_data_direct
  meson setup build
  meson compile -C build
  install -m 755 \
    /opt/mellanox/doca/samples/doca_mgmt/mgmt_data_direct/build/doca_mgmt_data_direct \
    /usr/local/bin/doca_mgmt_data_direct
fi

### 2. Unbind the VF from the driver
# lspci | grep -i Ethernet | grep 'mlx5Gen Virtual Function'
# 0000:03:00.2 Ethernet controller: Mellanox Technologies ConnectX Family mlx5Gen Virtual Function
# 0002:03:00.2 Ethernet controller: Mellanox Technologies ConnectX Family mlx5Gen Virtual Function
# 0010:03:00.2 Ethernet controller: Mellanox Technologies ConnectX Family mlx5Gen Virtual Function
# 0012:03:00.2 Ethernet controller: Mellanox Technologies ConnectX Family mlx5Gen Virtual Function
vfs=($(lspci | grep -i Ethernet | grep 'mlx5Gen Virtual Function' | awk '{print $1}'))
echo ${vfs[@]}
for i in ${vfs[@]}; do
  set -x
  echo ${i} | tee /sys/bus/pci/devices/${i}/driver/unbind
  set +x
done
sleep 3

### 3. set data-direct on the VFs(expected: Data direct: ENABLED)
for i in ${vfs[@]}; do
  set -x
  doca_mgmt_data_direct set --rep pci/${i%%.*}.0,pf0vf0 --enabled true
  set +x
done
sleep 1

### 4. Check data-direct on the VFs(expected: Data direct: ENABLED)
for i in ${vfs[@]}; do
  set -x
  doca_mgmt_data_direct get --rep pci/${i%%.*}.0,pf0vf0
  set +x
done
sleep 1

### 5. Bind the VFs to the driver
for i in ${vfs[@]}; do
  set -x
  echo ${i} | tee /sys/bus/pci/drivers/mlx5_core/bind
  set +x
done
sleep 5

### 6. Check VFs readiness(expected: vfs are up and active from rdma link output)
for i in ${vfs[@]}; do
  ls -l /sys/class/infiniband | grep ${i}
  rdma link | grep $(ls -l /sys/class/infiniband | grep -o ${i}/.* | awk -F'/' '{print $NF}')
done

### 7. Use the VFs for RDMA workloads(info: match the rdma nics and gpus shown in 'rdma_topo topo; nvidia-smi')
# numactl -N 0 -m 0 ib_write_bw -d roce_vf_r0 -F --report_gbits --run_infinitely --use_cuda_bus_id=0009:06:00.0 --use_cuda_dmabuf --use_data_direct 
# numactl -N 0 -m 0 ib_write_bw -d roce_vf_r1 -F --report_gbits --run_infinitely --use_cuda_bus_id=0008:06:00.0 --use_cuda_dmabuf --use_data_direct 
# numactl -N 1 -m 1 ib_write_bw -d roce_vf_r2 -F --report_gbits --run_infinitely --use_cuda_bus_id=0019:06:00.0 --use_cuda_dmabuf --use_data_direct 
# numactl -N 1 -m 1 ib_write_bw -d roce_vf_r3 -F --report_gbits --run_infinitely --use_cuda_bus_id=0018:06:00.0 --use_cuda_dmabuf --use_data_direct 
