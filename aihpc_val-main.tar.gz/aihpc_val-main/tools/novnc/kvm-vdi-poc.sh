#https://www.supermicro.com/en/support/resources/downloadcenter/smsdownload

############################
#Stress tests

wget http://10.238.149.126/ftp/docker-ce/img/ubuntu20.04.tar.gz -O -|docker load

#docker run --rm -ti --add-host node1:10.238.149.126 ubuntu:20.04 /bin/bash

cat > stress.dockerfile <<- 'EOF'
FROM ubuntu:20.04 AS builder
MAINTAINER JunLi Zhang<junli.zhang@intel.com>

RUN \
  echo '#' > /etc/apt/sources.list && \
  echo 'deb [arch=amd64] http://node1/ftp/os/ubuntu/20.04/ubuntu focal           main multiverse restricted universe' >> /etc/apt/sources.list && \
  echo 'deb [arch=amd64] http://node1/ftp/os/ubuntu/20.04/ubuntu focal-updates   main multiverse restricted universe' >> /etc/apt/sources.list && \
  echo 'deb [arch=amd64] http://node1/ftp/os/ubuntu/20.04/ubuntu focal-security  main multiverse restricted universe' >> /etc/apt/sources.list && \
  echo 'deb [arch=amd64] http://node1/ftp/os/ubuntu/20.04/ubuntu focal-proposed  main multiverse restricted universe' >> /etc/apt/sources.list && \
  echo 'deb [arch=amd64] http://node1/ftp/os/ubuntu/20.04/ubuntu focal-backports main multiverse restricted universe' >> /etc/apt/sources.list

ENV DEBIAN_FRONTEND=noninteractive

RUN \
  echo 'deb [trusted=yes arch=amd64] http://node1/ftp/gpu/repos/oneapi/ubuntu/2202.3 ./' > /etc/apt/sources.list.d/oneapi.list && \
  apt-get update -y && \
  apt-get install -y wget \
    make gcc g++ intel-oneapi-mkl-devel intel-oneapi-compiler-dpcpp-cpp cmake git && \
  apt-get clean all && \
  rm -rf /var/lib/apt/lists/

RUN \
  echo 'deb [trusted=yes arch=amd64] http://node1/ftp/gpu/public/ubuntu20.04/ubuntu focal main' > /etc/apt/sources.list.d/intel-media.list && \
  apt-get update -y && \
  apt-get install -y -q --no-install-recommends \
    ocl-icd-opencl-dev ocl-icd-libopencl1 intel-opencl-icd \
    intel-level-zero-gpu level-zero level-zero-dev \
    wget curl && \
  apt-get clean all && \
  rm -rf /var/lib/apt/lists/

RUN \
  wget http://node1/ftp/gpu/tools/stress.tar.gz -O - | tar -xzf -  && \
  . /opt/intel/oneapi/setvars.sh && \
  cd stress/stream-gpu && \
  make && \
  cd ../gemm-gpu && \
  make

RUN \
  wget http://10.238.149.126/ftp/gpu/tools/oneDNN.tar.gz -O - | tar -xzf -  && \
  . /opt/intel/oneapi/setvars.sh && \
  cd oneDNN && \
  chown -R root:root /oneDNN && \
  git checkout v3.0.1 && \
  mkdir -p build && \
  cd build && \
  CC=icx CXX=icpx \
  cmake -DCMAKE_INSTALL_PREFIX=/opt/oneDNN \
    -DDNNL_BLAS_VENDOR=MKL \
    -DDNNL_GPU_RUNTIME=OCL \
    -DDNNL_CPU_RUNTIME=TBB \
    -DONEDNN_BUILD_GRAPH=OFF \
    -LH .. && \
  make -j`nproc` benchdnn && \
  mv tests/benchdnn/benchdnn ../benchdnn.ocl && \
  mv src/libdnnl.so.3.0 ../libdnnl.so.3.0.ocl && \
  rm -rf * && \
  CC=icx CXX=icpx \
  cmake -DCMAKE_INSTALL_PREFIX=/opt/oneDNN \
    -DDNNL_BLAS_VENDOR=MKL \
    -DDNNL_GPU_RUNTIME=SYCL \
    -DDNNL_CPU_RUNTIME=TBB \
    -DONEDNN_BUILD_GRAPH=OFF \
    -LH .. && \
  make -j`nproc` benchdnn && \
  mv tests/benchdnn/benchdnn ../benchdnn.sycl && \
  mv src/libdnnl.so.3.0 ../libdnnl.so.3.0.sycl && \
  rm -rf *

FROM ubuntu:20.04
MAINTAINER JunLi Zhang<junli.zhang@intel.com>

RUN \
  echo '#' > /etc/apt/sources.list && \
  echo 'deb [arch=amd64] http://node1/ftp/os/ubuntu/20.04/ubuntu focal           main multiverse restricted universe' >> /etc/apt/sources.list && \
  echo 'deb [arch=amd64] http://node1/ftp/os/ubuntu/20.04/ubuntu focal-updates   main multiverse restricted universe' >> /etc/apt/sources.list && \
  echo 'deb [arch=amd64] http://node1/ftp/os/ubuntu/20.04/ubuntu focal-security  main multiverse restricted universe' >> /etc/apt/sources.list && \
  echo 'deb [arch=amd64] http://node1/ftp/os/ubuntu/20.04/ubuntu focal-proposed  main multiverse restricted universe' >> /etc/apt/sources.list && \
  echo 'deb [arch=amd64] http://node1/ftp/os/ubuntu/20.04/ubuntu focal-backports main multiverse restricted universe' >> /etc/apt/sources.list

ENV DEBIAN_FRONTEND=noninteractive

RUN \
  echo 'deb [trusted=yes arch=amd64] http://node1/ftp/gpu/public/ubuntu20.04/ubuntu focal main' > /etc/apt/sources.list.d/intel-media.list && \
  apt-get update -y && \
  apt-get install -y -q --no-install-recommends \
    ocl-icd-opencl-dev ocl-icd-libopencl1 intel-opencl-icd \
    intel-level-zero-gpu level-zero level-zero-dev \
    wget curl && \
  apt-get clean all && \
  rm -rf /var/lib/apt/lists/ && \
  wget http://node1//ftp/gpu/tools/clinfo/clinfo/clinfo -O /usr/bin/clinfo && \
  wget http://node1//ftp/gpu/tools/clpeak/clpeak/build/clpeak -O /usr/bin/clpeak && \
  chmod +x /usr/bin/clinfo /usr/bin/clpeak

RUN \
  echo 'deb [trusted=yes arch=amd64] http://node1/ftp/gpu/repos/oneapi/ubuntu/2202.3 ./' > /etc/apt/sources.list.d/oneapi.list && \
  apt-get update -y && \
  apt-get install -y wget intel-oneapi-runtime-mkl && \
  apt-get clean all && \
  rm -rf /var/lib/apt/lists/

RUN \
  echo 'while :; do clpeak -p 0 -d 0 --compute-sp; sleep 60; done' > /usr/bin/bench-clpeak.sh && \
  echo 'while :; do SYCL_DEVICE_FILTER=opencl:gpu ZE_AFFINITY_MASK=0 sgemm.mkl -s 20480 -l 500; sleep 300; done' > /usr/bin/bench-sgemm.sh && \
  echo 'while :; do SYCL_DEVICE_FILTER=opencl:gpu ZE_AFFINITY_MASK=0 dgemm.mkl -s 20480 -l 500; sleep 300; done' > /usr/bin/bench-dgemm.sh && \
  echo 'while :; do OverrideDefaultFP64Settings=1 IGC_EnableDPEmulation=1 SYCL_DEVICE_FILTER=opencl:gpu ZE_AFFINITY_MASK=0 stream_sycl.bin; ; sleep 60; done' > /usr/bin/bench-stream.sh && \
  chmod a+x /usr/bin/*

COPY --from=builder /stress/gemm-gpu/sgemm.mkl /usr/bin/sgemm.mkl
COPY --from=builder /stress/gemm-gpu/dgemm.mkl /usr/bin/dgemm.mkl
COPY --from=builder /stress/stream-gpu/stream_sycl.bin /usr/bin/stream_sycl.bin
COPY --from=builder /oneDNN/benchdnn.ocl /usr/bin/benchdnn.ocl
COPY --from=builder /oneDNN/benchdnn.sycl /usr/bin/benchdnn.sycl
COPY --from=builder /oneDNN/libdnnl.so.3.0.ocl /lib/x86_64-linux-gnu/libdnnl.so.3.0.ocl
COPY --from=builder /oneDNN/libdnnl.so.3.0.sycl /lib/x86_64-linux-gnu/libdnnl.so.3.0.sycl

RUN \
  echo '#!/bin/bash\n\
export COMMON="--matmul --engine=gpu --mode=po --perf-template=%Gflops%"\n\
rm -f /lib/x86_64-linux-gnu/libdnnl.so.3\n\
ln -s /lib/x86_64-linux-gnu/libdnnl.so.3.0.ocl /lib/x86_64-linux-gnu/libdnnl.so.3\n\
echo "OCL SGEMM: $(benchdnn.ocl $COMMON --cfg=f32 8192x8192:8192x8192)"\n\
echo "OCL BGEMM-packed data: $(benchdnn.ocl $COMMON --cfg=bf16bf16bf16 8192x8192:8192x8192)"\n\
echo "OCL BGEMM=unpacked data: $(benchdnn.ocl $COMMON --cfg=bf16bf16bf16 --wtag=ab --stag=ab --dtag=ab 8192x8192:8192x8192)"\n\
echo "OCL IGEMM-packed data: $(benchdnn.ocl $COMMON --cfg=s8s8s8 8192x8192:8192x8192)"\n\
echo "OCL IGEMM-unpacked data: $(benchdnn.ocl $COMMON --cfg=s8s8s8 --wtag=ab --stag=ab --dtag=ab 8192x8192:8192x8192)"\n\
rm -f /lib/x86_64-linux-gnu/libdnnl.so.3\n\
ln -s /lib/x86_64-linux-gnu/libdnnl.so.3.0.sycl /lib/x86_64-linux-gnu/libdnnl.so.3\n\
echo "SYCL SGEMM: $(benchdnn.sycl $COMMON --cfg=f32 8192x8192:8192x8192)"\n\
echo "SYCL BGEMM-packed data: $(benchdnn.sycl $COMMON --cfg=bf16bf16bf16 8192x8192:8192x8192)"\n\
echo "SYCL BGEMM=unpacked data: $(benchdnn.sycl $COMMON --cfg=bf16bf16bf16 --wtag=ab --stag=ab --dtag=ab 8192x8192:8192x8192)"\n\
echo "SYCL IGEMM-packed data: $(benchdnn.sycl $COMMON --cfg=s8s8s8 8192x8192:8192x8192)"\n\
echo "SYCL IGEMM-unpacked data: $(benchdnn.sycl $COMMON --cfg=s8s8s8 --wtag=ab --stag=ab --dtag=ab 8192x8192:8192x8192)"\n\
' > /usr/bin/bench-dnn.sh && \
  chmod a+x /usr/bin/*

#CMD ["/usr/bin/bash", "/usr/bin/bench.sh"]
CMD ["/usr/bin/bash"]
EOF

docker build --add-host node1:10.238.149.126 -f stress.dockerfile -t stress .

docker run --rm -ti --add-host node1:10.238.149.126 -v $PWD:/mnt -w /mnt --cpuset-cpus 8-14 --cpuset-mems 0 --device=/dev/dri/renderD129 stress /bin/bash /usr/bin/bench-dnn.sh

cat > bench.sh <<- 'EOF'
#!/bin/bash

start(){
  for gpu in /dev/dri/renderD*
  do
    docker run --name stress-${gpu##*/} -d --device=${gpu} stress /bin/bash /usr/bin/bench-sgemm.sh
  done
}

resume(){
  docker ps -a|grep stress-|awk '{print $NF}'|while read i
  do
     docker start $i
  done
}

stop(){
  docker ps -a|grep stress-|awk '{print $NF}'|while read i
  do
    docker stop $i &>/dev/null &
  done
  docker wait $(docker ps -a|grep stress-|awk '{print $NF}')
  echo All containers have been stopped
}

status(){
  docker ps -a|grep stress-
}

perf(){
  docker ps -a|grep stress-|awk '{print $NF}'|while read i; do echo $i $(docker logs $i 2>&1|grep 'SGEMM performance'|awk 'BEGIN{sum=0;}{sum+=$(NF-1);}END{print NR, int(sum/NR)}'); done
}

prune(){
  docker ps -a|grep stress-|awk '{print $NF}'|xargs -I {} docker rm -f {}
}

util(){
  ipmitool -I open sensor 2>&1|grep -E 'Watts|degrees'
}

show_help() {
  echo "Usage: `basename $0` {start|stop|resume|status|util|perf|prune}"
}

if [ $# -ne 1 ]; then
  show_help
  exit 1
fi
cmd=$1
case "${cmd}" in
  start)
    start
    ;;
  resume)
    resume
    ;;
  stop)
    stop
    ;;
  status)
    status
    ;;
  util)
    util
    ;;
  perf)
    perf
    ;;
  prune)
    prune
    ;;
  *)
    show_help
    exit 2
    ;;
esac
EOF

bash bench.sh prune
bash bench.sh start
bash bench.sh status
bash bench.sh util
bash bench.sh perf
bash bench.sh stop
bash bench.sh resume

############################

wget http://10.238.149.126/ftp/img/u2204-uefi.img.gz -O - | gunzip | dd of=/dev/sda bs=1M oflag=direct status=progress

efibootmgr -c -w -L "ubuntu22.04" -d /dev/sda -p 1 -l \\EFI\\ubuntu\\grubx64.efi

nmcli connection add con-name eno1 ifname eno2 type ethernet ip4 10.54.128.122/24 gw4 10.54.128.1 ipv4.dns "10.248.2.1 10.22.224.196 172.25.162.23"

systemctl disable ufw
systemctl stop ufw

#Disable poor Ethernet card
cat > /etc/rc.local <<- 'EOF'
#!/bin/bash
echo 1  > /sys/bus/pci/devices/0000:17:00.0/remove
echo 1  > /sys/bus/pci/devices/0000:17:00.1/remove
modprobe -r i40e
EOF
chmod +x /etc/rc.local 

wget http://node1/ftp/frp/frp_0.36.2_linux_amd64.tar.gz -O - | tar -xzvf - -C /tmp
cp /tmp/frp_0.36.2_linux_amd64/systemd/{frpc.service,frps.service} /lib/systemd/system/
systemctl daemon-reload
cp /tmp/frp_0.36.2_linux_amd64/{frpc,frps} /usr/bin/
chmod a+rx /usr/bin/{frpc,frps}
mkdir -p /etc/frp/
cat > /etc/frp/frps.ini <<- EOF
[common]
bind_addr = 0.0.0.0
bind_port = 17000
dashboard_port = 17001
bind_udp_port = 17002
dashboard_user = root
dashboard_pwd = root@123
max_pool_count = 50
token = intel@123
log_file = /var/tmp/frps.log
log_level = info
log_max_days = 3
EOF
systemctl enable --now frps
systemctl enable --now frpc

#Create VFs
cd /var/lib/libvirt/images/vgpu_profiles-2.7/
lspci -D|grep Display|awk '{print $1}'|grep 0\.0$|while read i
do
  GPU=$(ls -l /sys/class/drm|grep $i|grep -o /card.*|tr -d '/')
  echo 0 > /sys/class/drm/${GPU}/iov/pf/device/sriov_numvfs
  for i in /sys/class/drm/${GPU}/iov/vf*
  do
    echo 0 > $i/gt/doorbells_quota
    echo 0 > $i/gt/contexts_quota
    echo 0 > $i/gt/ggtt_quota
    echo 0 > $i/gt/lmem_quota
    echo 0 > $i/gt/exec_quantum_ms
    echo 0 > $i/gt/preempt_timeout_us
  done
  sleep 3
  ./vgpu_profiles.sh -cp ${GPU} -vp V1
done
grep . /sys/class/drm/card*/iov/vf1/gt/lmem_quota

cd /var/lib/libvirt/images/bench
cat > win-template.xml <<- EOF
<domain type='kvm' >
  <name>__VNAME__</name>
  <memory unit='GiB'>__VMEM__</memory>
  <currentMemory unit='GiB'>__VMEM__</currentMemory>
  <vcpu placement='static'>__VCPU__</vcpu>
  <iothreads>1</iothreads>
  <resource>
    <partition>/machine</partition>
  </resource>
  <os>
    <type arch='x86_64' machine='q35'>hvm</type>
  </os>
  <features>
    <acpi/>
    <apic/>
    <hyperv mode='custom'>
      <relaxed state='on'/>
      <vapic state='on'/>
      <spinlocks state='on' retries='8192'/>
      <vendor_id state='on' value='1234567890ab'/>
      <frequencies state='on'/>
    </hyperv>
    <kvm>
      <hidden state='off'/>
      <hint-dedicated state='on'/>
    </kvm>
  </features>
  <cpu mode='host-passthrough' check='none' migratable='off'/>
  <clock offset='localtime'>
    <timer name='hpet' present='no'/>
    <timer name='hypervclock' present='yes'/>
  </clock>
  <on_poweroff>destroy</on_poweroff>
  <on_reboot>restart</on_reboot>
  <on_crash>destroy</on_crash>
  <pm>
    <suspend-to-mem enabled='no'/>
    <suspend-to-disk enabled='no'/>
  </pm>
  <devices>
    <emulator>/usr/bin/qemu-system-x86_64</emulator>
    <disk type='file' device='disk'>
      <driver name='qemu' type='raw' cache='none' io='native' discard='unmap' iothread='1'/>
      <source file='__VDISK__'/>
      <target dev='vda' bus='virtio'/>
      <boot order='1'/>
    </disk>
    <controller type='pci' index='0' model='pcie-root'/>
    <interface type='network'>
      <source network='default'/>
      <model type='virtio'/>
    </interface>
    <serial type='pty'>
      <target type='isa-serial' port='0'>
        <model name='isa-serial'/>
      </target>
    </serial>
    <console type='pty'>
      <target type='serial' port='0'/>
    </console>
    <channel type='unix'>
      <target type='virtio' name='org.qemu.guest_agent.0'/>
      <address type='virtio-serial' controller='0' bus='0' port='1'/>
    </channel>
    <input type='tablet' bus='usb'>
      <address type='usb' bus='0' port='1'/>
    </input>
    <memballoon model='none'/>
  </devices>
</domain>
EOF

for id in {1..10}
do
  echo winvm${id}
  cp --reflink=always seed-ws2022.img winvm${id}.img
done

id=1; for gpu in $(lspci -D|grep Display|grep 0.1| awk '{print $1}')
do
  sed \
   -e "s:__VNAME__:winvm${id}:g" \
   -e "s:__VMEM__:16:g" \
   -e "s:__VCPU__:8:g" \
   -e "s:__VDISK__:/var/lib/libvirt/images/bench/winvm${id}.img:g" \
  win-template.xml > /var/lib/libvirt/images/bench/winvm${id}.xml
  virsh undefine --nvram winvm${id} 2>/dev/null
  virsh define winvm${id}.xml
  virt-xml winvm${id} --add-device --video model=qxl
  virt-xml winvm${id} --add-device --graphics vnc,listen=127.0.0.1,port=$[5900+$id]
  virt-xml winvm${id} --add-device --hostdev ${gpu},driver_name=vfio
  id=$[$id+1]
done

echo 3 > /proc/sys/vm/drop_caches
sysctl -w vm.nr_hugepages=$[10*16*1024/2]
numactl -H

## Tuning
## cat /proc/cmdline
#BOOT_IMAGE=/vmlinuz-5.15.0-48-generic root=/dev/mapper/ubuntu--vg-ubuntu--lv ro console=ttyS1,115200 console=tty0 drm.debug=0xe debug pci=realloc=off iommu=pt intel_iommu=on split_lock_detect=off nohpet pcie_ports=native pcie_port_pm=off transparent_hugepage=never numa_balancing=disable intel_pstate=disable pci=pcie_bus_perf i915.force_probe=* i915.enable_guc=7 i915.max_vfs=31 console=tty0 console=ttyS1,115200n8
## numactl -H
#available: 2 nodes (0-1)
#node 0 cpus: 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35
#node 0 size: 128560 MB
#node 0 free: 44411 MB
#node 1 cpus: 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59 60 61 62 63 64 65 66 67 68 69 70 71
#node 1 size: 129009 MB
#node 1 free: 45777 MB
## lspci -D | grep Display|awk '{print $1}'|while read i; do echo $i $(</sys/bus/pci/devices/$i/numa_node); done
#0000:51:00.0 0
#0000:56:00.0 0
#0000:59:00.0 0
#0000:5e:00.0 0
#0000:61:00.0 0
#0000:d0:00.0 1
#0000:d5:00.0 1
#0000:d8:00.0 1
#0000:dd:00.0 1
#0000:e0:00.0 1
## Leave 0 and 71 for iothread and emulator. Each VM has 7 physical cores, 16GB Hugepage backend memory, GPU/CPU/Mem with local affinities
j=1; for id in {1..10}
do
  m=$[id/6]
  c1=$[j]
  c2=$[j+6]
  [ $c2 -lt 36 ] && k=0 || k=71
  #echo $c1 $c2 $m $j $k
  virt-xml winvm${id} --edit --cpu host-passthrough
  virt-xml winvm${id} --edit --vcpus 7,maxvcpus=7,sockets=1,cores=7,threads=1
  virt-xml winvm${id} --edit --memory memory=$[16*1024],maxmemory=$[16*1024]
  virt-xml winvm${id} --edit --numatune clearxml=yes,nodeset=${m},mode=strict
  virt-xml winvm${id} --edit --memorybacking hugepages=on
  i=0; for c in $(seq $c1 $c2)
  do
    virsh vcpupin winvm${id} --vcpu $i --cpulist $c --config
    i=$[i+1]
  done
  virsh iothreadpin winvm${id} 1 "$k" --config
  virsh emulatorpin winvm${id} --cpulist "$k" --config
  j=$[j+7]
done

for id in {1..10}
do
  virsh start winvm${id}
  sleep 5
done

numastat -p qemu

for vmid in $(virsh list |grep winvm|awk '{print $2}')
do
  virsh domifaddr ${vmid}|grep ipv4
done

cat > /etc/frp/frpc.ini <<- EOF
[common]
server_addr = 0.0.0.0
server_port = 17000
token = intel@123
admin_addr = 127.0.0.1
admin_port = 7400
use_encryption = true
use_compression = true
EOF
for vmid in {1..10}
do
  echo winvm${vmid}
  IP=$(virsh domifaddr winvm${vmid}|grep ipv4|awk '{print $NF}'|cut -f1 -d'/')
  cat >> /etc/frp/frpc.ini <<- EOF

[winvm${vmid}-cs]
type = tcp
local_ip = 127.0.0.1
local_port = $[5900+$vmid]
remote_port = $[40000+$vmid]

[winvm${vmid}-vnc]
type = tcp
local_ip = ${IP}
local_port = 5900
remote_port = $[40100+$vmid]

[windows-wcg]
type = tcp
local_ip = ${IP}
local_port = 8096
remote_port = $[40200+$vmid]
EOF
done
systemctl restart frpc
netstat -lntp|grep frps

apt-get install -y pdsh sshpass dos2unix

ssh-keygen -t rsa -N '' -f $HOME/.ssh/id_rsa
cp $HOME/.ssh/id_rsa.pub $HOME/.ssh/authorized_keys
cat > $HOME/.ssh/config <<- EOF
Host *
  StrictHostKeyChecking no
  UserKnownHostsFile /dev/null
  LogLevel quiet
  CheckHostIP no
EOF
chmod 600 $HOME/.ssh/{authorized_keys,config,id_rsa}

for vmid in $(virsh list |grep winvm|awk '{print $2}')
do
  echo ${vmid}
  IP=$(virsh domifaddr ${vmid}|grep ipv4|awk '{print $NF}'|cut -f1 -d'/')
  sshpass -p intel@123 \
   scp -r $HOME/.ssh/ Administrator@${IP}:C:/Users/Administrator/
done


cat > bench-heaven.bat <<- 'EOF'
rem Run Heaven bechmark
@echo off
pushd %~dp0
mkdir %HOMEPATH%\Heaven\
del /s /q %HOMEPATH%\Heaven\
set i=3
:loop
set hdir="C:\Program Files (x86)\Unigine\Heaven Benchmark 4.0\"
cd %hdir%/bin
taskkill /F /im smartscreen.exe
taskkill /F /im AggregatorHost.exe
Heaven.exe ^
  -project_name Heaven ^
  -data_path ..\ ^
  -engine_config ..\data\heaven_4.0.cfg ^
  -system_script heaven/unigine.cpp ^
  -sound_app null ^
  -video_app direct3d11 ^
  -video_multisample 0 ^
  -video_mode -1 ^
  -video_height 1080 ^
  -video_width 1920 ^
  -extern_define ,RELEASE,LANGUAGE_EN,QUALITY_ULTRA,TESSELLATION_DISABLED,BENCHMARK
rem video_multisample(AA): 3=x8,2=x4,1=x2,0=off
rem Disable GPUMonitor by remove option -extern_plugin ,GPUMonitor
rem video_app: DirectX=direct3d11, DirectX12=direct3d12, OpenGL=opengl, Vulkan=vulkan, Direct9=direct3d9 
rem sound_app: null, openal
find "Score" %HOMEPATH%\Heaven\log.html >> %HOMEPATH%\Heaven\log.txt
del %HOMEPATH%\Heaven\log.html
timeout /t 5 /nobreak
set /a i-= 1
if %i% GTR 0 goto loop
rem C:\Apps\bench-heaven.bat
EOF
unix2dos bench-heaven.bat

cat > bench-superposition.bat <<- 'EOF'
@echo off
pushd %~dp0
cd C:\Program Files\Unigine\Superposition Benchmark\bin
del /f /q %HOMEPATH%\Superposition\log.txt
set i=3
:loop
taskkill /F /im smartscreen.exe
taskkill /F /im AggregatorHost.exe
.\superposition_cli.exe -xml .\pro_xml_samples\single_run_extreme.xml
find /I "score" "%HOMEPATH%\Superposition\automation\result_extreme.txt" >> %HOMEPATH%\Superposition\log.txt ^
  || echo Score: 0 >> %HOMEPATH%\Superposition\log.txt
del "%HOMEPATH%\Superposition\automation\result_extreme.txt"
timeout /t 5 /nobreak
set /a i-= 1
if %i% GTR 0 goto loop
rem C:\Apps\bench-superposition.bat
EOF
unix2dos bench-superposition.bat
printf 'FT9846HH16202HI2C8UA892BG' > license

cat > gpu-mon.ps1 <<- 'EOF'
# https://superuser.com/questions/1632758/how-to-get-gpu-usage-and-gpu-memory-info-of-a-process-by-powershell7?noredirect=1
# PS C:\Apps> Get-ExecutionPolicy -List
# PS C:\Apps> Set-ExecutionPolicy RemoteSigned
# PS C:\Apps> exit
function GPU-Mon {
  Write-Output "TimeStamp, GPU Engine Util(%), GPU Memory Used(MB)"
  #while(1){
    $GpuMemTotal = (((Get-Counter "\GPU Process Memory(*)\Local Usage").CounterSamples | where CookedValue).CookedValue | measure -sum).sum
    $GpuUseTotal = (((Get-Counter "\GPU Engine(*engtype_3D)\Utilization Percentage").CounterSamples | where CookedValue).CookedValue | measure -sum).sum
    $Timestamp = (Get-Date -Format "[yyyy-MM-dd HH:mm:ss]")
    Write-Output "$Timestamp, $([math]::Round($GpuUseTotal,2)), $([math]::Round($GpuMemTotal/1MB,2))"
    #Start-Sleep -s 2
  #}
}
GPU-Mon
EOF
unix2dos gpu-mon.ps1

for vmid in $(virsh list |grep winvm|awk '{print $2}')
do
  echo ${vmid}
  IP=$(virsh domifaddr ${vmid}|grep ipv4|awk '{print $NF}'|cut -f1 -d'/')
  ssh Administrator@${IP} md Superposition
  scp license Administrator@${IP}:C:/Users/Administrator/Superposition/license
  scp bench-heaven.bat bench-superposition.bat gpu-mon.ps1 MultiMonitorTool.exe Administrator@${IP}:C:/Apps/
done

IPS=$(echo $(for vmid in $(virsh list |grep winvm|awk '{print $2}'); do IP=$(virsh domifaddr ${vmid}|grep ipv4|awk '{print $NF}'|cut -f1 -d'/');   echo $IP; done)|tr ' ' ',')
pdsh -R ssh -l Administrator -w $IPS <<< 'sc query tvnserver|find "STATE"'
#interactive shell
pdsh -R ssh -l Administrator -w $IPS


wmic path win32_VideoController where "VideoProcessor LIKE '%Intel%'" get Caption,AdapterRAM,Status,VideoProcessor|find "Intel"

wmic path win32_VideoController where "Caption LIKE '%IddSampleDriver%'" get Caption,MaxRefreshRate,MinRefreshRate,PNPDeviceID,Status,VideoModeDescription

wmic datafile where name="C:\\windows\\system32\\mstsc.exe" get manufacturer, name, version

PowerShell -Command "& {Get-WmiObject win32_videocontroller | select Caption,DeviceID,DriverVersion,*RefreshRate,PNPDeviceID,AdapterRAM,Status,VideoModeDescription}"

#PowerShell -Command "& {Get-WmiObject win32_desktopmonitor}"

#PowerShell -Command "& {Get-WmiObject -Namespace 'root\WMI' -Class 'WMIMonitorID'}"

##Start notepad and use VNC connect to the VM to check whether the main display has change to IDD vdisplay or not

schtasks /create /F /SC ONCE /TN task_check_screens /TR "PowerShell -Command '& {Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.Screen]::AllScreens}' > %HOME%\screens.txt" /ST 00:00
schtasks /create /F /SC ONCE /TN task_check_monitors /TR "C:\Apps\MultiMonitorTool.exe /SaveConfig %HOME%\monitors.txt" /ST 00:00
schtasks /run /TN task_check_screens
schtasks /run /TN task_check_monitors
schtasks /delete /F /TN task_check_screens
schtasks /delete /F /TN task_check_monitors
type %HOME%\screens.txt
type %HOME%\monitors.txt

schtasks /create /F /SC ONCE /TN task_check_main_display /TR "notepad.exe" /ST 00:00
schtasks /run /TN task_check_main_display
tasklist|find /I "notepad.exe"
taskkill /f /im "notepad.exe"

dir /B "C:\Apps\bench-heaven.bat"
schtasks /create /F /SC ONCE /TN task_bench-heaven /TR "C:\Apps\bench-heaven.bat" /ST 00:00
taskkill /F /im smartscreen.exe
taskkill /F /im AggregatorHost.exe
schtasks /run /TN task_bench-heaven
tasklist|find /I "heaven"
type %HOMEPATH%\Heaven\log.txt
taskkill /f /im Heaven.exe

for d in {0..9}
do
  xpumcli dump -m 1,2,3,0,18,31,32,33,34 -n 3 -i 1 -d $d
done

#Each GPU's Util only 40%~50%, Total PW Consumption: 1800 Watts
for vmid in $(virsh list |grep winvm|awk '{print $2}')
do
  IP=$(virsh domifaddr ${vmid}|grep ipv4|awk '{print $NF}'|cut -f1 -d'/')
  echo "${vmid} $(ssh Administrator@$IP 'type %HOMEPATH%\Heaven\log.txt'|sed -e 's:<div class="m">::g' -e 's:&nbsp; &nbsp;::g' -e 's:<br/>: :g' -e 's:</div>::g'|grep Score|awk '{print int($NF)}'|tr '\r\n' ' ')"
done

### Without Tuning
# winvm1 2056  2132  2137
# winvm2 2054  2092  2083
# winvm3 2080  2005  2161
# winvm4 1903  2013  2222
# winvm5 2046  2117  2103
# winvm6 2093  2115  2116
# winvm7 2096  2351  2141
# winvm8 2127  2120  2089
# winvm9 2045  2067  2052
# winvm10 2189  2187  2183

### With Tuning - GPU >70% uilts, PW Consumption : ~2300 Watts, GPU 55 degrees
#ipmitool -I open sensor|grep -E 'Watts|degrees'
# winvm1 4336 4380 4371
# winvm2 4375 4391 4430
# winvm3 4332 4407 4385
# winvm4 4340 4290 4372
# winvm5 4284 4309 4327
# winvm6 4263 4344 4372
# winvm7 4350 4415 4393
# winvm8 4368 4368 4407
# winvm9 4351 4374 4393
# winvm10 4352 4367 4393

#Each GPU's Util only 70~90%, Total PW Consumption: 2280.000 Watts
schtasks /create /F /SC ONCE /TN task_bench-superposition /TR "C:\Apps\bench-superposition.bat" /ST 00:00
taskkill /F /im smartscreen.exe
taskkill /F /im AggregatorHost.exe
schtasks /run /TN task_bench-superposition
tasklist|find /I "superposition"
find /I "Benchmarking..." "%HOMEPATH%\Superposition\automation\result_extreme.txt"
type %HOMEPATH%\Superposition\log.txt

intel_gpu_top -d drm:/dev/dri/card2

for vmid in $(virsh list |grep winvm|awk '{print $2}')
do
  IP=$(virsh domifaddr ${vmid}|grep ipv4|awk '{print $NF}'|cut -f1 -d'/')
  echo "${vmid} $(ssh Administrator@$IP type '%HOMEPATH%\Superposition\log.txt'|grep Score|awk '{print int($NF)}'|tr '\r\n' ' ')"
done

### Without Tuning
# winvm1 5186 5268 5568
# winvm2 5499 5508 5291
# winvm3 5394 5276 5163
# winvm4 5553 6225 5539
# winvm5 5646 5769 5669
# winvm6 5444 4643 5358
# winvm7 5413 5235 5549
# winvm8 5507 4890 5768
# winvm9 5328 5233 5476
# winvm10 5717 5282 5613

### With Tuning - GPU >99% uilts, PW Consumption : 2552 Watts, GPU 60 degrees
#ipmitool -I open sensor|grep -E 'Watts|degrees'
# winvm1 7165 7138 7136
# winvm2 7137 7103 7103
# winvm3 7134 7101 7101
# winvm4 7278 7244 7244
# winvm5 7055 7055 7040
# winvm6 7093 7075 7070
# winvm7 7113 7075 7069
# winvm8 7244 7210 7209
# winvm9 6964 6960 6932
# winvm10 7173 7173 7152


## Stress test
cat > stress-superposition.bat <<- 'EOF'
@echo off
pushd %~dp0
cd C:\Program Files\Unigine\Superposition Benchmark\bin
del /f /q %HOMEPATH%\Superposition\log.txt
set i=1
:loop
taskkill /F /im smartscreen.exe
taskkill /F /im AggregatorHost.exe
.\superposition_cli.exe -xml .\pro_xml_samples\single_run_extreme.xml
find /I "score" "%HOMEPATH%\Superposition\automation\result_extreme.txt" >> %HOMEPATH%\Superposition\log.txt ^
  || echo Score: 0 >> %HOMEPATH%\Superposition\log.txt
del "%HOMEPATH%\Superposition\automation\result_extreme.txt"
timeout /t 30 /nobreak
set /a i+= 1
if %i% LEQ 1000 goto loop
EOF
unix2dos stress-superposition.bat
for vmid in $(virsh list |grep winvm|awk '{print $2}')
do
  echo ${vmid}
  IP=$(virsh domifaddr ${vmid}|grep ipv4|awk '{print $NF}'|cut -f1 -d'/')
  scp stress-superposition.bat Administrator@${IP}:C:/Apps/
done

pdsh -R ssh -l Administrator -w $IPS

wmic path win32_VideoController where "VideoProcessor LIKE '%Intel%'" get Caption,AdapterRAM,Status,VideoProcessor|find "Intel"

schtasks /create /F /SC ONCE /TN task_stress-superposition /TR "C:\Apps\stress-superposition.bat" /ST 00:00
schtasks /run /TN task_stress-superposition
tasklist|find /I "superposition"
type %HOMEPATH%\Superposition\log.txt
schtasks /end /TN task_stress-superposition
taskkill /f /im superposition.exe
schtasks /query /TN task_stress-superposition
schtasks /delete /TN task_stress-superposition

for vmid in $(virsh list |grep winvm|awk '{print $2}')
do
  IP=$(virsh domifaddr ${vmid}|grep ipv4|awk '{print $NF}'|cut -f1 -d'/')
  echo "${vmid} $(ssh Administrator@$IP type '%HOMEPATH%\Superposition\log.txt'|grep Score|awk '{print $NF}'|tr '\r\n' ' ')"
done | tee results.txt

echo 'VM   Loops Score(AVG)'
cat results.txt | while read line
do
  echo $line | awk 'BEGIN{sum=0;}{for(i = 2; i <= NF; i++) sum+=$i;}END{print $1,NF,int(sum/NF);}'
done

#VM   Loops Score(AVG)
#winvm1 474 7130
#winvm2 478 7097
#winvm3 476 7103
#winvm4 473 7243
#winvm5 479 7022
#winvm6 475 7069
#winvm7 478 7078
#winvm8 477 7206
#winvm9 476 6928
#winvm10 476 7135

## grep -i MHz /proc/cpuinfo |sort|uniq -c
#     67 cpu MHz         : 2401.000
#      1 cpu MHz         : 3099.999
#      2 cpu MHz         : 3100.000
#      2 cpu MHz         : 3100.001
## cpupower -c all frequency-info|grep 'current CPU frequency'|sort|uniq -c
#     72   current CPU frequency: 2.40 GHz (asserted by call to hardware)

## perf kvm stat live
#Analyze events for all VMs, all VCPUs:
#
#             VM-EXIT    Samples  Samples%     Time%    Min Time    Max Time         Avg time
#
#           MSR_WRITE      54421    42.33%     5.23%      0.62us  16529.94us     54.08us ( +-   5.07% )
#      IO_INSTRUCTION      38302    29.79%     6.39%      0.54us   8382.17us     93.84us ( +-   2.67% )
#                 HLT      32341    25.16%    88.15%      0.45us  18126.94us   1532.67us ( +-   1.09% )
#  EXTERNAL_INTERRUPT       2046     1.59%     0.10%      0.72us  11123.42us     26.79us ( +-  32.01% )
#   PAUSE_INSTRUCTION       1386     1.08%     0.12%      0.34us  13158.92us     49.74us ( +-  31.70% )
#               CPUID         29     0.02%     0.00%      0.34us      1.95us      0.61us ( +-  10.68% )
#       EPT_MISCONFIG         23     0.02%     0.00%      2.52us     85.09us      8.32us ( +-  42.56% )
#       EXCEPTION_NMI          4     0.00%     0.00%      7.15us     15.79us     10.46us ( +-  17.78% )
#