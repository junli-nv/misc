# Mon - Real-Time Cluster Monitoring Tools

Real-time monitoring tools for GPU, InfiniBand, and RoCE network performance on NVIDIA AIC cluster nodes.

## Tools

| Tool | Description |
|------|-------------|
| `gpumon` | GPU and InfiniBand monitoring |
| `ibmon/ibmon` | System resource monitoring framework (CPU, memory, IB, GPU) based on dool |
| `spxmon` | RoCE network quality monitoring (PFC, CNP, retransmissions) |

## gpumon

Comprehensive GPU and InfiniBand monitoring tool that captures NVIDIA GPU metrics via DCGMI alongside per-port IB throughput in a single view.

### Usage

```bash
./gpumon [delay]
```

- `delay` — sampling interval in seconds (default: 1)

### Metrics Collected

**GPU (via DCGMI):**
- SM clock, memory clock, GPU/memory temperature
- Power usage and limit
- GPU utilization (general, tensor INT/FP16/BF16/FP64/FP32, copy)
- Memory (free, used, total)
- NVLink bandwidth and error counters
- ECC single-bit and double-bit errors
- XID errors

**InfiniBand:**
- Per-adapter per-port receive/transmit throughput (MB/s)
- Auto-discovers all active IB adapters from `/sys/class/infiniband/`
- Supports both 32-bit and 64-bit port counters

### Output

Tab-separated columns with timestamp prefix. Header repeats every 10 iterations. Compatible with gnuplot for further visualization.

### Examples

```bash
# Monitor with default 1-second interval
./gpumon

# Monitor every 5 seconds and save to log file
./gpumon 5 | tee gpumon.log

# Filter output for a specific GPU (e.g., GPU_0) and plot utilization with gnuplot
cat gpumon.log | grep GPU_0 | grep -v TIMESTAMP | awk '{print $9}' | gnuplot -e "set term dumb size 300,50; set xtics 50; plot '-' with linespoints"
```

Sample output:
```
                TIMESTAMP  Id   Name       sm_clock memory_clock gpu_temp mem_temp power_limit power_usage gpu_util ... | mlx5_0:RMB mlx5_0:TMB mlx5_1:RMB mlx5_1:TMB
2026-04-22T10:30:01+00:00   0  GPU_0  NVIDIA_B200   2100        1593       45       42       1000         350       98  ... |    12500      12480      12300      12290
2026-04-22T10:30:01+00:00   1  GPU_1  NVIDIA_B200   2100        1593       46       43       1000         348       97  ... |
```

### Dependencies

- `dcgmi` (NVIDIA Data Center GPU Manager)

## ibmon

System and network monitoring framework combining CPU, memory, process, InfiniBand, and GPU metrics using the dool plugin system.

### Usage

```bash
./ibmon/ibmon
```

Sample output (ibmon):
```
----total-cpu-usage---- ------memory-usage----- -most-expensive- -most-expensive- --ib/mlx5_0:1-- --ib/mlx5_1:1-- ---nvidia-gpu--- ---nvidia-gpu-mem---- --nvidia-gpu-power--
usr sys idl wai stl| used  free  cach  avai| cpu process  | memory process |  recv  send |  recv  send | gpu0 gpu1 gpu2|  gpu0   gpu1   gpu2  |  gpu0  gpu1  gpu2
 45   3  52   0   0| 120G  780G   50G  830G| nccl-test 98| python   25.2G | 12.3G 12.1G | 12.0G 11.9G |  98%  97%  96%| 70.5G  70.5G  70.5G |  345W  342W  340W
```

## spxmon

RoCE (RDMA over Converged Ethernet) network quality monitoring. Tracks congestion, packet loss, and link health for SPX-connected nodes.

### Usage

```bash
./spxmon
```

Runs continuously with 5-second refresh interval via `watch`.

### Metrics Collected

| Metric | Description |
|--------|-------------|
| PFC rx/tx pause | Priority Flow Control pause frame counts |
| RoCE retransmissions | Adaptive routing retransmission count |
| CNP sent/handled | Congestion Notification Packets |
| Link down events | Link downed counter per port |

### Examples

```bash
# Run spxmon (refreshes every 5 seconds automatically)
./spxmon
```

Sample output:
```
mlx5_0,rx_prio3_pause:0,tx_prio3_pause:0,rx_prio3_discards:0,link_downed:0,roce_adp_retrans:0,np_cnp_sent:0,rp_cnp_handled:0
mlx5_1,rx_prio3_pause:0,tx_prio3_pause:0,rx_prio3_discards:0,link_downed:0,roce_adp_retrans:0,np_cnp_sent:0,rp_cnp_handled:0
mlx5_2,rx_prio3_pause:12,tx_prio3_pause:5,rx_prio3_discards:0,link_downed:0,roce_adp_retrans:3,np_cnp_sent:8,rp_cnp_handled:6
```

Non-zero values indicate:
- `rx/tx_prio3_pause` — PFC pause frames, sign of congestion on the lossless priority
- `rx_prio3_discards` — drops on the RoCE priority class
- `roce_adp_retrans` — RoCE adaptive retransmissions, indicates packet loss or path issues
- `np_cnp_sent` / `rp_cnp_handled` — congestion notification activity between endpoints

***The tools are written by Junli Zhang <junliz@nvidia.com> and this document maintained by Tina Wang <tinawang@nvidia.com>.***