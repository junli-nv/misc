# Nodetools - Multi-Vendor Node and Infrastructure Management

Remote management scripts for NVIDIA AIC cluster nodes and switches via IPMI, Redfish, and vendor-specific CLIs. Supports parallel execution across large node lists with consistent interfaces across heterogeneous hardware.
The scripts focus on monitoring power, temperature and fan. In the meantime, gather information for server deployment.

## Setup

### Inventory and Credentials

Before using nodetools, generate the required configuration files:

1. **`gen_hosts.sh`** - Generate `hosts.list` from BCM database (cmsh). Output format: `DeviceType Hostname BMC_IP`.
2. **`gen_passwd.sh`** - Generate `passwd.sh` with credentials for BMC, NVSwitch, InfiniBand switches, SPX switches, and power shelves.

### Hostlist Expressions

All scripts accept SLURM-style hostlist expressions for the `<nodelist>` argument, e.g.:

- `node01` - single node
- `node[01-10]` - range of nodes
- `node[01,03,05-08]` - mixed list

Hostlist expansion is handled by the bundled `python3-hostlist` library.

## Core Node Management

These scripts try to work across all OEM platforms via standard IPMI as much as possible.

| Script | Usage | Description |
|--------|-------|-------------|
| `nodepower` | `nodepower <nodelist> [status\|on\|off\|cycle\|reset]` | Power control via IPMI. Default: `status`. |
| `nodebmcreset` | `nodebmcreset <nodelist>` | BMC cold reset via IPMI. |
| `nodebmcinfo` | `nodebmcinfo <nodelist> [time]` | Query BMC info or set BMC system time. |
| `nodeconsole` | `nodeconsole <nodelist> [open\|close]` | Serial-over-LAN (SOL) console access. Opens SOL for first node only. |
| `nodeboot` | `nodeboot <nodelist> [pxe\|disk\|bios]` | Set next boot device. Default: `pxe`. |
| `nodeping` | `nodeping <nodelist>` | Check BMC network reachability via ICMP ping. |
| `nodelist` | `nodelist` | Display cluster inventory from hosts.list. |

## Diagnostics

| Script | Usage | Description |
|--------|-------|-------------|
| `nodeflapping` | `nodeflapping <nodelist>` | Network flapping test: BF3 mode verification, LLDP connectivity validation, 20k-packet ping with MTU test. |

## Switch Health Checks

| Script | Usage | Description |
|--------|-------|-------------|
| `ibswhc` | `ibswhc <nodelist>` | InfiniBand switch health: version, health status, RIP issues, environment (temp, PSU, fan). |
| `spxswhc` | `spxswhc <nodelist>` | SPX (SONiC) switch health: image version, health status, RIP issues, environment warnings. |

## OEM-Specific Tools (`oem/`)

Vendor-specific scripts extending the core functionality with Redfish, IPMI, or proprietary APIs. Each OEM directory contains a set of management scripts.

### NVIDIA DGX (`oem/dgx/`)

Redfish API-based management for DGX systems. 

| Script | Description |
|--------|-------------|
| `nodebootorder.dgx` | Display and manage boot order |
| `nodebios.dgx` | Query BIOS attributes via Redfish |
| `nodemacs.dgx` | Query OS/BMC MAC addresses and UEFI device paths |
| `nodefirmware` | Firmware versions |
| `nodefru.dgx` | Field replaceable unit information |
| `nodeinventory.dgx` | Firmware inventory |
| `nodeeventlog.dgx` | Query system and HGX baseboard event logs |
| `nodemon.dgx` | Real-time monitoring: power, voltage, temperature, fans |
| `nodefan.dgx` | Fan status and control |
| `nodepsu.dgx` | Power supply information |


### NVIDIA GB200 (`oem/gb200/`)

The most extensive OEM implementation. Redfish API-based management for GB200 compute trays. Function library: `func.sh`.

**Compute Node Management:**

| Script | Description |
|--------|-------------|
| `nodebios` | BIOS settings via Redfish |
| `nodemacs` | MAC addresses and UEFI device paths |
| `nodefru` | Field replaceable unit information |
| `nodeinventory` | Firmware inventory |
| `nodebootorder` | Boot order management |
| `nodenetboot` | Network boot setup |
| `nodetasks` | Query/debug Redfish async tasks |
| `nodereseat` | Physical reseat operation (AC power cycle) |
| `nodeAC` | AC power control |
| `nodebf3` | BlueField-3 NIC configuration |
| `nodemon` | Real-time monitoring: power, voltage, temperature, fans, leak detection |
| `nodeeventlog` | Query or clear BMC/HMC's event log entries |
| `nodefan` | Fan status/control (IPMI raw commands for auto/max modes) |
| `nodesensors` | Various sensor readings |


**GPU / Accelerator:**

| Script | Description |
|--------|-------------|
| `nodegpusn` | GPU serial numbers, UUIDs, and part numbers via OOB mode |
| `nodemon_nvlink` | NVLink bandwidth and error monitoring via OOB mode(RXBytes, TXBytes, LinkDownedCount, EffectiveError, SymbolErrors) |

**NVSwitch Management:**

| Script | Description |
|--------|-------------|
| `nvswhc` | NVSwitch health check: version, health, app status, link state, UPHY info, environment |
| `nvswsensors` | NVSwitch power and temperature sensors |
| `nvsweventlog` | NVSwitch event logs |
| `nvswinventory` | NVSwitch firmware inventory |

**Power Shelf:**

| Script | Description |
|--------|-------------|
| `pspower` | Power supply state monitoring |
| `psinventory` | Power shelf firmware versions |

### Dell PowerEdge (`oem/dell/`)

Uses Dell iDRAC Tools (`racadm`) with IPMI fallback. Installation script: `ins-racadm.sh`.

| Script | Description |
|--------|-------------|
| `nodebios.dell` | BIOS settings via racadm |
| `nodebootorder.dell` | Boot order configuration |
| `nodeipmi.dell` | Enable IPMI via iDRAC, IPMI is disabled by default |
| `nodemacs.dell` | MAC address information |
| `nodebf3.dell` | Change BF3 from DPU to NIC mode via OOB |
| `nodeinventory.dell` | Firmware inventory |
| `nodeuser.dell` | User account management |
| `nodefru.dell` | Field replaceable unit information |
| `nodenetboot.dell` | Network boot configuration |
| `nodeeventlog.dell` | Event log entries |
| `nodepsu.dell` | Change or query Power supply mode |
| `nodefan.dell` | Fan status via IPMI SDR |
| `nodemon.dell` | Monitoring: power, voltages, fans, temperatures |

### Supermicro (`oem/smc/`)

IPMI SDR and Redfish-based management. Installation script: `ins-saa.sh` (SuperServer Automation Assistant).

| Script | Description |
|--------|-------------|
| `nodebios.smc` | BIOS via Redfish |
| `nodeinventory.smc` | Firmware inventory |
| `nodemacs.smc` | MAC addresses |
| `nodebootorder.smc` | Boot order configuration |
| `nodefru.smc` | Field replaceable unit information |
| `nodemon.smc` | Monitoring via IPMI SDR (temperature, power supply, fans) |
| `nodeeventlog.smc` | Event logs |
| `nodefan.smc` | Fan status |

### AMI (`oem/ami/`)

Pure Redfish-based management for AMI BMC systems.

| Script | Description |
|--------|-------------|
| `nodebios.ami` | BIOS via Redfish (filters SETUP/MapIDlist/LAN/IPMI noise) |
| `nodeinventory.ami` | Firmware inventory |
| `nodemacs.ami` | MAC addresses |
| `nodebootorder.ami` | Boot order |
| `nodefru.ami` | Field replaceable unit information |
| `nodeeventlog.ami` | Event logs |
| `nodemon.ami` | Monitoring |
| `nodefan.ami` | Fan status |

### BYD (`oem/byd/`)

Redfish-based management with BYD-specific hardware support (including leak detection).

| Script | Description |
|--------|-------------|
| `nodebios.byd` | BIOS settings |
| `nodeinventory.byd` | Firmware inventory |
| `nodemacs.byd` | MAC addresses |
| `nodebootorder.byd` | Boot order |
| `nodefru.byd` | Field replaceable unit information |
| `nodeeventlog.byd` | Event logs |
| `nodemon.byd` | Monitoring including leak detector support |
| `nodefan.byd` | Fan status |

### Lenovo (`oem/lenovo/`)

Docker-based Confluent management platform. Setup script: `confluent.sh`.

Provides `nodepower`, `nodehealth`, `nodesensors`, `nodeeventlog`, `nodeboot`, and `nodeconsole` via the Confluent container.

Details of confluent can be found at [Lenovo website](https://hpc.lenovo.com/users/documentation/whatisconfluent.html).

## python3-hostlist/

Bundled Python library and CLI utilities for SLURM-style hostlist operations.

| Tool | Description |
|------|-------------|
| `hostlist` | Expand, collapse, intersect, diff, and manipulate hostlist expressions. |
| `pshbak` | Aggregate `host: output` lines, grouping identical or similar outputs across nodes. Supports diff display. |
| `hostgrep` | Hostlist-aware grep: search files using hostlist expressions as search terms. |
| `dbuck` | Data bucketing/histogram tool with hostlist-aware output for numerical data analysis. |

Details of python-hostlist can be found at [Kent's homepage](https://www.nsc.liu.se/~kent/python-hostlist/).


## Utilities

| File | Description |
|------|-------------|
| `redfish_walker.py` | Recursively traverse and print the Redfish API resource tree on a BMC. |

***The tools are written by Junli Zhang <junliz@nvidia.com> and this document maintained by Tina Wang <tinawang@nvidia.com>.***
