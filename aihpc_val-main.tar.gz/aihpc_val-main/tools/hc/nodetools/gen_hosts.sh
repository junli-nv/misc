#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

module load cmsh
rm -f hosts.list

cmsh -c 'device; foreach -t PhysicalNode ( get hostname; interfaces; list bmc)' > hosts.tmp
buffer=""; while read line; do
    if [[ $line == *"bmc"* ]]; then
        echo ${buffer} $line
        buffer=""
    else
        buffer="${buffer} $line"
    fi
done < hosts.tmp | awk '{print "PhysicalNode",$(NF-5),$(NF-2)}'|sort| tee hosts.list
rm -f hosts.tmp
#cmsh -c 'device; foreach -t PhysicalNode ( get hostname; interfaces; list bmc)' | paste - - | grep bmc| awk '{print "PhysicalNode",$1,$(NF-2)}' |sort| tee -a hosts.list

cmsh -c 'device; foreach -t Switch ( get hostname; interfaces; list bmc)' | paste - - | grep bmc| awk '{print "Switch",$1,$(NF-2)}' |sort| tee -a hosts.list

cmsh -c 'device; foreach -t PowerShelf ( get hostname; interfaces; list bmc)' | paste - - | grep bmc| awk '{print "PowerShelf",$1,$(NF-2)}' |sort| tee -a hosts.list
# cmsh -c 'device; foreach -t PowerShelf ( get hostname; interfaces; list physical)' | paste - - | grep eth0| awk '{print "PowerShelf",$1,$(NF-2)}' |sort| tee -a hosts.list

## IB switch
# Format: Switch IB-SW-HOSTNAME XXX.XXX.XXX.XXX 
# UFM(Managed Elements->Devices->CSV->AllData) -> Devices-YYYYMMDD.csv
# grep -i switch Devices-20260323.csv|cut -f2,4 -d' '|tr -d '"'|sort|dos2unix | tee -a hosts.list

## SPX switch info
# Format: Switch SPX-SW-HOSTNAME XXX.XXX.XXX.XXX
