#!/bin/bash

export new_username=nvis
export new_password=nvis@123

add_user(){
  bmc_ip=$1
  bmc_username=$2
  bmc_password=$3
  payload=$(
    jq -n \
      --arg username "${new_username}" \
      --arg password "${new_password}" \
      '{
        UserName: $username,
        Password: $password,
        RoleId: "Administrator",
        Enabled: true,
        AccountTypes: [
          "Redfish",
          "IPMI"
        ]
      }'
  )
  curl --fail-with-body -ik \
    -u "${bmc_username}:${bmc_password}" \
    -X POST \
    "https://${bmc_ip}/redfish/v1/AccountService/Accounts" \
    -H "Content-Type: application/json" \
    --data-raw "${payload}"
}

## Check if the BMC is reachable and the old user credentials are valid
while read -r bmc_ip bmc_username bmc_password; do
  echo ${bmc_ip} $(timeout 5 curl --fail-with-body -ik -s -u "${bmc_username}:${bmc_password}" "https://${bmc_ip}/redfish/v1/AccountService/Accounts" | grep HTTP || echo "Unreachable")
done < <(grep -v '^#' ./bmc.txt | awk '{print $1, $2, $3}') | tee ./check_old_user.log

## Add new user to BMC
while read -r bmc_ip bmc_username bmc_password; do
  echo add_user "${bmc_ip}" "${bmc_username}" "${bmc_password}"
  add_user "${bmc_ip}" "${bmc_username}" "${bmc_password}"
  echo
done < <(grep -v '^#' ./bmc.txt | awk '{print $1, $2, $3}') | tee ./add_user.log

## Check if the new user credentials are valid
while read -r bmc_ip; do
  echo ${bmc_ip} $(timeout 5 curl --fail-with-body -ik -s -u "${new_username}:${new_password}" "https://${bmc_ip}/redfish/v1/AccountService/Accounts" | grep HTTP || echo "Unreachable")
done < <(grep -v '^#' ./bmc.txt | awk '{print $1}') | tee ./check_new_user.log
