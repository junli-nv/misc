#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

## Export nfs volume on BCM server(E.g: 192.168.0.9, the ip can be reach by nodes BMC IPs)
echo '/var/www/html/isos/ *(ro,no_root_squash,async)' >> /etc/exports

## https://192.168.16.61/#/service/image-redirection
## Ctrl+Shift+I to open the developer tools, then click the Network tab to see the API calls.

server_ip=${1:-"192.168.0.9"}
nfs_path=${2:-"/var/www/html/isos"}

## Mount the remote media via NFS
payload=$(jq -n --arg host "${server_ip}" --arg path "${nfs_path}" '{Host:$host, Path:$path, Protocol:"NFS"}')
curl --fail-with-body -i -k \
  -u "${bmc_username}:${bmc_password}" \
  -X POST \
  "https://${bmc_ip}/redfish/v1/Managers/1/VMMService/RemoteMount" \
  -H "Content-Type: application/json" \
  --data-raw "${payload}"

## Check the remote media mount status
curl -s -k -u "${bmc_username}:${bmc_password}" \
https://${bmc_ip}/redfish/v1/Managers/1/VMMService | jq '.RemoteMount'

## Browse the remote media and check if the ISO image is available
curl --fail-with-body -i -k \
  -u "${bmc_username}:${bmc_password}" \
  "https://${bmc_ip}/redfish/v1/Managers/1/VMMService/BrowserRemoteFiles?\$filter=Path%20eq%20NFS"

## Connect to the remote media and insert the ISO image
payload=$(jq -n --arg path "NFS/ubuntu-24.04-live.iso" --arg type "File" '{ImagePath:$path, FileType:$type}')
curl --fail-with-body -i -k \
  -u "${bmc_username}:${bmc_password}" \
  -X POST \
  "https://${bmc_ip}/redfish/v1/Managers/1/VMMService/RemoteMediaInsert" \
  -H "Content-Type: application/json" \
  --data-raw "${payload}"

## Check the remote media mount status
curl -s -k -u "${bmc_username}:${bmc_password}" \
https://${bmc_ip}/redfish/v1/Managers/1/VMMService | jq '.VirtualMediaList[]?'

## Eject the remote media
payload=$(jq -n --arg path "NFS/ubuntu-24.04-live.iso" '{ImagePath:$path}')
curl --fail-with-body -i -k \
  -u "${bmc_username}:${bmc_password}" \
  -X POST \
  "https://${bmc_ip}/redfish/v1/Managers/1/VMMService/RemoteMediaEject" \
  -H "Content-Type: application/json" \
  --data-raw "${payload}"

## Umount the remote media
payload=$(jq -n --arg protocol "NFS" '{Protocol:$protocol}')
curl --fail-with-body -i -k \
  -u "${bmc_username}:${bmc_password}" \
  -X POST \
  "https://${bmc_ip}/redfish/v1/Managers/1/VMMService/RemoteUmount" \
  -H "Content-Type: application/json" \
  --data-raw "${payload}"
