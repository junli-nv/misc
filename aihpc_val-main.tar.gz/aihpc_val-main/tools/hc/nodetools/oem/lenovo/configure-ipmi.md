## Download OneCli

OneCli can be found at [Lenovo website](https://support.lenovo.com/us/en/solutions/lnvo-tcli)
```
wget -c https://download.lenovo.com/servers/mig/2026/03/03/64355/lnvgy_utl_lxce_onecli01v-5.5.0_linux_indiv.tgz
mkdir -p /home/cmsupport/workspace/onecli
tar -xzvf lnvgy_utl_lxce_onecli01v-5.5.0_linux_indiv.tgz -C /home/cmsupport/workspace/onecli
```

## Create BCM user

```
root@br-chl2-b300-tlv1-32:~# /home/cmsupport/workspace/onecli/onecli misc bmcuser create --username JUNLI --password p@55w0Rd4Junli --role admin
Succeed.

root@br-chl2-b300-tlv1-32:~# /home/cmsupport/workspace/onecli misc bmcuser list | grep JUNLI
    | 5             | JUNLI           | Administrator     | Enabled |
```

## Enable user's IPMI/Redfish access

```
root@br-chl2-b300-tlv1-32:~# /home/cmsupport/workspace/onecli misc bmcuser set --id 5 --username JUNLI --password p@55w0Rd4Junli --status enabled --accounttypes IPMI,Redfish,WebUI,ManagerConsole
Succeed.

root@br-chl2-b300-tlv1-32:~# ipmitool user list 1|grep -v false
ID  Name             Callin  Link Auth  IPMI Msg   Channel Priv Limit
5   bright           true    true       true       ADMINISTRATOR
6   JUNLI            true    true       true       ADMINISTRATOR

root@br-chl2-b300-tlv1-32:~# ipmitool lan print 1|grep IP\ Address
IP Address Source       : DHCP Address
IP Address              : 10.1.1.32
```

## Test IPMI/Redfish via OOB

```
root@br-master1:~# curl -s -k -u JUNLI:p@55w0Rd4Junli https://10.1.1.32/redfish/v1/Managers/1/NetworkProtocol|jq '.IPMI'
{
  "Port": 623,
  "ProtocolEnabled": true
}

root@br-master1:~# ipmitool -I lanplus -H 10.1.1.32 -U JUNLI -P p@55w0Rd4Junli power status
Chassis Power is on
```

## Apply the changes on multiple nodes
```
# NODELIST=br-chl2-b300-tlv1-[01-31,37-45,49,51-80,81-92,94-112,129-139,141-144,147-160]
pdsh -f 100 -R ssh -w ${NODELIST} <<- 'EOF'
/home/cmsupport/workspace/onecli/onecli misc bmcuser create --username JUNLI --password p@55w0Rd4Junli --role admin || true
/home/cmsupport/workspace/onecli/onecli misc bmcuser list | grep JUNLI || true
id=$(/home/cmsupport/workspace/onecli/onecli misc bmcuser list | grep JUNLI | awk '{print $2}'); [ ! -z ${id} ] && /home/cmsupport/workspace/onecli/onecli misc bmcuser set --id ${id} --username JUNLI --password p@55w0Rd4Junli --status enabled --accounttypes IPMI,Redfish,WebUI,ManagerConsole || true
ipmitool user list 1|grep JUNLI || true
EOF
```

## Via OOB way
```
/home/cmsupport/workspace/onecli/onecli misc bmcuser list -b Lenovo:Lenovo@1234@10.1.1.46
/home/cmsupport/workspace/onecli/onecli misc bmcuser create -b Lenovo:Lenovo@1234@10.1.1.46 --username JUNLI --password p@55w0Rd4Junli --role admin
id=$(/home/cmsupport/workspace/onecli/onecli misc bmcuser list -b Lenovo:Lenovo@1234@10.1.1.46 | grep JUNLI | awk '{print $2}'); [ ! -z ${id} ] && /home/cmsupport/workspace/onecli/onecli misc bmcuser set -b Lenovo:Lenovo@1234@10.1.1.46 --id ${id} --username JUNLI --password p@55w0Rd4Junli --status enabled --accounttypes IPMI,Redfish,WebUI,ManagerConsole
ipmitool -I lanplus -H 10.1.1.46 -U Lenovo -P Lenovo@1234 user list 1|grep JUNLI
```