#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

## Install Docker on x86 BCM head node
apt update
apt install -y docker.io
systemctl enable --now docker

### Build conflunet on x86 BCM head node
cat > confluent.dockerfile <<- 'EOF'
FROM rockylinux:9.3
MAINTAINER JunLi Zhang<junliz@nvidia.com>

RUN \
  echo -e '[lenovo-hpc]\nname=Lenovo packages for HPC\nbaseurl=https://hpc.lenovo.com/yum/latest/el9/x86_64/\nenabled=1\ngpgcheck=0' > /etc/yum.repos.d/lenovo-hpc.repo && \
  yum install -y https://dl.fedoraproject.org/pub/epel/epel-release-latest-9.noarch.rpm && \
  yum update -y && \
  yum install -y lenovo-confluent tftp-server openssh-clients openssl vim-enhanced iproute jq

RUN \
  echo -e '#!/bin/bash\nrm -f /var/run/confluent/pid /run/confluent/pid >& /dev/null\n/opt/confluent/bin/confluent -f' > /bin/runconfluent.sh

RUN \
  yum install -y procps ncurses iputils net-tools \
      pdsh pdsh-rcmd-ssh pdsh-mod-genders pdsh-mod-dshgroup pdsh-mod-netgroup \
      ipmitool

CMD ["/usr/sbin/init"]
EOF
docker build -f confluent.dockerfile -t confluent .
docker save confluent | pigz -c - > confluent.tar.gz

### Configure confluent
docker rm -f confluent
docker run -d -ti --privileged \
  --hostname confluent \
  --name confluent \
  confluent /usr/sbin/init
sleep 5
docker exec confluent systemctl start confluent
sleep 3
docker exec confluent systemctl status confluent

cd /home/cmsupport/workspace/aihpc_val/tools/hc/nodetools
bash gen_hosts.sh
docker cp $PWD/hosts.list confluent:/root/host-bmc.txt

### Configure - https://hpc.lenovo.com/users/documentation/
docker exec -ti confluent /bin/bash
nodegroupattrib everything console.logging=full console.method=ipmi
nodegroupattrib everything discovery.passwordrules="expiration=no,loginfailures=no,complexity=no,reuse=no"

nodegroupattrib everything -p bmcuser bmcpass #U:JUNLI P:p@55w0Rd4Junli

## Define nodes in confluent. host-bmc.txt be copied from BMC head node
nodelist | while read i; do noderemove $i; done
cat /root/host-bmc.txt | while read type hostname ip
do
  noderemove ${hostname} &>/dev/null
  nodedefine ${hostname}
  nodeattrib ${hostname} hardwaremanagement.manager=${ip} id.uuid=$(uuidgen)
done

## Query GB200 nodes status
docker exec -ti confluent /bin/bash

nodepower br-chl2-b300-tlv1-[01-32] status

nodehealth br-chl2-b300-tlv1-[01-32]

nodesensors br-chl2-b300-tlv1-[01-32] -c fans

nodesensors br-chl2-b300-tlv1-[01-32] -c power

nodesensors br-chl2-b300-tlv1-[01-32] -c temp

nodeeventlog br-chl2-b300-tlv1-[01-32]

nodeboot br-chl2-b300-tlv1-09 network

nodeconsole br-chl2-b300-tlv1-09 #Quit: ctrl+e -> c -> . 
