"""Regression tests for dispatch and lifecycle issues found during runtime review."""
import contextlib
import io
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from sol_tools import cli
from sol_tools.arguments import parser_for_tool, parser_for_batch, parse_operation
from sol_tools.session import Console

ROOT = Path(__file__).resolve().parent.parent


class RuntimeReviewTest(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        inventory = Path(temp.name) / 'inventory.ini'
        inventory.write_text('[all]\n192.0.2.1\n')
        default = patch('sol_tools.inventory.default_config_path', return_value=inventory)
        default.start()
        self.addCleanup(default.stop)

    def test_selector_only_operations_across_tools(self):
        for tool in ('exec', 'file', 'control'):
            for flag in ('--check-hosts', '--list-hosts'):
                with self.subTest(tool=tool, flag=flag):
                    args = parse_operation(parser_for_tool(tool), ['--hosts', '192.0.2.1', flag])
                    self.assertEqual(args.explicit_options, {'hosts', flag[2:].replace('-', '_')})
                    with patch.object(sys, 'argv', [f'sol_{tool}.py', '--hosts', '192.0.2.1', flag]), \
                            patch('sol_tools.batch.ping_host', return_value=(True, '')) as ping, \
                            patch('sol_tools.batch.prompt_credential') as prompt, \
                            contextlib.redirect_stdout(io.StringIO()) as output:
                        self.assertEqual(cli.main(tool), 0)
                        self.assertIn('192.0.2.1', output.getvalue())
                        self.assertEqual(ping.call_count, int(flag == '--check-hosts'))
                        prompt.assert_not_called()

    def test_flag_operations_without_positional_action(self):
        for words in (['--power', 'status'], ['--bmc-log', 'info'],
                      ['--bootdev', 'pxe'], ['--console'], ['--interactive'],
                      ['--replay', 'log.jsonl']):
            with self.subTest(words=words):
                args = parse_operation(parser_for_tool('control'), words)
                self.assertIsNone(args.action)
                self.assertNotIn('action', args.explicit_options)
        args = parse_operation(parser_for_tool('file'), ['--upload', 'local', '--remote-path', '/remote'])
        self.assertIsNone(args.direction)
        self.assertNotIn('direction', args.explicit_options)

    def test_interspersed_operands_single_and_batch(self):
        for factory in (parser_for_tool, parser_for_batch):
            args = parse_operation(factory('file'), ['download', '--hosts', 'node[01-02]',
                                                     '/remote', '--no-resume', 'local'])
            self.assertEqual((args.download, args.local_path, args.no_resume), ('/remote', Path('local'), True))
            args = parse_operation(factory('control'), ['power', '--hosts', 'node[01-02]', 'on'])
            self.assertEqual(args.power, 'on')

    def test_invalid_inputs_fail_before_ping_or_prompts(self):
        cases = [('exec', ['--timeout', 'nan', 'hostname']),
                 ('exec', ['--prompt', '[', 'hostname']),
                 ('exec', ['--command-file', '/nonexistent-sol-test-script']),
                 ('file', ['upload', '/nonexistent-sol-test-payload', '/tmp/file']),
                 ('control', ['power', 'on', '--replay-export']),
                 ('control', ['power', 'on', '--log-file', 'unused.jsonl'])]
        for tool, words in cases:
            with self.subTest(tool=tool, words=words), patch.object(sys, 'argv', [f'sol_{tool}.py', *words]), \
                    patch.object(cli, 'ping_host') as ping, patch.object(cli, 'prompt_credential') as prompt, \
                    contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit) as exc:
                    cli.main(tool)
                self.assertEqual(exc.exception.code, 2)
                ping.assert_not_called()
                prompt.assert_not_called()

    def test_bmc_output_refuses_existing_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / 'output'
            target.write_text('keep')
            with patch.object(sys, 'argv', ['sol_control.py', 'power', 'on', '--output', str(target)]), \
                    patch.object(cli, 'run_bmc_single') as run, contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit) as exc:
                    cli.main('control')
                self.assertEqual(exc.exception.code, 2)
                run.assert_not_called()
                self.assertEqual(target.read_text(), 'keep')

    def test_console_close_handles_reaped_child_and_is_idempotent(self):
        console = Console.__new__(Console)
        console.pid, console.fd, console.input_sent = 123, 99, False
        with patch.object(console, 'send'), patch('sol_tools.session.os.waitpid', side_effect=ChildProcessError), \
                patch('sol_tools.session.os.close') as close, patch('sol_tools.session.os.kill') as kill:
            console.close()
            console.close()
            close.assert_called_once_with(99)
            kill.assert_not_called()

    def test_console_close_closes_fd_when_reaping_fails(self):
        console = Console.__new__(Console)
        console.pid, console.fd, console.input_sent = 123, 99, False
        with patch.object(console, 'send'), patch('sol_tools.session.os.waitpid', side_effect=OSError('unexpected')), \
                patch('sol_tools.session.os.close') as close:
            with self.assertRaises(OSError):
                console.close()
            close.assert_called_once_with(99)

    def test_download_conflict_reports_error_without_traceback(self):
        from sol_tools.download import download
        import hashlib
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / 'existing'
            target.write_bytes(b'local')
            argv = ['sol_file.py', '--hosts', '192.0.2.1', '--bmc-user', 'admin',
                    '--bmc-password', 'test', '--os-user', 'root', '--os-password', 'test',
                    '--skip-ping', '--no-log', '--ipmitool', sys.executable,
                    'download', '/remote', str(target)]

            def execute(con, command, args):
                import re
                token = re.search(r'SOL_FILE_[a-f0-9]+', command)[0]
                return 0, f'{token}:6:{hashlib.sha256(b"remote").hexdigest()}\n'

            with patch.object(sys, 'argv', argv), \
                    patch.object(cli, 'run_with_reconnect', side_effect=lambda args, *_: download(None, args)), \
                    patch('sol_tools.download.execute', side_effect=execute), \
                    contextlib.redirect_stderr(io.StringIO()) as err:
                self.assertEqual(cli.main('file'), 125)
                self.assertIn('use --overwrite', err.getvalue())
                self.assertNotIn('Traceback', err.getvalue())
            self.assertEqual(target.read_bytes(), b'local')

    def test_real_pty_command_execution_without_bmc(self):
        with tempfile.TemporaryDirectory() as tmp:
            inv = Path(tmp) / 'inventory.ini'
            inv.write_text('[all]\n192.0.2.1\n')
            fake = Path(tmp) / 'fake-ipmitool'
            fake.write_text(f'#!{sys.executable}\n' + '''import os
print('SOL Session operational', flush=True)
env = dict(os.environ, PS1='fake# ', PROMPT_COMMAND='')
os.execve('/bin/bash', ['/bin/bash', '--noprofile', '--norc', '-i'], env)
''')
            fake.chmod(0o700)
            result = subprocess.run([sys.executable, str(ROOT / 'sol_exec.py'), '--inventory', str(inv), '--hosts', '192.0.2.1',
                                     '--bmc-user', 'admin', '--bmc-password', 'test',
                                     '--os-user', 'root', '--os-password', 'test',
                                     '--skip-ping', '--no-log', '--ipmitool', str(fake),
                                     '--connect-timeout', '5', "printf 'SOL_REVIEW_OK\\n'; exit 7"],
                                    cwd=tmp, capture_output=True, text=True, timeout=20)
            self.assertEqual(result.returncode, 7, result.stderr)
            self.assertIn('SOL_REVIEW_OK', result.stdout)


if __name__ == '__main__':
    unittest.main()
