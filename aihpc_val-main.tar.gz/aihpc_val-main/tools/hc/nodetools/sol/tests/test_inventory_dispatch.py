"""All remote entry points resolve targets through the same inventory selection."""
import contextlib
import io
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

from sol_tools import cli
from sol_tools.arguments import parser_for_tool, parse_operation
from sol_tools.inventory import select_nodes


class InventoryDispatchTest(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.inventory = Path(temp.name) / 'inventory.ini'
        self.inventory.write_text('[cluster]\nnode[01-02] host=192.0.2.[1-2]\n')

    def select(self, *words):
        return select_nodes(parse_operation(parser_for_tool('exec'),
                            ['--inventory', str(self.inventory), *words]))

    def test_default_all_and_equivalent_selectors(self):
        self.assertEqual(len(self.select()), 2)
        for option in ('--hosts',):
            self.assertEqual(len(self.select(option, 'node[01-02]')), 2)
            self.assertEqual(len(self.select(option, 'node01,192.0.2.1')), 1)
        self.assertEqual(len(self.select('--group', 'cluster', '--hosts', 'node02')), 1)

    def test_unknown_and_conflicting_selectors_fail(self):
        for words in [('--hosts', '192.0.2.99'), ('--group', 'absent'),
                      ('--hosts', 'node99', '--group', 'cluster')]:
            with self.subTest(words=words), self.assertRaises(ValueError):
                self.select(*words)

    def test_removed_selectors_rejected(self):
        for option in ('--host', '--match', '--hosts-file'):
            with self.subTest(option=option), contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit):
                    parse_operation(parser_for_tool('exec'), [option, 'node01', 'hostname'])

    def test_console_requires_exactly_one_selected_node(self):
        for selector in (['--hosts', 'node[01-02]'], ['--group', 'cluster']):
            with patch.object(sys, 'argv', ['sol_control.py', '--inventory', str(self.inventory),
                                          *selector, 'console']), contextlib.redirect_stderr(io.StringIO()) as err:
                with self.assertRaises(SystemExit):
                    cli.main('control')
                self.assertIn('exactly one', err.getvalue())
        self.inventory.write_text('[cluster]\nnode01 host=192.0.2.1\n')
        argv = ['sol_control.py', '--inventory', str(self.inventory), '--group', 'cluster',
                '--bmc-user', 'admin', '--bmc-password', 'test', '--skip-ping', '--no-log',
                '--ipmitool', sys.executable, 'console']
        with patch.object(sys, 'argv', argv), patch.object(sys.stdin, 'isatty', return_value=True), \
                patch.object(sys.stdout, 'isatty', return_value=True), \
                patch.object(cli, 'run_with_reconnect', return_value=0) as run:
            self.assertEqual(cli.main('control'), 0)
            self.assertEqual(run.call_args.args[0].host, '192.0.2.1')

    def test_inventory_required_even_with_cli_credentials(self):
        argv = ['sol_exec.py', '--inventory', str(self.inventory.parent / 'missing.ini'),
                '--hosts', '192.0.2.1', '--bmc-user', 'admin', '--bmc-password', 'test',
                '--os-user', 'root', '--os-password', 'test', 'hostname']
        with patch.object(sys, 'argv', argv), patch.object(cli, 'run_with_reconnect') as run, \
                contextlib.redirect_stderr(io.StringIO()) as err:
            with self.assertRaises(SystemExit):
                cli.main('exec')
            self.assertIn('Inventory not found', err.getvalue())
            run.assert_not_called()

    def test_dispatch_uses_selection_count(self):
        for option in ('--hosts', '--group'):
            value = 'cluster' if option == '--group' else 'node[01-02]'
            argv = ['sol_exec.py', '--inventory', str(self.inventory), option, value, 'hostname']
            with patch.object(sys, 'argv', argv), patch.object(cli, 'run_batch', return_value=0) as run:
                self.assertEqual(cli.main('exec'), 0)
                self.assertEqual(len(run.call_args.args[3]), 2)
        argv = ['sol_exec.py', '--inventory', str(self.inventory), '--hosts', 'node01',
                '--bmc-user', 'admin', '--bmc-password', 'test', '--os-user', 'root',
                '--os-password', 'test', '--skip-ping', '--no-log', '--ipmitool', sys.executable, 'hostname']
        with patch.object(sys, 'argv', argv), patch.object(cli, 'run_with_reconnect', return_value=0) as run:
            self.assertEqual(cli.main('exec'), 0)
            self.assertEqual(run.call_args.args[0].host, '192.0.2.1')
