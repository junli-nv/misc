"""Typed runtime defaults, CLI precedence and operation scoping."""
import contextlib
import io
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

from sol_tools import cli
from sol_tools.arguments import parser_for_tool, parse_operation
from sol_tools.defaults import apply_defaults
from sol_tools.inventory import parse_ini_inventory, load_inventory


class InventoryDefaultsTest(unittest.TestCase):
    def settings(self, text):
        return parse_ini_inventory('[sol:defaults]\n' + text)['runtime_defaults']

    def test_types_and_cli_values_equal_to_builtin_defaults(self):
        args = parse_operation(parser_for_tool('exec'), ['--jobs=4', '--timeout', '300', '--ping', '--log', 'hostname'])
        apply_defaults(args, self.settings('jobs=8\ntimeout=600\nskip_ping=yes\nno_log=true\nping_jobs=12'))
        self.assertEqual((args.jobs, args.timeout, args.skip_ping, args.no_log, args.ping_jobs),
                         (4, 300, False, False, 12))

    def test_negative_flags_and_operation_scoping(self):
        settings = self.settings('reconnect=true\nreconnect_delay=8\nno_log=false\nlog_compress=true')
        args = parse_operation(parser_for_tool('control'), ['console', '--no-reconnect', '--no-log-compress'])
        apply_defaults(args, settings)
        self.assertEqual((args.reconnect, args.reconnect_delay, args.log_compress), (False, 8, False))
        args = parse_operation(parser_for_tool('control'), ['power', 'status'])
        apply_defaults(args, settings)
        self.assertIsNone(args.reconnect)
        self.assertIsNone(args.log_compress)
        self.assertEqual(args.reconnect_delay, 3)

    def test_invalid_defaults_fail(self):
        for text in ('jobs=0', 'jobs=many', 'timeout=nan', 'skip_ping=maybe', 'unknown=1',
                     'jobs=1\njobs=2', 'reconnect_delay=61', 'overwrite=true'):
            with self.subTest(text=text), self.assertRaises(ValueError):
                self.settings(text)

    def test_real_dispatch_with_inventory_defaults(self):
        with tempfile.TemporaryDirectory() as tmp:
            inventory = Path(tmp) / 'inventory.ini'
            inventory.write_text('''[sol:defaults]
jobs=8
timeout=600
skip_ping=true
no_log=true
[all:vars]
bmc_user=admin
bmc_password=test
os_user=root
os_password=test
[cluster]
node[01-02] host=192.0.2.[1-2]
''')
            self.assertEqual(len(load_inventory(inventory)), 2)
            common = ['sol_exec.py', '--inventory', str(inventory), '--ipmitool', sys.executable]
            with patch.object(sys, 'argv', [*common, '--hosts', 'node01', 'hostname']), \
                    patch.object(cli, 'run_with_reconnect', return_value=0) as run, \
                    patch.object(cli, 'ping_host') as ping:
                self.assertEqual(cli.main('exec'), 0)
                self.assertEqual(run.call_args.args[0].timeout, 600)
                self.assertTrue(run.call_args.args[0].no_log)
                ping.assert_not_called()
            with patch.object(sys, 'argv', [*common, 'hostname']), \
                    patch.object(cli, 'run_batch', return_value=0) as run:
                self.assertEqual(cli.main('exec'), 0)
                self.assertEqual(run.call_args.args[2].jobs, 8)

    def test_batch_compression_override_reaches_workers(self):
        with tempfile.TemporaryDirectory() as tmp:
            inventory = Path(tmp) / 'inventory.ini'
            inventory.write_text('[sol:defaults]\nlog_compress=false\n'
                                 '[all:vars]\nbmc_user=admin\nbmc_password=test\n'
                                 'os_user=root\nos_password=test\n'
                                 '[cluster]\nnode[01-02] host=192.0.2.[1-2]\n')
            argv = ['sol_exec.py', '--inventory', str(inventory), '--skip-ping',
                    '--ipmitool', sys.executable, '--log-compress',
                    '--result-dir', str(Path(tmp) / 'results'), 'hostname']
            with patch.object(sys, 'argv', argv), patch('sol_tools.batch.subprocess.Popen') as popen, \
                    contextlib.redirect_stdout(io.StringIO()):
                popen.return_value.wait.return_value = 0
                self.assertEqual(cli.main('exec'), 0)
                children = [call.args[0][1:] for call in popen.call_args_list]
            for child in children:
                with patch.object(sys, 'argv', child), \
                        patch.object(cli, 'run_with_reconnect', return_value=0) as run, \
                        contextlib.redirect_stderr(io.StringIO()):
                    self.assertEqual(cli.main('exec'), 0)
                    self.assertTrue(run.call_args.args[0].log_compress)

    def test_help_and_replay_do_not_read_inventory(self):
        with patch.object(sys, 'argv', ['sol_control.py', 'replay', 'missing.jsonl']), \
                patch.object(cli, 'select_nodes') as select, \
                patch.object(cli, 'replay', return_value=0):
            self.assertEqual(cli.main('control'), 0)
            select.assert_not_called()
