"""Download protocol tests using a local Bash stand-in, never a BMC."""
import argparse
import base64
import contextlib
import fcntl
import io
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from sol_tools.download import download, validate_download, CHUNK_SIZE


class DownloadTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source = self.root / "remote ' file"
        self.target = self.root / 'received.bin'
        self.args = argparse.Namespace(download=str(self.source), local_path=self.target,
            overwrite=False, no_resume=False,
            remote_path=None, mode='600', timeout=10, connect_timeout=10)
        # macOS base64 lacks GNU's -w; emulate just that executable, and run the
        # actual generated Bash commands, dd, wc and sha256sum without changes.
        binary = self.root / 'base64'
        binary.write_text(f'#!{sys.executable}\nimport base64,sys\n'
                          'sys.stdout.write(base64.b64encode(sys.stdin.buffer.read()).decode())\n')
        binary.chmod(0o700)
        self.env = dict(os.environ, PATH=str(self.root) + os.pathsep + os.environ['PATH'])
        self.commands = []

    def execute(self, con, command, args):
        self.commands.append(command)
        result = subprocess.run(['/bin/bash', '-c', command], env=self.env,
                                capture_output=True, text=True, timeout=10)
        return result.returncode, result.stdout + result.stderr

    def run_download(self, execute=None):
        with patch('sol_tools.download.execute', side_effect=execute or self.execute), contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            return download(None, self.args)

    def test_binary_multiple_chunks_and_empty(self):
        for payload in (bytes(range(256)) * 29, b''):
            self.source.write_bytes(payload)
            self.assertEqual(self.run_download(), 0)
            self.assertEqual(self.target.read_bytes(), payload)
            self.assertEqual(self.target.stat().st_mode & 0o777, 0o600)
            self.target.unlink()
        self.assertFalse(list(self.root.glob('.sol-download-*')))

    def test_remote_path_containing_protocol_placeholder(self):
        self.source = self.root / 'literal __TOKEN__ file'
        self.args.download = str(self.source)
        self.source.write_bytes(b'correct path')
        self.run_download()
        self.assertEqual(self.target.read_bytes(), b'correct path')

    def test_missing_remote_file(self):
        with self.assertRaises(RuntimeError):
            self.run_download()
        self.assertFalse(self.target.exists())

    def test_no_clobber_and_overwrite(self):
        self.source.write_bytes(b'new')
        self.target.write_bytes(b'old')
        with self.assertRaises(ValueError):
            self.run_download()
        self.assertEqual(self.target.read_bytes(), b'old')
        self.args.overwrite = True
        self.run_download()
        self.assertEqual(self.target.read_bytes(), b'new')

    def test_corruption_preserves_existing_destination(self):
        self.source.write_bytes(b'new')
        self.target.write_bytes(b'old')
        self.args.overwrite = True
        def corrupt(con, command, args):
            rc, output = self.execute(con, command, args)
            if 'data=$(dd' in command:
                output = output.replace(base64.b64encode(b'new').decode(), base64.b64encode(b'bad').decode())
            return rc, output
        with self.assertRaisesRegex(RuntimeError, 'SHA-256'):
            self.run_download(corrupt)
        self.assertEqual(self.target.read_bytes(), b'old')
        self.assertFalse(list(self.root.glob('.sol-download-*')))

    def test_timeout_retains_and_resumes_partial_file(self):
        self.source.write_bytes(b'x' * (CHUNK_SIZE + 1))
        def interrupted(con, command, args):
            if 'skip=1' in command:
                raise TimeoutError('simulated disconnection')
            return self.execute(con, command, args)
        with self.assertRaises(TimeoutError):
            self.run_download(interrupted)
        self.assertFalse(self.target.exists())
        part = next(self.root.glob('.sol-download-*.part'))
        self.assertEqual(part.stat().st_size, CHUNK_SIZE)
        self.commands.clear()
        self.run_download()
        self.assertEqual(self.target.read_bytes(), self.source.read_bytes())
        self.assertFalse(any('skip=0' in command for command in self.commands))
        self.assertTrue(any('head -c' in command for command in self.commands))
        self.assertFalse(list(self.root.glob('.sol-download-*')))

    def test_changed_remote_file_rejected(self):
        self.source.write_bytes(b'old')
        def changed(con, command, args):
            result = self.execute(con, command, args)
            if 'data=$(dd' in command:
                self.source.write_bytes(b'new')
            return result
        with self.assertRaisesRegex(RuntimeError, 'remote file changed'):
            self.run_download(changed)
        self.assertFalse(self.target.exists())

    def test_concurrent_destination_creation_not_overwritten(self):
        self.source.write_bytes(b'payload')
        def racing(con, command, args):
            result = self.execute(con, command, args)
            if 'data=$(dd' in command:
                self.target.write_bytes(b'other writer')
            return result
        with self.assertRaises(FileExistsError):
            self.run_download(racing)
        self.assertEqual(self.target.read_bytes(), b'other writer')
        self.assertTrue(list(self.root.glob('.sol-download-*.part')))

    def interrupted_download(self):
        self.source.write_bytes(b'x' * (CHUNK_SIZE + 19))
        def interrupted(con, command, args):
            if 'skip=1' in command:
                raise TimeoutError('interrupted')
            return self.execute(con, command, args)
        with self.assertRaises(TimeoutError):
            self.run_download(interrupted)
        self.commands.clear()

    def test_corrupt_prefix_restarts(self):
        self.interrupted_download()
        next(self.root.glob('.sol-download-*.part')).write_bytes(b'!' * CHUNK_SIZE)
        self.run_download()
        self.assertEqual(self.target.read_bytes(), self.source.read_bytes())
        self.assertTrue(any('skip=0' in c for c in self.commands))

    def test_changed_source_restarts(self):
        self.interrupted_download()
        self.source.write_bytes(b'y' * (CHUNK_SIZE + 19))
        self.run_download()
        self.assertEqual(self.target.read_bytes(), self.source.read_bytes())
        self.assertTrue(any('skip=0' in c for c in self.commands))

    def test_no_resume_restarts(self):
        self.interrupted_download()
        self.args.no_resume = True
        self.run_download()
        self.assertTrue(any('skip=0' in c for c in self.commands))

    def test_identical_destination_skips_transfer(self):
        self.source.write_bytes(b'complete')
        self.target.write_bytes(b'complete')
        self.run_download()
        self.assertFalse(any('data=$(dd' in c for c in self.commands))

    def test_partial_chunk_is_retried(self):
        self.interrupted_download()
        with next(self.root.glob('.sol-download-*.part')).open('ab') as out:
            out.write(b'partial')
        self.run_download()
        self.assertEqual(self.target.read_bytes(), self.source.read_bytes())
        self.assertFalse(any('skip=0' in c for c in self.commands))

    def test_concurrent_resume_rejected(self):
        self.interrupted_download()
        part = next(self.root.glob('.sol-download-*.part'))
        with part.open('r+b') as writer:
            fcntl.flock(writer, fcntl.LOCK_EX | fcntl.LOCK_NB)
            with self.assertRaisesRegex(RuntimeError, 'Another download'):
                self.run_download()
        self.assertEqual(part.stat().st_size, CHUNK_SIZE)

    def test_bad_metadata_restarts(self):
        self.interrupted_download()
        next(self.root.glob('.sol-download-*.json')).write_text('broken json')
        self.run_download()
        self.assertEqual(self.target.read_bytes(), self.source.read_bytes())
        self.assertTrue(any('skip=0' in c for c in self.commands))



if __name__ == '__main__':
    unittest.main()
