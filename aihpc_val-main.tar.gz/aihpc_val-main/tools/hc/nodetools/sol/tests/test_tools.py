"""Offline regression coverage for the split tools and short CLI syntax."""
import contextlib
import io
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from sol_tools import cli
from sol_tools.arguments import parser_for_tool, normalize_operation
from sol_tools.inventory import default_config_path

ROOT = Path(__file__).resolve().parent.parent


class SplitToolsTest(unittest.TestCase):
    def parse(self, tool, *words):
        parser = parser_for_tool(tool)
        args = parser.parse_args(words)
        normalize_operation(parser, args)
        return args

    def test_short_forms(self):
        self.assertEqual(self.parse('exec', '--hosts', 'node', 'echo hi').command, 'echo hi')
        args = self.parse('file', '--hosts', 'node', 'upload', 'a file', '/tmp/a file')
        self.assertEqual((args.upload, args.remote_path), (Path('a file'), '/tmp/a file'))
        download = self.parse('file', '--hosts', 'node', 'download', '/remote', 'local')
        self.assertEqual((download.download, download.local_path), ('/remote', Path('local')))
        self.assertEqual(self.parse('control', 'power').power, 'status')
        self.assertEqual(self.parse('control', 'logs', '--last', '20').sel_last, 20)
        self.assertTrue(self.parse('control', 'console').console)
        self.assertTrue(self.parse('control', 'login').interactive)
        self.assertEqual(self.parse('control', 'replay', 'log.jsonl').replay, Path('log.jsonl'))
        self.assertEqual(default_config_path(), ROOT / 'inventory.ini')

    def test_operation_boundaries(self):
        cases = [('file', ['--transfer', 'zmodem']), ('file', ['--zmodem-sender', '/tmp/sz']),
                 ('exec', ['--upload', 'file']), ('file', ['-c', 'hostname']),
                 ('control', ['-c', 'hostname']), ('exec', ['--power', 'on']),
                 ('file', ['one-file']), ('control', ['boot']),
                 ('control', ['power', 'on', '--power', 'off']),
                 ('exec', ['-c', 'hostname', 'uptime'])]
        for tool, words in cases:
            with self.subTest(tool=tool, words=words), contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit) as error:
                    self.parse(tool, *words)
                self.assertEqual(error.exception.code, 2)

    def test_scoped_help_and_completion(self):
        for tool, included, excluded in [('exec', '--command-file', '--upload'),
                                         ('file', '--upload', '--power'),
                                         ('control', '--bootdev', '--command-file')]:
            result = subprocess.run([sys.executable, str(ROOT / f'sol_{tool}.py'), '--help-all'],
                                    capture_output=True, text=True, check=True)
            self.assertIn(included, result.stdout)
            self.assertNotIn(excluded, result.stdout)

    def test_single_sol_dispatch(self):
        with tempfile.TemporaryDirectory() as tmp:
            inv = Path(tmp) / 'inventory.ini'
            inv.write_text('[all]\n192.0.2.1\n')
            source = Path(tmp) / 'input.txt'
            source.write_text('payload')
            for tool, operation in [('exec', ['echo hello']), ('file', ['upload', str(source), '/tmp/upload.txt'])]:
                argv = [f'sol_{tool}.py', '--inventory', str(inv), '--hosts', '192.0.2.1', '--bmc-user', 'admin',
                        '--bmc-password', 'bmc', '--os-user', 'root', '--os-password', 'os',
                        '--ipmitool', sys.executable, '--skip-ping', '--no-log', *operation]
                with patch.object(sys, 'argv', argv), patch.object(cli, 'run_with_reconnect', return_value=0) as run:
                    self.assertEqual(cli.main(tool), 0)
                    args, bmc, os_password = run.call_args.args
                    self.assertEqual((bmc, os_password), ('bmc', 'os'))
                    self.assertEqual(args.command if tool == 'exec' else args.upload,
                                     'echo hello' if tool == 'exec' else source)

    def test_batch_routes_to_matching_entry(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            inv = root / 'inventory.ini'
            inv.write_text('[all:vars]\nbmc_user=admin\nbmc_password=bmc\nos_user=root\nos_password=os\n'
                           '[cluster]\ngpu[001-002] host=192.0.2.[1-2]\n')
            source = root / 'file.txt'
            source.write_text('payload')
            for tool, operation in [('exec', ['echo hello']), ('file', ['upload', str(source), '/tmp/upload.txt'])]:
                directory = root / tool
                argv = [f'sol_{tool}.py', '--config', str(inv), '--hosts', 'gpu[001-002]',
                        '--ipmitool', sys.executable, '--skip-ping', '--no-log',
                        '--result-dir', str(directory), *operation]
                with patch.object(sys, 'argv', argv), patch('sol_tools.batch.subprocess.Popen') as popen, contextlib.redirect_stdout(io.StringIO()):
                    popen.return_value.wait.return_value = 0
                    self.assertEqual(cli.main(tool), 0)
                    self.assertEqual(popen.call_count, 2)
                    for call in popen.call_args_list:
                        child = call.args[0]
                        self.assertEqual(Path(child[1]), ROOT / f'sol_{tool}.py')
                        self.assertIn('--command-file' if tool == 'exec' else '--upload', child)
                self.assertEqual(json.loads((directory / 'results.json').read_text())['completed'], 2)

    def test_download_single_and_batch_dispatch(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            inv = root / 'inventory.ini'
            inv.write_text('[all]\n192.0.2.[1-2]\n')
            common = ['--inventory', str(inv), '--bmc-user', 'admin', '--bmc-password', 'bmc', '--os-user', 'root',
                      '--os-password', 'os', '--ipmitool', sys.executable, '--skip-ping', '--no-log']
            argv = ['sol_file.py', '--hosts', '192.0.2.1', *common, 'download', '/etc/hostname', str(root / 'hostname')]
            with patch.object(sys, 'argv', argv), patch.object(cli, 'run_with_reconnect', return_value=0) as run:
                self.assertEqual(cli.main('file'), 0)
                self.assertEqual(run.call_args.args[0].download, '/etc/hostname')
            argv = ['sol_file.py', '--hosts', '192.0.2.[1-2]', *common,
                    '--result-dir', str(root / 'results'), '--no-resume', 'download', '/etc/hostname', str(root / 'downloads')]
            with patch.object(sys, 'argv', argv), patch('sol_tools.batch.subprocess.Popen') as popen, contextlib.redirect_stdout(io.StringIO()):
                popen.return_value.wait.return_value = 0
                self.assertEqual(cli.main('file'), 0)
                targets = []
                for call in popen.call_args_list:
                    child = call.args[0]
                    self.assertEqual(Path(child[1]), ROOT / 'sol_file.py')
                    self.assertEqual(child[child.index('--download') + 1], '/etc/hostname')
                    self.assertIn('--no-resume', child)
                    target = Path(child[child.index('--local-path') + 1])
                    self.assertEqual(target.name, 'hostname')
                    self.assertEqual(target.parent.parent, (root / 'downloads').resolve())
                    targets.append(target)
                self.assertEqual(len(set(targets)), 2)

    def test_replay_remains_local(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'session.jsonl'
            path.write_text(json.dumps({'time': '2026-09-20T12:00:00+00:00',
                                        'direction': 'OUT', 'data': 'recorded output'}) + '\n')
            result = subprocess.run([sys.executable, str(ROOT / 'sol_control.py'),
                                     'replay', str(path), '--replay-export'],
                                    cwd=tmp, capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(result.stdout, 'recorded output')

    def test_bash_completion_coexists_and_handles_positionals(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / 'file with spaces').touch()
            sources = []
            for tool in ('exec', 'file', 'control'):
                result = subprocess.run([sys.executable, str(ROOT / f'sol_{tool}.py'), '--bash-completion'],
                                        capture_output=True, text=True, check=True)
                target = root / f'{tool}.bash'
                target.write_text(result.stdout)
                subprocess.run(['/bin/bash', '-n', str(target)], check=True)
                sources.append('source ' + shlex.quote(str(target)))
            cases = [('file', ['d'], ['download']),
                     ('file', ['download', '/remote', 'file w'], ['file with spaces']),
                     ('control', ['--hosts', 'node', 'boot', 'p'], ['pxe']),
                     ('control', ['--hosts', 'node', 'power', 'o'], ['on', 'off']),
                     ('control', ['--hosts', 'node', 'lo'], ['login', 'logs']),
                     ('file', ['upload', 'file w'], ['file with spaces']),
                     ('exec', ['--up'], [])]
            for tool, words, expected in cases:
                words = [f'sol_{tool}', *words]
                code = '\n'.join(sources) + '\nCOMP_WORDS=(' + ' '.join(map(shlex.quote, words)) + ')\n'
                code += f'COMP_CWORD={len(words)-1}\n_sol_{tool}_complete\n'
                code += 'for x in "${COMPREPLY[@]}"; do printf "%s\\n" "$x"; done\n'
                result = subprocess.run(['/bin/bash', '-c', code], cwd=root, capture_output=True, text=True, check=True)
                self.assertEqual(result.stdout.splitlines(), expected)


if __name__ == '__main__':
    unittest.main()
