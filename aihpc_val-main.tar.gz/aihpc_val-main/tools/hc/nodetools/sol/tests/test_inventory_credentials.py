"""Inventory-only credentials and their explicit overrides, without remote I/O."""
import contextlib
import io
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

from sol_tools import cli


class InventoryCredentialsTest(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        self.inventory = self.root / 'inventory.ini'
        self.inventory.write_text('''[all:vars]
bmc_user=admin
bmc_password=global-bmc
os_user=root
os_password=global-os
[cluster:vars]
os_user=operator
os_password=group-os
[cluster]
node01 host=192.0.2.1
node02 host=192.0.2.2 bmc_password=node-bmc os_password=node-os
[all]
node03 host=192.0.2.3
''')
        self.common = ['--inventory', str(self.inventory), '--skip-ping', '--no-log',
                       '--ipmitool', sys.executable]
        env = patch.dict(os.environ, {}, clear=True)
        env.start()
        self.addCleanup(env.stop)

    def test_inventory_only_commands_and_transfers(self):
        source = self.root / 'source'
        source.write_text('payload')
        for tool, operation in [('exec', ['hostname']),
                                ('file', ['upload', str(source), '/tmp/file']),
                                ('file', ['download', '/tmp/file', str(self.root / 'download')])]:
            for node, user, bmc, password in [('node01', 'operator', 'global-bmc', 'group-os'),
                                             ('node02', 'operator', 'node-bmc', 'node-os'),
                                             ('node03', 'root', 'global-bmc', 'global-os')]:
                with self.subTest(tool=tool, node=node), \
                        patch.object(sys, 'argv', [f'sol_{tool}.py', *self.common, '--hosts', node, *operation]), \
                        patch.object(cli, 'prompt_credential') as prompt, \
                        patch.object(cli, 'run_with_reconnect', return_value=0) as run:
                    self.assertEqual(cli.main(tool), 0)
                    args, resolved_bmc, resolved_os = run.call_args.args
                    self.assertEqual((args.bmc_user, args.os_user, resolved_bmc, resolved_os),
                                     ('admin', user, bmc, password))
                    prompt.assert_not_called()

    def test_environment_and_cli_password_precedence(self):
        with patch.dict(os.environ, IPMI_PASSWORD='env-bmc', SOL_OS_PASSWORD='env-os'):
            for overrides, expected in [([], ('env-bmc', 'env-os')),
                                        (['--bmc-password', 'cli-bmc', '--os-password', 'cli-os'],
                                         ('cli-bmc', 'cli-os'))]:
                with patch.object(sys, 'argv', ['sol_exec.py', *self.common, '--hosts', 'node02',
                                               *overrides, 'hostname']), \
                        patch.object(cli, 'run_with_reconnect', return_value=0) as run:
                    self.assertEqual(cli.main('exec'), 0)
                    self.assertEqual(run.call_args.args[1:], expected)

    def test_batch_inventory_only_credentials(self):
        argv = ['sol_exec.py', *self.common, '--group', 'cluster',
                '--result-dir', str(self.root / 'results'), 'hostname']
        with patch.object(sys, 'argv', argv), patch('sol_tools.batch.prompt_credential') as prompt, \
                patch('sol_tools.batch.subprocess.Popen') as popen, contextlib.redirect_stdout(io.StringIO()):
            popen.return_value.wait.return_value = 0
            self.assertEqual(cli.main('exec'), 0)
            prompt.assert_not_called()
            environments = {call.args[0][call.args[0].index('--hosts') + 1]: call.kwargs['env']
                            for call in popen.call_args_list}
            self.assertEqual(environments['192.0.2.1']['SOL_OS_PASSWORD'], 'group-os')
            self.assertEqual(environments['192.0.2.2']['SOL_OS_PASSWORD'], 'node-os')
            self.assertEqual(environments['192.0.2.2']['IPMI_PASSWORD'], 'node-bmc')
