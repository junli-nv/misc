"""Offline regression tests for the SOL tools; not required at runtime."""
