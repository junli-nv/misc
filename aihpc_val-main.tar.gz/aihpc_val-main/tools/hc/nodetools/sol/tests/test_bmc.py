"""Offline CLI integration tests; the fake ipmitool never accesses the network."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


SCRIPT = Path(__file__).resolve().parent.parent / 'sol_control.py'


class BMCOperationsTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.fake = self.root / 'ipmitool'
        self.fake.write_text(f'#!{sys.executable}\n' + '''import json, os, sys, time
args = sys.argv[1:]
assert '-E' in args and '-P' not in args
assert os.environ['IPMI_PASSWORD'] == 'test-secret'
assert 'SOL_OS_PASSWORD' not in os.environ
assert 'sol' not in args
if os.environ.get('FAKE_SLEEP'):
    time.sleep(10)
print(json.dumps(args))
sys.exit(7 if args[args.index('-H') + 1] == '192.0.2.2' else 0)
''')
        self.fake.chmod(0o700)
        self.inventory = self.root / 'inventory.ini'
        self.inventory.write_text('[all:vars]\nbmc_user=admin\nbmc_password=test-secret\n'
                                  '[cluster]\ngpu[001-002] host=192.0.2.[1-2]\n')
        self.env = os.environ.copy()
        self.env.pop('IPMI_PASSWORD', None)
        self.env['SOL_OS_PASSWORD'] = 'must-not-reach-ipmitool'

    def cli(self, *args):
        return subprocess.run([sys.executable, str(SCRIPT), '--config', str(self.inventory),
                               '--ipmitool', str(self.fake), '--skip-ping', *args],
                              cwd=self.root, env=self.env, capture_output=True, text=True, timeout=15)

    def test_power_actions(self):
        for action in ('status', 'on', 'off', 'soft', 'reset', 'cycle'):
            with self.subTest(action=action):
                result = self.cli('--hosts', 'gpu001', '--power', action)
                self.assertEqual(result.returncode, 0, result.stderr)
                argv = json.loads(result.stdout)
                self.assertEqual(argv[-3:], ['chassis', 'power', action])
                self.assertEqual(argv[argv.index('-H') + 1], '192.0.2.1')
                self.assertNotIn('test-secret', result.stdout)

    def test_sel_and_output(self):
        for mode in ('list', 'elist', 'info'):
            result = self.cli('--hosts', 'gpu001', '--bmc-log', mode)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(result.stdout)[-2:], ['sel', mode])
        output = self.root / 'sel.txt'
        result = self.cli('--hosts', 'gpu001', '--bmc-log', 'elist', '--sel-last', '10', '--output', str(output))
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(output.read_text())[-4:], ['sel', 'elist', 'last', '10'])

    def test_batch_results_and_bmc_only_credentials(self):
        for option, value in (('--power', 'status'), ('--bmc-log', 'list')):
            directory = self.root / value
            result = self.cli('--hosts', 'gpu[001-002]', option, value, '--result-dir', str(directory))
            self.assertEqual(result.returncode, 1, result.stderr)
            summary = json.loads((directory / 'results.json').read_text())
            self.assertEqual([r['exit_code'] for r in summary['results']], [0, 7])
            self.assertEqual(len(list(directory.glob('*/stdout.txt'))), 2)
            self.assertFalse(list(directory.glob('*/sol.jsonl*')))
            self.assertTrue((directory / 'ipmi-operation.txt').exists())

    def test_preview_does_not_execute(self):
        result = self.cli('--hosts', 'gpu[001-002]', '--power', 'off', '--list-hosts')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn('gpu002\t192.0.2.2', result.stdout)
        self.assertNotIn('chassis', result.stdout)

    def test_invalid_combinations(self):
        for args in (('--sel-last', '2'), ('--bmc-log', 'info', '--sel-last', '2'),
                     ('--bmc-log', 'list', '--sel-last', '0'),
                     ('--power', 'on', '-c', 'hostname'),
                     ('--power', 'on', '--bmc-log', 'list'),
                     ('--check-hosts', '--power', 'on'),
                     ('--power', 'status', '--timeout', 'nan')):
            with self.subTest(args=args):
                self.assertEqual(self.cli('--hosts', 'gpu001', *args).returncode, 2)

    def test_short_control_syntax_and_boot(self):
        cases = [(['power', 'on'], ['chassis', 'power', 'on']),
                 (['logs', '--last', '4'], ['sel', 'elist', 'last', '4']),
                 (['boot', 'pxe'], ['chassis', 'bootdev', 'pxe']),
                 (['boot', 'disk', '--uefi', '--persistent'],
                  ['chassis', 'bootdev', 'disk', 'options=efiboot,persistent']),
                 (['boot', 'none'], ['chassis', 'bootdev', 'none'])]
        for words, expected in cases:
            result = self.cli('--hosts', 'gpu001', *words)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(result.stdout)[-len(expected):], expected)
        for words in (['power', 'on', '--uefi'], ['logs', '--persistent'], ['boot', 'bad-device']):
            self.assertEqual(self.cli('--hosts', 'gpu001', *words).returncode, 2)

    def test_batch_boot_and_short_logs(self):
        for action in ('boot', 'logs'):
            directory = self.root / action
            words = ['boot', 'pxe', '--uefi', '--persistent'] if action == 'boot' else ['logs', '--last', '5']
            result = self.cli('--hosts', 'gpu001', '--result-dir', str(directory), *words)
            self.assertEqual(result.returncode, 0, result.stderr)
            argv = json.loads(next(directory.glob('*/stdout.txt')).read_text())
            expected = (['chassis', 'bootdev', 'pxe', 'options=efiboot,persistent'] if action == 'boot'
                        else ['sel', 'elist', 'last', '5'])
            self.assertEqual(argv[-len(expected):], expected)

    def test_timeout(self):
        self.env['FAKE_SLEEP'] = '1'
        result = self.cli('--hosts', 'gpu001', '--power', 'status', '--timeout', '0.1')
        self.assertEqual(result.returncode, 124, result.stderr)
        self.assertIn('completion is unknown', result.stderr)


if __name__ == '__main__':
    unittest.main()
