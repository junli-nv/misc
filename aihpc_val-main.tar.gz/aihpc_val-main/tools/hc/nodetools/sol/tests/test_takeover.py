"""Occupied SOL sessions require a configured or confirmed takeover."""
import argparse
import contextlib
import io
import subprocess
import unittest
from unittest.mock import Mock, patch

from sol_tools import runtime


class TakeoverTest(unittest.TestCase):
    def args(self, policy='ask'):
        return argparse.Namespace(host='192.0.2.1', bmc_user='admin', cipher=17,
                                  ipmitool='ipmitool', connect_timeout=2,
                                  sol_takeover=policy, console=True)

    def test_busy_closes_before_deactivation_and_retries_once(self):
        first, second = Mock(), Mock()
        events = []
        first.close.side_effect = lambda: events.append('close')
        def deactivate(argv, **kwargs):
            events.append('deactivate')
            self.assertEqual(argv[-2:], ['sol', 'deactivate'])
            self.assertEqual(kwargs['env']['IPMI_PASSWORD'], 'secret')
            self.assertNotIn('secret', argv)
            return Mock(returncode=0)
        with patch.object(runtime, 'Console', side_effect=[first, second]), \
                patch.object(runtime, 'activate', side_effect=[runtime.SOLBusy('busy'), None]) as activate, \
                patch.object(runtime.subprocess, 'run', side_effect=deactivate), \
                patch.object(runtime, 'interactive', return_value=0), \
                contextlib.redirect_stderr(io.StringIO()) as output:
            self.assertEqual(runtime.run(self.args('force'), 'secret', None), 0)
        self.assertEqual(events[:2], ['close', 'deactivate'])
        self.assertEqual(activate.call_count, 2)
        second.close.assert_called_once()
        self.assertIn('occupied', output.getvalue())

    def test_unrelated_failure_never_deactivates(self):
        with patch.object(runtime, 'Console'), \
                patch.object(runtime, 'activate', side_effect=RuntimeError('bad credentials')), \
                patch.object(runtime.subprocess, 'run') as deactivate:
            with self.assertRaisesRegex(RuntimeError, 'bad credentials'):
                runtime.run(self.args('force'), 'secret', None)
            deactivate.assert_not_called()

    def test_still_busy_after_takeover_does_not_loop(self):
        with patch.object(runtime, 'Console'), \
                patch.object(runtime, 'activate', side_effect=runtime.SOLBusy('busy')) as activate, \
                patch.object(runtime, 'takeover') as takeover:
            with self.assertRaises(runtime.SOLBusy):
                runtime.run(self.args('force'), 'secret', None)
            takeover.assert_called_once()
            self.assertEqual(activate.call_count, 2)

    def test_confirmation_and_noninteractive_behavior(self):
        for terminal, answer, accepted in [(True, 'yes', True), (True, 'Y', True),
                                            (True, '', False), (True, 'no', False),
                                            (True, EOFError(), False), (False, 'yes', False)]:
            with self.subTest(terminal=terminal, answer=answer), \
                    patch.object(runtime.sys.stdin, 'isatty', return_value=terminal), \
                    patch('builtins.input', side_effect=answer if isinstance(answer, Exception) else None,
                          return_value=answer) as prompt, \
                    patch.object(runtime.subprocess, 'run', return_value=Mock(returncode=0)) as deactivate, \
                    contextlib.redirect_stderr(io.StringIO()):
                if accepted:
                    runtime.takeover(self.args(), ['ipmitool', 'sol', 'activate'], {}, 'secret', None)
                else:
                    with self.assertRaises(RuntimeError):
                        runtime.takeover(self.args(), ['ipmitool', 'sol', 'activate'], {}, 'secret', None)
                self.assertEqual(deactivate.call_count, int(accepted))
                self.assertEqual(prompt.call_count, int(terminal))

    def test_deactivation_failure_prevents_new_connection(self):
        for result in [Mock(returncode=1, stdout='', stderr='Error: secret'),
                       subprocess.TimeoutExpired('ipmitool', 2)]:
            with self.subTest(result=result), patch.object(runtime, 'Console') as console, \
                    patch.object(runtime, 'activate', side_effect=runtime.SOLBusy('busy')), \
                    patch.object(runtime.subprocess, 'run',
                          side_effect=result if isinstance(result, Exception) else None,
                          return_value=result), contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises((RuntimeError, TimeoutError)) as error:
                    runtime.run(self.args('force'), 'secret', None)
                self.assertNotIn('secret', str(error.exception))
                console.assert_called_once()
