"""Check Base64 upload checkpoints remain compatible after transport simplification."""
import argparse
import base64
import hashlib
from pathlib import Path
import subprocess
import tempfile
import unittest

from sol_tools.upload import upload_stage, resume_offset


class UploadResumeTest(unittest.TestCase):
    def test_existing_base64_checkpoint_identity(self):
        args = argparse.Namespace(remote_path='/tmp/payload', no_resume=False)
        digest = hashlib.sha256(b'payload').hexdigest()
        old_key = hashlib.sha256(('/tmp/payload\0base64\0' + digest).encode()).hexdigest()[:32]
        self.assertEqual(upload_stage(args, digest), '/tmp/.sol-upload-' + old_key)
        args.no_resume = True
        self.assertNotEqual(upload_stage(args, digest), '/tmp/.sol-upload-' + old_key)

    def test_prefix_verification_and_corruption_reset(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / 'source'
            source.write_bytes(bytes(range(256)) * 3)
            partial = root / 'payload.b64'
            partial.write_bytes(base64.b64encode(source.read_bytes()[:192]))
            def checked(command):
                return subprocess.run(['/bin/bash', '-c', command], check=True,
                                      capture_output=True, text=True).stdout
            self.assertEqual(resume_offset(checked, tmp, source), 192)
            partial.write_bytes(base64.b64encode(b'wrong!'))
            self.assertEqual(resume_offset(checked, tmp, source), 0)
            self.assertEqual(partial.read_bytes(), b'')


if __name__ == '__main__':
    unittest.main()
