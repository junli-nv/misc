#!/usr/bin/env python3
"""Upload and download files over SOL."""
from sol_tools.cli import main


if __name__ == '__main__':
    raise SystemExit(main('file'))
