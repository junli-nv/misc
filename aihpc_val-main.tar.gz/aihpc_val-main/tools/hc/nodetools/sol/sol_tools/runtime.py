"""Runtime support for the SOL tools."""
import argparse
import os
import pathlib
import sys
import time
import uuid

from .session import Console, interactive, setup_remote_terminal, marker_command, boundary, execute, SOLDisconnected
from .upload import upload
from .download import download
from .inventory import ping_host

def run(args, bmc_password, os_password):
    env = os.environ.copy()
    env.pop('IPMITOOL_PASSWORD', None)
    env.pop('SOL_OS_PASSWORD', None)
    env['IPMI_PASSWORD'] = bmc_password
    argv = [args.ipmitool, '-I', 'lanplus', '-H', args.host, '-U', args.bmc_user,
            '-E', '-C', str(args.cipher), '-L', 'ADMINISTRATOR', '-e', '~',
            'sol', 'activate']
    session_log = getattr(args, 'session_log', None)
    if session_log:
        label = f'{args.node_name} ({args.host})' if args.node_name and args.node_name != args.host else args.host
        session_log.record('EVENT', f'Connecting to BMC {label}')
    con = Console(argv, env, session_log)
    try:
        result, _, _ = con.expect([
            r'SOL Session operational',
            r'(?i)(?:SOL payload already active|Error[^\n]*|Unable[^\n]*)'
        ], args.connect_timeout)
        if result:
            raise RuntimeError('SOL activation failed (check BMC credentials, cipher, SOL enablement or an existing session)')
        if args.console:
            return interactive(con)
        con.send('\r')
        if args.interactive and not args.os_user:
            return interactive(con)
        deadline = time.monotonic() + args.connect_timeout
        sent_user = sent_password = False
        while True:
            result, _, _ = con.expect([
                r'(?im)(?:^|\n)[^\n]*login:\s*$',
                r'(?im)(?:^|\n)[^\n]*password:\s*$',
                r'(?i)Login incorrect|Authentication failure',
                args.prompt,
            ], max(0.01, deadline - time.monotonic()))
            if result == 0:
                if sent_user or not args.os_user:
                    raise RuntimeError('Linux login required/failed; supply --os-user and --os-password or SOL_OS_PASSWORD')
                con.send(args.os_user + '\r')
                sent_user = True
            elif result == 1:
                if not sent_user or sent_password or os_password is None:
                    raise RuntimeError('Unexpected password prompt; refusing to retry credentials')
                con.send_password(os_password)
                sent_password = True
            elif result == 2:
                raise RuntimeError('Linux authentication failed')
            else:
                con.auth_private = False
                break

        if args.interactive:
            setup_remote_terminal(con, args)
            con.send('\r')  # Refresh the prompt consumed during automatic login.
            return interactive(con)
        token = 'SOL_' + uuid.uuid4().hex
        con.send(marker_command(token) + '\r')
        con.expect([boundary(token)], args.connect_timeout)
        if args.download:
            return download(con, args)
        if args.upload:
            return upload(con, args)
        rc, output = execute(con, args.command, args)
        sys.stdout.write(output)
        sys.stdout.flush()
        if args.output:
            path = pathlib.Path(args.output)
            with path.open('x', encoding='utf-8') as file:
                file.write(output)
        return rc
    finally:
        con.close()
        if session_log:
            session_log.record('EVENT', 'SOL session closed')


def run_with_reconnect(args, bmc_password, os_password):
    try:
        return run(args, bmc_password, os_password)
    except SOLDisconnected:
        if not args.reconnect:
            print('SOL disconnected; automatic reconnection is disabled.', file=sys.stderr)
            return 0

    # Reboot may leave BIOS/GRUB on screen. Never replay login or command input.
    resumed = argparse.Namespace(**vars(args))
    resumed.console = True
    resumed.interactive = False
    resumed.os_user = None
    resumed.os_password = None
    for attempt in range(1, args.reconnect_attempts + 1):
        if getattr(args, 'session_log', None):
            args.session_log.record('EVENT', f'Reconnect attempt {attempt}/{args.reconnect_attempts}')
        print(f'SOL disconnected; reconnecting in {args.reconnect_delay:g}s '
              f'({attempt}/{args.reconnect_attempts}). Ctrl-C cancels.',
              file=sys.stderr, flush=True)
        time.sleep(args.reconnect_delay)
        if not args.skip_ping:
            reachable, error = ping_host(args.host, args.ping_timeout, args.ping_attempts, args.ping_interval)
            if not reachable:
                print(f'{args.host}: {error}; skipping SOL for this reconnect attempt', file=sys.stderr, flush=True)
                if getattr(args, 'session_log', None):
                    args.session_log.record('EVENT', f'ICMP check failed; skipped reconnect attempt {attempt}/{args.reconnect_attempts}')
                continue
        try:
            return run(resumed, bmc_password, None)
        except (RuntimeError, OSError, TimeoutError) as exc:
            print(f'Reconnect attempt ended: {exc}', file=sys.stderr, flush=True)
    raise RuntimeError('SOL reconnect attempts exhausted; check BMC availability and SOL session state')
