"""Runtime support for the SOL tools."""
import argparse
import json
import os
import pathlib
import re
import subprocess
import sys
import time
import uuid

from .session import Console, interactive, setup_remote_terminal, marker_command, boundary, execute, SOLDisconnected
from .upload import upload
from .download import download
from .inventory import ping_host


class SOLBusy(RuntimeError):
    """The BMC explicitly reported an already active SOL payload."""


def diagnostic(detail, *passwords):
    for secret in sorted({value for value in passwords if value}, key=len, reverse=True):
        detail = detail.replace(secret, '[REDACTED]')
    return json.dumps(detail.strip()[:2000], ensure_ascii=False)


def activate(con, timeout, bmc_password, os_password):
    """Retain transport diagnostics only before any automatic login input."""
    error_type = RuntimeError
    try:
        result, match, before = con.expect([
            r'SOL Session operational',
            r'(?i)(?:SOL payload already active|Error|Unable)[^\n]*\n',
        ], timeout)
    except (RuntimeError, TimeoutError) as exc:
        detail = con.buffer
        reason = str(exc)
        error_type = type(exc)
    else:
        if result == 0:
            return
        detail = before + match.group(0)
        reason = 'check BMC credentials, cipher, SOL enablement or an existing session'
    # Even startup output is untrusted. Redact credentials before truncating,
    # and escape control characters instead of rendering terminal sequences.
    if re.search(r'(?i)\bSOL payload already active\b', detail):
        error_type = SOLBusy
    message = f'SOL activation failed ({reason})'
    if detail.strip():
        message += ': ipmitool output: ' + diagnostic(detail, bmc_password, os_password)
    raise error_type(message) from None


def takeover(args, argv, env, bmc_password, os_password):
    message = f'{args.host}: SOL is occupied by an existing console session.'
    print(message, file=sys.stderr, flush=True)
    if getattr(args, 'session_log', None):
        args.session_log.record('EVENT', message)
    if args.sol_takeover == 'ask':
        if not sys.stdin.isatty():
            raise RuntimeError('SOL is occupied; cannot ask without a terminal. Use --sol-takeover force to disconnect the existing session')
        print('Disconnect the existing SOL session and reconnect? [y/N] ',
              file=sys.stderr, end='', flush=True)
        try:
            confirmed = input().strip().lower() in {'y', 'yes'}
        except EOFError:
            confirmed = False
        if not confirmed:
            raise RuntimeError('SOL takeover declined; existing session left connected')
    print(f'{args.host}: Disconnecting the existing SOL session, then reconnecting...',
          file=sys.stderr, flush=True)
    try:
        result = subprocess.run(argv[:-2] + ['sol', 'deactivate'], env=env,
                                stdin=subprocess.DEVNULL, capture_output=True,
                                text=True, errors='replace', timeout=args.connect_timeout)
    except subprocess.TimeoutExpired:
        raise TimeoutError('SOL deactivation timed out; session state is unknown') from None
    if result.returncode:
        detail = diagnostic(result.stdout + result.stderr, bmc_password, os_password)
        raise RuntimeError(f'SOL deactivation failed (exit {result.returncode}): {detail}')
    if getattr(args, 'session_log', None):
        args.session_log.record('EVENT', 'Existing SOL session deactivated; retrying activation once')


def run(args, bmc_password, os_password):
    env = os.environ.copy()
    env.pop('IPMITOOL_PASSWORD', None)
    env.pop('SOL_OS_PASSWORD', None)
    env['IPMI_PASSWORD'] = bmc_password
    argv = [args.ipmitool, '-I', 'lanplus', '-H', args.host, '-U', args.bmc_user,
            '-E', '-C', str(args.cipher), '-L', 'ADMINISTRATOR', '-e', '~',
            'sol', 'activate']
    session_log = getattr(args, 'session_log', None)
    if session_log:
        label = f'{args.node_name} ({args.host})' if args.node_name and args.node_name != args.host else args.host
        session_log.record('EVENT', f'Connecting to BMC {label}')
    con = Console(argv, env, session_log)
    try:
        try:
            activate(con, args.connect_timeout, bmc_password, os_password)
        except SOLBusy:
            con.close()
            takeover(args, argv, env, bmc_password, os_password)
            con = Console(argv, env, session_log)
            activate(con, args.connect_timeout, bmc_password, os_password)
        if args.console:
            return interactive(con)
        con.send('\r')
        if args.interactive and not args.os_user:
            return interactive(con)
        deadline = time.monotonic() + args.connect_timeout
        sent_user = sent_password = False
        while True:
            result, _, _ = con.expect([
                r'(?im)(?:^|\n)[^\n]*login:\s*$',
                r'(?im)(?:^|\n)[^\n]*password:\s*$',
                r'(?i)Login incorrect|Authentication failure',
                args.prompt,
            ], max(0.01, deadline - time.monotonic()))
            if result == 0:
                if sent_user or not args.os_user:
                    raise RuntimeError('Linux login required/failed; supply --os-user and --os-password or SOL_OS_PASSWORD')
                con.send(args.os_user + '\r')
                sent_user = True
            elif result == 1:
                if not sent_user or sent_password or os_password is None:
                    raise RuntimeError('Unexpected password prompt; refusing to retry credentials')
                con.send_password(os_password)
                sent_password = True
            elif result == 2:
                raise RuntimeError('Linux authentication failed')
            else:
                con.auth_private = False
                break

        if args.interactive:
            setup_remote_terminal(con, args)
            con.send('\r')  # Refresh the prompt consumed during automatic login.
            return interactive(con)
        token = 'SOL_' + uuid.uuid4().hex
        con.send(marker_command(token) + '\r')
        con.expect([boundary(token)], args.connect_timeout)
        if args.download:
            return download(con, args)
        if args.upload:
            return upload(con, args)
        rc, output = execute(con, args.command, args)
        sys.stdout.write(output)
        sys.stdout.flush()
        if args.output:
            path = pathlib.Path(args.output)
            with path.open('x', encoding='utf-8') as file:
                file.write(output)
        return rc
    finally:
        con.close()
        if session_log:
            session_log.record('EVENT', 'SOL session closed')


def run_with_reconnect(args, bmc_password, os_password):
    try:
        return run(args, bmc_password, os_password)
    except SOLDisconnected:
        if not args.reconnect:
            print('SOL disconnected; automatic reconnection is disabled.', file=sys.stderr)
            return 0

    # Reboot may leave BIOS/GRUB on screen. Never replay login or command input.
    resumed = argparse.Namespace(**vars(args))
    resumed.console = True
    resumed.interactive = False
    resumed.os_user = None
    resumed.os_password = None
    for attempt in range(1, args.reconnect_attempts + 1):
        if getattr(args, 'session_log', None):
            args.session_log.record('EVENT', f'Reconnect attempt {attempt}/{args.reconnect_attempts}')
        print(f'SOL disconnected; reconnecting in {args.reconnect_delay:g}s '
              f'({attempt}/{args.reconnect_attempts}). Ctrl-C cancels.',
              file=sys.stderr, flush=True)
        time.sleep(args.reconnect_delay)
        if not args.skip_ping:
            reachable, error = ping_host(args.host, args.ping_timeout, args.ping_attempts, args.ping_interval)
            if not reachable:
                print(f'{args.host}: {error}; skipping SOL for this reconnect attempt', file=sys.stderr, flush=True)
                if getattr(args, 'session_log', None):
                    args.session_log.record('EVENT', f'ICMP check failed; skipped reconnect attempt {attempt}/{args.reconnect_attempts}')
                continue
        try:
            return run(resumed, bmc_password, None)
        except (RuntimeError, OSError, TimeoutError) as exc:
            print(f'Reconnect attempt ended: {exc}', file=sys.stderr, flush=True)
    raise RuntimeError('SOL reconnect attempts exhausted; check BMC availability and SOL session state')
