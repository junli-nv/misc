"""Cli support for the SOL tools."""
import math
import os
import pathlib
import re
import shutil
import signal
import sys

from .defaults import apply_defaults
from .inventory import parse_ini_inventory, select_nodes, prompt_credential, validate_ping_options, ping_host
from .session import replay, automatic_log_path, SessionLog
from .bmc import bmc_command, bmc_operation, run_bmc_single
from .runtime import run_with_reconnect
from .batch import run_batch
from .completion import bash_completion

from .validation import validate_preflight

from .arguments import parser_for_tool, parse_operation, print_brief_help

def _main(tool):
    parser = parser_for_tool(tool)
    if len(sys.argv) == 1:
        print_brief_help(parser)
        return 0
    args = parse_operation(parser)
    if args.bash_completion:
        print(bash_completion(parser), end='')
        return 0
    try:
        bmc_command(args)
    except ValueError as exc:
        parser.error(str(exc))
    nodes = None
    if not args.replay:
        try:
            nodes = select_nodes(args)
            settings = parse_ini_inventory(args.config.read_text(encoding="utf-8"))["runtime_defaults"]
            apply_defaults(args, settings)
        except (OSError, ValueError, re.error) as exc:
            parser.error(str(exc))
        if len(nodes) > 1 or args.result_dir is not None or args.list_hosts or args.check_hosts:
            if args.interactive or args.console:
                parser.error('Console/login requires exactly one inventory node')
            if (args.output or args.log_file is not None or args.log_dir != pathlib.Path('logs')):
                parser.error('Multiple nodes use --result-dir instead of --output/--log-file/--log-dir')
            return run_batch(tool, parser, args, nodes)
        args.host = nodes[0]['host']
    try:
        validate_preflight(args)
    except (OSError, ValueError) as exc:
        parser.error(str(exc))
    if bmc_operation(args):
        try:
            return run_bmc_single(args, nodes[0])
        except (OSError, ValueError) as exc:
            parser.error(str(exc))
    if not any((args.command is not None, args.command_file, args.upload, args.download, args.interactive, args.console, args.replay)):
        parser.error('Choose an operation, or use --list-hosts to preview inventory nodes')
    if not math.isfinite(args.replay_speed) or not .125 <= args.replay_speed <= 64:
        parser.error('--replay-speed must be between 0.125 and 64')
    if args.replay:
        if (args.hosts is not None or args.group is not None or
                args.jobs is not None or args.result_dir is not None or
                args.list_hosts or args.check_hosts):
            parser.error('Inventory selection and concurrency options do not apply to local replay')
        if args.no_resume:
            parser.error('--no-resume cannot be used with --replay')
        if args.rows is not None or args.cols is not None or args.term is not None or args.no_terminal_setup:
            parser.error('Terminal setup options are not used with --replay')
        if args.skip_ping or args.ping_jobs != 32 or args.ping_timeout != 2 or args.ping_attempts != 3 or args.ping_interval != 0.5:
            parser.error('Ping options are not used with --replay')
        if args.replay_export and (args.replay_inputs or args.replay_speed != 1):
            parser.error('--replay-export cannot be combined with --replay-inputs or --replay-speed')
        if args.log_compress is not None:
            parser.error('Compression options control recording, not replay; pass the file to --replay')
        if any(value is not None for value in (args.config, args.host, args.bmc_user, args.bmc_password,
                                               args.os_user, args.os_password, args.log_file,
                                               args.output, args.remote_path, args.reconnect)) or args.overwrite or args.mode != '600' or args.log_dir != pathlib.Path('logs'):
            parser.error('--replay cannot be combined with credentials, logging, upload or reconnect options')
        try:
            return replay(args)
        except (OSError, ValueError) as exc:
            print(f'ERROR: {exc}', file=sys.stderr)
            return 125
        except KeyboardInterrupt:
            print('\nReplay interrupted.', file=sys.stderr)
            return 130
    if args.replay_export or args.replay_inputs or args.replay_speed != 1:
        parser.error('--replay-export, --replay-speed and --replay-inputs require --replay')
    config = nodes[0]
    args.node_name = config['name']
    if config:
        for field in ('host', 'bmc_user', 'os_user'):
            if field == 'os_user' and args.console:
                continue
            if getattr(args, field) is None:
                setattr(args, field, config.get(field))
    if not args.host:
        parser.error('Specify --hosts or provide a single-node inventory')
    try:
        if args.bmc_user is None:
            args.bmc_user = prompt_credential('bmc_user', args.host)
    except ValueError as exc:
        parser.error(str(exc))
    bmc_password = args.bmc_password if args.bmc_password is not None else os.environ.get('IPMI_PASSWORD')
    if bmc_password is None:
        bmc_password = config.get('bmc_password')
    if bmc_password is None:
        try:
            bmc_password = prompt_credential('bmc_password', args.host)
        except ValueError as exc:
            parser.error(str(exc))
    os_password = None if args.console else (
        args.os_password if args.os_password is not None else os.environ.get('SOL_OS_PASSWORD'))
    if not args.console and os_password is None:
        os_password = config.get('os_password')
    if args.os_user and os_password is None:
        try:
            os_password = prompt_credential('os_password', args.host)
        except ValueError as exc:
            parser.error(str(exc))
    for field, value in (('bmc_user', args.bmc_user), ('bmc_password', bmc_password),
                         ('os_user', args.os_user), ('os_password', os_password)):
        if value is not None and (any(c in value for c in '\x00\r\n') or
                                  (field.endswith('_user') and not value.strip())):
            parser.error(f'Invalid {field}')
    if not args.host or not args.bmc_user:
        parser.error('host and bmc_user are required via CLI or --config, except with --replay')
    if args.no_log and args.log_compress:
        parser.error('--log-compress cannot be combined with --no-log')
    if args.log_compress is None:
        args.log_compress = not args.no_log
    if args.log_compress is False and isinstance(args.log_file, pathlib.Path) and args.log_file.suffix.lower() == '.gz':
        parser.error('--no-log-compress requires a log filename without .gz')
    if not args.no_log and args.log_file is None:
        args.log_file = True
    args.auto_log = args.log_file is True
    if args.log_dir != pathlib.Path('logs') and not args.auto_log:
        parser.error('--log-dir requires automatic log naming; omit --no-log and explicit --log-file paths')
    if args.auto_log:
        args.log_file = automatic_log_path(args.host, args.log_dir, args.log_compress, args.node_name)
    elif args.log_compress and args.log_file and args.log_file.suffix.lower() != '.gz':
        args.log_file = pathlib.Path(str(args.log_file) + '.gz')
    if args.reconnect is not None and not (args.interactive or args.console):
        parser.error('--reconnect/--no-reconnect requires --interactive or --console')
    if args.reconnect is None:
        args.reconnect = bool(args.interactive or args.console)
    if args.reconnect_attempts < 1 or not 0 <= args.reconnect_delay <= 60:
        parser.error('reconnect attempts must be positive and delay must be between 0 and 60 seconds')
    if args.console and (args.os_user is not None or args.os_password is not None):
        parser.error('--console does not use OS credentials; omit --os-user and --os-password')
    if args.interactive or args.console:
        if not sys.stdin.isatty() or not sys.stdout.isatty():
            parser.error('--interactive/--console requires a terminal on stdin and stdout')
        if args.output:
            parser.error('--output is not supported with --interactive or --console')
    terminal_options = args.rows is not None or args.cols is not None or args.term is not None
    if (terminal_options or args.no_terminal_setup) and not args.interactive:
        parser.error('Terminal setup options require --interactive with automatic Linux login')
    if terminal_options and (not args.os_user or args.no_terminal_setup):
        parser.error('--rows/--cols/--term require automatic login and cannot be combined with --no-terminal-setup')
    if (args.rows is None) != (args.cols is None):
        parser.error('--rows and --cols must be supplied together')
    if args.rows is not None and not (1 <= args.rows <= 65535 and 1 <= args.cols <= 65535):
        parser.error('--rows and --cols must be between 1 and 65535')
    if args.term is not None and not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.+-]*', args.term):
        parser.error('Invalid --term value')
    if not shutil.which(args.ipmitool):
        parser.error('ipmitool is not installed or not on PATH')
    try:
        validate_ping_options(args)
    except ValueError as exc:
        parser.error(str(exc))
    if args.log_file and args.log_file.exists():
        parser.error('--log-file already exists; choose a new path')
    if args.log_file and args.output and args.log_file.resolve() == args.output.resolve():
        parser.error('--log-file and --output must use different paths')
    if args.download and args.log_file and args.log_file.resolve() == args.local_path.resolve():
        parser.error('Download destination and --log-file must use different paths')
    if not args.skip_ping:
        reachable, error = ping_host(args.host, args.ping_timeout, args.ping_attempts, args.ping_interval)
        if not reachable:
            print(f'ERROR: {args.host}: {error}', file=sys.stderr)
            return 125
    args.session_log = None
    def terminate_session(signum, frame):
        raise KeyboardInterrupt
    previous_sigterm = signal.signal(signal.SIGTERM, terminate_session)
    try:
        if args.log_file:
            if args.auto_log:
                args.log_file.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            args.session_log = SessionLog(args.log_file, host=args.host, name=args.node_name or args.host)
            args.session_log.record('EVENT', 'Logging started')
            print(f'SOL I/O log: {args.log_file.resolve()} (manual input, including passwords, is recorded).',
                  file=sys.stderr, flush=True)
        return run_with_reconnect(args, bmc_password, os_password)
    except TimeoutError as exc:
        print(f'ERROR: {exc}. Remote command may still be running; not retried.', file=sys.stderr)
        return 124
    except (RuntimeError, OSError, ValueError) as exc:
        print(f'ERROR: {exc}', file=sys.stderr)
        return 125
    except KeyboardInterrupt:
        print('Interrupted; remote command may still be running.', file=sys.stderr)
        return 130
    finally:
        signal.signal(signal.SIGTERM, previous_sigterm)
        if args.session_log:
            args.session_log.close()

def main(tool):
    try:
        return _main(tool)
    except KeyboardInterrupt:
        print('\nInterrupted.', file=sys.stderr)
        return 130
