"""Typed inventory runtime defaults, separate from credentials and target selection."""
import math

DEFAULT_JOBS = 8


def boolean(value):
    values = {'true': True, 'yes': True, '1': True, 'false': False, 'no': False, '0': False}
    try:
        return values[value.lower()]
    except KeyError:
        raise ValueError('expected true/false, yes/no or 1/0') from None


# Exclude operations, selectors and output paths; takeover is an explicit policy.
TYPES = {
    'jobs': int, 'ping_jobs': int, 'timeout': float, 'connect_timeout': float,
    'ping_timeout': float, 'ping_attempts': int, 'ping_interval': float,
    'cipher': int, 'ipmitool': str, 'skip_ping': boolean,
    'no_log': boolean, 'log_compress': boolean,
    'reconnect': boolean, 'reconnect_attempts': int, 'reconnect_delay': float,
    'sol_takeover': str,
}


def parse_default(key, value):
    if key not in TYPES:
        raise ValueError(f'Unknown [sol:defaults] option: {key}')
    try:
        result = TYPES[key](value)
        if key == 'sol_takeover' and result not in {'ask', 'force'}:
            raise ValueError('expected ask or force')
        if isinstance(result, float) and not math.isfinite(result):
            raise ValueError('must be finite')
        if key in {'jobs', 'ping_jobs', 'timeout', 'connect_timeout', 'ping_timeout',
                   'ping_attempts', 'reconnect_attempts'} and result <= 0:
            raise ValueError('must be positive')
        if key in {'ping_interval', 'cipher', 'reconnect_delay'} and result < 0:
            raise ValueError('must be nonnegative')
        if key == 'reconnect_delay' and result > 60:
            raise ValueError('must not exceed 60')
        if key == 'ipmitool' and (not result.strip() or any(c in result for c in '\x00\r\n')):
            raise ValueError('expected an executable name or path')
        return result
    except ValueError as exc:
        raise ValueError(f'Invalid [sol:defaults] {key}: {exc}') from None


def apply_defaults(args, settings):
    """CLI > applicable inventory defaults > built-in defaults."""
    explicit = args.explicit_options
    direct_bmc = args.power is not None or args.bmc_log is not None or args.bootdev is not None
    for key, value in settings.items():
        if key in explicit:
            continue
        if key.startswith('reconnect') and not (args.console or args.interactive):
            continue
        if key in {'no_log', 'log_compress'}:
            if direct_bmc or args.list_hosts or args.check_hosts:
                continue
            if key == 'no_log' and 'log_file' in explicit:
                continue
            if key == 'log_compress' and args.no_log:
                continue
        setattr(args, key, value)
    if not direct_bmc and args.no_log and 'log_compress' not in explicit:
        args.log_compress = False
