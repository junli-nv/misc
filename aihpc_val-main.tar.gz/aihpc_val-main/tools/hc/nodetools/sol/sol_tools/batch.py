"""Batch support for the SOL tools."""
import json
from datetime import datetime
import os
import re
import shutil
import shlex
import signal
import sys
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import subprocess
import threading

from .defaults import DEFAULT_JOBS
from .inventory import FIELDS, validate_ping_options, ping_host, prompt_credential
from .bmc import bmc_command, bmc_operation
from .session import node_file_label
from .validation import validate_preflight

def run_batch(tool, parser, args, nodes):
    """Run an already-resolved selection; never reparse CLI arguments."""
    args.inventory = args.config
    args.jobs = DEFAULT_JOBS if args.jobs is None else args.jobs
    try:
        validate_preflight(args, batch=True)
        if args.no_log and args.log_compress:
            raise ValueError('--log-compress cannot be combined with --no-log')
        if args.log_compress is None:
            args.log_compress = not args.no_log
        bmc_command(args)
        direct_bmc = bmc_operation(args)
        hosts = [node['host'] for node in nodes]
        validate_ping_options(args)
        if args.jobs < 1:
            raise ValueError('--jobs must be positive')
        if args.check_hosts:
            if args.skip_ping or args.list_hosts or args.command is not None or args.command_file or args.upload or args.download or direct_bmc:
                raise ValueError('--check-hosts cannot be combined with commands, --list-hosts or --skip-ping')
            failed = 0
            cancelled = threading.Event()
            previous = {sig: signal.signal(sig, lambda signum, frame: cancelled.set())
                        for sig in (signal.SIGINT, signal.SIGTERM)}
            try:
                with ThreadPoolExecutor(max_workers=min(args.ping_jobs, len(hosts))) as pool:
                    futures = {pool.submit(ping_host, n['host'], args.ping_timeout, args.ping_attempts, args.ping_interval, cancelled): n for n in nodes}
                    for future in as_completed(futures):
                        if cancelled.is_set():
                            continue
                        node = futures[future]
                        reachable, error = future.result()
                        print(f'{node["name"]}\t{node["host"]}\t' + ('reachable' if reachable else f'ERROR: {error}'), flush=True)
                        failed += not reachable
            finally:
                for sig, handler in previous.items():
                    signal.signal(sig, handler)
            if cancelled.is_set():
                print('Ping checks interrupted.', file=sys.stderr)
                return 130
            print(f'Ping summary: {len(hosts) - failed} reachable, {failed} failed, {len(hosts)} total', flush=True)
            return 1 if failed else 0
        if args.list_hosts:
            for node in nodes:
                print(f'{node["name"]}\t{node["host"]}\t{node.get("group") or "-"}')
            return 0
        if args.command is None and args.command_file is None and args.upload is None and args.download is None and not direct_bmc:
            raise ValueError('Supply --command, --command-file, --upload, --power or --bmc-log')
        if args.download:
            command = args.download
            args.local_path = args.local_path.resolve()
            args.local_path.mkdir(mode=0o700, parents=True, exist_ok=True)
        elif not args.upload:
            command = shlex.join(bmc_command(args)) if direct_bmc else args.command
        credentials_by_host = {}
        prompted = {}
        for node in nodes:
            credentials = {}
            for field in sorted({'bmc_user', 'bmc_password'} if direct_bmc else FIELDS):
                value = getattr(args, field)
                if value is None and field.endswith('_password'):
                    value = os.environ.get('IPMI_PASSWORD' if field == 'bmc_password' else 'SOL_OS_PASSWORD')
                if value is None:
                    value = node.get(field)
                if value is None:
                    # Prompt once per missing group field, before starting any workers.
                    scope = node.get('group') or node['host']
                    key = (node.get('group') is not None, scope, field)
                    if key not in prompted:
                        prompted[key] = prompt_credential(field, f'Group {scope}' if node.get('group') else scope)
                    value = prompted[key]
                if field.endswith('_user') and not value.strip():
                    raise ValueError(f'Empty {field} for {node["host"]}')
                if any(c in value for c in '\x00\r\n'):
                    raise ValueError(f'Invalid control character in {field}')
                credentials[field] = value
            credentials_by_host[node['host']] = credentials
        from shutil import which
        ipmitool = which(args.ipmitool)
        if not ipmitool:
            raise ValueError('ipmitool is not installed or not on PATH')
        directory = args.result_dir or Path('batch-logs') / (
            'run_' + datetime.now().astimezone().strftime('%Y%m%d_%H%M%S%z') + '_' + uuid.uuid4().hex[:8])
        directory = directory.resolve()
        directory.mkdir(mode=0o700, parents=True, exist_ok=False)
        snapshot = directory / ('download-source.txt' if args.download else 'ipmi-operation.txt' if direct_bmc else 'upload.payload' if args.upload else 'command.sh')
        fd = os.open(snapshot, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, 'wb') as output:
            if args.upload:
                with args.upload.open('rb') as source:
                    shutil.copyfileobj(source, output)
            else:
                output.write(command.encode('utf-8'))
    except (OSError, ValueError, re.error) as exc:
        parser.error(str(exc))

    stopped = threading.Event()
    lock = threading.RLock()
    processes = set()
    results = []
    ping_results = {}

    def worker(index, host):
        credentials = credentials_by_host[host]
        env = os.environ.copy()
        env['IPMI_PASSWORD'] = credentials['bmc_password']
        env.pop('SOL_OS_PASSWORD', None)
        if not direct_bmc:
            env['SOL_OS_PASSWORD'] = credentials['os_password']
        env.pop('IPMITOOL_PASSWORD', None)
        started = time.monotonic()
        node_name = nodes[index - 1]['name']
        folder = directory / f'{index:04d}_{node_file_label(host, node_name)}'
        result = {'host': host, 'name': nodes[index - 1]['name'], 'status': 'cancelled', 'exit_code': None,
                  'duration_seconds': 0, 'directory': str(folder)}
        if stopped.is_set():
            return result
        if not args.skip_ping:
            reachable, error = ping_results[host]
            if not reachable:
                result.update(status='unreachable', exit_code=125, error=error,
                              duration_seconds=round(time.monotonic() - started, 3))
                label = f'{node_name} ({host})' if node_name != host else host
                print(f'ERROR: {label}: {error}', file=sys.stderr, flush=True)
                return result
        try:
            folder.mkdir(mode=0o700)
            stdout_fd = os.open(folder / 'stdout.txt', os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(stdout_fd, 'w') as out:
                stderr_fd = os.open(folder / 'stderr.txt', os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
                with os.fdopen(stderr_fd, 'w') as err:
                    argv = [sys.executable, str(Path(__file__).resolve().parent.parent / f'sol_{tool}.py'),
                            '--inventory', str(args.config), '--hosts', host, '--node-name=' + node_name, '--skip-ping', '--bmc-user=' + credentials['bmc_user'],
                            '--timeout', str(args.timeout), '--connect-timeout', str(args.connect_timeout),
                            '--cipher', str(args.cipher), '--ipmitool', ipmitool, '--prompt', args.prompt]
                    if not direct_bmc:
                        argv += ['--os-user=' + credentials['os_user']]
                    if direct_bmc:
                        if args.bootdev:
                            argv += ['--bootdev', args.bootdev]
                            if args.uefi:
                                argv += ['--uefi']
                            if args.persistent:
                                argv += ['--persistent']
                        else:
                            argv += ['--power', args.power] if args.power else ['--bmc-log', args.bmc_log]
                        if args.sel_last is not None:
                            argv += ['--sel-last', str(args.sel_last)]
                    elif args.download:
                        target_dir = args.local_path / folder.name
                        target_dir.mkdir(mode=0o700, exist_ok=True)
                        target = target_dir / Path(args.download).name
                        result['download_path'] = str(target)
                        argv += ['--download', args.download, '--local-path', str(target)]
                        if args.no_resume:
                            argv += ['--no-resume']
                        if args.overwrite:
                            argv += ['--overwrite']
                    elif args.upload:
                        argv += ['--upload', str(snapshot), '--remote-path', args.remote_path, '--mode', args.mode]
                        if args.no_resume:
                            argv += ['--no-resume']
                        if args.overwrite:
                            argv += ['--overwrite']
                    else:
                        argv += ['--command-file', str(snapshot)]
                    log_name = 'sol.jsonl.gz' if args.log_compress else 'sol.jsonl'
                    argv += ['--no-log'] if args.no_log or direct_bmc else ['--log-file', str(folder / log_name)]
                    if not direct_bmc and not args.no_log:
                        argv += ['--log-compress' if args.log_compress else '--no-log-compress']
                    with lock:
                        if stopped.is_set():
                            return result
                        proc = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=out, stderr=err,
                                                env=env, start_new_session=True)
                        processes.add(proc)
                    try:
                        rc = proc.wait()
                    finally:
                        with lock:
                            processes.discard(proc)
                    result.update(exit_code=rc, status='ok' if rc == 0 else 'failed')
                    if stopped.is_set() and rc != 0:
                        result['status'] = 'cancelled'
        except OSError as exc:
            result.update(status='failed', error=str(exc))
        result['duration_seconds'] = round(time.monotonic() - started, 3)
        return result

    def stop(signum, frame):
        stopped.set()
        # Children handle SIGTERM and close their SOL transport in finally.
        with lock:
            for proc in list(processes):
                try:
                    proc.terminate()
                except ProcessLookupError:
                    pass

    previous = {sig: signal.signal(sig, stop) for sig in (signal.SIGINT, signal.SIGTERM)}
    print(f'Running on {len(hosts)} hosts, concurrency={min(args.jobs, len(hosts))}; results: {directory}', flush=True)
    try:
        if not args.skip_ping:
            print(f'Checking ICMP: concurrency={min(args.ping_jobs, len(hosts))}', flush=True)
            def probe(host):
                if stopped.is_set():
                    return False, 'Check cancelled'
                return ping_host(host, args.ping_timeout, args.ping_attempts, args.ping_interval, stopped)
            with ThreadPoolExecutor(max_workers=min(args.ping_jobs, len(hosts))) as ping_pool:
                checks = {ping_pool.submit(probe, host): host for host in hosts}
                for future in as_completed(checks):
                    host = checks[future]
                    ping_results[host] = future.result()
        with ThreadPoolExecutor(max_workers=min(args.jobs, len(hosts))) as pool:
            futures = [pool.submit(worker, index, host) for index, host in enumerate(hosts, 1)]
            for future in as_completed(futures):
                result = future.result()
                results.append(result)
                label = (f'{result["name"]} ({result["host"]})'
                         if result.get('name') and result['name'] != result['host'] else result['host'])
                print(f'{label}: {result["status"]} (exit={result["exit_code"]})', flush=True)
                summary = {'hosts': len(hosts), 'completed': len(results),
                           'interrupted': stopped.is_set(), 'results': sorted(results, key=lambda r: hosts.index(r['host']))}
                temp = directory / 'results.tmp'
                fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
                with os.fdopen(fd, 'w') as output:
                    json.dump(summary, output, indent=2)
                    output.write('\n')
                temp.replace(directory / 'results.json')
    finally:
        for sig, handler in previous.items():
            signal.signal(sig, handler)
    return 130 if stopped.is_set() else (0 if all(r['status'] == 'ok' for r in results) else 1)
