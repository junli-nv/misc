"""Inventory support for the SOL tools."""
import getpass
import math
import os
import pathlib
import re
import shutil
import shlex
import sys
import time
import subprocess
import threading

from .defaults import parse_default

FIELDS = {'bmc_user', 'bmc_password', 'os_user', 'os_password'}
MAX_HOSTS = 10000

def ini_value(value):
    """Literal INI value, optionally quoted using shell-style quoting."""
    value = value.strip()
    if value.startswith(('"', "'")):
        try:
            parts = shlex.split(value, comments=False)
        except ValueError:
            raise ValueError('Invalid quoted INI value') from None
        if len(parts) != 1:
            raise ValueError('Expected one quoted INI value')
        return parts[0]
    return value


def expand_hostlist(expression):
    """Expand numeric Slurm-style brackets, preserving zero padding (bounded)."""
    terms, depth, start = [], 0, 0
    for pos, char in enumerate(expression):
        if char == '[':
            depth += 1
            if depth > 1:
                raise ValueError('Nested hostlist brackets are not supported')
        elif char == ']':
            depth -= 1
            if depth < 0:
                raise ValueError('Unbalanced hostlist brackets')
        elif char == ',' and depth == 0:
            terms.append(expression[start:pos].strip())
            start = pos + 1
    if depth:
        raise ValueError('Unbalanced hostlist brackets')
    terms.append(expression[start:].strip())
    expanded = []
    for term in terms:
        if not term:
            raise ValueError('Empty hostlist entry')
        values = ['']
        cursor = 0
        for match in re.finditer(r'\[([^\]]*)\]', term):
            literal = term[cursor:match.start()]
            numbers = []
            for item in match.group(1).split(','):
                spec = re.fullmatch(r'([0-9]+)(?:-([0-9]+))?', item)
                if not spec:
                    raise ValueError('Hostlist brackets require numbers or ascending numeric ranges')
                low, high = spec.groups()
                if len(low) > 20 or (high is not None and len(high) > 20):
                    raise ValueError('Hostlist number is too long')
                if high is None:
                    numbers.append(low)
                else:
                    first, last = int(low), int(high)
                    if last < first or last - first + 1 + len(numbers) > MAX_HOSTS:
                        raise ValueError('Descending or oversized hostlist range')
                    width = len(low) if len(low) > 1 and low.startswith('0') else 0
                    numbers.extend(str(n).zfill(width) for n in range(first, last + 1))
            if len(values) * len(numbers) + len(expanded) > MAX_HOSTS:
                raise ValueError(f'Hostlist expansion exceeds {MAX_HOSTS} entries')
            values = [prefix + literal + number for prefix in values for number in numbers]
            cursor = match.end()
        expanded.extend(value + term[cursor:] for value in values)
        if len(expanded) > MAX_HOSTS:
            raise ValueError(f'Hostlist expansion exceeds {MAX_HOSTS} entries')
    return list(dict.fromkeys(expanded))


def parse_ini_inventory(source):
    """Small Ansible-style subset; no interpolation, plugins or children groups."""
    defaults, groups, standalone = {}, {}, []
    runtime_defaults = {}
    section = None
    seen_sections = set()
    for lineno, raw in enumerate(source.splitlines(), 1):
        line = raw.strip()
        if not line or line.startswith(('#', ';')):
            continue
        if line.startswith('['):
            match = re.fullmatch(r'\[([^\]]+)\]\s*(?:[#;].*)?', line)
            if not match:
                raise ValueError(f'Invalid inventory section at line {lineno}')
            section = match.group(1).strip()
            if not section or section in seen_sections:
                raise ValueError(f'Empty or duplicate inventory section at line {lineno}')
            seen_sections.add(section)
            if section == 'sol:defaults':
                continue
            if ':' in section and not section.endswith(':vars'):
                raise ValueError('Only group sections and :vars sections are supported')
            group = section.removesuffix(':vars')
            if not group or ':' in group:
                raise ValueError(f'Invalid group at line {lineno}')
            if group != 'all':
                groups.setdefault(group, {'nodes': []})
            continue
        if section is None:
            raise ValueError(f'Inventory entry before a section at line {lineno}')
        if section == 'sol:defaults':
            key, sep, value = line.partition('=')
            key = key.strip()
            if not sep or key in runtime_defaults:
                raise ValueError(f'Invalid or duplicate runtime default at line {lineno}')
            runtime_defaults[key] = parse_default(key, ini_value(value))
        elif section.endswith(':vars'):
            key, sep, value = line.partition('=')
            key = key.strip()
            if not sep or key not in FIELDS:
                raise ValueError(f'Invalid credential assignment at line {lineno}')
            # Whole-line comments only; unquoted passwords retain #, %, ; and backslashes.
            value = value.strip()
            try:
                value = ini_value(value)
            except ValueError:
                raise ValueError(f'Invalid quoted value at line {lineno}') from None
            target = defaults if section == 'all:vars' else groups[section[:-5]]
            if key in target:
                raise ValueError(f'Duplicate credential assignment at line {lineno}')
            target[key] = value
        else:
            try:
                parts = shlex.split(line, comments=True)
            except ValueError:
                raise ValueError(f'Invalid host entry quoting at line {lineno}') from None
            node = {'name': parts[0], 'host': parts[0]}
            assigned = set()
            for item in parts[1:]:
                key, sep, value = item.partition('=')
                if not sep or key not in FIELDS | {'host'} or key in assigned:
                    raise ValueError(f'Invalid or duplicate host field at line {lineno}')
                assigned.add(key)
                node[key] = value
            (standalone if section == 'all' else groups[section]['nodes']).append(node)
    return {'defaults': defaults, 'groups': groups, 'nodes': standalone, 'runtime_defaults': runtime_defaults}


def load_inventory(path):
    source = path.read_text(encoding='utf-8')
    if source.lstrip().startswith('{'):
        raise ValueError('JSON inventories are no longer supported; use inventory.example.ini')
    data = parse_ini_inventory(source)
    if not isinstance(data, dict) or set(data) - {'defaults', 'nodes', 'groups', 'runtime_defaults'}:
        raise ValueError('Inventory must contain only defaults, groups and nodes')
    defaults = data.get('defaults', {})
    nodes = data.get('nodes', [])
    if not isinstance(defaults, dict) or set(defaults) - FIELDS:
        raise ValueError('Invalid inventory defaults fields')
    def validate_credentials(source):
        for field in FIELDS & source.keys():
            if (not isinstance(source[field], str) or any(c in source[field] for c in '\x00\r\n') or
                    (field.endswith('_user') and not source[field].strip())):
                raise ValueError(f'Invalid inventory credential field: {field}')
    validate_credentials(defaults)
    if not isinstance(nodes, list):
        raise ValueError('Inventory nodes must be a list')
    groups = data.get('groups', {})
    if not isinstance(groups, dict):
        raise ValueError('Inventory groups must be an object keyed by group name')
    entries = [(node, defaults, None) for node in nodes]
    for group_name, group in groups.items():
        if not group_name.strip() or any(c in group_name for c in '\x00\r\n'):
            raise ValueError('Invalid inventory group name')
        if not isinstance(group, dict) or set(group) - (FIELDS | {'nodes'}):
            raise ValueError('Invalid inventory group fields')
        validate_credentials(group)
        if not isinstance(group.get('nodes'), list) or not group['nodes']:
            raise ValueError('Each inventory group requires a nonempty nodes list')
        inherited = {**defaults, **{k: v for k, v in group.items() if k in FIELDS}}
        entries.extend((node, inherited, group_name) for node in group['nodes'])
    if not entries:
        raise ValueError('Inventory must contain at least one node')
    expanded_entries = []
    for node, inherited, group_name in entries:
        if isinstance(node, str):
            node = {'host': node}
        if not isinstance(node, dict) or set(node) - (FIELDS | {'name', 'host'}):
            raise ValueError('Invalid inventory node fields')
        if not isinstance(node.get('host'), str) or not isinstance(node.get('name', node['host']), str):
            raise ValueError('Inventory host and name must be strings')
        node_hosts = expand_hostlist(node['host'])
        node_names = expand_hostlist(node.get('name', node['host']))
        if len(node_hosts) != len(node_names):
            raise ValueError('Node name and BMC host ranges must expand to the same count')
        expanded_entries.extend(({**node, 'host': h, 'name': n}, inherited, group_name)
                                for h, n in zip(node_hosts, node_names))
        if len(expanded_entries) > MAX_HOSTS:
            raise ValueError(f'Inventory exceeds {MAX_HOSTS} nodes')
    names, hosts, validated = set(), set(), []
    for node, inherited, group_name in expanded_entries:
        host = node.get('host', '')
        name = node.get('name', host)
        if not isinstance(host, str) or not re.fullmatch(r'[A-Za-z0-9_.:%-]+', host) or host.startswith('-'):
            raise ValueError('Each inventory node requires a valid BMC host')
        if not isinstance(name, str) or not name.strip() or any(c in name for c in '\x00\r\n'):
            raise ValueError('Invalid inventory node name')
        if name in names or host in hosts:
            raise ValueError('Inventory names and BMC hosts must be unique')
        names.add(name)
        hosts.add(host)
        validate_credentials(node)
        combined = {**inherited, **node, 'name': name, 'group': group_name}
        validated.append(combined)
    return validated


def default_config_path():
    return pathlib.Path(__file__).resolve().parent.parent / 'inventory.ini'


def prompt_credential(field, label):
    if not sys.stdin.isatty():
        raise ValueError(f'Missing {field} for {label}; no interactive terminal. Supply CLI, environment or INI credentials')
    prompt = f'{label} {field}: '
    try:
        value = getpass.getpass(prompt) if field.endswith('_password') else input(prompt)
    except EOFError:
        raise ValueError(f'No input received for {field}') from None
    if any(c in value for c in '\x00\r\n') or (field.endswith('_user') and not value.strip()):
        raise ValueError(f'Invalid or empty {field}')
    return value


def ping_host(host, timeout=2, attempts=3, interval=0.5, cancelled=None):
    """Bounded ICMP probes; any reply passes, failures do not prove a host offline."""
    cancelled = cancelled if cancelled is not None else threading.Event()
    binary = 'ping6' if ':' in host and sys.platform == 'darwin' else 'ping'
    executable = shutil.which(binary)
    if not executable:
        return False, f'Cannot check ICMP: {binary} is not installed'
    argv = [executable] + (['-6'] if ':' in host and binary == 'ping' else []) + ['-n', '-c', '1', host]
    for attempt in range(attempts):
        if cancelled.is_set():
            return False, 'Check cancelled'
        proc = None
        try:
            proc = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                    stderr=subprocess.DEVNULL, start_new_session=True)
            deadline = time.monotonic() + timeout
            while proc.poll() is None:
                if cancelled.is_set():
                    return False, 'Check cancelled'
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise subprocess.TimeoutExpired(argv, timeout)
                cancelled.wait(min(0.05, remaining))
            if proc.returncode == 0:
                return True, ''
            reason = f'ping exit={proc.returncode}'
        except subprocess.TimeoutExpired:
            reason = f'ping timed out after {timeout:g}s'
        except OSError as exc:
            return False, f'Cannot run ping: {exc}'
        finally:
            if proc is not None:
                if proc.poll() is None:
                    proc.terminate()
                    try:
                        proc.wait(timeout=0.3)
                    except subprocess.TimeoutExpired:
                        proc.kill()
                proc.wait()
        if attempt + 1 < attempts:
            if cancelled.wait(interval):
                return False, 'Check cancelled'
    return False, f'ICMP check failed after {attempts} attempts ({reason}); host may block ICMP'


def validate_ping_options(args):
    if args.ping_jobs < 1:
        raise ValueError('--ping-jobs must be positive')
    if args.ping_attempts < 1:
        raise ValueError('--ping-attempts must be positive')
    if not math.isfinite(args.ping_timeout) or args.ping_timeout <= 0:
        raise ValueError('--ping-timeout must be finite and positive')
    if not math.isfinite(args.ping_interval) or args.ping_interval < 0:
        raise ValueError('--ping-interval must be finite and nonnegative')


def add_ping_options(parser):
    parser.add_argument('--ping-jobs', type=int, default=32, help='Maximum concurrent ping checks, independent of SOL --jobs (default: 32)')
    parser.add_argument('--check-hosts', action='store_true', help='Check selected BMCs with bounded ping retries and exit; no credentials/ipmitool required')
    parser.add_argument('--ping-timeout', type=float, default=2, help='Per-attempt ping deadline in seconds (default: 2)')
    parser.add_argument('--ping-attempts', type=int, default=3, help='Maximum ICMP probes per check; stop on first reply (default: 3)')
    parser.add_argument('--ping-interval', type=float, default=0.5, help='Seconds between failed probes (default: 0.5)')
    parser.add_argument('--skip-ping', action='store_true', help='Skip default pre-connection ping checks (for networks blocking ICMP)')


def select_nodes(args):
    """Resolve every remote target through one mandatory inventory."""
    args.config = (args.config or default_config_path()).resolve()
    if not args.config.is_file():
        raise ValueError(f'Inventory not found: {args.config}; supply --inventory FILE')
    args.inventory = args.config
    inventory = load_inventory(args.config)
    if args.group:
        if set(args.group) - {n['group'] for n in inventory}:
            raise ValueError('Unknown inventory group')
    raw_hosts = [args.hosts] if args.hosts is not None else []
    hosts = []
    for line in raw_hosts:
        expression = line.split('#', 1)[0].strip()
        if not expression:
            continue
        for host in expand_hostlist(expression):
            if not re.fullmatch(r'[A-Za-z0-9_.:%-]+', host) or host.startswith('-'):
                raise ValueError('Host entries must be node names, BMC IPs or hostnames, without whitespace or shell syntax')
            if host not in hosts:
                hosts.append(host)
        if len(hosts) > MAX_HOSTS:
            raise ValueError(f'Host list exceeds {MAX_HOSTS} nodes')
    if args.hosts is not None:
        by_host = {n['host']: n for n in inventory}
        by_name = {n['name']: n for n in inventory}
        nodes, selected = [], set()
        for host in hosts:
            named, addressed = by_name.get(host), by_host.get(host)
            if named is not None and addressed is not None and named is not addressed:
                raise ValueError(f'Ambiguous host selector {host!r}: matches different inventory nodes by name and BMC address')
            node = named if named is not None else addressed
            if node is None:
                raise ValueError(f'Host selector {host!r} does not match any inventory node name or BMC address')
            if node['host'] not in selected:
                nodes.append(node)
                selected.add(node['host'])
    else:
        nodes = inventory
    if args.group:
        nodes = [n for n in nodes if n['group'] in args.group]
    hosts = [n['host'] for n in nodes]
    if not hosts:
        raise ValueError('Host list is empty')
    return nodes
