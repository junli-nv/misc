"""Local preflight shared by single-host and batch dispatch, before any I/O to BMCs."""
import math
import os
from pathlib import Path, PurePosixPath
import re

from .bmc import bmc_command, bmc_operation
from .download import validate_download
from .inventory import validate_ping_options
from .upload import validate_transfer_options


def validate_preflight(args, batch=False):
    if batch and (args.rows is not None or args.cols is not None or args.term is not None or
                  args.no_terminal_setup or args.reconnect is not None or
                  args.reconnect_attempts != 10 or args.reconnect_delay != 3 or
                  args.replay_export or args.replay_inputs or args.replay_speed != 1):
        raise ValueError('Terminal, reconnect and replay options require a single-node console or local replay')
    validate_ping_options(args)
    for name in ('timeout', 'connect_timeout'):
        value = getattr(args, name)
        if not math.isfinite(value) or value <= 0:
            raise ValueError(f'--{name.replace("_", "-")} must be finite and positive')
    if args.jobs is not None and args.jobs < 1:
        raise ValueError('--jobs must be positive')
    try:
        re.compile(args.prompt)
    except re.error as exc:
        raise ValueError(f'Invalid --prompt regex: {exc}') from None
    if args.no_log and args.log_compress:
        raise ValueError('--log-compress cannot be combined with --no-log')
    bmc_command(args)
    if bmc_operation(args):
        if (args.replay_export or args.replay_inputs or args.replay_speed != 1 or
                args.rows is not None or args.cols is not None or args.term is not None or
                args.no_terminal_setup or args.reconnect is not None or
                args.reconnect_attempts != 10 or args.reconnect_delay != 3 or
                args.log_file is not None or args.log_dir != Path('logs') or
                args.log_compress is not None):
            raise ValueError('SOL logging, terminal, reconnect and replay options do not apply to IPMI operations')
    # Preview/check-only commands do not read payloads or change destinations.
    if args.list_hosts or args.check_hosts or args.replay:
        return
    validate_transfer_options(args)
    validate_download(args, batch=batch)
    if args.upload:
        if not args.upload.is_file():
            raise ValueError('--upload must be a readable regular file')
        if (not args.remote_path or not args.remote_path.startswith('/') or
                args.remote_path.endswith('/') or PurePosixPath(args.remote_path).name in ('.', '..') or
                any(c in args.remote_path for c in '\x00\r\n')):
            raise ValueError('--remote-path must be an absolute remote filename')
        if not re.fullmatch(r'[0-7]{3}', args.mode):
            raise ValueError('--mode must be three octal digits')
    elif not args.download and (args.remote_path or args.overwrite or args.mode != '600'):
        raise ValueError('--remote-path, --overwrite and --mode require a file transfer')
    if args.command_file:
        args.command = args.command_file.read_text(encoding='utf-8')
    if args.command is not None and (not args.command or '\x00' in args.command):
        raise ValueError('Command must be nonempty and contain no NUL')
    if args.output and os.path.lexists(args.output):
        raise ValueError('--output already exists; choose a new path')
