"""Bmc support for the SOL tools."""
import math
import os
import shutil
import signal
import sys
import subprocess

from .inventory import prompt_credential, validate_ping_options, ping_host

def add_bmc_options(parser, operation):
    operation.add_argument('--power', choices=('status', 'on', 'off', 'soft', 'reset', 'cycle'),
                           help='IPMI chassis power: status/on, hard off/reset/cycle, or ACPI soft shutdown; no OS login')
    operation.add_argument('--bmc-log', choices=('list', 'elist', 'info'),
                           help='Read BMC System Event Log (SEL): list, extended list, or repository info')
    operation.add_argument('--bootdev', choices=('pxe', 'disk', 'cdrom', 'bios', 'floppy', 'none'),
                           help='Set boot device override without rebooting (default: next boot only)')
    parser.add_argument('--uefi', action='store_true', help='Request UEFI boot; requires boot DEVICE')
    parser.add_argument('--persistent', action='store_true', help='Keep boot override across boots; requires boot DEVICE')
    parser.add_argument('--sel-last', type=int, metavar='N',
                        help='Show only the last N SEL entries; requires --bmc-log list/elist')


def bmc_operation(args):
    return args.power is not None or args.bmc_log is not None or args.bootdev is not None


def bmc_command(args):
    if (args.uefi or args.persistent) and args.bootdev is None:
        raise ValueError('--uefi/--persistent require boot DEVICE or --bootdev')
    if args.sel_last is not None and (args.sel_last < 1 or args.bmc_log not in ('list', 'elist')):
        raise ValueError('--sel-last must be positive and requires --bmc-log list/elist')
    if args.bootdev is not None:
        options = (['efiboot'] if args.uefi else []) + (['persistent'] if args.persistent else [])
        return ['chassis', 'bootdev', args.bootdev] + (['options=' + ','.join(options)] if options else [])
    if args.power is not None:
        return ['chassis', 'power', args.power]
    if args.bmc_log is not None:
        return ['sel', args.bmc_log] + (['last', str(args.sel_last)] if args.sel_last is not None else [])
    return []


def run_bmc(args, password):
    """One bounded IPMI request; never activate SOL or retry a power operation."""
    command = bmc_command(args)
    if not math.isfinite(args.timeout) or args.timeout <= 0:
        raise ValueError('--timeout must be finite and positive')
    validate_ping_options(args)
    if not shutil.which(args.ipmitool):
        raise ValueError('ipmitool is not installed or not on PATH')
    if not args.skip_ping:
        reachable, error = ping_host(args.host, args.ping_timeout, args.ping_attempts, args.ping_interval)
        if not reachable:
            print(f'ERROR: {args.host}: {error}', file=sys.stderr)
            return 125
    env = os.environ.copy()
    env.pop('IPMITOOL_PASSWORD', None)
    env.pop('SOL_OS_PASSWORD', None)
    env['IPMI_PASSWORD'] = password
    argv = [args.ipmitool, '-I', 'lanplus', '-H', args.host, '-U', args.bmc_user,
            '-E', '-C', str(args.cipher), '-L', 'ADMINISTRATOR'] + command
    output = None
    proc = None
    def interrupt(signum, frame):
        raise KeyboardInterrupt
    previous = signal.signal(signal.SIGTERM, interrupt)
    try:
        if args.output:
            output = args.output.open('x', encoding='utf-8')
        proc = subprocess.Popen(argv, env=env, stdin=subprocess.DEVNULL, stdout=output)
        try:
            return proc.wait(timeout=args.timeout)
        except subprocess.TimeoutExpired:
            print('ERROR: IPMI request timed out; completion is unknown. Check power status before retrying a power operation.', file=sys.stderr)
            return 124
    finally:
        if proc is not None and proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=2)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait()
        if output is not None:
            output.close()
        signal.signal(signal.SIGTERM, previous)


def run_bmc_single(args, config):
    """Execute against a node already resolved by the inventory dispatcher."""
    args.host = config.get('host', args.host)
    if not args.host:
        raise ValueError('Specify --hosts or provide a single-node inventory')
    for field in ('bmc_user', 'bmc_password'):
        value = getattr(args, field)
        if value is None and field == 'bmc_password':
            value = os.environ.get('IPMI_PASSWORD')
        if value is None:
            value = config.get(field)
        if value is None:
            value = prompt_credential(field, args.host)
        if any(c in value for c in '\x00\r\n') or (field == 'bmc_user' and not value.strip()):
            raise ValueError(f'Invalid {field}')
        setattr(args, field, value)
    return run_bmc(args, args.bmc_password)
