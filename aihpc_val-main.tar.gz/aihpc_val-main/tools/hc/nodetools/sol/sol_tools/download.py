"""Bounded Base64 downloads with end-to-end integrity checks and atomic publish."""
import base64
import binascii
import hashlib
import os
import math
from pathlib import Path, PurePosixPath
import re
import shlex
import fcntl
import json
import stat
import sys
import uuid

from .session import execute

CHUNK_SIZE = 3072


def validate_download(args, batch=False):
    if not args.download:
        if args.local_path is not None:
            raise ValueError('--local-path requires a download')
        return
    if (not args.download.startswith('/') or args.download.endswith('/') or
            PurePosixPath(args.download).name in ('.', '..') or
            any(c in args.download for c in '\x00\r\n')):
        raise ValueError('Download source must be an absolute remote filename')
    if not all(math.isfinite(t) and t > 0 for t in (args.timeout, args.connect_timeout)):
        raise ValueError('Timeouts must be finite and positive')
    if args.local_path is None:
        raise ValueError('Download requires a local destination')
    if args.remote_path or args.mode != '600':
        raise ValueError('--remote-path and --mode apply only to uploads')
    if batch:
        if args.local_path.exists() and not args.local_path.is_dir():
            raise ValueError('Batch download destination must be a directory')
    else:
        if not args.local_path.parent.is_dir():
            raise ValueError('Local destination parent directory must exist')
        if args.local_path.is_dir():
            raise ValueError('Single-host download destination must be a filename')
        if args.local_path.is_symlink() and not args.overwrite:
            raise ValueError('Local destination is a symlink; use --overwrite to replace it')


def download(con, args):
    """Read bounded chunks; reject damaged data and publish only after verification."""
    validate_download(args)
    remote = shlex.quote(args.download)

    def checked(command):
        rc, output = execute(con, command, args)
        if rc:
            raise RuntimeError(f'Download failed (remote exit {rc}): {output.strip()}')
        return output

    def record(command_factory):
        token = 'SOL_FILE_' + uuid.uuid4().hex
        output = checked(command_factory(token))
        records = [line[len(token) + 1:] for line in output.splitlines() if line.startswith(token + ':')]
        if len(records) != 1:
            raise RuntimeError('Missing or ambiguous download record; serial output may be corrupted')
        return records[0]

    def metadata():
        data = record(lambda token: f'''set -e
 test -f {remote} && test -r {remote}
 size=$(wc -c < {remote})
 digest=$(sha256sum < {remote})
 printf '{token}:%s:%s\\n' "$size" "${{digest%% *}}"''')
        match = re.fullmatch(r'\s*(\d+):([0-9a-f]{64})', data)
        if not match:
            raise RuntimeError('Invalid download metadata')
        return int(match[1]), match[2]

    size, expected = metadata()
    destination = Path(args.local_path)
    def local_digest(path):
        digest = hashlib.sha256()
        with path.open('rb') as source:
            while data := source.read(1024 * 1024):
                digest.update(data)
        return digest.hexdigest()

    if os.path.lexists(destination) and not args.overwrite:
        if (not destination.is_symlink() and destination.is_file() and
                destination.stat().st_size == size and local_digest(destination) == expected and
                metadata() == (size, expected)):
            print(f'Already downloaded: {destination}; SHA-256 verified: {expected}')
            return 0
        raise ValueError('Local destination differs from remote file; use --overwrite to replace it')

    identity = [getattr(args, 'host', ''), args.download, str(destination.absolute())]
    key = hashlib.sha256(json.dumps(identity).encode()).hexdigest()[:32]
    temporary = destination.parent / f'.sol-download-{key}.part'
    state_path = destination.parent / f'.sol-download-{key}.json'
    state = {'source': identity, 'size': size, 'sha256': expected}

    def private_file(path):
        fd = os.open(path, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid() or info.st_nlink != 1:
            os.close(fd)
            raise ValueError('Unsafe download checkpoint file')
        os.fchmod(fd, 0o600)
        return os.fdopen(fd, 'r+b', buffering=0)

    digest = hashlib.sha256()
    completed = discard = False
    with private_file(temporary) as output:
        try:
            fcntl.flock(output, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise RuntimeError('Another download is already using this destination') from None
        try:
            with private_file(state_path) as saved:
                try:
                    previous = json.loads(saved.read(65536))
                except (ValueError, UnicodeError):
                    previous = None
                offset = os.fstat(output.fileno()).st_size
                if args.no_resume or previous != state or offset > size:
                    offset = 0
                elif offset != size:
                    offset -= offset % CHUNK_SIZE
                output.truncate(offset)
                output.seek(0)
                remaining = offset
                while remaining:
                    data = output.read(min(1024 * 1024, remaining))
                    if not data:
                        raise RuntimeError('Download checkpoint was truncated during verification')
                    digest.update(data)
                    remaining -= len(data)
                if offset:
                    prefix = record(lambda token: f"set -e; set -o pipefail; digest=$(head -c {offset} {remote} | sha256sum); printf '{token}:%s\\n' \"${{digest%% *}}\"")
                    if prefix != digest.hexdigest():
                        offset = 0
                        digest = hashlib.sha256()
                        output.truncate(0)
                        print('Saved download prefix differs; restarting.', file=sys.stderr)
                    else:
                        print(f'Resuming download at verified offset {offset} bytes.', file=sys.stderr)
                output.seek(offset)
                saved.seek(0)
                saved.truncate()
                saved.write(json.dumps(state).encode())
                os.fsync(saved.fileno())
            for offset in range(offset, size, CHUNK_SIZE):
                encoded = record(lambda token: f'''set -e
 set -o pipefail
 data=$(dd if={remote} bs={CHUNK_SIZE} skip={offset // CHUNK_SIZE} count=1 2>/dev/null | base64 -w 0)
 printf '{token}:%s\\n' "$data"''')
                try:
                    data = base64.b64decode(encoded, validate=True)
                except (binascii.Error, ValueError) as exc:
                    raise RuntimeError('Corrupt Base64 download data') from exc
                if len(data) != min(CHUNK_SIZE, size - offset):
                    raise RuntimeError('Download chunk size mismatch; remote file changed or SOL data was lost')
                output.write(data)
                digest.update(data)
            output.flush()
            os.fsync(output.fileno())
            if digest.hexdigest() != expected or metadata() != (size, expected):
                discard = True
                raise RuntimeError('Download SHA-256 mismatch or remote file changed; destination not replaced')
            # Remove metadata while the checkpoint inode is still locked and named.
            # After replace, another writer may create a new checkpoint at that path.
            state_path.unlink(missing_ok=True)
            if args.overwrite:
                os.replace(temporary, destination)
            else:
                os.link(temporary, destination)
            completed = True
            print(f'Downloaded {size} bytes to {destination}; SHA-256 verified: {expected}')
            return 0
        finally:
            if completed or discard:
                if discard:
                    state_path.unlink(missing_ok=True)
                if not (completed and args.overwrite):
                    temporary.unlink(missing_ok=True)
            else:
                print(f'Download progress retained: {temporary}; rerun the same command to resume.', file=sys.stderr)
