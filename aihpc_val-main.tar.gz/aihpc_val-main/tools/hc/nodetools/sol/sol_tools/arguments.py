"""Cli support for the SOL tools."""
import argparse
import pathlib
from pathlib import Path

from .defaults import DEFAULT_JOBS
from .inventory import add_ping_options
from .upload import add_transfer_options
from .bmc import add_bmc_options

def print_brief_help(parser):
    """Show common options without changing how normal commands are parsed."""
    brief = {
        'help': 'Show common usage', 'help_all': 'Show all advanced options',
        'hosts': 'Select one or more nodes, e.g. gpu[001-003,007]',
        'group': 'Select an inventory group', 'config': 'Inventory file (default: inventory.ini beside tools)',
        'inventory': 'Inventory file', 'list_hosts': 'Preview selected nodes without connecting',
        'command_file': 'Execute a local Bash script', 'sel_last': 'Show the last N SEL events',
        'direction': 'upload or download',
        'text': 'Quoted Bash command', 'source': 'Source filename', 'destination': 'Destination filename',
        'uefi': 'Use UEFI for boot DEVICE', 'persistent': 'Keep boot override across boots',
        'action': 'Operation', 'value': 'Power action, boot device, log format or replay file',
    }
    for action in parser._actions:
        action.help = brief.get(action.dest, argparse.SUPPRESS)
    parser.usage = '%(prog)s [--hosts HOSTLIST] [--group GROUP] OPERATION'
    parser.print_help()

class HelpAction(argparse.Action):
    def __call__(self, parser, namespace, values, option_string=None):
        if self.const == 'all':
            parser.print_help()
        elif self.const == 'batch':
            parser_for_batch(parser.tool).print_help()
        elif self.const == 'examples':
            print(parser.epilog.split('\nPassword precedence:', 1)[0].rstrip())
        else:
            print_brief_help(parser)
        parser.exit()

def parser_for_batch(tool):
    return parser_for_tool(tool)


def parse_operation(parser, words=None):
    """Accept options before or between positional operands, then normalize once."""
    args = parser.parse_intermixed_args(words)
    # Parse with suppressed defaults to distinguish explicit CLI values, including
    # values equal to built-ins and the negative forms of boolean switches.
    # Positional defaults must stay intact: older argparse versions validate
    # the SUPPRESS string against choices for an omitted optional positional.
    saved = [(action, action.default) for action in parser._actions if action.option_strings]
    defaults = parser._defaults
    try:
        parser._defaults = {}
        for action, _ in saved:
            action.default = argparse.SUPPRESS
        explicit = parser.parse_intermixed_args(words)
    finally:
        parser._defaults = defaults
        for action, default in saved:
            action.default = default
    args.explicit_options = set(vars(explicit)) & {action.dest for action, _ in saved}
    normalize_operation(parser, args)
    return args


def parser_for_tool(tool):
    parser = argparse.ArgumentParser(
        add_help=False, allow_abbrev=False,
        description=(
            'Connect over IPMI SOL to watch boot, interact with Linux, run commands or upload files.\n'
            'Local: Python 3.9+ and ipmitool. Batch commands: remote Linux, Bash and base64.\n'
            'Uploads also need sha256sum and GNU coreutils. Boot console only needs BMC SOL\n'
            'and serial redirection configured for the boot stages you want to observe.'
        ),
        formatter_class=argparse.RawTextHelpFormatter,
        epilog='',
    )
    parser.add_argument('-h', '--help', action=HelpAction, nargs=0, const='brief',
                        help='Show brief help and exit')
    parser.add_argument('--help-all', action=HelpAction, nargs=0, const='all',
                        help='Show all options, examples and detailed notes, then exit')
    parser.add_argument('--help-examples', action=HelpAction, nargs=0, const='examples',
                        help='Show usage examples only, then exit')
    parser.add_argument('--help-batch', action=HelpAction, nargs=0, const='batch',
                        help='Show batch parameters and examples, then exit')
    parser.add_argument('--bash-completion', action='store_true',
                        help='Print Bash completion and a shell function for this tool; source the output to enable')
    batching = parser.add_argument_group('Inventory selection and concurrency')
    add_ping_options(parser)
    parser.add_argument('--ping', dest='skip_ping', action='store_false', default=argparse.SUPPRESS,
                        help='Enable ping checks, overriding inventory skip_ping')
    add_transfer_options(parser)
    batching.add_argument('--hosts', help='Inventory names or BMC hostlist (numeric ranges supported)')
    batching.add_argument('--group', action='append', help='Select inventory group; repeat to select several')
    batching.add_argument('--list-hosts', action='store_true', help='Preview batch selection without connecting')
    batching.add_argument('--jobs', type=int, help=f'Maximum concurrent hosts (built-in default: {DEFAULT_JOBS}; inventory jobs overrides)')
    batching.add_argument('--result-dir', type=pathlib.Path, help='New batch results directory')
    connection = parser.add_argument_group('Connection and login')
    connection.add_argument('--config', '--inventory', type=pathlib.Path, metavar='INI_FILE',
                            help='Load INI inventory (default: inventory.ini beside this script); --hosts selects one or more nodes\n'
                                 'CLI overrides config; password environment variables also override config')
    parser.set_defaults(host=None)  # Resolved BMC address, never a CLI selector.
    connection.add_argument('--node-name', help=argparse.SUPPRESS)
    terminal = parser.add_argument_group('Terminal setup after automatic interactive login')
    terminal.add_argument('--rows', type=int, help='Remote terminal rows; use with --cols (default: local window size)')
    terminal.add_argument('--cols', type=int, help='Remote terminal columns; use with --rows')
    terminal.add_argument('--term', help='Remote TERM after shell login (default: xterm)')
    terminal.add_argument('--no-terminal-setup', action='store_true', help='Disable automatic stty/TERM setup for interactive login')
    connection.add_argument('--bmc-user', metavar='USER',
                            help='Optional override of inventory bmc_user; BMC ADMINISTRATOR privilege required')
    connection.add_argument('--bmc-password', metavar='PASSWORD',
                            help='Optional override of IPMI_PASSWORD / inventory bmc_password')
    connection.add_argument('--os-user', metavar='USER',
                            help='Optional override of inventory os_user for automatic Linux login')
    connection.add_argument('--os-password', metavar='PASSWORD',
                            help='Optional override of SOL_OS_PASSWORD / inventory os_password')
    connection.add_argument('--cipher', type=int, default=17, metavar='ID',
                            help='IPMI cipher suite ID (default: 17); select a suite supported by the BMC')
    connection.add_argument('--ipmitool', default='ipmitool', metavar='PATH',
                            help='ipmitool executable name or path (default: ipmitool found on PATH)')
    operations = parser.add_argument_group('Operation (choose exactly one)')
    group = operations.add_mutually_exclusive_group()
    add_bmc_options(parser, group)
    group.add_argument('--replay', type=pathlib.Path, metavar='LOG_FILE',
                       help='Play a previously recorded JSONL log locally; never connects or executes commands')
    group.add_argument('--console', action='store_true',
                       help='Open the raw SOL console immediately to watch boot or log in manually\n'
                            'No automatic input or OS login; requires a terminal; Ctrl-] disconnects')
    group.add_argument('--interactive', '-i', action='store_true',
                       help='Open a live console; Ctrl-] disconnects, Ctrl-C goes to the remote host\n'
                            'Auto-login with --os-user; otherwise hand over immediately after SOL connects')
    group.add_argument('--command', '-c', metavar='COMMAND',
                       help='Run a noninteractive Bash command; single-quote it to avoid local expansion')
    group.add_argument('--command-file', type=pathlib.Path, metavar='LOCAL_SCRIPT',
                       help='Execute a local UTF-8 script remotely without saving it as a remote file')
    group.add_argument('--upload', type=pathlib.Path, metavar='LOCAL_FILE',
                       help='Upload a local file, including binary or empty files; requires --remote-path')
    transfer = parser.add_argument_group('Upload options (require --upload)')
    transfer.add_argument('--remote-path', metavar='REMOTE_FILE',
                          help='Absolute remote filename, e.g. /tmp/check.sh; parent must exist and be writable')
    transfer.add_argument('--overwrite', action='store_true',
                          help='Replace an existing destination file (default: refuse); cannot replace directories')
    transfer.add_argument('--mode', default='600', metavar='OCTAL',
                          help='Three-digit octal permissions (default: 600); use 755 for executable scripts')
    runtime = parser.add_argument_group('Output and timeouts')
    compression = runtime.add_mutually_exclusive_group()
    compression.add_argument('--log-compress', action='store_true', default=None,
                         help='Compress SOL logs with gzip (default); auto names end in .jsonl.gz\n'
                              'Explicit --log-file gains .gz if needed; replay accepts gzip directly')
    compression.add_argument('--no-log-compress', action='store_false', dest='log_compress',
                             help='Write uncompressed JSONL logs; use a filename without .gz')
    playback = parser.add_argument_group('Local replay options')
    playback.add_argument('--replay-export', action='store_true',
                          help='Export only recorded OUT to stdout immediately; accepts JSONL/gzip\n'
                               'Strip ANSI/control codes and normalize line endings for grep; no playback UI')
    playback.add_argument('--replay-speed', type=float, default=1, metavar='FACTOR',
                          help='Initial playback speed, 0.125 to 64 (default: 1); 4 means four times faster')
    playback.add_argument('--replay-inputs', action='store_true',
                          help='Show recorded IN data as escaped annotations (default: output and events only)')
    logging = runtime.add_mutually_exclusive_group()
    logging.add_argument('--log-file', type=pathlib.Path, nargs='?', const=True, metavar='LOCAL_FILE',
                         help='Record SOL IN/OUT and events as timestamped JSON Lines in all modes\n'
                              'Remote sessions log by default; omit filename for BMC + timestamp naming\n'
                              'New file only, permissions 600; reconnects share it; manual input is logged')
    logging.add_argument('--no-log', action='store_true',
                         help='Disable default SOL I/O logging; replay never creates logs')
    logging.add_argument('--log', dest='no_log', action='store_false', default=argparse.SUPPRESS,
                         help='Enable SOL logging, overriding inventory no_log')
    runtime.add_argument('--log-dir', type=pathlib.Path, default=pathlib.Path('logs'), metavar='DIRECTORY',
                         help='Directory for auto-named logs (default: ./logs); created if needed\n'
                              'Applies to default logging or --log-file without a filename')
    runtime.add_argument('--output', type=pathlib.Path, metavar='LOCAL_FILE',
                         help='Save merged command output locally; file must not exist; not for uploads')
    runtime.add_argument('--timeout', type=float, default=300, metavar='SECONDS',
                         help='Remote command completion timeout (default: 300 seconds)\n'
                              'Uploads: per processing command, not whole transfer; ignored during interaction')
    runtime.add_argument('--connect-timeout', type=float, default=60, metavar='SECONDS',
                         help='Wait for SOL activation, login or each chunk acknowledgement (default: 60 seconds)')
    reconnect = runtime.add_mutually_exclusive_group()
    reconnect.add_argument('--reconnect', action='store_true', default=None,
                           help='Enable reconnection (default for --interactive/--console)\n'
                                'Reopens the raw console without OS login; Ctrl-] exits normally')
    reconnect.add_argument('--no-reconnect', action='store_false', dest='reconnect',
                           help='Disable automatic reconnection for interactive/console sessions')
    runtime.add_argument('--reconnect-attempts', type=int, default=10, metavar='N',
                         help='Maximum reconnect attempts across this invocation (default: 10)')
    runtime.add_argument('--reconnect-delay', type=float, default=3, metavar='SECONDS',
                         help='Delay before each reconnect attempt (default: 3 seconds)')
    runtime.add_argument('--prompt', default=r'(?m)^[^\n]*[#$] ?$', metavar='REGEX',
                         help='Python regular expression for the Linux shell prompt\n'
                              'Default: a line ending in # or $, optionally followed by one space')
    scope_parser(parser, tool)
    return parser


TOOL_OPTIONS = {
    'exec': {'command', 'command_file'},
    'file': {'upload', 'remote_path', 'mode', 'overwrite', 'no_resume'},
    'control': {'bootdev', 'uefi', 'persistent', 'power', 'bmc_log', 'sel_last', 'console', 'interactive', 'replay',
                'replay_export', 'replay_speed', 'replay_inputs', 'rows', 'cols', 'term',
                'no_terminal_setup', 'reconnect', 'reconnect_attempts', 'reconnect_delay'},
}
EXAMPLES = {
    'exec': """Execute commands:
  sol_exec --hosts gpu001 'hostname; uptime'
  sol_exec --hosts 'gpu[001-003]' 'hostname'
  sol_exec --group cluster --command-file check.sh
""",
    'file': """File transfer:
  sol_file --hosts gpu001 upload ./check.sh /tmp/check.sh
  sol_file --hosts gpu001 download /var/log/messages ./messages
  sol_file --hosts 'gpu[001-003]' download /etc/hostname ./downloads
Batch downloads create a separate node directory under the local destination.
""",
    'control': """Remote control:
  sol_control --hosts gpu001 console
  sol_control --hosts gpu001 login
  sol_control --hosts 'gpu[001-003]' power status
  sol_control --hosts gpu001 power on
  sol_control --hosts gpu001 logs --last 20
  sol_control --hosts gpu001 boot pxe --uefi
  sol_control --hosts gpu001 boot disk --persistent
  sol_control replay ./node-sol.jsonl.gz
Power: status, on, soft (ACPI shutdown), off (hard power off), reset, cycle.
Logs: standard IPMI SEL; use logs info for repository information.
""",
}


def scope_parser(parser, tool):
    """Expose only this tool's arguments, retaining defaults for shared workers.

    argparse stores actions in several groups; remove excluded actions from all
    of them so parsing, help and completion have the same supported options.
    """
    parser.set_defaults(download=None, local_path=None)
    parser.tool = tool
    parser.prog = f'sol_{tool}.py'
    parser.description = {'exec': 'Execute Bash commands over SOL.',
                          'file': 'Upload and download files over SOL with checksum verification.',
                          'control': 'Remote console, power, boot device and BMC event logs.'}[tool]
    parser.epilog = EXAMPLES[tool] + '\nUse --help-all for advanced options. Config defaults to inventory.ini beside the tools.'
    excluded = set().union(*TOOL_OPTIONS.values()) - TOOL_OPTIONS[tool]
    if tool == 'file':
        excluded.add('output')
    for action in list(parser._actions):
        if action.dest not in excluded:
            continue
        parser.set_defaults(**{action.dest: action.default})
        parser._remove_action(action)
        for option in action.option_strings:
            parser._option_string_actions.pop(option, None)
        for group in parser._action_groups + parser._mutually_exclusive_groups:
            if action in group._group_actions:
                group._group_actions.remove(action)
    parser._mutually_exclusive_groups[:] = [g for g in parser._mutually_exclusive_groups if g._group_actions]
    if tool == 'exec':
        parser.add_argument('text', nargs='?', help='Quoted Bash command to execute')
    elif tool == 'file':
        parser.add_argument('direction', nargs='?', choices=('upload', 'download'), help='Transfer direction')
        parser.add_argument('source', nargs='?', help='Source filename')
        parser.add_argument('destination', nargs='?', help='Destination filename (directory for batch downloads)')
        operation = next(g for g in parser._mutually_exclusive_groups if any(a.dest == 'upload' for a in g._group_actions))
        operation.add_argument('--download', help='Remote source filename (alternative to download SOURCE DESTINATION)')
        parser.add_argument('--local-path', type=Path, help='Local download destination')
    else:
        choices = ('console', 'login', 'power', 'logs', 'boot', 'replay')
        parser.add_argument('action', nargs='?', choices=choices, help='Remote control operation')
        parser.add_argument('value', nargs='?', help='Power action, boot device, SEL format, or replay filename')
        action = next(a for a in parser._actions if a.dest == 'sel_last')
        action.option_strings.append('--last')
        parser._option_string_actions['--last'] = action


def normalize_operation(parser, args):
    """Translate short positional syntax into the shared operation namespace."""
    tool = parser.tool
    selected = any(getattr(args, name, None) is not None and getattr(args, name) is not False
                   for name in ('command', 'command_file', 'upload', 'power', 'bmc_log', 'bootdev', 'replay', 'console', 'interactive'))
    if tool == 'file' and args.direction is not None:
        if selected or args.download or args.remote_path or args.local_path:
            parser.error('Use either DIRECTION SOURCE DESTINATION or explicit transfer options')
        if args.source is None or args.destination is None:
            parser.error('File transfer requires DIRECTION SOURCE DESTINATION')
        if args.direction == 'upload':
            args.upload, args.remote_path = Path(args.source), args.destination
        else:
            args.download, args.local_path = args.source, Path(args.destination)
    elif tool == 'exec' and args.text is not None:
        if selected:
            parser.error('Use either a positional command or --command/--command-file')
        args.command = args.text
    elif tool == 'control' and args.action is not None:
        if selected:
            parser.error('Use either positional control syntax or an operation option')
        if args.action in ('console', 'login'):
            if args.value is not None:
                parser.error('console/login does not take an extra argument')
            setattr(args, 'console' if args.action == 'console' else 'interactive', True)
        elif args.action == 'power':
            args.power = args.value or 'status'
            if args.power not in ('status', 'on', 'off', 'soft', 'reset', 'cycle'):
                parser.error('Power action must be status, on, off, soft, reset or cycle')
        elif args.action == 'boot':
            if args.value not in ('pxe', 'disk', 'cdrom', 'bios', 'floppy', 'none'):
                parser.error('boot requires pxe, disk, cdrom, bios, floppy or none')
            args.bootdev = args.value
        elif args.action == 'logs':
            args.bmc_log = args.value or 'elist'
            if args.bmc_log not in ('list', 'elist', 'info'):
                parser.error('Log format must be list, elist or info')
        else:
            if not args.value:
                parser.error('replay requires a log filename')
            args.replay = Path(args.value)
