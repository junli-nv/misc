"""Shared implementation for the SOL command, upload and control tools."""
