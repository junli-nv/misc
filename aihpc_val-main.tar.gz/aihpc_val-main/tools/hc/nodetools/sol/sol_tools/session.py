"""Session support for the SOL tools."""
import base64
import errno
import gzip
import io
import json
from datetime import datetime
import os
import pty
import re
import select
import shlex
import signal
import sys
import termios
import time
import tty
import uuid
import zlib


class SOLDisconnected(RuntimeError):
    """An established interactive SOL transport closed unexpectedly."""


class SessionLog:
    """Timestamped JSON Lines; control characters are escaped, not executed."""
    def __init__(self, path, host=None, name=None):
        self.host = host
        self.name = name
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        self.raw = os.fdopen(fd, 'wb')
        try:
            stream = (gzip.GzipFile(filename='', fileobj=self.raw, mode='wb', compresslevel=6)
                      if str(path).lower().endswith('.gz') else self.raw)
            self.file = io.TextIOWrapper(stream, encoding='utf-8')
        except BaseException:
            self.raw.close()
            raise

    def record(self, direction, data):
        entry = {'time': datetime.now().astimezone().isoformat(timespec='milliseconds'),
                 'direction': direction, 'data': data}
        if self.host is not None:
            entry['bmc_host'] = self.host
        if self.name is not None:
            entry['node_name'] = self.name
        self.file.write(json.dumps(entry, ensure_ascii=True) + '\n')
        self.file.flush()
        self.raw.flush()

    def close(self):
        try:
            self.file.close()
        finally:
            self.raw.close()


def node_file_label(host, name=None):
    address = re.sub(r'[^A-Za-z0-9._-]', '_', host)[:100] or 'bmc'
    if name and name != host:
        return (re.sub(r'[^A-Za-z0-9._-]', '_', name)[:100] or 'node') + '_' + address
    return address


def automatic_log_path(host, directory, compress=True, name=None):
    # Keep IPv4/hostnames readable, and make IPv6 or unusual names filesystem-safe.
    label = node_file_label(host, name)
    stamp = datetime.now().astimezone().strftime('%Y%m%d_%H%M%S_%f%z')
    return directory / (f'sol_{label}_{stamp}.jsonl' + ('.gz' if compress else ''))


def load_replay(path):
    try:
        return _load_replay(path)
    except (EOFError, zlib.error) as exc:
        raise ValueError('Compressed replay log is incomplete or corrupt') from exc


def _load_replay(path):
    """Validate the whole log before rendering; preserve order if wall time moved back."""
    events = []
    origin = None
    previous = 0.0
    with path.open('rb') as probe:
        compressed = probe.read(2) == b'\x1f\x8b' or str(path).lower().endswith('.gz')
    with (gzip.open(path, 'rt', encoding='utf-8') if compressed else path.open(encoding='utf-8')) as source:
        for number, line in enumerate(source, 1):
            if not line.strip():
                continue
            try:
                record = json.loads(line)
                timestamp = datetime.fromisoformat(record['time'])
                if timestamp.utcoffset() is None:
                    raise ValueError('timestamp must include a timezone')
                if record['direction'] not in ('IN', 'OUT', 'EVENT') or not isinstance(record['data'], str):
                    raise ValueError('invalid direction or data')
                seconds = timestamp.timestamp()
            except (ValueError, TypeError, KeyError, OverflowError) as exc:
                raise ValueError(f'Invalid replay record on line {number}: {exc}') from exc
            if origin is None:
                origin = seconds
            previous = max(previous, seconds - origin)
            events.append((previous, record['direction'], record['data']))
    if not events:
        raise ValueError('Replay log contains no records')
    return events


def replay(args):
    """Local playback only: this function never opens a SOL connection."""
    events = load_replay(args.replay)
    if args.replay_export:
        # Join chunks before stripping escapes: serial reads may split sequences.
        output = ''.join(data for _, direction, data in events if direction == 'OUT')
        output = re.sub(r'\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)', '', output)
        output = re.sub(r'\x1b[P^_X].*?\x1b\\', '', output, flags=re.S)
        output = re.sub(r'(?:\x1b\[|\x9b)[0-?]*[ -/]*[@-~]', '', output)
        output = re.sub(r'\x1b[ -/]*[@-Z\\-_]', '', output)
        output = output.replace('\r\n', '\n').replace('\r', '\n')
        output = re.sub(r'[\x00-\x08\x0b-\x1f\x7f-\x9f]', '', output)
        try:
            sys.stdout.write(output)
            sys.stdout.flush()
        except BrokenPipeError:
            # grep -q/head may close the pipe early; avoid a shutdown traceback.
            with open(os.devnull, 'w') as sink:
                os.dup2(sink.fileno(), sys.stdout.fileno())
        return 0
    controls = sys.stdin.isatty() and sys.stdout.isatty()
    saved = termios.tcgetattr(sys.stdin.fileno()) if controls else None
    handlers = {}
    position, speed, paused = 0.0, args.replay_speed, False
    index = 0
    last = time.monotonic()

    def status():
        print(f'\r\n[Replay {position:.1f}/{events[-1][0]:.1f}s | {speed:g}x | '
              f'{"paused" if paused else "playing"}]', file=sys.stderr, flush=True)

    def interrupted(signum, frame):
        raise KeyboardInterrupt

    print('Local replay only. Space: pause/resume; +: faster; -: slower; '
          'f: forward 10s; n: next record; q: quit.', file=sys.stderr, flush=True)
    try:
        if controls:
            for sig in (signal.SIGTERM, signal.SIGHUP):
                handlers[sig] = signal.signal(sig, interrupted)
            tty.setraw(sys.stdin.fileno(), when=termios.TCSANOW)
        status()
        while index < len(events):
            now = time.monotonic()
            if not paused:
                position += (now - last) * speed
            last = now
            # Render skipped records immediately, retaining their terminal effects.
            while index < len(events) and events[index][0] <= position:
                when, direction, data = events[index]
                if direction == 'OUT':
                    sys.stdout.write(data)
                    sys.stdout.flush()
                elif direction == 'EVENT' or args.replay_inputs:
                    print(f'\r\n[{when:.3f}s {direction}] {json.dumps(data, ensure_ascii=True)}',
                          file=sys.stderr, flush=True)
                index += 1
            if index == len(events):
                break
            delay = .1 if paused else min(.1, max(0, (events[index][0] - position) / speed))
            if controls:
                if select.select([sys.stdin.fileno()], [], [], delay)[0]:
                    keys = os.read(sys.stdin.fileno(), 128)
                    if not keys:
                        return 0
                    now = time.monotonic()
                    if not paused:
                        position += (now - last) * speed
                    last = now
                    for key in keys:
                        if key in (ord('q'), 0x1d):
                            return 0
                        if key == 3:
                            raise KeyboardInterrupt
                        if key == ord(' '):
                            paused = not paused
                        elif key in (ord('+'), ord('=')):
                            speed = min(64, speed * 2)
                        elif key == ord('-'):
                            speed = max(.125, speed / 2)
                        elif key == ord('f'):
                            position = min(events[-1][0], position + 10)
                        elif key == ord('n'):
                            position = max(position, events[index][0])
                        else:
                            continue
                        status()
            else:
                time.sleep(delay)
        print('\r\nReplay complete.', file=sys.stderr, flush=True)
        return 0
    finally:
        try:
            if saved is not None:
                termios.tcsetattr(sys.stdin.fileno(), termios.TCSANOW, saved)
        finally:
            for sig, handler in handlers.items():
                signal.signal(sig, handler)


class Console:
    def __init__(self, argv, env, session_log=None):
        self.pid, self.fd = pty.fork()
        if self.pid == 0:
            os.execvpe(argv[0], argv, env)
        self.buffer = ''
        self.input_sent = False
        self.session_log = session_log
        self.auth_private = False

    def log_bytes(self, direction, data):
        if self.session_log and data:
            text = '[REDACTED: automatic authentication]' if self.auth_private else data.decode('utf-8', errors='backslashreplace')
            self.session_log.record(direction, text)

    def send_password(self, password):
        # Suppress both the password input and possible serial echo until login completes.
        self.auth_private = True
        self.send(password + '\r')

    def send(self, text):
        self.send_bytes(text.encode())

    def send_bytes(self, data):
        if data:
            self.input_sent = True
        while data:
            count = os.write(self.fd, data)
            self.log_bytes('IN', data[:count])
            data = data[count:]

    def expect(self, patterns, timeout):
        deadline = time.monotonic() + timeout
        while True:
            for index, pattern in enumerate(patterns):
                match = re.search(pattern, self.buffer)
                if match:
                    before = self.buffer[:match.start()]
                    self.buffer = self.buffer[match.end():]
                    return index, match, before
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError('Timed out waiting for SOL/remote shell response')
            if not select.select([self.fd], [], [], remaining)[0]:
                continue
            try:
                data = os.read(self.fd, 65536)
            except OSError as exc:
                if exc.errno != errno.EIO:
                    raise
                data = b''
            if not data:
                # Never print console buffers here: login credentials may have echoed.
                raise RuntimeError('ipmitool disconnected before completion')
            self.log_bytes('OUT', data)
            self.buffer += data.decode('utf-8', errors='replace').replace('\r', '')

    def close(self):
        """Reap the transport and close its PTY, including an already-exited child."""
        if getattr(self, '_closed', False):
            return
        self._closed = True

        def reaped():
            try:
                return bool(os.waitpid(self.pid, os.WNOHANG)[0])
            except ChildProcessError:
                return True

        fd_open = True
        try:
            try:
                self.send('\r~.' if self.input_sent else '~.')
            except OSError:
                pass
            for signum in (None, signal.SIGTERM, signal.SIGKILL):
                if reaped():
                    return
                if signum is not None:
                    try:
                        os.kill(self.pid, signum)
                    except ProcessLookupError:
                        pass
                if signum == signal.SIGKILL:
                    # Release the PTY before blocking in waitpid: terminal teardown
                    # can otherwise wait for the master to drain on macOS.
                    os.close(self.fd)
                    fd_open = False
                    try:
                        os.waitpid(self.pid, 0)
                    except ChildProcessError:
                        pass
                    return
                for _ in range(20):
                    if reaped():
                        return
                    time.sleep(0.05)
        finally:
            if fd_open:
                os.close(self.fd)


def marker_command(token):
    # The complete token never appears in terminal input echo.
    return "printf '\\n%s%s\\n' '%s' '%s'" % ('%s', '%s', token[:16], token[16:])


def boundary(token):
    return r'(?m)^' + re.escape(token) + r'\n'


def interactive(con):
    """Relay raw terminal bytes; Ctrl-] detaches locally."""
    input_fd, output_fd = sys.stdin.fileno(), sys.stdout.fileno()
    saved = termios.tcgetattr(input_fd)
    handlers = {}

    def interrupted(signum, frame):
        raise KeyboardInterrupt

    def display(data):
        while data:
            data = data[os.write(output_fd, data):]

    print('Interactive SOL: Ctrl-] disconnects; Ctrl-C is sent to the remote console.',
          file=sys.stderr, flush=True)
    sys.stdout.flush()
    try:
        for sig in (signal.SIGTERM, signal.SIGHUP):
            handlers[sig] = signal.signal(sig, interrupted)
        tty.setraw(input_fd, when=termios.TCSANOW)
        if con.buffer:
            display(con.buffer.replace('\n', '\r\n').encode())
            con.buffer = ''
        while True:
            ready, _, _ = select.select([input_fd, con.fd], [], [])
            if con.fd in ready:
                try:
                    data = os.read(con.fd, 65536)
                except OSError as exc:
                    if exc.errno != errno.EIO:
                        raise
                    data = b''
                if not data:
                    raise SOLDisconnected('SOL transport disconnected')
                con.log_bytes('OUT', data)
                display(data)
            if input_fd in ready:
                data = os.read(input_fd, 4096)
                if not data:
                    return 0
                before, separator, _ = data.partition(b'\x1d')
                con.send_bytes(before)
                if separator:
                    if con.session_log:
                        con.session_log.record('EVENT', 'User detached with Ctrl-]')
                    return 0
    finally:
        try:
            termios.tcsetattr(input_fd, termios.TCSANOW, saved)
        finally:
            for sig, handler in handlers.items():
                signal.signal(sig, handler)
        print('\nSOL interactive session ended.', file=sys.stderr, flush=True)


def execute(con, command_text, args):
    token = "SOL_" + uuid.uuid4().hex
    # Stage bounded lines with an acknowledgement each; avoids serial line limits.
    var = 'SOL_CMD_' + uuid.uuid4().hex
    encoded = base64.b64encode(command_text.encode()).decode()
    con.send(var + "='' ; " + marker_command(token) + '\r')
    con.expect([boundary(token)], args.connect_timeout)
    for offset in range(0, len(encoded), 256):
        con.send(f'{var}="${{{var}}}"\'{encoded[offset:offset+256]}\'; '
                 + marker_command(token) + '\r')
        con.expect([boundary(token)], args.connect_timeout)
    begin, end = token + '_BEGIN', token + '_END'
    command = (marker_command(begin) + '; '
               + f'bash -c "$(printf \'%s\' "${{{var}}}" | base64 -d)"; '
               + f'{var}_RC=$?; unset {var}; '
               + "printf '\\n%s%s:%s\\n' "
               + f"'{end[:16]}' '{end[16:]}' \"${{{var}_RC}}\"; unset {var}_RC\r")
    con.send(command)
    con.expect([boundary(begin)], args.connect_timeout)
    _, match, output = con.expect([r'(?m)^' + re.escape(end) + r':(\d+)\n'], args.timeout)
    return int(match.group(1)), output[:-1] if output.endswith("\n") else output


def setup_remote_terminal(con, args):
    """Only called after detecting a Linux shell, before interactive handover."""
    if args.no_terminal_setup:
        return
    if args.rows is not None:
        rows, cols = args.rows, args.cols
    else:
        try:
            size = os.get_terminal_size(sys.stdout.fileno())
            rows, cols = size.lines, size.columns
        except OSError:
            raise RuntimeError('Cannot read local terminal size; specify --rows and --cols or --no-terminal-setup') from None
    if rows <= 0 or cols <= 0:
        raise RuntimeError('Local terminal size is zero; specify --rows and --cols')
    term = args.term or 'xterm'
    token = 'SOL_TTY_' + uuid.uuid4().hex
    command = (f'stty rows {rows} cols {cols} && '
               f'{{ unset LINES COLUMNS; export TERM={shlex.quote(term)}; }}; '
               "printf '\\n%s%s:%s\\n' " + f"'{token[:16]}' '{token[16:]}' \"$?\"")
    con.send(command + '\r')
    _, match, _ = con.expect([r'(?m)^' + re.escape(token) + r':(\d+)\n'], args.connect_timeout)
    if int(match.group(1)) != 0:
        raise RuntimeError('Remote terminal setup failed; check stty availability or use --no-terminal-setup')
    message = f'Remote terminal configured: TERM={term}, rows={rows}, cols={cols}'
    print(message, file=sys.stderr, flush=True)
    if con.session_log:
        con.session_log.record('EVENT', message)
