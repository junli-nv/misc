"""Upload support for the SOL tools."""
import base64
import hashlib
import pathlib
import re
import shlex
import sys
import time
import uuid

from .session import execute

def upload_digest(path, limit=None):
    digest = hashlib.sha256()
    with path.open('rb') as source:
        remaining = limit
        while remaining is None or remaining > 0:
            data = source.read(1024 * 1024 if remaining is None else min(1024 * 1024, remaining))
            if not data:
                break
            digest.update(data)
            if remaining is not None:
                remaining -= len(data)
    return digest.hexdigest()


def upload_stage(args, digest):
    identity = hashlib.sha256((args.remote_path + '\0base64\0' + digest).encode()).hexdigest()[:32]
    if args.no_resume:
        identity = uuid.uuid4().hex
    return str(pathlib.PurePosixPath(args.remote_path).parent / ('.sol-upload-' + identity))


def upload_already_complete(checked, args, digest):
    if args.no_resume:
        return False
    q = shlex.quote
    token = 'SOL_COMPLETE_' + uuid.uuid4().hex
    output = checked(f'''if test -f {q(args.remote_path)} && test ! -L {q(args.remote_path)}; then
if test "$(sha256sum {q(args.remote_path)} | cut -d ' ' -f 1)" = '{digest}'; then
chmod {args.mode} {q(args.remote_path)} && printf '{token}\\n'
fi
fi
true''')
    if token in output.splitlines():
        print(f'Already uploaded: {args.remote_path}; SHA-256 verified: {digest}')
        return True
    return False


def prepare_upload_stage(checked, staging):
    q = shlex.quote
    checked(f'''set -e
umask 077
test ! -L {q(staging)}
mkdir -p -- {q(staging)}
test -O {q(staging)}
chmod 700 -- {q(staging)}
for f in payload payload.b64 prefix; do
  test ! -L {q(staging)}/"$f"
  test ! -e {q(staging)}/"$f" || test -f {q(staging)}/"$f"
done
''')


def resume_offset(checked, staging, source):
    """Verify remote prefix against the local file before trusting any resume data."""
    q = shlex.quote
    partial = staging + '/payload.b64'
    binary = staging + '/prefix'
    decode = f'base64 -d < {q(partial)} > {q(binary)}'
    token = 'SOL_PREFIX_' + uuid.uuid4().hex
    output = checked(f'''if test -f {q(partial)}; then
 if {decode}; then
  printf '{token}:%s:%s\\n' "$(wc -c < {q(binary)})" "$(sha256sum {q(binary)} | cut -d ' ' -f 1)"
 else printf '{token}:INVALID\\n'; fi
else printf '{token}:0:{hashlib.sha256(b'').hexdigest()}\\n'; fi''')
    match = re.search(re.escape(token) + r':\s*(\d+):([0-9a-f]{64})', output)
    if match:
        count = int(match.group(1))
        if (count <= source.stat().st_size and (count % 3 == 0 or count == source.stat().st_size)
                and upload_digest(source, count) == match.group(2)):
            if count:
                print(f'Resuming upload at verified offset {count} bytes.', file=sys.stderr, flush=True)
            return count
    print('Saved upload prefix is invalid; restarting this file.', file=sys.stderr, flush=True)
    checked(f': > {q(partial)}')
    return 0


def add_transfer_options(parser):
    parser.add_argument('--no-resume', action='store_true', help='Start a fresh transfer; default: verify and reuse saved progress on rerun')


def validate_transfer_options(args):
    if args.no_resume and not (args.upload or getattr(args, 'download', None)):
        raise ValueError('--no-resume requires upload or download')


def upload(con, args):
    full_digest = upload_digest(args.upload)
    staging = upload_stage(args, full_digest)
    q = shlex.quote

    def checked(command):
        rc, output = execute(con, command, args)
        if rc:
            raise RuntimeError(f'Upload failed (remote exit {rc}): {output.strip()}')
        return output

    # Own a private directory on the destination filesystem; never truncate the target.
    checked('command -v base64 sha256sum chmod ln mv wc cut >/dev/null')
    if upload_already_complete(checked, args, full_digest):
        return 0
    prepare_upload_stage(checked, staging)
    synchronized = True
    completed = False
    try:
        total = resume_offset(checked, staging, args.upload)
        checked(f'touch -- {q(staging + "/payload.b64")}')
        last_report = time.monotonic()
        with args.upload.open('rb') as source:
            source.seek(total)
            while data := source.read(192):
                encoded = base64.b64encode(data).decode('ascii')
                token = 'SOL_' + uuid.uuid4().hex
                # One bounded serial line and status acknowledgement per chunk.
                con.send(f"printf '%s' '{encoded}' >> {q(staging + '/payload.b64')}; "
                         + "printf '\\n%s%s:%s\\n' "
                         + f"'{token[:16]}' '{token[16:]}' \"$?\"\r")
                _, match, _ = con.expect(
                    [r'(?m)^' + re.escape(token) + r':(\d+)\n'], args.connect_timeout)
                if int(match.group(1)):
                    raise RuntimeError('Remote write failed during upload')
                total += len(data)
                if time.monotonic() - last_report >= 5:
                    print(f'Uploaded {total} bytes...', file=sys.stderr)
                    last_report = time.monotonic()
        action = 'mv -fT' if args.overwrite else 'ln -T'
        checked(f'''set -e
base64 -d < {q(staging + '/payload.b64')} > {q(staging + '/payload')}
cd -- {q(staging)}
printf '%s  payload\\n' '{full_digest}' | sha256sum -c -
chmod {args.mode} payload
{action} -- payload {q(args.remote_path)}
''')
        completed = True
        print(f'Uploaded {total} bytes to {args.remote_path}; SHA-256 verified: {full_digest}')
        return 0
    except (TimeoutError, KeyboardInterrupt):
        synchronized = False
        print(f'Upload interrupted; remote state is uncertain. Temporary directory: {staging}', file=sys.stderr)
        raise
    finally:
        if synchronized and completed:
            try:
                checked(f'rm -f -- {q(staging + "/payload.b64")} {q(staging + "/payload")} {q(staging + "/prefix")}; rmdir -- {q(staging)}')
            except (RuntimeError, OSError, TimeoutError):
                print(f'Could not clean remote temporary directory: {staging}', file=sys.stderr)

        if not completed:
            print(f'Upload progress retained; rerun the same upload to resume: {staging}', file=sys.stderr)
