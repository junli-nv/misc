# IPMI SOL Command Execution

[中文](README.md) | [English](README.en.md)

`sol_exec.py` connects to a BMC's SOL console using IPMI 2.0 (`lanplus`), logs in to the Linux serial console, and executes custom Bash commands. The local machine can run Linux or macOS and needs only Python 3.9+ and `ipmitool`; no third-party Python packages are required. The remote Linux machine needs `bash` and `base64`.

Runtime requires only `sol_exec.py` and one `inventory.ini` copied from `inventory.example.ini`; no helper Python files are needed. Use `--host` for single-host operations and `--batch` for batches. `--hosts`, `--hosts-file`, `--group`, `--match`, `--list-hosts`, `--jobs` or `--result-dir` also enable batch mode. Use `--help-batch` for batch help.

## Dependencies when distributing to a new machine

The script uses only the Python standard library, so **no third-party pip packages are required**. Use **Python 3.9+** on Linux/macOS; Unix modules such as `pty` and `termios` are not supported by native Windows Python. Remote nodes do not need Python.

Ubuntu/Debian controller:

```bash
sudo apt-get update
sudo apt-get install -y python3 ipmitool iputils-ping

# Optional, for ZMODEM uploads
sudo apt-get install -y lrzsz

# Run directly after installing system dependencies
python3 sol_exec.py --help-all
```

Neither pip nor a virtual environment is required. Install Python and the necessary system tools, then run the script directly.

| Location/function | Dependency |
| --- | --- |
| Controller SOL connection | `ipmitool` |
| Default reachability checks | `ping`; macOS IPv6 checks use `ping6` |
| Controller ZMODEM uploads | `sz` or `lsz` from lrzsz |
| Remote commands | `bash`, `base64` |
| Remote uploads/resume | GNU coreutils: `base64`, `sha256sum`, `wc`, `cut`, `chmod`, `ln`, `mv`, `mkdir`, `rm`, `rmdir`, `touch`, `cat` |
| Remote ZMODEM uploads | The above, plus `rz` or `lrz` from lrzsz and `stty` |

Remote Ubuntu/Debian installation:

```bash
sudo apt-get install -y bash coreutils
sudo apt-get install -y lrzsz  # ZMODEM only
```

For a macOS controller with Python 3.9+, use `brew install ipmitool` and optionally `brew install lrzsz`; ping is provided by the OS. Similarly named pip packages are not substitutes for these system executables.

Distribute `sol_exec.py`, `inventory.example.ini` and the desired README. Copy the template to `inventory.ini`, fill in real nodes, and apply `chmod 600 inventory.ini`; do not distribute real credentials to unrelated users. Enabling BMC SOL and configuring Linux serial login remain system setup tasks, not pip dependencies.

## IPMI power control and BMC logs

These operations call `ipmitool` directly and need only BMC credentials, without OS login or SOL. Use `--host` for one node, or `--hosts`, `--hosts-file`, `--group` and `--match` for batches. Replace `sol_exec` with `python3 sol_exec.py` if the shell function is not enabled.

```bash
# Single-host power status, power on, and ACPI shutdown
sol_exec --config inventory.ini --host gpu001 --power status
sol_exec --config inventory.ini --host gpu001 --power on
sol_exec --config inventory.ini --host gpu001 --power soft

# Preview the selection, then power on selected nodes
sol_exec --config inventory.ini --hosts 'gpu[001-003,007]' --power on --list-hosts
sol_exec --config inventory.ini --hosts 'gpu[001-003,007]' --power on --jobs 4

# Read the System Event Log (SEL)
sol_exec --config inventory.ini --host gpu001 --bmc-log list
sol_exec --config inventory.ini --host gpu001 --bmc-log elist --sel-last 20
sol_exec --config inventory.ini --host gpu001 --bmc-log info
sol_exec --config inventory.ini --host gpu001 --bmc-log elist --output sel.txt

# Collect the latest 50 records from each selected BMC
sol_exec --config inventory.ini --group cluster --bmc-log elist --sel-last 50 --result-dir ./bmc-results
```

| `--power` value | Meaning |
| --- | --- |
| `status` | Query power state |
| `on` | Power on |
| `soft` | Request ACPI shutdown; requires OS support |
| `off` | Hard power off without waiting for OS shutdown |
| `reset` | Hard reset |
| `cycle` | Power off and back on |

`--bmc-log list` displays SEL records, `elist` adds sensor descriptions, and `info` reports SEL repository information. `--sel-last N` requires `list/elist` and a positive N. This reads standard IPMI SEL, not vendor-specific BMC debug logs, and never clears records. See the [official ipmitool manual](https://github.com/ipmitool/ipmitool/blob/master/doc/ipmitool.1.in).

A successful power request means the BMC accepted it; it does not confirm that OS startup or shutdown has finished. Query `--power status` afterward. The script does not automatically retry power operations. `--timeout` bounds each IPMI request (default: 300 seconds); timeout returns 124 and leaves the operation's completion unknown. BMC ping preflight remains enabled; use `--skip-ping` when ICMP is blocked.

Single-host output goes to the terminal, or to `--output` (overwriting the destination). Batch output uses `batch-logs` or `--result-dir`: each node gets `stdout.txt` and `stderr.txt`, `results.json` summarizes exit codes, and `ipmi-operation.txt` records the operation. No SOL session logs are created. Batch exit status is 0 if all nodes succeed, or 1 if any fail. Power, SEL, remote commands, uploads and interactive console operations are mutually exclusive.

## Bash completion

Run once in Bash from the script directory:

```bash
source <(python3 ./sol_exec.py --bash-completion)
```

This creates a `sol_exec` shell function and enables Tab completion without third-party Python packages or the `bash-completion` package. It supports macOS Bash 3.2. The function remembers the absolute Python and script paths, so it works from any directory:

```bash
sol_exec --con<Tab>             # --config / --console / --connect-timeout
sol_exec --transfer <Tab>       # base64 / zmodem
sol_exec --upload ./<Tab>       # Local files, including paths containing spaces
sol_exec --log-dir ./<Tab>      # Local directories
```

Direct execution as `./sol_exec.py` also supports completion once the script has executable permission. Completion is not registered for `python3 sol_exec.py ...`; use `sol_exec ...`. Passwords, remote paths and remote commands have no completion candidates. Completion never connects to a BMC.

To enable it for future Bash login shells, add the following to `~/.profile`, replacing the path with the actual absolute path. For non-login interactive Bash, add the same line to `~/.bashrc`:

```bash
if [ -n "${BASH_VERSION:-}" ]; then source <(python3 /absolute/path/to/sol_exec.py --bash-completion); fi
```

Options are generated from the script's argument definitions. Run `source` again after updating the script to refresh them.

## Installation and usage

Three levels of help are available without connecting to a BMC:

```bash
python3 sol_exec.py                 # Brief help by default
python3 sol_exec.py -h              # Same as --help: common options and quick start
python3 sol_exec.py --help-all      # All options, defaults, limitations and examples
python3 sol_exec.py --help-examples # Usage examples only
```

Help text is in English. Advanced options omitted from brief help remain available.

On an Ubuntu/Debian control machine:

```bash
sudo apt-get install ipmitool python3
python3 sol_exec.py --host 192.0.2.10 --bmc-user admin --os-user root \
  --command 'hostname; uname -r; cat /sys/module/intel_idle/parameters/max_cstate'
```

The script prompts for the BMC password and then the Linux password. These are separate accounts. The IPMI account needs SOL access, SOL must be enabled on the BMC, and Linux must have serial console login configured. The connection requests ADMINISTRATOR privilege and uses cipher suite 17 by default. Use `--cipher` if the device documentation specifies another suite.

Execute multiple commands from a local file:

```bash
python3 sol_exec.py --host 192.0.2.10 --bmc-user admin --os-user root \
  --command-file check_cpu.sh --timeout 120 --output node-cpu.txt
echo "Remote exit code: $?"
```

Example `check_cpu.sh`:

```bash
set -e
hostname
uname -r
for p in max_cstate states_off; do
    printf '%s=' "$p"
    cat "/sys/module/intel_idle/parameters/$p"
done
```

To avoid interactive password prompts, supply both passwords as arguments:

```bash
python3 sol_exec.py --host 192.0.2.10 \
  --bmc-user admin --bmc-password 'BMC_PASSWORD' \
  --os-user root --os-password 'LINUX_PASSWORD' \
  --command 'hostname; uname -r'
```

Password precedence is: command-line argument > corresponding environment variable > configuration file > interactive prompt. Explicit empty strings are respected. For passwords starting with `-`, use `--bmc-password='-example'` or `--os-password='-example'`.

Automation can also supply the `IPMI_PASSWORD` and `SOL_OS_PASSWORD` environment variables. Command-line passwords may appear in shell history and process arguments; environment variables avoid putting passwords in the script's command line. The script always passes the BMC password to ipmitool through its environment and redacts automatic password input and its authentication response when logging is enabled. Do not set passwords in a shell with `set -x` enabled. You can omit `--os-user` when a shell is already logged in.

## One configuration for single-host and batch operations

Maintain one INI file based on [inventory.example.ini](inventory.example.ini). Both modes accept `--config` and its alias `--inventory`, using the same nodes and credential inheritance.

```bash
cp inventory.example.ini inventory.ini
chmod 600 inventory.ini
# Edit addresses and passwords, then select one node by name or BMC address
python3 sol_exec.py --config inventory.ini --host gpu-bj-01 -c 'hostname'
python3 sol_exec.py --config inventory.ini --host 192.0.2.10 --interactive
python3 sol_exec.py --config inventory.ini --host gpu-bj-01 --console

# Use the same file for a batch
python3 sol_exec.py --batch --config inventory.ini --group beijing -c 'hostname'
python3 sol_exec.py --batch --config inventory.ini --match '^gpu-' --list-hosts
```

Single-host operations require exactly one node. Omit `--host` only if the inventory has one node; otherwise select an exact name or BMC address. Missing and ambiguous matches fail without choosing a default. With configuration, `--host` must select an inventory entry. CLI usernames override configuration; passwords follow CLI > environment > node > group > global defaults. Boot console mode ignores configured Linux credentials.

A single-node inventory uses the same format:

```ini
[all:vars]
bmc_user=admin
bmc_password=BMC_PASSWORD
os_user=root
os_password=LINUX_PASSWORD

[all]
node001 host=192.0.2.10
```

Migrate old `[connection]` configurations to this format; the separate template has been removed. Without --config, inventory.ini beside the script is used when needed; replay needs none. Passwords are plaintext: set permissions to `600`. Group and quoting details follow below.

## Watching boot before the OS starts

Use `--console` to connect to BMC SOL and immediately display incoming serial output:

```bash
python3 sol_exec.py --host 192.0.2.10 \
  --bmc-user admin --bmc-password 'BMC_PASSWORD' --console
```

- No Linux credentials are needed. Do not combine this mode with `--os-user` or `--os-password`.
- It does not wait for a login prompt or automatically send Enter, usernames or passwords. Watch BIOS POST, bootloader and kernel output; type manually to operate menus or log in when Linux is ready.
- Ctrl-] disconnects. Key forwarding and terminal restoration work as in interactive mode. A real terminal is required; `--output` is not supported.
- There is no session timeout after connection. `--connect-timeout` only limits SOL activation. Established SOL sessions reconnect by default; use `--no-reconnect` to disable this.
- The script does not power on or reboot the host. Connect first, then start the host using your existing management procedure to observe the full boot sequence. The script cannot replay output emitted before connection.
- The BMC must be reachable with SOL enabled. BIOS, bootloader and kernel serial redirection must each be configured for the stages you want to observe. Linux need not be running, but some BMCs may refuse SOL activation while the host is powered off.
- Unlike `--interactive --os-user ...`, which waits for Linux and authenticates automatically, `--console` hands over immediately without OS login detection.

## Interactive console

Automatically log in to Linux and open a live console:

```bash
python3 sol_exec.py --host 192.0.2.10 \
  --bmc-user admin --bmc-password 'BMC_PASSWORD' \
  --os-user root --os-password 'LINUX_PASSWORD' --interactive
```

For manual Linux login, multi-factor authentication (MFA), or direct access to an existing console, omit `--os-user`:

```bash
python3 sol_exec.py --host 192.0.2.10 --bmc-user admin --interactive
```

- `--interactive` / `-i` is mutually exclusive with command execution and uploads.
- Standard input and output must be connected to a real terminal; `--output` is not supported.
- Output streams live. Ctrl-C, Ctrl-D, Tab, arrow keys and UTF-8 input go to the remote console. Ctrl-] disconnects locally and is not sent remotely.
- After handover, you can answer sudo password prompts and run interactive programs. Automatic login does not support MFA; use manual login in that case.
- There is no interactive session timeout. `--connect-timeout` still applies to connection and automatic login.
- Local terminal settings are restored on normal exit, disconnect and handled interruption, including SIGTERM/SIGHUP. SIGKILL cannot be handled; use `stty sane` if the script is forcibly killed while the terminal is in raw mode.
- SOL does not negotiate terminal dimensions or terminal type. If needed, set `TERM` and run `stty rows N cols N` in the remote shell.
- Disconnecting SOL does not log out Linux or stop remote commands. To log out, run `exit` remotely first, then press Ctrl-] to disconnect.
- Tested using a simulated BMC console and local pseudo-terminals (PTYs); real BMC compatibility still requires validation.

## Rebooting after login and watching boot

```bash
python3 sol_exec.py --host 192.0.2.10 \
  --bmc-user admin --bmc-password 'BMC_PASSWORD' \
  --os-user root --os-password 'LINUX_PASSWORD' \
  --interactive --reconnect-attempts 10 --reconnect-delay 3
```

Once logged in, type `reboot` manually (or `sudo reboot` if appropriate).

- If SOL stays connected, subsequent boot output appears directly.
- If SOL drops, reconnection waits three seconds before each reactivation attempt by default; no explicit `--reconnect` is needed. It then opens the console directly without waiting for Linux login or replaying usernames, passwords or `reboot`.
- `--reconnect-attempts` limits total reconnect attempts across this invocation (default: 10). Each activation is still subject to `--connect-timeout`. Successful reconnections do not reset the attempt budget. Exhausting retries returns 125. Change the default three-second delay with `--reconnect-delay` (0–60 seconds). Total elapsed time also includes connection attempts, not just 10 × 3 seconds.
- Automatic reconnection is enabled by default only for `--interactive` and `--console`. Use `--no-reconnect` to disable it; `--reconnect` is retained for compatibility. It does not retry batch commands, uploads or initial connection failures.
- Ctrl-] deliberately disconnects without retrying. During reconnect waits, Ctrl-C exits locally; while connected, Ctrl-C goes to the remote console.
- BIOS, bootloader and kernel serial output must be configured. Output emitted during a disconnect may be lost and cannot be replayed. Reconnection may temporarily fail while the BMC retains a stale SOL session; the script does not forcibly evict it.
- Do not use `--command reboot` to watch boot continuously: batch mode waits for a command completion marker and does not provide this reconnect workflow.

## Uploading files

```bash
python3 sol_exec.py --host 192.0.2.10 \
  --bmc-user admin --bmc-password 'BMC_PASSWORD' \
  --os-user root --os-password 'LINUX_PASSWORD' \
  --upload ./check_cpu.sh --remote-path /tmp/check_cpu.sh --mode 755
```

- Choose exactly one of `--upload`, `--command`, `--command-file`, `--interactive`, `--console` and `--replay`. Uploading saves the file without executing it.
- `--remote-path` must be an absolute remote filename. Its parent directory must already exist and be writable by the logged-in user.
- Existing files are not overwritten by default. Add `--overwrite` to replace one. A directory cannot be the destination file.
- Default permissions are `600`. Use three octal digits, such as `--mode 755`, to change them. The file belongs to the Linux user performing the upload; local ownership, timestamps and other metadata are not preserved.
- Binary content and empty files are supported. Each chunk contains 192 bytes of original data, with a write acknowledgement per chunk. The destination is published only after SHA-256 verification succeeds.
- A temporary directory is created in the destination's parent directory. Transfer or checksum failures do not publish the destination. Failures/interruption preserve `.sol-upload-*` checkpoints and report their paths; rerun to verify and resume. Successful transfers clean staging. Rerunning after a final-publication disconnect verifies the target hash before retransmitting; there is no automatic reconnection.
- The remote machine needs Linux Bash, Base64, `sha256sum` and GNU coreutils (`ln -T` / `mv -T`). No additional local Python packages are needed.
- SOL bandwidth is limited, so uploads are best suited to scripts and small configuration files. Progress is written to stderr approximately every five seconds. `--connect-timeout` controls each chunk acknowledgement; `--timeout` controls each remote processing command. Neither is a total upload time limit.

## Saving SOL input/output logs (enabled by default)

All remote connection modes record I/O by default; no `--log-file` flag is needed. Automatic reconnections continue writing to the same file. Local `--replay` never creates a new log:

```bash
python3 sol_exec.py --host 192.0.2.10 \
  --bmc-user admin --bmc-password 'BMC_PASSWORD' \
  --console --log-dir ./logs
```

An example of the default generated path is:

```text
logs/sol_192.168.1.100_20260910_143025_123456+0800.jsonl
```

The filename includes the BMC host, local recording start date/time, microseconds and UTC offset. Unsafe filename characters, such as IPv6 colons, are replaced with underscores. `--log-dir` defaults to `logs/` in the working directory and is created automatically. Each invocation creates a new file; reconnects continue in that file.

You can still use an explicit filename: `--log-file ./node-sol.jsonl`. Its parent must already exist; do not combine this with `--log-dir`. Use `--no-log` to disable logging; it cannot be combined with `--log-file`. The script prints the absolute log path when recording starts; pass that path to `--replay` later.

- Logs use JSON Lines. Each record has a timezone-aware `time`, a `direction` and `data`.
- `IN` records input sent to ipmitool/SOL, `OUT` records console output, and `EVENT` records connections, closure and reconnect attempts. Records follow I/O chunks, not necessarily complete commands or lines.
- Each record is flushed immediately. The file must not exist. New files use permissions `600`. Auto-naming creates the log directory; an explicit filename requires an existing parent. Reconnection neither truncates nor recreates the file.
- Control characters such as carriage returns, newlines and arrow keys are JSON-escaped. Split UTF-8 characters or non-UTF-8 bytes may appear as byte escapes; this is not a raw binary serial capture format.
- The BMC password is not logged. Automatically sent Linux passwords and subsequent responses until the login result is matched are replaced with redaction markers, preventing password echo from leaking. This brief authentication output is therefore not preserved in full.
- **Manual input is recorded, including manually entered login or sudo passwords, even when remote echo is disabled.** Logs may also contain commands, Base64 upload content and sensitive system information.
- `--log-file` records I/O, while `--output` saves only the final batch-command output. They may be combined using different file paths.

## Playing back recorded sessions

Replay JSONL logs created by this script's `--log-file` option:

```bash
# Original timing
python3 sol_exec.py --replay ./node-sol.jsonl

# Four times faster
python3 sol_exec.py --replay ./node-sol.jsonl --replay-speed 4

# Also show recorded input
python3 sol_exec.py --replay ./node-sol.jsonl --replay-speed 2 --replay-inputs
```

Replay requires no BMC address, credentials or ipmitool. It never connects to a remote host or re-executes recorded commands.

| Key | Action |
|---|---|
| Space | Pause or resume |
| `+` / `=` | Double speed, up to 64x |
| `-` | Halve speed, down to 0.125x |
| `f` | Advance 10 seconds of recorded time |
| `n` | Jump to the next record to skip an idle interval |
| `q` / Ctrl-] | Quit playback |
| Ctrl-C | Interrupt playback |

- `--replay-speed` defaults to 1 and accepts 0.125–64. Keyboard controls require a real terminal. Redirected/piped playback uses the selected speed without reading keyboard input.
- Timestamps determine delays, including reconnect gaps. Backward wall-clock changes preserve record order and compress the backward interval to zero delay.
- `OUT` data is rendered to stdout; `EVENT` annotations go to stderr. `--replay-inputs` additionally displays escaped `IN` annotations without sending input to a shell. Command echoes already present in recorded output remain visible.
- Forward skips render intervening records immediately to preserve terminal updates. Reverse playback and backward seeking are not supported.
- Recorded ANSI control sequences are rendered by the local terminal. Appearance depends on terminal type and dimensions. Missing output, redacted passwords and lost serial bytes cannot be restored. This is terminal-log playback, not a video file.
- The entire log is validated and loaded into memory before playback. Empty or malformed logs produce an error. Large logs require sufficient memory. Completion returns 0, read/format errors return 125, and interruption returns 130.
- `--replay` is mutually exclusive with other operations and cannot be combined with BMC/Linux credentials, log-writing or upload options.

## General behavior and limitations

- For batch commands, stdout contains remote command output. A serial console cannot separate remote stdout and stderr and may include kernel or other process messages. Output is returned on command completion, making this mode suitable for diagnostic commands with finite output.
- Automatic login recognizes shell prompts ending in `#` or `$` by default. Use `--prompt` to supply a Python regular expression for a different prompt. Before batch execution, a random marker verifies shell responsiveness.
- Commands are Base64-encoded and transferred in acknowledged chunks to avoid serial line length and quoting problems. Batch commands run in a separate Bash process without changing the login shell's working directory.
- Batch mode supports noninteractive commands only. It does not answer sudo, MFA, password-expiration or BIOS prompts. Use `--interactive` for manual operation; omit `--os-user` when extra authentication steps require manual login.
- Remote command exit codes are returned unchanged. Local timeout returns 124, connection/authentication/upload failure returns 125, and interruption returns 130. Successful uploads and normal interactive disconnects return 0. Remote commands can return the same numeric codes, so consult stderr to distinguish them.
- Timeouts do not retry commands or guarantee that remote commands stop. Commands that disconnect the console, such as reboot or shutdown, usually cannot return a completion marker.
- Cleanup uses ipmitool's local `~.` escape to close this SOL session. It does not issue a global `sol deactivate` or evict other sessions.
- Linux login sessions are not automatically logged out, including sessions logged in by the script. Follow your site's console management practices. SOL is a shared serial console; avoid simultaneous input from other users.
- Local output files must not already exist. Command output may contain sensitive information; choose its storage location accordingly.

## Validation

Linux login and interactive shell behavior have been tested using local PTYs. The script has not been validated against a real BMC, so compatibility with a particular vendor's SOL implementation is not confirmed.

Upload tests cover empty files, binary chunk boundaries, special filenames, overwrite protection, explicit replacement, permissions, corruption detection and temporary-file cleanup. On macOS, GNU `ln -T` / `mv -T` were simulated using corresponding file operations; validation on the actual Linux/BMC environment is still required.

Protocol option reference: https://github.com/ipmitool/ipmitool/blob/master/doc/ipmitool.1.in

## Multi-host execution, credential groups and regex selection

`sol_exec.py --batch` runs the same noninteractive Bash command or local script on multiple hosts, with at most 4 concurrent connections by default. A host failure does not stop other hosts. Commands are never retried automatically. Run the following examples from `sol`:

```bash
cp inventory.example.ini inventory.ini
chmod 600 inventory.ini
# Edit addresses and passwords before use
python3 sol_exec.py --help-batch
```

Use [inventory.example.ini](inventory.example.ini) as the recommended template:

```ini
[all:vars]
os_user=root
os_password=LINUX_PASSWORD

[beijing]
gpu-bj-01 host=192.0.2.10
gpu-bj-02 host=192.0.2.11 bmc_password='SPECIAL_PASSWORD'

[beijing:vars]
bmc_user=admin
bmc_password=BEIJING_PASSWORD

[shenzhen]
192.0.2.[20-21]

[shenzhen:vars]
bmc_user=operator
bmc_password=SHENZHEN_PASSWORD
```

`[all:vars]` supplies global credentials; `[group:vars]` supplies group credentials. In `[group]`, write one BMC address per line, or `name host=BMC_ADDRESS`. Addresses refer to BMCs, not Linux OS interfaces. Override any of `bmc_user`, `bmc_password`, `os_user`, `os_password` on individual host lines. Optional `[all]` holds standalone hosts. Node names and BMC addresses must each be unique; a host cannot appear in multiple groups.

Inheritance per field: **host line > group vars > all:vars**. CLI usernames override configuration. Password precedence: **CLI > `IPMI_PASSWORD` / `SOL_OS_PASSWORD` environment > configuration hierarchy**. Existing environment passwords override all group/node passwords.

Vars sections use `key=value`, allowing whitespace around `=`. Unquoted values retain internal spaces, `#`, `;`, `%` and backslashes without interpolation; whole values may also be quoted. Host lines use shell-style quoting: quote passwords containing spaces or `#`. Blank lines and whole-line `#`/`;` comments are supported. Do not put trailing comments on vars assignments: they become part of the value.

This is an Ansible-style subset, without `:children`, Jinja, Ansible variable aliases or dynamic inventory. Both modes use this INI format; migrate old JSON or `[connection]` configurations.

Preview selection without connecting, complete credentials, or ipmitool:

```bash
python3 sol_exec.py --batch --inventory inventory.ini --list-hosts
python3 sol_exec.py --batch --inventory inventory.ini --group beijing --list-hosts
python3 sol_exec.py --batch --inventory inventory.ini --match '^gpu-bj-0[12]$' --list-hosts
python3 sol_exec.py --batch --inventory inventory.ini --match '^192\.0\.2\.(10|11)$' --list-hosts
```

Output columns are node name, BMC address and group (`-` for standalone nodes). Repeat `--group` to select several groups; combine it with `--match` to narrow the selection. Regex uses Python search semantics and is case-sensitive by default; anchor with `^` and `$` for a full match. It matches inventory names/addresses only: no DNS resolution, network scanning or IP range expansion. Without a selector, all inventory nodes are selected. Empty selections and unknown groups fail explicitly.

```bash
python3 sol_exec.py --batch --inventory inventory.ini --group beijing -c 'hostname; uname -r'
python3 sol_exec.py --batch --inventory inventory.ini --match '^gpu-' \
  --command-file check_cpu.sh --jobs 4 --timeout 120

# Select BMC addresses from the same inventory
python3 sol_exec.py --batch --config inventory.ini --hosts 192.0.2.10,192.0.2.11 -c 'hostname'
python3 sol_exec.py --batch --config inventory.ini --hosts-file hosts.txt --command-file check_cpu.sh
```

Host files contain one BMC address/hostname per line, ignoring blank lines and `#` comments and deduplicating addresses. `--hosts`, `--hosts-file` and `--match` are mutually exclusive. The first two expand hostlists and match exact inventory node names or BMC addresses; every selector must exist when an inventory is provided. Without an inventory, entries are BMC addresses. Selecting the same node by both name and address runs it once; a name matching another node's address is rejected as ambiguous. Missing BMC/Linux credentials are prompted in the main thread before connections; workers never prompt for passwords.

Results default to `batch-logs/run_<timestamp-and-timezone>_<random-ID>/` under the working directory. Use `--result-dir` to specify a new directory. It contains `command.sh` (command/script snapshot), `results.json` (updated after each host completes), and `<index>_<BMC-address>/` directories with:

- `stdout.txt`: remote command output, including merged remote stdout/stderr because SOL cannot separate them.
- `stderr.txt`: local connection/error diagnostics.
- `sol.jsonl.gz`: default SOL log, playable with `sol_exec.py --replay <path>`. `--no-log` disables only this file.

The summary includes name, BMC address, status, exit code, duration and output directory, without configuration passwords. Cancelled queued hosts appear in the summary but may have no output directory. Directories have mode `700`; files have mode `600`. Logs and command snapshots may contain sensitive command data.

Exit codes: `0` all succeeded, `1` any failure, `2` invalid input, `130` interrupted. Ctrl-C closes active local sessions and cancels queued work; disconnects and timeouts do not guarantee remote commands stop. Commands must not require input such as sudo passwords or MFA; use `sudo -n` where appropriate.

**The batch entry point does not support interactive/boot consoles, replay, or keyboard broadcasting.** For multiple live consoles, run separate `sol_exec.py --interactive` or `--console` instances in terminal tabs or tmux panes. Each instance connects to one BMC and records its own log. Both modes read the same grouped INI inventory.

### Slurm-style host ranges

INI host lines, `--hosts` and `--hosts-file` accept numeric hostlist expansion:

```ini
[beijing]
192.0.2.[10-11]
node[001-003,007]
# Aliases and BMC addresses are paired in order
worker[001-002] host=192.0.2.[40-41]
```

```bash
python3 sol_exec.py --batch --config inventory.ini --hosts '192.0.2.[10-11]' -c 'hostname'
python3 sol_exec.py --config inventory.ini --hosts 'worker[001-002]' --list-hosts
python3 sol_exec.py --config inventory.ini --hosts 'worker[001-002]' --jobs 2 -c 'hostname; uptime'
# Alternatively, select inventory nodes with a Python regex
python3 sol_exec.py --config inventory.ini --match '^worker00[12]$' -c 'hostname'
```

`node[001-002]` produces `node001,node002`; `rack[1-2]node[01-02]` produces four combinations. Comma lists work both inside and outside brackets. Leading zeros on the range start are preserved. Quote CLI expressions to prevent shell glob expansion.

`--hosts` also selects inventory aliases: `--hosts 'worker[001-002]'` connects to `192.0.2.40` and `192.0.2.41`. Add `--group` to narrow the selection further. Alternatively, use `--match` with a Python regex; it cannot be combined with `--hosts` or `--hosts-file`. Alias/address ranges must expand to equal counts and are paired in order. For a special host password, exclude that host from the range and add it on a separate line.

This supports common Slurm numeric hostlist syntax, not the complete Slurm parser: no strides, alphabetic ranges, nested brackets or descending ranges. Inventories/selections are limited to 10,000 expanded nodes; invalid or oversized ranges fail before connecting.

## Compressing large logs

Use `--log-compress` for single-host or batch sessions to write gzip directly using the Python standard library. Gzip is enabled by default; omit `--log-compress`. Use `--no-log-compress` for plain JSONL or `--no-log` to disable logging.

```bash
python3 sol_exec.py --config inventory.ini --host gpu-bj-01 --interactive --log-compress
python3 sol_exec.py --config inventory.ini --batch --group beijing -c 'hostname' --log-compress
python3 sol_exec.py --replay ./session.jsonl.gz --replay-speed 4
```

Automatic filenames end in `.jsonl.gz`; each batch node gets `sol.jsonl.gz`. With an explicit `--log-file session.jsonl`, `--log-compress` appends `.gz`. An explicit filename ending in `.gz` also enables gzip. Explicit `--log-compress` cannot be combined with `--no-log`; default compression does not prevent disabling logs. `--no-log-compress` requires a filename without `.gz`. Only SOL logs are compressed; batch command snapshots, stdout/stderr and result summaries remain uncompressed.

Replay accepts plain JSONL and detects gzip headers automatically, retaining speed and seek controls. Records are flushed as they arrive; normal closure writes the gzip trailer. Power loss or forced termination may leave an incomplete compressed file, which replay rejects. Replay after recording finishes.

Compression saves disk space; replay still loads all decompressed records into memory. Files remain exclusive-create with mode `600`, with the same password redaction rules.

## Export recorded screen output for grep

Use `--replay-export` to write recorded `OUT` to stdout immediately, without playback delays or UI. Both plain JSONL and gzip logs are supported:

```bash
python3 sol_exec.py --replay session.jsonl.gz --replay-export | grep -ni 'error'
python3 sol_exec.py --replay session.jsonl.gz --replay-export | grep -n -C 3 'GPU'
python3 sol_exec.py --replay session.jsonl.gz --replay-export > session.txt
```

Export concatenates OUT records in order, excluding IN/EVENT, stripping ANSI and control codes, and normalizing CRLF/CR to newlines. Commands echoed by the remote console are OUT and remain included. Errors go to stderr. Do not combine with `--replay-inputs` or a nondefault `--replay-speed`.

This is searchable output history, not a final terminal screenshot: progress updates and full-screen redraws may leave repeated content; cursor overwrites are not emulated. All records are loaded and validated before export, requiring memory for the decompressed log. Unrecorded or redacted content cannot be recovered.

## Check BMC reachability and skip failed pings

```bash
python3 sol_exec.py --config inventory.ini --check-hosts
python3 sol_exec.py --config inventory.ini --group beijing --check-hosts --ping-jobs 32 --ping-attempts 3 --ping-timeout 2 --ping-interval 0.5
```

By default, up to **32 BMCs** are checked concurrently (`--ping-jobs`). Each check sends up to **3 probes**, with a **2-second** deadline per probe and **0.5 seconds** between failures; any reply passes immediately. All-timeout checks take about 7 seconds plus process scheduling overhead. Hosts run concurrently; retries within each host are sequential. Batch mode finishes ping preflight before starting SOL on passing hosts. SOL concurrency remains independently controlled by `--jobs` (default: 4). Select with `--group`, `--match` or `--hosts`. Output includes name, address, reachable/ERROR and totals. Check-only mode needs neither credentials nor ipmitool and creates no SOL logs. Exit is `0` for all reachable, `1` for any failure. Hostnames are resolved locally; checks target BMC addresses, not OS interfaces.

Single-host and batch connections now check ping by default. Failed hosts never start SOL or retry; other batch hosts continue. Batch `results.json` records `status=unreachable`, exit code `125` and an error, without a SOL output directory. Single-host failures return `125`. Interactive reconnection performs the same check before each round. Failed ICMP checks skip SOL for that round; subsequent rounds remain bounded by `--reconnect-attempts` and `--reconnect-delay`.

A failed ping can indicate blocked ICMP rather than unavailable IPMI, and a successful ping does not establish SOL availability. Use `--skip-ping` for networks that block ICMP, restoring direct connection and the previous reconnection policy. `--ping-attempts`, `--ping-timeout` and `--ping-interval` control probe count, per-probe deadline and retry delay. `--ping-jobs` controls ping concurrency independently of `--jobs`. Check-only mode cannot be combined with command execution, `--list-hosts` or `--skip-ping`. Actual SOL sessions still require credentials.

## Ctrl-C behavior

- During ping checks, including concurrent probes, retry delays and batch preflight, Ctrl-C cancels pending work, terminates/reaps active ping children and returns `130` without waiting through every timeout/retry.
- During connection, automatic login, noninteractive commands/uploads and reconnection waits, Ctrl-C interrupts the local task and cleans up the session. Disconnecting SOL does not guarantee remote commands stop.
- After `--interactive` or `--console` enters terminal relay mode, keyboard Ctrl-C is forwarded as byte `0x03` for the remote program to handle; it does not exit the local script. Use **Ctrl-]** to detach. Local terminal settings are restored on exit.

Batch interruption preserves completed results and marks cancelled work accordingly. Sending an external SIGINT to the process differs from typing Ctrl-C in raw terminal mode.

## Default configuration and missing credentials

Without `--config`, the script looks for `inventory.ini` beside `sol_exec.py`, independently of the current working directory. Copy and edit `inventory.example.ini` there. Explicit `--config` takes precedence. A missing default file permits CLI-only use; an explicitly requested missing file or malformed configuration is an error.

Usernames: CLI > INI > terminal prompt. Passwords: CLI > existing environment variables > INI > terminal prompt. Only missing fields are requested, with password echo disabled. Without an interactive terminal, missing required fields produce an error instead of blocking.

Batch prompts occur in the main thread before ping/SOL starts. Each missing field is requested once per group, or separately for standalone hosts. Complete CLI credentials with explicit addresses do not need default configuration. Single-host mode without an OS username retains existing-shell/manual-console behavior; a configured OS username with no password triggers a prompt. Boot console needs no OS credentials. Replay reads no configuration; ping checks need no credentials.

## Node names in logs

Named inventory nodes appear as `gpu01 (192.0.2.10): ok` in batch results; address-only nodes display just the BMC address. Automatic single-host log names use `sol_<node-name>_<BMC-address>_<timestamp>.jsonl.gz`. Batch directories use `<index>_<node-name>_<BMC-address>/`, retaining `sol.jsonl.gz` inside. Identical names and addresses are not duplicated.

Every SOL log record includes `node_name` and `bmc_host`; connection events also identify the node. Explicit `--log-file` names are retained while their records carry node metadata. Existing logs remain compatible with replay and export.

## Batch file uploads

```bash
./sol_exec.py --inventory inventory.ini --group L5pod3 \
  --upload ./stat.sh --remote-path /tmp/stat.sh --mode 755
```

`--group` automatically enables batch mode; `--batch` is optional. Select with `--hosts`, `--hosts-file` or `--match` too. Default ping concurrency is 32, followed by up to 4 concurrent uploads; adjust with `--ping-jobs` and `--jobs` respectively.

Uploads reuse single-host Base64 (default) or ZMODEM, with SHA-256 verification, permissions and overwrite protection. Identical completed targets are skipped by default; different contents require `--overwrite`. The destination parent must exist. Uploading saves the file without executing it; issue a separate command to run it.

Every node receives the same `upload.payload` snapshot stored in the results directory with mode `600`. Logs and results are separate per node; one failure does not stop others. Uploads are never automatically retried. Interruptions/timeouts may require inspecting the remote file state. Use `--command-file` instead when you only want to execute a script.

## Interactive terminal size and TERM

```bash
# After automatic login, use local window dimensions and TERM=xterm
./sol_exec.py --inventory inventory.ini --host gpu01 --interactive

# Explicit dimensions/type
./sol_exec.py --inventory inventory.ini --host gpu01 --interactive \
  --rows 50 --cols 180 --term xterm

# Preserve remote settings
./sol_exec.py --inventory inventory.ini --host gpu01 --interactive --no-terminal-setup
```

This requires an OS login user from CLI or INI. After detecting the Linux shell, the script runs `stty rows N cols N`, unsets LINES/COLUMNS and exports TERM in that shell before handing over the keyboard. Rows/columns default to the actual local window; explicit values must be supplied together, within 1–65535. Choose a TERM matching local capabilities; override with `--term vt220` if appropriate.

No boot/login configuration files are modified. Raw boot console, manual login without an OS username and reconnection never inject setup commands into BIOS, login prompts or running applications. Set stty manually after reaching a shell in those modes. Window changes are not live-synchronized; leave full-screen applications before updating dimensions or starting a fresh automatic-login session.

## ZMODEM uploads and automatic resume

**Base64 remains the default.** Select `--transfer zmodem` to use local lrzsz over the existing SOL session. The script starts the local sender and remote receiver; do not launch them manually in separate terminals. ZMODEM currently supports uploads only, not downloads or automatic transfer detection during interactive console use.

Install `lrzsz` on the controller and remote Linux host (`sudo apt install lrzsz` on Ubuntu/Debian; `brew install lrzsz` on a macOS controller). The controller needs `sz` or `lsz`; the target needs `rz` or `lrz`. Remote bash, base64 (for control commands), stty, sha256sum, wc, cut and GNU coreutils remain required. The destination filesystem must be writable and support hard links. Software is not installed automatically and transfer methods are never silently switched.

```bash
# Base64 (default), with resume enabled
./sol_exec.py --host gpu01 --upload ./stat.sh --remote-path /tmp/stat.sh --mode 755

# Single-host ZMODEM
./sol_exec.py --inventory inventory.ini --host gpu01 \
  --upload ./stat.sh --remote-path /tmp/stat.sh --mode 755 --transfer zmodem

# Batch ZMODEM, independent progress per host
./sol_exec.py --inventory inventory.ini --group L5pod3 \
  --upload ./stat.sh --remote-path /tmp/stat.sh --mode 755 \
  --transfer zmodem --jobs 4 --timeout 600

# Explicit local sender executable
./sol_exec.py --host gpu01 --upload ./stat.sh --remote-path /tmp/stat.sh \
  --transfer zmodem --zmodem-sender /opt/homebrew/bin/sz

# Start fresh, without reusing a checkpoint (old checkpoints remain)
./sol_exec.py --host gpu01 --upload ./stat.sh --remote-path /tmp/stat.sh --no-resume
```

**Resume is enabled by default: rerun the same upload command after interruption.** No offset is required. This does not automatically reconnect forever: failed pings still skip nodes, and failed/interrupted transfers return while preserving progress.

- Checkpoints reside in `.sol-upload-<identity>/` under the destination parent, mode `700`, keyed by destination path, source SHA-256 and transport. Single/batch runs and different controllers can reuse progress with identical content/path/transport and appropriate directory access.
- Base64 verifies decoded prefix length/hash before appending. ZMODEM verifies the partial file before enabling lrzsz recovery. Invalid prefixes restart safely.
- Changed content or transport gets a separate checkpoint. `--no-resume` creates a fresh staging directory. Do not run simultaneous uploads of the same file to the same host/destination from multiple controllers.
- If the final target already matches SHA-256, default resume treats it as complete, applies the requested mode and skips transfer. Different contents still require `--overwrite`. Rerunning a batch therefore skips already-completed files.
- Successful uploads clean their staging directory; failures retain progress and print its path. Reboots or temporary-file cleanup may remove checkpoints. Remove obsolete staging directories manually when no longer needed.
- Some rz versions unlink partial files on cancellation; a temporary hard link preserves their data. A still-running previous receiver prevents a new one from starting.

ZMODEM uses a binary relay with ipmitool escape quoting and no ordinary keyboard forwarding. Protocol bytes are omitted from screen logs; transfer events/results are recorded, with progress on stderr. `--timeout` bounds the ZMODEM protocol stage (default 300 seconds), with separate timeouts for control commands; Base64 retains per-chunk/control-command timeouts. Ctrl-C terminates the sender and attempts receiver cancellation/TTY restoration. Severe disconnects leave staging for inspection and recovery.

Local tests used real lrzsz, PTYs and an ipmitool escape emulator: binary/empty files, overwrite protection, SHA-256, both resume paths, corrupt prefixes, and actual Ctrl-C preservation/resume passed. Real BMC compatibility is not yet verified; unsolicited console output and firmware differences can affect transfers.

### Complete ZMODEM example: sender and receiver responsibilities

Upload **`./stat.sh` on the controller `bcm11-headnode`** to **`/tmp/stat.sh` on Linux node `gpu01`**, whose BMC address is `192.0.2.10`:

```text
Sender: bcm11-headnode                     Receiver: gpu01 Linux
local stat.sh → sz/lsz ⇄ sol_exec.py ⇄ ipmitool ⇄ BMC SOL ⇄ rz/lrz → /tmp/stat.sh
```

The BMC supplies the serial channel; the file is saved in the node's Linux filesystem, not the BMC filesystem. Transfer uses SOL and does not require SSH connectivity to the target OS.

**Step 1: prepare the receiver in gpu01's Linux shell.**

Use an existing SSH or SOL login. Package installation requires access to a package repository or prior offline installation.

```bash
sudo apt-get update
sudo apt-get install -y lrzsz bash coreutils
command -v rz || command -v lrz
command -v bash base64 stty sha256sum
```

Ensure the upload account can write `/tmp`. **Do not start rz manually; leave the shell at its normal prompt.** If you used another SOL client for preparation, disconnect it first to release the SOL session.

**Step 2: prepare the sender on bcm11-headnode.**

```bash
sudo apt-get update
sudo apt-get install -y python3 ipmitool iputils-ping lrzsz
command -v sz || command -v lsz
ls -l ./stat.sh
sha256sum ./stat.sh
```

Configure BMC and Linux credentials in the controller's `inventory.ini`:

```ini
[all:vars]
bmc_user=admin
bmc_password=REPLACE_WITH_BMC_PASSWORD
os_user=root
os_password=REPLACE_WITH_LINUX_PASSWORD

[L5pod3]
gpu01 host=192.0.2.10
```

Replace addresses/passwords and run `chmod 600 inventory.ini`. BMC credentials open SOL; OS credentials log in to the receiving Linux system.

**Step 3: run one upload command on the sender only.**

```bash
python3 sol_exec.py --inventory inventory.ini --host gpu01 \
  --upload ./stat.sh --remote-path /tmp/stat.sh --mode 755 \
  --transfer zmodem --timeout 600
```

The script automatically:

1. Checks BMC reachability, activates SOL and logs in to Linux.
2. Creates/reuses `.sol-upload-<identity>/` under the target parent and verifies saved progress.
3. Starts remote `rz -b -e -r -q` (or `lrz`) inside that staging directory.
4. Starts local `sz -b -e -r -q <local-snapshot-directory>/payload` (or `lsz`) and bridges protocol bytes bidirectionally through a raw PTY and SOL.
5. Receives the temporary file `payload`, verifies its full SHA-256, applies mode `755` and publishes it as `/tmp/stat.sh`.
6. Restores serial settings, cleans up successful staging and exits. **It does not execute stat.sh.**

The sz/rz commands explain the internal flow; they are not additional manual steps. `-b` selects binary transfer, `-e` escapes control characters, `-r` enables recovery and `-q` reduces lrzsz output. Running sz and rz in two unrelated terminals does not establish a SOL bridge.

Successful output resembles this (size and hash vary):

```text
Uploaded <bytes> bytes via ZMODEM to /tmp/stat.sh; SHA-256 verified: <SHA-256>
```

Verify the remote result from the controller:

```bash
python3 sol_exec.py --inventory inventory.ini --host gpu01 \
  -c 'ls -l /tmp/stat.sh; sha256sum /tmp/stat.sh'
```

**Step 4: resume or upload to a group.**

- After interruption, rerun the exact Step 3 command to verify/resume. Add `--no-resume` to start fresh.
- If the target already has different contents, add `--overwrite` only when replacement is intended.
- Replace `--host gpu01` with `--group L5pod3 --jobs 4` for a batch. Each node needs receiver dependencies installed beforehand; the script starts each receiver and reports separate results.
- Missing sz/lsz refers to the controller; missing rz/lrz refers to the remote Linux OS. Do not install the receiver inside the BMC shell or open another SOL session to run rz manually.
