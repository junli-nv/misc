#!/usr/bin/env python3
"""Control remote consoles, power and BMC logs."""
from sol_tools.cli import main


if __name__ == "__main__":
    raise SystemExit(main("control"))
