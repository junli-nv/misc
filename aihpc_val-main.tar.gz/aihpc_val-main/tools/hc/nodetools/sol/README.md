# IPMI SOL 命令执行

BMC 和 OS 的用户名、密码均可写入 inventory 的 `[all:vars]`、`[组名:vars]` 或节点行，继承顺序为全局 < 组 < 节点。配置完整后无需传入任何凭据参数，例如 `sol_exec --hosts node01 'hostname'`。`--bmc-user`、`--bmc-password`、`--os-user`、`--os-password` 仅用于临时覆盖；密码优先级为命令行 > 环境变量（`IPMI_PASSWORD` / `SOL_OS_PASSWORD`）> inventory。

[中文](README.md) | [English](README.en.md)

文档与脚本位于同一目录；以下命令均从 `sol/` 工具目录运行。

`sol_exec.py` 使用 IPMI 2.0 (`lanplus`) 连接 BMC 的 SOL，然后登录 Linux 串口控制台、执行自定义 Bash 命令。支持 Linux/macOS 控制端，仅需要 Python 3.9+ 和 `ipmitool`，不需要 Python 第三方包。目标 Linux 需要 `bash`、`base64`。

运行时需要对应入口脚本、完整的 `sol_tools/` 目录和 inventory。所有远程操作必须从 inventory 选择节点；默认读取工具目录下的 `inventory.ini`，也可指定 `--inventory FILE`（`--config` 为别名）。`--hosts` 支持节点名、BMC 地址及 Slurm 数字范围；也可使用 `--group`。不指定筛选条件时选择全部节点。选中一台直接执行，多台自动并发执行，无需切换模式。控制台和交互登录要求恰好一台；本地回放、帮助和补全不需要 inventory。

单机和多机使用同一套节点选择接口。`--jobs` 只控制并发数，不改变节点选择。下载选中一台时目标是文件名，多台时是目录。需要为单台也保存结构化结果时可指定 `--result-dir`，此时下载目标同样按目录处理。


## Inventory 中的运行默认值

`[sol:defaults]` 是保留配置段，统一设置执行参数，不是主机组。优先级：**命令行 > inventory > 程序内置默认值**。凭据仍放在 `[all:vars]`、`[组名:vars]` 或节点行。

```ini
[sol:defaults]
jobs=8
ping_jobs=32
timeout=600
connect_timeout=60
ping_timeout=2
ping_attempts=3
ping_interval=0.5
skip_ping=false
cipher=17
ipmitool=ipmitool
no_log=false
log_compress=true
reconnect=true
reconnect_attempts=10
reconnect_delay=3
```

例如 `sol_exec --group beijing 'hostname'` 默认使用 8 路并发；加 `--jobs 2` 临时改为 2 路。布尔值支持 true/false、yes/no、1/0。`--ping` 可覆盖 `skip_ping=true`，`--log` 可覆盖 `no_log=true`，`--no-log-compress` 和 `--no-reconnect` 可关闭对应功能。日志默认值只用于 SOL，重连默认值只用于控制台/交互登录；本地回放、帮助、补全不读取这些默认值。

这些设置是全局运行策略，不支持组或节点级覆盖。未知键、重复键及非法值直接报错。操作、节点筛选、覆盖文件开关和输出路径仍需显式指定，不作为 inventory 默认值。`ipmitool` 可用 PATH 中的程序名或绝对路径。


## 三个工具，三种用法

| 工具 | 用途 | 常用格式 |
| --- | --- | --- |
| `sol_exec.py` | 执行命令/本地脚本 | `sol_exec --hosts gpu001 'hostname; uptime'` |
| `sol_file.py` | 上传/下载文件 | `sol_file --hosts gpu001 upload ./file /tmp/file` |
| `sol_control.py` | 控制台、电源、启动设备、BMC 日志、回放 | `sol_control --hosts gpu001 power status` |

以下短命令需先启用下文的 Bash 补全；否则将 `sol_exec` / `sol_file` / `sol_control` 换成 `python3 sol_exec.py` / `python3 sol_file.py` / `python3 sol_control.py`。

```bash
sol_exec --hosts gpu001 'hostname; uptime'
sol_exec --hosts 'gpu[001-003,007]' 'hostname'
sol_exec --group cluster --command-file check.sh
sol_file --hosts gpu001 upload ./check.sh /tmp/check.sh
sol_control --hosts gpu001 console
sol_control --hosts gpu001 login
sol_control --hosts gpu001 power on
sol_control --hosts gpu001 logs --last 20
sol_control replay ./node-sol.jsonl.gz
```

通常只需记住 `--hosts`（一台或多台）、`--group`（分组）。默认读取工具旁的 `inventory.ini`；使用 `--config FILE` 可指定清单。`--list-hosts` 仅预览节点，`--help` 显示简要用法，`--help-all` 显示当前工具的高级选项。命令执行、上传、下载、电源、启动设备与日志都支持批量；控制台要求选中一台，回放是本地操作。

`sol_exec.py` 执行命令，`sol_file.py` 上传和下载文件，`sol_control.py` 管理控制台、电源、启动设备、BMC 日志及本地回放。三个入口共享 `sol_tools/`，部署时必须一并复制该目录，不能只复制入口文件。

## 上传与下载

```bash
sol_file --hosts gpu001 upload ./check.sh /tmp/check.sh
sol_file --hosts gpu001 download /var/log/messages ./messages
# 多台机器下载同名文件，按节点隔离保存
sol_file --hosts 'gpu[001-003]' download /etc/hostname ./downloads
```

单机下载的最后一个参数是本地文件名，其父目录必须存在。批量下载的最后一个参数是本地目录，可自动创建；文件保存在 `<目录>/<序号>_<节点名>_<BMC地址>/<远端文件名>`，结果汇总中的 `download_path` 记录保存位置。批量 stdout、stderr 和 SOL 会话日志仍保存在 `--result-dir` 或默认的 `batch-logs/`。

上传和下载统一使用 Base64，均支持自动断点续传。远端下载需要 Bash、GNU `base64`（支持 `-w 0`）、`dd`、`wc`、`head`、`sha256sum`。只下载可读的普通文件；对持续写入的日志，建议先在远端生成稳定副本或压缩包。

下载按 3 KiB 分块读取，校验每块长度及最终 SHA-256，并再次检查远端文件大小和摘要。全部通过后才原子写入目标文件，权限为 `600`。目标已存在且大小和 SHA-256 相同会直接报告完成；内容不同则默认不覆盖，加 `--overwrite` 才可替换。中断、超时或断连会保留同目录下权限为 `600` 的 `.sol-download-<标识>.part` 和 `.json` 进度文件，不覆盖原有目标。重新执行同一命令时，先检查 BMC 地址、远端路径、文件大小和摘要，再校验已下载前缀；校验通过后从完整分块边界继续，未写完整的末尾分块重新获取。源文件变化或前缀损坏会从头开始。完整文件校验失败时丢弃本次进度；成功后清理进度文件。`--timeout` 对每次分块/校验命令生效，不是总传输时限。

续传默认开启，无需指定偏移量；`--no-resume` 可清空已有进度并重新下载，仍遵守最终文件不覆盖规则。同一本地进度文件不允许并发写入。批量下载重新运行同样的节点选择和目标目录即可逐台续传，已完成节点直接跳过；更改节点选择顺序可能改变节点子目录，请保持一致。续传不代表自动重连，失败后需重新执行命令。

```bash
# 中断后重新运行同一命令即可续传
sol_file --hosts gpu001 download /var/log/archive.tar.gz ./archive.tar.gz
# 放弃已有下载进度；若最终文件内容不同还需 --overwrite
sol_file --hosts gpu001 download /var/log/archive.tar.gz ./archive.tar.gz --no-resume
```

默认 SOL 会话日志会包含下载文件的 Base64 内容；需要避免记录文件内容时使用 `--no-log`。

## 设置启动设备

```bash
# 下一次启动使用 UEFI PXE，不自动重启
sol_control --hosts gpu001 boot pxe --uefi
# 持续从本地硬盘启动
sol_control --hosts gpu001 boot disk --persistent
# 批量设置，可先加 --list-hosts 预览
sol_control --hosts 'gpu[001-003]' boot pxe --uefi
# 取消启动设备覆盖
sol_control --hosts gpu001 boot none
```

`boot DEVICE` 对应 `ipmitool chassis bootdev DEVICE`。支持 `pxe`、`disk`、`cdrom`、`bios`、`floppy`、`none`；默认仅下一次启动生效，`--persistent` 请求持续生效，`--uefi` 设置 EFI 启动标志。不加 `--uefi` 使用 ipmitool 默认的传统 BIOS 启动标志。这是启动设备覆盖，不是完整 BIOS 启动顺序编辑；是否支持取决于设备固件。设置后不会自动重启；需要时另执行 `power cycle` 或其他电源操作。参数依据 [ipmitool 官方实现](https://github.com/ipmitool/ipmitool/blob/master/lib/ipmi_chassis.c)。


## 分发到新机器：依赖安装

当前脚本仅使用 Python 标准库，**无需通过 pip 安装第三方包**。Python 版本要求 **3.9+**，支持 Linux/macOS；`pty`、`termios` 属于 Unix 标准库，不支持原生 Windows Python。远端节点无需安装 Python。

Ubuntu/Debian 控制端：

```bash
sudo apt-get update
sudo apt-get install -y python3 ipmitool iputils-ping


# 安装系统依赖后直接运行
python3 sol_exec.py --help-all
```

脚本不要求虚拟环境或 pip，安装 Python 和所需系统工具后即可直接运行。

| 位置/功能 | 依赖 |
| --- | --- |
| 控制端连接 SOL | `ipmitool` |
| 默认可达性检查 | `ping`；macOS IPv6 检查使用 `ping6` |
| 远端执行命令 | `bash`、`base64` |
| 远端文件上传/续传 | GNU coreutils：`base64`、`sha256sum`、`wc`、`cut`、`chmod`、`ln`、`mv`、`mkdir`、`rm`、`rmdir`、`touch`、`cat` |

远端 Ubuntu/Debian 的安装示例：

```bash
sudo apt-get install -y bash coreutils
```

macOS 控制端使用已有 Python 3.9+，通过 `brew install ipmitool` 安装 IPMI 工具。系统自带 ping。不要通过 pip 安装同名的 `ipmitool` Python 包来替代这些可执行程序。

分发时复制三个入口 `sol_exec.py`、`sol_file.py`、`sol_control.py`、完整的 `sol_tools/` 目录、`inventory.example.ini` 和同目录中所需的 README。将配置模板复制为 `inventory.ini` 并填写真实节点，设置 `chmod 600 inventory.ini`；不应将真实密码打包分发给无关人员。BMC 仍需启用 SOL，Linux 仍需配置串口登录服务，这些不属于 pip 依赖。

## IPMI 电源控制与 BMC 日志

这些操作直接调用 `ipmitool`，只需要 BMC 用户名/密码，不需要 Linux 凭据或 SOL 登录。使用 `--hosts` 或 `--group` 选择一台或多台；未启用 `sol_control` 快捷函数时使用 `python3 sol_control.py`。

```bash
# 单机：查看状态、开机、请求正常关机
sol_control --config inventory.ini --hosts gpu001 --power status
sol_control --config inventory.ini --hosts gpu001 --power on
sol_control --config inventory.ini --hosts gpu001 --power soft

# 批量：先预览选择，再执行开机
sol_control --config inventory.ini --hosts 'gpu[001-003,007]' --power on --list-hosts
sol_control --config inventory.ini --hosts 'gpu[001-003,007]' --power on --jobs 4

# 查看 BMC 系统事件日志（SEL）
sol_control --config inventory.ini --hosts gpu001 --bmc-log list
sol_control --config inventory.ini --hosts gpu001 --bmc-log elist --sel-last 20
sol_control --config inventory.ini --hosts gpu001 --bmc-log info
sol_control --config inventory.ini --hosts gpu001 --bmc-log elist --output sel.txt

# 批量收集最近 50 条日志
sol_control --config inventory.ini --group cluster --bmc-log elist --sel-last 50 --result-dir ./bmc-results
```

| `--power` 值 | 含义 |
| --- | --- |
| `status` | 查看电源状态 |
| `on` | 开机 |
| `soft` | 请求 ACPI 正常关机，需要操作系统支持 |
| `off` | 强制断电关机，不等待操作系统退出 |
| `reset` | 硬复位 |
| `cycle` | 断电后重新上电 |

`--bmc-log list` 显示 SEL 事件，`elist` 额外关联传感器描述，`info` 显示 SEL 存储信息；`--sel-last N` 仅适用于 `list/elist`，N 必须为正整数。这里的日志是标准 IPMI SEL，不包含厂商专有 BMC 调试日志，也不会清空日志。命令含义参见 [ipmitool 官方手册](https://github.com/ipmitool/ipmitool/blob/master/doc/ipmitool.1.in)。

电源操作成功表示 BMC 接受了请求，不代表操作系统已启动或关机完成；可再次用 `--power status` 查询。脚本不自动重试电源操作。`--timeout` 限制每台设备的 IPMI 请求时间（默认 300 秒）；超时返回 124，此时操作是否完成未知。默认仍先检查 BMC ping；禁用 ICMP 的环境可加 `--skip-ping`。

单机直接显示 IPMI 输出，`--output` 可保存输出（目标文件必须不存在）。批量结果沿用 `batch-logs` 或 `--result-dir`：每台保存 `stdout.txt` / `stderr.txt`，`results.json` 汇总退出码，`ipmi-operation.txt` 记录操作；不生成 SOL 会话日志。批量全部成功返回 0，任一失败返回 1。电源、SEL、远端命令、上传和交互控制台操作互斥。

## Bash 自动补全

在 Bash 中执行一次（从脚本所在目录运行）：

```bash
source <(python3 ./sol_exec.py --bash-completion)
source <(python3 ./sol_file.py --bash-completion)
source <(python3 ./sol_control.py --bash-completion)
```

这会创建三个工具的快捷函数并启用 Tab 补全，无需安装 `bash-completion` 或 Python 第三方包，兼容 macOS 自带的 Bash 3.2。快捷函数保存当前 Python 和脚本的绝对路径，可在任意目录使用：

```bash
sol_control --con<Tab>             # 补全 --config / --console / --connect-timeout
sol_file --upload ./<Tab>       # 本地文件（支持含空格的路径）
sol_exec --log-dir ./<Tab>      # 本地目录
```

也支持直接执行 `./sol_exec.py` 时的补全（需先赋予脚本执行权限）。`python3 sol_exec.py ...` 不注册补全，请使用 `sol_exec ...`。密码、远端路径和远端命令不提供候选项；补全过程不会连接 BMC。

若要每次启动 Bash 时启用，将下面一行加入 `~/.profile`，替换为实际绝对路径；非登录交互式 Bash 可将同一行加入 `~/.bashrc`：

```bash
if [ -n "${BASH_VERSION:-}" ]; then
    for tool in sol_exec sol_file sol_control; do
        source <(python3 "/absolute/path/to/${tool}.py" --bash-completion)
    done
fi
```

参数列表由脚本实时生成；更新脚本后重新执行 `source` 即可刷新。

## 安装与运行

帮助信息分为三个层级，均无需连接 BMC：

```bash
python3 sol_exec.py                 # 默认显示简要帮助
python3 sol_exec.py -h              # 同 --help：常用参数和快速入门
python3 sol_exec.py --help-all      # 全部参数、默认值、限制和示例
python3 sol_exec.py --help-examples # 仅显示完整使用示例
```

帮助文本保持英文。简要帮助未列出的高级参数仍可正常使用。

以下示例假定已将 `inventory.example.ini` 复制为 `inventory.ini`，填写了节点及 BMC、OS 凭据；`--hosts` 的值必须存在于该清单。使用其他清单时加 `--inventory FILE`。

Ubuntu/Debian 控制端：

```bash
sudo apt-get install ipmitool python3
python3 sol_exec.py --hosts 192.0.2.10 \
  --command 'hostname; uname -r; cat /sys/module/intel_idle/parameters/max_cstate'
```

脚本从 inventory 读取 BMC 和 Linux 凭据；这是两个不同的账号体系。仅在缺少必要凭据时才尝试交互提示，非交互环境缺少凭据则报错。IPMI 账号需要 SOL 权限，BMC 必须已经启用 SOL，Linux 必须配置串口登录服务。默认请求 ADMINISTRATOR（管理员）权限并使用编号为 17 的加密套件；若设备文档指定其他套件，可用 `--cipher` 明确指定。

文件中的多条命令：

```bash
python3 sol_exec.py --hosts 192.0.2.10 \
  --command-file check_cpu.sh --timeout 120 --output node-cpu.txt
echo "远端退出码：$?"
```

`check_cpu.sh` 示例：

```bash
set -e
hostname
uname -r
for p in max_cstate states_off; do
    printf '%s=' "$p"
    cat "/sys/module/intel_idle/parameters/$p"
done
```

凭据集中维护在 inventory 中。命令行凭据参数仅用于临时覆盖；优先级为命令行 > 对应环境变量 > inventory > 交互输入。自动化系统可注入 `IPMI_PASSWORD` 和 `SOL_OS_PASSWORD`。脚本通过环境变量向 ipmitool 传递 BMC 密码，并在 SOL 日志中脱敏自动登录期间的认证输入及响应。

## 单机和批量共用一份配置

只需维护 [inventory.example.ini](inventory.example.ini) 对应的一份 INI 文件。单机与批量模式的 `--config` 与 `--inventory` 是同义选项，使用相同的节点清单和凭据继承规则。

```bash
cp inventory.example.ini inventory.ini
chmod 600 inventory.ini
# 编辑地址和密码后，单机按节点名或 BMC 地址选择
python3 sol_exec.py --config inventory.ini --hosts gpu-bj-01 -c 'hostname'
python3 sol_control.py --config inventory.ini --hosts 192.0.2.10 --interactive
python3 sol_control.py --config inventory.ini --hosts gpu-bj-01 --console

# 同一份文件用于批量操作
python3 sol_exec.py --config inventory.ini --group beijing -c 'hostname'
python3 sol_exec.py --config inventory.ini --group beijing --list-hosts
```

所有选择项必须存在于 inventory，零匹配或歧义报错。未指定筛选条件时执行全部节点；可以先用 `--list-hosts` 预览。CLI 用户名覆盖配置；密码优先级为 CLI > 环境变量 > 主机 > 组 > 全局默认。`--console` 不使用配置中的 Linux 凭据。

只有一台主机时也使用相同格式，例如：

```ini
[all:vars]
bmc_user=admin
bmc_password=BMC_PASSWORD
os_user=root
os_password=LINUX_PASSWORD

[all]
node001 host=192.0.2.10
```

未指定配置时尝试脚本同目录的 `inventory.ini`；回放无需配置。密码以明文保存，请设置权限 `600`。详细分组、覆盖及引号规则见下文。

## 观察开机过程（无需进入操作系统）

使用 `--console` 只连接 BMC SOL，立即显示后续串口输出：

```bash
python3 sol_control.py --hosts 192.0.2.10 \
  --console
```

- 不需要 Linux 账号；此模式不能同时指定 `--os-user` 或 `--os-password`。
- 不等待登录提示，不自动发送回车、用户名或密码，适合观察 BIOS 自检、引导程序和内核启动。需要操作菜单或在系统启动后登录时，可以手动输入。
- Ctrl-] 断开；终端恢复、按键透传等行为与交互模式一致。需要真实终端，不支持 `--output`。
- 连接后没有会话超时；`--connect-timeout` 只限制 SOL 激活等待时间。已建立的 SOL 会话断连后默认自动重连；可用 `--no-reconnect` 关闭。
- 脚本不自动开机或重启。要完整观察启动过程，应先连接 SOL，再通过现场已有管理方式启动机器。连接前已经输出的内容不会由脚本补回。
- BMC 必须可达并启用 SOL。BIOS、引导程序和内核都需分别配置串口重定向，否则只能看到已启用重定向的启动阶段。Linux 尚未运行不影响此模式连接，但主机关机时部分 BMC 可能不允许激活 SOL。
- 与 `login` 的区别：后者使用 inventory 中的 OS 凭据等待 Linux 登录并自动认证；`--console` 连接成功后立即交给用户，不进行系统登录检测。

## 交互式控制台

自动登录 Linux 并进入实时交互控制台：

```bash
python3 sol_control.py --hosts 192.0.2.10 \
  --interactive
```

如果需要手动登录 Linux、处理多因素认证（MFA），或直接操作已有控制台，使用 `console`，它会忽略 inventory 中的 OS 凭据：

```bash
python3 sol_control.py --hosts 192.0.2.10 console
```

- `--interactive` / `-i` 与命令执行、文件上传模式互斥。
- 标准输入和标准输出必须连接真实终端；不支持 `--output`。
- 输出实时显示。Ctrl-C、Ctrl-D、Tab、方向键和 UTF-8 输入都会传给远端控制台。Ctrl-] 用于本地断开，不会发送到远端。
- 进入交互模式后，可以回答 sudo 密码提示并运行交互式程序。自动登录流程不支持多因素认证，这种情况应使用手动登录。
- 交互会话没有超时限制；`--connect-timeout` 仍用于连接和自动登录阶段。
- 正常退出、断连及可处理的中断（包括 SIGTERM/SIGHUP）都会恢复本地终端设置。SIGKILL 无法处理；如果脚本在终端原始模式下被强制结束，可执行 `stty sane` 恢复终端。
- SOL 协议不协商终端尺寸；脚本在自动登录后的交互会话中设置本地行列数与 `TERM=xterm`，详见下方终端设置。
- 断开 SOL 不会注销 Linux，也不会停止远端命令。如需注销，先在远端执行 `exit`，再按 Ctrl-] 断开。
- 已通过模拟 BMC 控制台和本地伪终端（PTY）测试；真实 BMC 兼容性仍需验证。

## 登录后执行 reboot 并观察启动

```bash
python3 sol_control.py --hosts 192.0.2.10 \
  --interactive --reconnect-attempts 10 --reconnect-delay 3
```

进入远端 shell 后手动执行 `reboot`（非 root 用户按需使用 `sudo reboot`）。

- SOL 连接保持时，会直接显示后续启动输出，无需重新连接。
- SOL 连接断开时，默认每次等待三秒后尝试重新激活 SOL，无需指定 `--reconnect`。重连后直接显示控制台，不等待 Linux 登录，也不重发用户名、密码或 `reboot`。
- `--reconnect-attempts` 是本次脚本运行的重连尝试总上限，默认 10 次；每次激活仍受 `--connect-timeout` 限制。重连成功后不重置次数预算；重试用尽返回 125。默认间隔为 3 秒（允许 0–60 秒），可用 `--reconnect-delay` 修改。注意总耗时还包含每次连接尝试等待，不只是 10 × 3 秒。
- 自动重连仅默认用于 `--interactive` 和 `--console`；可用 `--no-reconnect` 关闭，可用 `--reconnect` 显式开启或覆盖 inventory 设置。不会重试批处理命令、上传或首次连接失败。
- Ctrl-] 主动断开不会触发重连。重连等待期间可用 Ctrl-C 退出；连接后的 Ctrl-C 仍传给远端。
- BIOS/引导程序/内核需启用相应串口输出。断连期间的输出可能丢失，脚本无法补回；BMC 尚未释放旧 SOL 会话时，重连可能暂时失败，脚本不会强制踢掉旧会话。
- 不要使用 `--command reboot` 来持续观察启动；批处理模式等待退出码标记，不提供此重连流程。

## 上传文件

```bash
python3 sol_file.py --hosts 192.0.2.10 \
  --upload ./check_cpu.sh --remote-path /tmp/check_cpu.sh --mode 755
```

- `--upload`、`--command`、`--command-file`、`--interactive`、`--console`、`--replay` 六选一。上传仅保存文件，不执行它。
- `--remote-path` 必须是远端绝对文件路径，父目录必须已存在且登录用户可写。
- 默认拒绝覆盖；需要替换时显式加 `--overwrite`。目标为目录时失败。
- 默认权限 `600`；可用 `--mode 755` 等三位八进制权限。文件归上传时的 Linux 用户所有，不保留本地所有权、时间戳等元数据。
- 支持任意二进制内容及空文件。以 192 字节原始数据为一段传输，每段确认写入；最终校验 SHA-256，通过后才发布目标文件。
- 临时目录位于目标文件同目录，传输及校验失败时不发布目标文件。失败或中断会保留 `.sol-upload-*` 进度目录并报告路径，重新执行同一命令可校验后续传；成功后清理。最终提交阶段断连后，重跑会检查目标 SHA-256 是否已完成，不自动重连。
- 远端需要 Linux 的 Bash、Base64、`sha256sum` 及 GNU coreutils（`ln -T` / `mv -T`）。本地仍无需额外 Python 包。
- SOL 带宽有限，适合脚本、小配置等文件；每约五秒在 stderr 显示已传字节数。`--connect-timeout` 控制每段确认等待时间，`--timeout` 控制每个远端处理命令的等待时间，均不是整个上传的总时限。

## 保存 SOL 输入输出日志（默认开启）

所有连接远端的模式默认记录输入输出，无需指定 `--log-file`；自动重连继续写入同一文件。本地 `--replay` 不生成新日志：

```bash
python3 sol_control.py --hosts 192.0.2.10 \
  --console --log-dir ./logs
```

默认自动命名示例：

```text
logs/sol_192.168.1.100_20260910_143025_123456+0800.jsonl
```

文件名包含 BMC 地址、开始记录的本地日期和时间、微秒及 UTC 时区偏移。IPv6 地址中的冒号等不适合文件名的字符会替换为下划线。`--log-dir` 默认是当前目录下的 `logs/`，自动创建；每次运行生成新文件，重连继续使用该文件。

仍可指定固定文件名：`--log-file ./node-sol.jsonl`。此时父目录须已存在，不使用 `--log-dir`。需要关闭日志时使用 `--no-log`；它不能与 `--log-file` 同时使用。脚本开始记录时会打印日志的绝对路径，随后可将该路径传给 `--replay`。

- 日志采用 JSON Lines 格式，每行包含带时区的时间戳 `time`、方向 `direction` 和内容 `data`。
- `IN` 表示发给 ipmitool/SOL 的输入，`OUT` 表示从控制台读取的输出，`EVENT` 记录连接、断开及重连等事件。记录按读写数据块划分，不一定对应完整命令或完整输出行。
- 每条记录立即刷新；文件必须不存在，新建权限为 `600`；自动命名模式会创建日志目录，显式文件名模式要求父目录已存在。重连不会覆盖或重新创建文件。
- 回车、换行、方向键等控制字符以 JSON 转义形式保存，避免查看日志时直接执行终端控制序列。UTF-8 字符跨数据块或非 UTF-8 字节可能显示为字节转义；这不是原始二进制串口抓包格式。
- BMC 密码不写入日志；自动发送的 Linux 密码及其后直到登录结果匹配前的响应均用脱敏标记代替，以防串口回显密码。这一小段认证输出不会完整保留。
- **手动输入会原样记录，包括手动登录、sudo 等密码，即使远端关闭回显也一样。** 日志还可能包含命令、上传内容的 Base64 数据和系统敏感信息。
- `--log-file` 用于完整 I/O 记录；`--output` 仍仅保存批处理命令的最终输出。两者可同时使用，但必须指定不同文件。

## 像视频一样回放日志

使用本脚本 `--log-file` 生成的 JSONL 日志进行本地回放：

```bash
# 原速播放
python3 sol_control.py --replay ./node-sol.jsonl

# 四倍速播放
python3 sol_control.py --replay ./node-sol.jsonl --replay-speed 4

# 同时显示记录过的输入
python3 sol_control.py --replay ./node-sol.jsonl --replay-speed 2 --replay-inputs
```

回放不需要 BMC 地址、账号、密码或 ipmitool，不连接任何远端，也不重新执行日志中的命令。

| 按键 | 功能 |
|---|---|
| 空格 | 暂停或继续 |
| `+` / `=` | 速度翻倍，最高 64 倍 |
| `-` | 速度减半，最低 0.125 倍 |
| `f` | 向前快进 10 秒日志时间 |
| `n` | 跳到下一条记录，方便跳过长时间无输出的阶段 |
| `q` / Ctrl-] | 退出回放 |
| Ctrl-C | 中断回放 |

- `--replay-speed` 默认 1，支持 0.125–64。按键控制需要真实终端；输出重定向或管道模式按指定倍速顺序播放，不读取快捷键。
- 根据日志时间戳还原间隔，包括重连等待。时间戳倒退时保留记录顺序，并将倒退部分的等待压缩为零。
- 默认将 `OUT` 内容输出到 stdout，将 `EVENT` 注释输出到 stderr。`--replay-inputs` 额外显示转义后的 `IN` 注释，不会将输入发送给 shell。原始输出中的命令回显仍然可见。
- 快进会立即显示跨过的记录，以保留终端画面更新。当前支持向前跳转，不支持倒放或向后定位。
- 日志里的 ANSI 控制序列会交给本地终端显示。回放效果取决于终端类型和尺寸；此前未记录的内容、脱敏密码以及缺失的串口字节无法恢复。这是终端日志回放，不是视频文件。
- 先校验整份日志再播放；空文件或损坏记录会报错并标明原因。日志载入内存，超大日志需要相应内存。正常结束返回 0，读取或格式错误返回 125，中断返回 130。
- `--replay` 与其他操作互斥，不能同时指定 BMC/Linux 账号、日志写入或上传选项。

## 通用行为与限制

- 批处理模式下，stdout 是远端命令输出；串口无法分离远端 stdout/stderr，也可能混入内核或其他进程的控制台消息。输出在命令完成后一次性返回，适合有限输出的诊断命令。
- 默认识别以 `#` 或 `$` 结尾的 shell 提示符；特殊提示符可用 `--prompt` 指定 Python 正则表达式。批处理执行前使用随机标记验证 shell 响应。
- 每段命令经 Base64 编码，分段确认传输，避免串口行长度限制和命令转义问题。远端在独立 Bash 中执行，不影响登录 shell 的工作目录。
- 批处理模式仅适用于非交互命令；不自动回答 sudo 密码、MFA、密码过期提示或 BIOS 菜单。需要手动登录或处理额外认证步骤时使用 `console`。
- 命令退出码原样返回；本地超时为 124，连接/认证/上传失败为 125，中断为 130。上传成功及交互会话正常断开返回 0。这些数字也可能由远端命令返回，需结合 stderr 区分。
- 超时不会重试命令，也不保证远端命令停止。重启、关机等主动断开控制台的命令通常无法获得完成标记。
- 结束时使用 ipmitool 的本地 `~.` 退出，仅断开本次 SOL；不执行全局 `sol deactivate`，不抢占其他会话。
- 不自动退出已有 Linux 登录会话，自己登录的会话也会保持登录；应按现场控制台管理要求处理。SOL 是共享串口，运行脚本期间不要让其他人同时输入。
- 输出文件必须不存在，避免覆盖已有结果。输出可能包含命令产生的敏感信息，应自行选择保存位置。

## 验证

已使用本地 PTY 模拟 Linux 登录及交互 shell 验证；尚未在真实 BMC 上验证，不代表特定厂商 SOL 兼容性已确认。

上传流程已通过本地 PTY 测试：空文件、二进制分段边界、特殊文件名、拒绝覆盖、显式覆盖、权限设置、传输损坏校验和临时文件清理。macOS 测试中 GNU `ln -T` / `mv -T` 使用对应文件操作模拟，仍需在实际 Linux/BMC 环境验证。

协议选项参考：https://github.com/ipmitool/ipmitool/blob/master/doc/ipmitool.1.in

## 多主机批量执行、分组账号与节点选择

使用 `sol_exec.py` 在多台主机执行同一条非交互 Bash 命令或本地脚本。默认最多并发 8 台，单台失败不影响其他节点；不会自动重试命令。以下示例在 `sol` 目录运行。

```bash
cp inventory.example.ini inventory.ini
chmod 600 inventory.ini
# 编辑 inventory.ini，替换地址和密码
python3 sol_exec.py --help-batch
```

推荐使用 [inventory.example.ini](inventory.example.ini)，格式示例：

```ini
[all:vars]
os_user=root
os_password=LINUX_PASSWORD

[beijing]
gpu-bj-01 host=192.0.2.10
gpu-bj-02 host=192.0.2.11 bmc_password='SPECIAL_PASSWORD'

[beijing:vars]
bmc_user=admin
bmc_password=BEIJING_PASSWORD

[shenzhen]
192.0.2.[20-21]

[shenzhen:vars]
bmc_user=operator
bmc_password=SHENZHEN_PASSWORD
```

- `[all:vars]`：全局默认账号、密码。
- `[组名]`：每行一台节点，可直接写 BMC IP/主机名，或用 `节点名 host=BMC地址` 设置别名。这里的地址是 **BMC 地址，不是 Linux 系统 IP**。
- `[组名:vars]`：组内共享账号密码。支持 `bmc_user`、`bmc_password`、`os_user`、`os_password`。
- 主机行末可覆盖任意账号密码，例如 `bmc_user=other bmc_password='different password'`，不需要为每台主机重复配置。
- 可选 `[all]` 段放独立主机，只继承全局默认值。节点名、BMC 地址分别唯一；同一主机不能重复出现在多个组中。
- 配置逐字段继承：**主机行 > 所属组 vars > all:vars**。CLI 用户名覆盖配置；密码优先级是 **CLI > `IPMI_PASSWORD` / `SOL_OS_PASSWORD` 环境变量 > 配置继承顺序**。已有密码环境变量会覆盖所有节点的对应密码。
- vars 段使用 `key=value`，`=` 两侧可有空格。未加引号的值保留内部空格、`#`、`;`、`%` 和反斜杠，不做变量插值；可以给整个值加引号。主机行使用 shell 风格引号，含空格或 `#` 的密码需用引号包住。
- 空行及以 `#`、`;` 开头的整行注释可用；**vars 赋值行不要添加行末注释**，否则会成为密码的一部分。
- 这是 Ansible 风格的子集，不支持 `:children`、Jinja、Ansible 变量名或动态 inventory。单机与批量共用此 INI 格式。

先预览选择结果，不连接 BMC、不要求密码齐全或安装 ipmitool：

```bash
# 列出全部节点：节点名、BMC 地址、组名（独立节点为 -）
python3 sol_exec.py --inventory inventory.ini --list-hosts

# 选择一个组，可重复 --group 选择多个组
python3 sol_exec.py --inventory inventory.ini --group beijing --list-hosts

# 按数字范围选择节点名或 BMC 地址，可与组选择同时使用
python3 sol_exec.py --inventory inventory.ini --hosts 'gpu-bj-0[1-2]' --list-hosts
python3 sol_exec.py --inventory inventory.ini --hosts '192.0.2.[10-11]' --list-hosts
```

`--hosts` 展开后精确匹配清单中的节点名或 BMC 地址；可与 `--group` 组合取交集。未指定筛选条件时选择全部节点，空结果或未知组报错。

```bash
# 在北京组执行命令
python3 sol_exec.py --inventory inventory.ini --group beijing -c 'hostname; uname -r'

# 在匹配的节点执行本地 Bash 脚本，最多同时连接 4 台
python3 sol_exec.py --inventory inventory.ini --group beijing \
  --command-file check_cpu.sh --jobs 4 --timeout 120

# 从同一清单按 BMC 地址或组选择
python3 sol_exec.py --config inventory.ini --hosts 192.0.2.10,192.0.2.11 -c 'hostname'
python3 sol_exec.py --config inventory.ini --group beijing --command-file check_cpu.sh
```

同一节点通过名称和地址重复选中时只执行一次；名称与另一节点地址冲突时报歧义错误。所有选择项必须存在于 inventory。复杂节点集合可定义为 inventory 分组。

结果默认保存在当前目录的 `batch-logs/run_<时间戳及时区>_<随机ID>/`，可用 `--result-dir` 指定一个尚不存在的目录：

- `command.sh`：本次执行的命令/脚本快照。
- `<序号>_<BMC地址>/stdout.txt`：远端命令输出。SOL 串口不能区分远端 stdout/stderr；两者合并在此文件。
- 同目录 `stderr.txt`：本地连接和错误诊断；`sol.jsonl.gz`：默认开启的 SOL 日志，可用 `sol_control.py --replay <路径>` 回放。`--no-log` 仅关闭 SOL 日志。
- `results.json`：逐台完成后更新的结果汇总，包括节点名、BMC 地址、状态、退出码、耗时和输出目录，不包含配置密码。取消后未运行节点也会列为 `cancelled`，不一定有输出目录。

返回码：全部成功 `0`；至少一台失败 `1`；输入错误 `2`；中断 `130`。Ctrl-C 停止本地活动会话并取消排队任务。超时或断开 SOL 不保证远端命令停止。批量模式不支持 sudo 密码、MFA 等交互提示，应使用无需交互的命令（如 `sudo -n`）。日志/命令快照可能包含业务敏感内容，目录权限为 `700`，文件为 `600`。

**批量入口不支持交互式控制台、启动控制台或回放，也不提供多节点键盘广播。** 同时观察或操作多台机器，请在不同终端标签页或 tmux 窗格分别运行 `sol_control.py --interactive` 或 `--console`；每个实例只连接一台 BMC，分别保存日志。单机与批量模式均读取同一份分组 INI 清单。

### Slurm 风格主机范围

INI 主机行和 `--hosts` 均支持数字范围展开：

```ini
[beijing]
192.0.2.[10-11]
node[001-003,007]
# 别名范围与 BMC 地址范围按顺序一一对应
worker[001-002] host=192.0.2.[40-41]
```

```bash
python3 sol_exec.py --config inventory.ini --hosts '192.0.2.[10-11]' -c 'hostname'
python3 sol_exec.py --config inventory.ini --hosts 'worker[001-002]' --list-hosts
python3 sol_exec.py --config inventory.ini --hosts 'worker[001-002]' --jobs 2 -c 'hostname; uptime'
# 按数字范围选择 inventory 中的节点
python3 sol_exec.py --config inventory.ini --hosts 'worker[001-002]' -c 'hostname'
```

`node[001-002]` 展开为 `node001,node002`；`rack[1-2]node[01-02]` 展开为四种组合。支持方括号内逗号列表和主机表达式之间的逗号，保留起始数字的前导零。命令行表达式请加引号，避免 shell 通配符展开。

`--hosts` 可选择配置中的别名，例如 `--hosts 'worker[001-002]'` 会连接对应的 `192.0.2.40` 和 `192.0.2.41`。可叠加 `--group` 进一步筛选。别名与地址范围必须展开成相同数量，按顺序配对。若其中一台需要覆盖密码，请将该台从范围中拆出单独写一行，避免重复节点。

支持的是 Slurm 常用数字主机列表语法，不是完整 Slurm 解析器：不支持步长、字母范围、嵌套或倒序范围。每次清单/选择最多展开 10,000 个节点；格式错误或超过上限会在连接前报错。

## 压缩大日志

单机和批量模式均支持 `--log-compress`，使用 Python 标准库直接写入 gzip，无需外部压缩工具。默认开启 gzip，无需指定 `--log-compress`；使用 `--no-log-compress` 可保存未压缩 JSONL，`--no-log` 可完全关闭日志。

```bash
python3 sol_control.py --config inventory.ini --hosts gpu-bj-01 --interactive --log-compress
python3 sol_exec.py --config inventory.ini --group beijing -c 'hostname' --log-compress
python3 sol_control.py --replay ./session.jsonl.gz --replay-speed 4
```

默认自动命名以 `.jsonl.gz` 结尾；批量每台节点保存 `sol.jsonl.gz`。默认指定 `--log-file session.jsonl` 时也会追加 `.gz`；指定 `.gz` 文件名时必须启用压缩；若 inventory 设置了 `log_compress=false`，需用 `--log-compress` 覆盖。显式 `--log-compress` 不能与 `--no-log` 同用；默认压缩不影响 `--no-log`。`--no-log-compress` 要求文件名不以 `.gz` 结尾。压缩仅针对 SOL 日志，批量的命令快照、stdout/stderr 和结果汇总不压缩。

回放支持 JSONL 和 gzip 日志，自动检测 gzip 文件头，无需手动解压，支持快进和倍速。每条记录刷新写入，正常关闭时完成 gzip 尾部；异常断电或强制终止可能留下不完整压缩文件，回放会报错。建议结束录制后再回放。

压缩节省磁盘空间，但当前回放仍将解压后的全部记录载入内存，不降低大日志回放的内存需求。文件以权限 `600` 创建且不覆盖已有文件；自动登录期间的认证输入及响应会脱敏。

## 导出日志中的屏幕输出，配合 grep 查询

使用 `--replay-export` 将记录的 `OUT` 内容立即导出到标准输出，不按录制时间等待，也不显示播放控件。支持未压缩 JSONL 和默认 gzip 日志：

```bash
python3 sol_control.py --replay session.jsonl.gz --replay-export | grep -ni 'error'
python3 sol_control.py --replay session.jsonl.gz --replay-export | grep -n -C 3 'GPU'
python3 sol_control.py --replay session.jsonl.gz --replay-export > session.txt
```

导出按顺序拼接屏幕输出，排除 `IN` 和 `EVENT`，去除 ANSI 颜色/光标等控制序列，将 CRLF/CR 统一为换行。串口回显的命令本身属于 `OUT`，仍会保留。错误诊断输出到 stderr，不混入正常导出的文本。不能与 `--replay-inputs` 或非默认 `--replay-speed` 同用。

这是便于检索的输出历史，不是终端最终屏幕截图：进度条更新和全屏程序刷新可能留下多条历史内容，不模拟光标覆盖。导出仍先读取并校验全部记录，大日志需要相应内存；从未记录或已经脱敏的内容无法恢复。

## 检查 BMC 可达性，跳过 ping 失败节点

```bash
# 检查 INI 清单全部节点；也可用 --group 或 --hosts 筛选
python3 sol_exec.py --config inventory.ini --check-hosts
python3 sol_exec.py --config inventory.ini --group beijing --check-hosts --ping-jobs 32 --ping-attempts 3 --ping-timeout 2 --ping-interval 0.5
```

默认同时检查最多 **32 台** BMC（`--ping-jobs`），每台最多 ping **3 次**，单次超时 **2 秒**，失败后间隔 **0.5 秒**，任意一次成功即通过。单台全部超时约需 7 秒（另有进程调度开销）。节点间并行，节点内重试按顺序进行。批量先完成并发 ping 检查，再对通过的节点执行 SOL；SOL 并发独立由 `--jobs` 控制，默认 8。显示节点名、地址及 reachable/ERROR，最后汇总成功和失败数量。此模式不需要账号密码或 ipmitool，不执行命令、不创建 SOL 日志；全部通过返回 `0`，有失败返回 `1`。主机名由本机解析，检查的是配置中的 BMC 地址，不是 Linux 系统 IP。

单机和批量连接前默认检查 ping。失败节点不启动 SOL，不反复重试；批量继续执行其他节点，并在 `results.json` 记录 `status=unreachable`、退出码 `125` 和错误原因（没有 SOL 输出目录）。单机检查失败返回 `125`。交互控制台每轮重连先进行上述检查；ICMP 检查失败只跳过该轮 SOL 连接，受 `--reconnect-attempts` 次数上限和 `--reconnect-delay` 间隔限制，不会无限重试。

ping 失败可能是 ICMP 被禁止，不能单凭它断定 IPMI 服务不可用；ping 成功也不保证 SOL 可用。已知网络屏蔽 ICMP 时可显式添加 `--skip-ping`，跳过连接前的 ICMP 检查。`--ping-attempts`、`--ping-timeout`、`--ping-interval` 分别控制次数、单次超时和失败间隔；`--ping-jobs` 控制检查并发，与 `--jobs` 独立；`--check-hosts` 不能与命令执行、`--list-hosts` 或 `--skip-ping` 同用。正常 SOL 连接依然需要相应账号密码。

## Ctrl-C 的行为

- ping 检查（含并发检查、重试间隔、批量连接前检查）：Ctrl-C 取消后续检查，终止并回收正在运行的 ping 子进程，返回 `130`，不等待所有节点的超时/重试结束。
- 连接等待、自动登录、非交互命令/上传及重连等待：Ctrl-C 中断本地任务并清理会话。关闭 SOL 不保证远端命令停止。
- 已进入 `--interactive` 或 `--console` 的终端转发阶段：键盘 Ctrl-C 作为 `0x03` 发给远端，由远端程序处理；不会退出本地脚本。使用 **Ctrl-]** 断开本地控制台，退出时恢复本地终端设置。

批量中断会停止后续 SOL 任务并保留已完成的结果；取消中的节点标记为 `cancelled`。外部向脚本发送 SIGINT 与原始终端模式下键入 Ctrl-C 是不同操作。

## 默认配置与缺失凭据

不指定 `--config` 时，脚本从自身所在目录寻找 `inventory.ini`，与当前工作目录无关。复制 `inventory.example.ini` 为该文件并填写即可；显式 `--config` 优先。未找到默认文件时必须使用 `--inventory FILE` 指定清单；显式指定的文件不存在或配置格式错误会直接报错。

用户名优先使用命令行，然后读取 INI；密码优先级为命令行 > 已有环境变量 > INI > 终端提示输入。只补齐缺少的字段，不覆盖已有值。终端提示中的密码不回显；无交互终端时明确报告缺失字段，不挂起等待。

批量缺失凭据在启动任何 ping/SOL 任务前统一提示；同组缺失的同一字段只询问一次，不同组或独立主机分别询问。即使提供完整命令行凭据，仍必须读取 inventory。未指定 Linux 用户的单机模式继续保留已有 shell/手动控制台用法；配置了 Linux 用户但缺少密码时提示补充。`--console` 不需要 Linux 凭据。回放不读取配置，ping 检查不要求凭据。

## 日志中的节点名称

inventory 配置了独立节点名时，批量结果显示 `gpu01 (192.0.2.10): ok`；未设置别名时只显示 BMC 地址。单机自动日志命名为 `sol_<节点名>_<BMC地址>_<时间戳>.jsonl.gz`，批量目录为 `<序号>_<节点名>_<BMC地址>/`（内部继续使用 `sol.jsonl.gz`）。节点名和地址相同时不重复拼接。

每条 SOL 日志记录包含 `node_name` 和 `bmc_host` 字段，连接事件也包含节点名。显式 `--log-file` 文件名保持用户指定，日志内容仍携带节点信息。

## 批量上传文件

```bash
./sol_file.py --inventory inventory.ini --group L5pod3 \
  --upload ./stat.sh --remote-path /tmp/stat.sh --mode 755
```

执行方式由选中节点数量决定。也可用 `--hosts` 或 `--group` 选择节点。默认先以 32 路并发检查 ping，然后最多同时上传 8 台；分别用 `--ping-jobs` 和 `--jobs` 调整。

上传复用单机 Base64 传输逻辑，提供 SHA-256 校验、权限设置和目标文件保护。默认仅跳过内容相同的已完成文件，拒绝覆盖不同内容；需要覆盖时显式加 `--overwrite`。目标父目录必须存在。只保存文件，不自动执行；需要运行时另用 `--command`，不能与上传同时指定。

所有节点使用本次结果目录中的同一份 `upload.payload` 快照（权限 `600`），避免上传期间源文件变化导致各节点内容不一致。每台分别记录日志和结果，单台失败不影响其他节点；不会自动重试上传。中断或超时后远端文件状态可能需要检查。可用 `--command-file` 执行脚本而不保存为指定远端文件。

## 自动设置交互终端尺寸与 TERM

```bash
# 自动登录后，按本地窗口尺寸设置远端 stty，默认 TERM=xterm
./sol_control.py --inventory inventory.ini --hosts gpu01 --interactive

# 固定 50 行、180 列，并指定终端类型
./sol_control.py --inventory inventory.ini --hosts gpu01 --interactive \
  --rows 50 --cols 180 --term xterm

# 保留远端原有设置
./sol_control.py --inventory inventory.ini --hosts gpu01 --interactive --no-terminal-setup
```

上述自动设置要求提供 Linux 登录用户（命令行或 INI 的 `os_user`）。脚本确认进入 Linux shell 后，在同一个 shell 执行 `stty rows N cols N`、`unset LINES COLUMNS`、`export TERM=...`，然后转交键盘输入，可直接运行 `top`。默认读取本地实际窗口尺寸，固定行列数必须一起指定，范围为 1–65535。终端类型应与本地终端能力一致，可用 `--term vt220` 等覆盖默认值。

设置只影响当前串口/登录 shell，不写 `/etc/rc.local` 或用户配置。`--console`、未提供 Linux 用户的手动交互登录，以及断线重连阶段不自动发送设置命令，避免干扰 BIOS、登录提示或正在运行的程序；这些场景请进入 shell 后手动执行 `stty`。窗口大小变化暂不实时同步，需退出全屏程序后重新设置或重新建立自动登录交互会话。

## 上传自动断点续传

```bash
sol_file --hosts gpu001 upload ./stat.sh /tmp/stat.sh
# 中断后重新执行原命令即可；如需从头开始：
sol_file --hosts gpu001 upload ./stat.sh /tmp/stat.sh --no-resume
```

上传会验证远端暂存数据的长度和 SHA-256，再从确认的偏移继续追加；损坏的前缀会重置。相同源文件和目标路径使用相同的 `.sol-upload-*` 进度目录。目标已存在且 SHA-256 相同时，默认跳过重传并应用指定权限；不同内容需要 `--overwrite`。成功后清理进度，中断时保留；续传需重新运行命令，不自动重连。`--timeout` 对每次分块/控制命令生效。

## 回归测试

测试集中在 `tests/`，不属于运行时依赖，部署时可以不复制。测试使用模拟 IPMI 进程、本地 Bash 和临时文件，不连接真实 BMC。测试环境需要 Bash、`sha256sum`、`dd`、`wc`、`head`、`cut` 和 `base64` 等本地工具。

从 `sol/` 工具目录运行全部测试：

```bash
python3 -m unittest discover -s tests -t . -v
```

仅运行下载测试：

```bash
python3 -m unittest tests.test_download -v
```
