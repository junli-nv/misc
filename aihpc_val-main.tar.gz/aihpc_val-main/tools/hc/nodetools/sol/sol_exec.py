#!/usr/bin/env python3
"""Execute remote Bash commands over SOL."""
from sol_tools.cli import main


if __name__ == "__main__":
    raise SystemExit(main("exec"))
