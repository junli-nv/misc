#!/usr/bin/env python3
"""Execute Bash commands or upload files over ipmitool SOL (stdlib only).

Author: Codex
Supervised by: Junli
"""
import argparse
import base64
import errno
import gzip
import getpass
import io
import hashlib
import json
import math
from datetime import datetime
import os
import pathlib
import pty
import re
import select
import shutil
import shlex
import signal
import sys
import termios
import time
import tty
import uuid
import zlib

from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import subprocess
import threading
import tempfile


def ini_value(value):
    """Literal INI value, optionally quoted using shell-style quoting."""
    value = value.strip()
    if value.startswith(('"', "'")):
        try:
            parts = shlex.split(value, comments=False)
        except ValueError:
            raise ValueError('Invalid quoted INI value') from None
        if len(parts) != 1:
            raise ValueError('Expected one quoted INI value')
        return parts[0]
    return value


FIELDS = {'bmc_user', 'bmc_password', 'os_user', 'os_password'}
MAX_HOSTS = 10000


def expand_hostlist(expression):
    """Expand numeric Slurm-style brackets, preserving zero padding (bounded)."""
    terms, depth, start = [], 0, 0
    for pos, char in enumerate(expression):
        if char == '[':
            depth += 1
            if depth > 1:
                raise ValueError('Nested hostlist brackets are not supported')
        elif char == ']':
            depth -= 1
            if depth < 0:
                raise ValueError('Unbalanced hostlist brackets')
        elif char == ',' and depth == 0:
            terms.append(expression[start:pos].strip())
            start = pos + 1
    if depth:
        raise ValueError('Unbalanced hostlist brackets')
    terms.append(expression[start:].strip())
    expanded = []
    for term in terms:
        if not term:
            raise ValueError('Empty hostlist entry')
        values = ['']
        cursor = 0
        for match in re.finditer(r'\[([^\]]*)\]', term):
            literal = term[cursor:match.start()]
            numbers = []
            for item in match.group(1).split(','):
                spec = re.fullmatch(r'([0-9]+)(?:-([0-9]+))?', item)
                if not spec:
                    raise ValueError('Hostlist brackets require numbers or ascending numeric ranges')
                low, high = spec.groups()
                if len(low) > 20 or (high is not None and len(high) > 20):
                    raise ValueError('Hostlist number is too long')
                if high is None:
                    numbers.append(low)
                else:
                    first, last = int(low), int(high)
                    if last < first or last - first + 1 + len(numbers) > MAX_HOSTS:
                        raise ValueError('Descending or oversized hostlist range')
                    width = len(low) if len(low) > 1 and low.startswith('0') else 0
                    numbers.extend(str(n).zfill(width) for n in range(first, last + 1))
            if len(values) * len(numbers) + len(expanded) > MAX_HOSTS:
                raise ValueError(f'Hostlist expansion exceeds {MAX_HOSTS} entries')
            values = [prefix + literal + number for prefix in values for number in numbers]
            cursor = match.end()
        expanded.extend(value + term[cursor:] for value in values)
        if len(expanded) > MAX_HOSTS:
            raise ValueError(f'Hostlist expansion exceeds {MAX_HOSTS} entries')
    return list(dict.fromkeys(expanded))


def parse_ini_inventory(source):
    """Small Ansible-style subset; no interpolation, plugins or children groups."""
    defaults, groups, standalone = {}, {}, []
    section = None
    seen_sections = set()
    for lineno, raw in enumerate(source.splitlines(), 1):
        line = raw.strip()
        if not line or line.startswith(('#', ';')):
            continue
        if line.startswith('['):
            match = re.fullmatch(r'\[([^\]]+)\]\s*(?:[#;].*)?', line)
            if not match:
                raise ValueError(f'Invalid inventory section at line {lineno}')
            section = match.group(1).strip()
            if not section or section in seen_sections:
                raise ValueError(f'Empty or duplicate inventory section at line {lineno}')
            seen_sections.add(section)
            if ':' in section and not section.endswith(':vars'):
                raise ValueError('Only group sections and :vars sections are supported')
            group = section.removesuffix(':vars')
            if not group or ':' in group:
                raise ValueError(f'Invalid group at line {lineno}')
            if group != 'all':
                groups.setdefault(group, {'nodes': []})
            continue
        if section is None:
            raise ValueError(f'Inventory entry before a section at line {lineno}')
        if section.endswith(':vars'):
            key, sep, value = line.partition('=')
            key = key.strip()
            if not sep or key not in FIELDS:
                raise ValueError(f'Invalid credential assignment at line {lineno}')
            # Whole-line comments only; unquoted passwords retain #, %, ; and backslashes.
            value = value.strip()
            try:
                value = ini_value(value)
            except ValueError:
                raise ValueError(f'Invalid quoted value at line {lineno}') from None
            target = defaults if section == 'all:vars' else groups[section[:-5]]
            if key in target:
                raise ValueError(f'Duplicate credential assignment at line {lineno}')
            target[key] = value
        else:
            try:
                parts = shlex.split(line, comments=True)
            except ValueError:
                raise ValueError(f'Invalid host entry quoting at line {lineno}') from None
            node = {'name': parts[0], 'host': parts[0]}
            assigned = set()
            for item in parts[1:]:
                key, sep, value = item.partition('=')
                if not sep or key not in FIELDS | {'host'} or key in assigned:
                    raise ValueError(f'Invalid or duplicate host field at line {lineno}')
                assigned.add(key)
                node[key] = value
            (standalone if section == 'all' else groups[section]['nodes']).append(node)
    return {'defaults': defaults, 'groups': groups, 'nodes': standalone}


def load_inventory(path):
    source = path.read_text(encoding='utf-8')
    if source.lstrip().startswith('{'):
        raise ValueError('JSON inventories are no longer supported; use inventory.example.ini')
    data = parse_ini_inventory(source)
    if not isinstance(data, dict) or set(data) - {'defaults', 'nodes', 'groups'}:
        raise ValueError('Inventory must contain only defaults, groups and nodes')
    defaults = data.get('defaults', {})
    nodes = data.get('nodes', [])
    if not isinstance(defaults, dict) or set(defaults) - FIELDS:
        raise ValueError('Invalid inventory defaults fields')
    def validate_credentials(source):
        for field in FIELDS & source.keys():
            if (not isinstance(source[field], str) or any(c in source[field] for c in '\x00\r\n') or
                    (field.endswith('_user') and not source[field].strip())):
                raise ValueError(f'Invalid inventory credential field: {field}')
    validate_credentials(defaults)
    if not isinstance(nodes, list):
        raise ValueError('Inventory nodes must be a list')
    groups = data.get('groups', {})
    if not isinstance(groups, dict):
        raise ValueError('Inventory groups must be an object keyed by group name')
    entries = [(node, defaults, None) for node in nodes]
    for group_name, group in groups.items():
        if not group_name.strip() or any(c in group_name for c in '\x00\r\n'):
            raise ValueError('Invalid inventory group name')
        if not isinstance(group, dict) or set(group) - (FIELDS | {'nodes'}):
            raise ValueError('Invalid inventory group fields')
        validate_credentials(group)
        if not isinstance(group.get('nodes'), list) or not group['nodes']:
            raise ValueError('Each inventory group requires a nonempty nodes list')
        inherited = {**defaults, **{k: v for k, v in group.items() if k in FIELDS}}
        entries.extend((node, inherited, group_name) for node in group['nodes'])
    if not entries:
        raise ValueError('Inventory must contain at least one node')
    expanded_entries = []
    for node, inherited, group_name in entries:
        if isinstance(node, str):
            node = {'host': node}
        if not isinstance(node, dict) or set(node) - (FIELDS | {'name', 'host'}):
            raise ValueError('Invalid inventory node fields')
        if not isinstance(node.get('host'), str) or not isinstance(node.get('name', node['host']), str):
            raise ValueError('Inventory host and name must be strings')
        node_hosts = expand_hostlist(node['host'])
        node_names = expand_hostlist(node.get('name', node['host']))
        if len(node_hosts) != len(node_names):
            raise ValueError('Node name and BMC host ranges must expand to the same count')
        expanded_entries.extend(({**node, 'host': h, 'name': n}, inherited, group_name)
                                for h, n in zip(node_hosts, node_names))
        if len(expanded_entries) > MAX_HOSTS:
            raise ValueError(f'Inventory exceeds {MAX_HOSTS} nodes')
    names, hosts, validated = set(), set(), []
    for node, inherited, group_name in expanded_entries:
        host = node.get('host', '')
        name = node.get('name', host)
        if not isinstance(host, str) or not re.fullmatch(r'[A-Za-z0-9_.:%-]+', host) or host.startswith('-'):
            raise ValueError('Each inventory node requires a valid BMC host')
        if not isinstance(name, str) or not name.strip() or any(c in name for c in '\x00\r\n'):
            raise ValueError('Invalid inventory node name')
        if name in names or host in hosts:
            raise ValueError('Inventory names and BMC hosts must be unique')
        names.add(name)
        hosts.add(host)
        validate_credentials(node)
        combined = {**inherited, **node, 'name': name, 'group': group_name}
        validated.append(combined)
    return validated


def default_config_path():
    return pathlib.Path(__file__).resolve().with_name('inventory.ini')


def find_config(explicit, needed=True):
    if explicit is not None:
        return explicit
    default = default_config_path()
    return default if needed and default.exists() else None


def missing_cli_credentials(args, os_required=True):
    return (args.bmc_user is None or
            (args.bmc_password is None and os.environ.get('IPMI_PASSWORD') is None) or
            (os_required and (args.os_user is None or
             (args.os_password is None and os.environ.get('SOL_OS_PASSWORD') is None))))


def prompt_credential(field, label):
    if not sys.stdin.isatty():
        raise ValueError(f'Missing {field} for {label}; no interactive terminal. Supply CLI, environment or INI credentials')
    prompt = f'{label} {field}: '
    try:
        value = getpass.getpass(prompt) if field.endswith('_password') else input(prompt)
    except EOFError:
        raise ValueError(f'No input received for {field}') from None
    if any(c in value for c in '\x00\r\n') or (field.endswith('_user') and not value.strip()):
        raise ValueError(f'Invalid or empty {field}')
    return value


def load_config(path, selector=None):
    """Resolve exactly one node by exact name or BMC address, never silently choose."""
    nodes = load_inventory(path)
    selected = nodes if selector is None else [n for n in nodes if selector in (n['name'], n['host'])]
    if not selected:
        raise ValueError('No node matches --host in the inventory')
    if len(selected) != 1:
        raise ValueError('Single-host mode requires exactly one node; specify --host with an unambiguous node name or BMC address. Use sol_exec.py --batch for multiple nodes.')
    return selected[0]


class SOLDisconnected(RuntimeError):
    """An established interactive SOL transport closed unexpectedly."""


def ping_host(host, timeout=2, attempts=3, interval=0.5, cancelled=None):
    """Bounded ICMP probes; any reply passes, failures do not prove a host offline."""
    cancelled = cancelled if cancelled is not None else threading.Event()
    binary = 'ping6' if ':' in host and sys.platform == 'darwin' else 'ping'
    executable = shutil.which(binary)
    if not executable:
        return False, f'Cannot check ICMP: {binary} is not installed'
    argv = [executable] + (['-6'] if ':' in host and binary == 'ping' else []) + ['-n', '-c', '1', host]
    for attempt in range(attempts):
        if cancelled.is_set():
            return False, 'Check cancelled'
        proc = None
        try:
            proc = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                    stderr=subprocess.DEVNULL, start_new_session=True)
            deadline = time.monotonic() + timeout
            while proc.poll() is None:
                if cancelled.is_set():
                    return False, 'Check cancelled'
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise subprocess.TimeoutExpired(argv, timeout)
                cancelled.wait(min(0.05, remaining))
            if proc.returncode == 0:
                return True, ''
            reason = f'ping exit={proc.returncode}'
        except subprocess.TimeoutExpired:
            reason = f'ping timed out after {timeout:g}s'
        except OSError as exc:
            return False, f'Cannot run ping: {exc}'
        finally:
            if proc is not None:
                if proc.poll() is None:
                    proc.terminate()
                    try:
                        proc.wait(timeout=0.3)
                    except subprocess.TimeoutExpired:
                        proc.kill()
                proc.wait()
        if attempt + 1 < attempts:
            if cancelled.wait(interval):
                return False, 'Check cancelled'
    return False, f'ICMP check failed after {attempts} attempts ({reason}); host may block ICMP'


def validate_ping_options(args):
    if args.ping_jobs < 1:
        raise ValueError('--ping-jobs must be positive')
    if args.ping_attempts < 1:
        raise ValueError('--ping-attempts must be positive')
    if not math.isfinite(args.ping_timeout) or args.ping_timeout <= 0:
        raise ValueError('--ping-timeout must be finite and positive')
    if not math.isfinite(args.ping_interval) or args.ping_interval < 0:
        raise ValueError('--ping-interval must be finite and nonnegative')


def add_ping_options(parser):
    parser.add_argument('--ping-jobs', type=int, default=32, help='Maximum concurrent ping checks, independent of SOL --jobs (default: 32)')
    parser.add_argument('--check-hosts', action='store_true', help='Check selected BMCs with bounded ping retries and exit; no credentials/ipmitool required')
    parser.add_argument('--ping-timeout', type=float, default=2, help='Per-attempt ping deadline in seconds (default: 2)')
    parser.add_argument('--ping-attempts', type=int, default=3, help='Maximum ICMP probes per check; stop on first reply (default: 3)')
    parser.add_argument('--ping-interval', type=float, default=0.5, help='Seconds between failed probes (default: 0.5)')
    parser.add_argument('--skip-ping', action='store_true', help='Skip default pre-connection ping checks (for networks blocking ICMP)')


class SessionLog:
    """Timestamped JSON Lines; control characters are escaped, not executed."""
    def __init__(self, path, host=None, name=None):
        self.host = host
        self.name = name
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        self.raw = os.fdopen(fd, 'wb')
        try:
            stream = (gzip.GzipFile(filename='', fileobj=self.raw, mode='wb', compresslevel=6)
                      if str(path).lower().endswith('.gz') else self.raw)
            self.file = io.TextIOWrapper(stream, encoding='utf-8')
        except BaseException:
            self.raw.close()
            raise

    def record(self, direction, data):
        entry = {'time': datetime.now().astimezone().isoformat(timespec='milliseconds'),
                 'direction': direction, 'data': data}
        if self.host is not None:
            entry['bmc_host'] = self.host
        if self.name is not None:
            entry['node_name'] = self.name
        self.file.write(json.dumps(entry, ensure_ascii=True) + '\n')
        self.file.flush()
        self.raw.flush()

    def close(self):
        try:
            self.file.close()
        finally:
            self.raw.close()


def node_file_label(host, name=None):
    address = re.sub(r'[^A-Za-z0-9._-]', '_', host)[:100] or 'bmc'
    if name and name != host:
        return (re.sub(r'[^A-Za-z0-9._-]', '_', name)[:100] or 'node') + '_' + address
    return address


def automatic_log_path(host, directory, compress=True, name=None):
    # Keep IPv4/hostnames readable, and make IPv6 or unusual names filesystem-safe.
    label = node_file_label(host, name)
    stamp = datetime.now().astimezone().strftime('%Y%m%d_%H%M%S_%f%z')
    return directory / (f'sol_{label}_{stamp}.jsonl' + ('.gz' if compress else ''))


def load_replay(path):
    try:
        return _load_replay(path)
    except (EOFError, zlib.error) as exc:
        raise ValueError('Compressed replay log is incomplete or corrupt') from exc


def _load_replay(path):
    """Validate the whole log before rendering; preserve order if wall time moved back."""
    events = []
    origin = None
    previous = 0.0
    with path.open('rb') as probe:
        compressed = probe.read(2) == b'\x1f\x8b' or str(path).lower().endswith('.gz')
    with (gzip.open(path, 'rt', encoding='utf-8') if compressed else path.open(encoding='utf-8')) as source:
        for number, line in enumerate(source, 1):
            if not line.strip():
                continue
            try:
                record = json.loads(line)
                timestamp = datetime.fromisoformat(record['time'])
                if timestamp.utcoffset() is None:
                    raise ValueError('timestamp must include a timezone')
                if record['direction'] not in ('IN', 'OUT', 'EVENT') or not isinstance(record['data'], str):
                    raise ValueError('invalid direction or data')
                seconds = timestamp.timestamp()
            except (ValueError, TypeError, KeyError, OverflowError) as exc:
                raise ValueError(f'Invalid replay record on line {number}: {exc}') from exc
            if origin is None:
                origin = seconds
            previous = max(previous, seconds - origin)
            events.append((previous, record['direction'], record['data']))
    if not events:
        raise ValueError('Replay log contains no records')
    return events


def replay(args):
    """Local playback only: this function never opens a SOL connection."""
    events = load_replay(args.replay)
    if args.replay_export:
        # Join chunks before stripping escapes: serial reads may split sequences.
        output = ''.join(data for _, direction, data in events if direction == 'OUT')
        output = re.sub(r'\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)', '', output)
        output = re.sub(r'\x1b[P^_X].*?\x1b\\', '', output, flags=re.S)
        output = re.sub(r'(?:\x1b\[|\x9b)[0-?]*[ -/]*[@-~]', '', output)
        output = re.sub(r'\x1b[ -/]*[@-Z\\-_]', '', output)
        output = output.replace('\r\n', '\n').replace('\r', '\n')
        output = re.sub(r'[\x00-\x08\x0b-\x1f\x7f-\x9f]', '', output)
        try:
            sys.stdout.write(output)
            sys.stdout.flush()
        except BrokenPipeError:
            # grep -q/head may close the pipe early; avoid a shutdown traceback.
            with open(os.devnull, 'w') as sink:
                os.dup2(sink.fileno(), sys.stdout.fileno())
        return 0
    controls = sys.stdin.isatty() and sys.stdout.isatty()
    saved = termios.tcgetattr(sys.stdin.fileno()) if controls else None
    handlers = {}
    position, speed, paused = 0.0, args.replay_speed, False
    index = 0
    last = time.monotonic()

    def status():
        print(f'\r\n[Replay {position:.1f}/{events[-1][0]:.1f}s | {speed:g}x | '
              f'{"paused" if paused else "playing"}]', file=sys.stderr, flush=True)

    def interrupted(signum, frame):
        raise KeyboardInterrupt

    print('Local replay only. Space: pause/resume; +: faster; -: slower; '
          'f: forward 10s; n: next record; q: quit.', file=sys.stderr, flush=True)
    try:
        if controls:
            for sig in (signal.SIGTERM, signal.SIGHUP):
                handlers[sig] = signal.signal(sig, interrupted)
            tty.setraw(sys.stdin.fileno(), when=termios.TCSANOW)
        status()
        while index < len(events):
            now = time.monotonic()
            if not paused:
                position += (now - last) * speed
            last = now
            # Render skipped records immediately, retaining their terminal effects.
            while index < len(events) and events[index][0] <= position:
                when, direction, data = events[index]
                if direction == 'OUT':
                    sys.stdout.write(data)
                    sys.stdout.flush()
                elif direction == 'EVENT' or args.replay_inputs:
                    print(f'\r\n[{when:.3f}s {direction}] {json.dumps(data, ensure_ascii=True)}',
                          file=sys.stderr, flush=True)
                index += 1
            if index == len(events):
                break
            delay = .1 if paused else min(.1, max(0, (events[index][0] - position) / speed))
            if controls:
                if select.select([sys.stdin.fileno()], [], [], delay)[0]:
                    keys = os.read(sys.stdin.fileno(), 128)
                    if not keys:
                        return 0
                    now = time.monotonic()
                    if not paused:
                        position += (now - last) * speed
                    last = now
                    for key in keys:
                        if key in (ord('q'), 0x1d):
                            return 0
                        if key == 3:
                            raise KeyboardInterrupt
                        if key == ord(' '):
                            paused = not paused
                        elif key in (ord('+'), ord('=')):
                            speed = min(64, speed * 2)
                        elif key == ord('-'):
                            speed = max(.125, speed / 2)
                        elif key == ord('f'):
                            position = min(events[-1][0], position + 10)
                        elif key == ord('n'):
                            position = max(position, events[index][0])
                        else:
                            continue
                        status()
            else:
                time.sleep(delay)
        print('\r\nReplay complete.', file=sys.stderr, flush=True)
        return 0
    finally:
        try:
            if saved is not None:
                termios.tcsetattr(sys.stdin.fileno(), termios.TCSANOW, saved)
        finally:
            for sig, handler in handlers.items():
                signal.signal(sig, handler)


class Console:
    def __init__(self, argv, env, session_log=None):
        self.pid, self.fd = pty.fork()
        if self.pid == 0:
            os.execvpe(argv[0], argv, env)
        self.buffer = ''
        self.input_sent = False
        self.session_log = session_log
        self.auth_private = False

    def log_bytes(self, direction, data):
        if self.session_log and data:
            text = '[REDACTED: automatic authentication]' if self.auth_private else data.decode('utf-8', errors='backslashreplace')
            self.session_log.record(direction, text)

    def send_password(self, password):
        # Suppress both the password input and possible serial echo until login completes.
        self.auth_private = True
        self.send(password + '\r')

    def send(self, text):
        self.send_bytes(text.encode())

    def send_bytes(self, data):
        if data:
            self.input_sent = True
        while data:
            count = os.write(self.fd, data)
            self.log_bytes('IN', data[:count])
            data = data[count:]

    def expect(self, patterns, timeout):
        deadline = time.monotonic() + timeout
        while True:
            for index, pattern in enumerate(patterns):
                match = re.search(pattern, self.buffer)
                if match:
                    before = self.buffer[:match.start()]
                    self.buffer = self.buffer[match.end():]
                    return index, match, before
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError('Timed out waiting for SOL/remote shell response')
            if not select.select([self.fd], [], [], remaining)[0]:
                continue
            try:
                data = os.read(self.fd, 65536)
            except OSError as exc:
                if exc.errno != errno.EIO:
                    raise
                data = b''
            if not data:
                # Never print console buffers here: login credentials may have echoed.
                raise RuntimeError('ipmitool disconnected before completion')
            self.log_bytes('OUT', data)
            self.buffer += data.decode('utf-8', errors='replace').replace('\r', '')

    def close(self):
        try:
            # A passive boot-console session is already at the escape line start.
            self.send('\r~.' if self.input_sent else '~.')
        except OSError:
            pass
        for _ in range(20):
            if os.waitpid(self.pid, os.WNOHANG)[0]:
                os.close(self.fd)
                return
            time.sleep(0.05)
        os.kill(self.pid, signal.SIGTERM)
        for _ in range(20):
            if os.waitpid(self.pid, os.WNOHANG)[0]:
                os.close(self.fd)
                return
            time.sleep(0.05)
        os.kill(self.pid, signal.SIGKILL)
        os.waitpid(self.pid, 0)
        os.close(self.fd)


def marker_command(token):
    # The complete token never appears in terminal input echo.
    return "printf '\\n%s%s\\n' '%s' '%s'" % ('%s', '%s', token[:16], token[16:])


def boundary(token):
    return r'(?m)^' + re.escape(token) + r'\n'


def interactive(con):
    """Relay raw terminal bytes; Ctrl-] detaches locally."""
    input_fd, output_fd = sys.stdin.fileno(), sys.stdout.fileno()
    saved = termios.tcgetattr(input_fd)
    handlers = {}

    def interrupted(signum, frame):
        raise KeyboardInterrupt

    def display(data):
        while data:
            data = data[os.write(output_fd, data):]

    print('Interactive SOL: Ctrl-] disconnects; Ctrl-C is sent to the remote console.',
          file=sys.stderr, flush=True)
    sys.stdout.flush()
    try:
        for sig in (signal.SIGTERM, signal.SIGHUP):
            handlers[sig] = signal.signal(sig, interrupted)
        tty.setraw(input_fd, when=termios.TCSANOW)
        if con.buffer:
            display(con.buffer.replace('\n', '\r\n').encode())
            con.buffer = ''
        while True:
            ready, _, _ = select.select([input_fd, con.fd], [], [])
            if con.fd in ready:
                try:
                    data = os.read(con.fd, 65536)
                except OSError as exc:
                    if exc.errno != errno.EIO:
                        raise
                    data = b''
                if not data:
                    raise SOLDisconnected('SOL transport disconnected')
                con.log_bytes('OUT', data)
                display(data)
            if input_fd in ready:
                data = os.read(input_fd, 4096)
                if not data:
                    return 0
                before, separator, _ = data.partition(b'\x1d')
                con.send_bytes(before)
                if separator:
                    if con.session_log:
                        con.session_log.record('EVENT', 'User detached with Ctrl-]')
                    return 0
    finally:
        try:
            termios.tcsetattr(input_fd, termios.TCSANOW, saved)
        finally:
            for sig, handler in handlers.items():
                signal.signal(sig, handler)
        print('\nSOL interactive session ended.', file=sys.stderr, flush=True)


def execute(con, command_text, args):
    token = "SOL_" + uuid.uuid4().hex
    # Stage bounded lines with an acknowledgement each; avoids serial line limits.
    var = 'SOL_CMD_' + uuid.uuid4().hex
    encoded = base64.b64encode(command_text.encode()).decode()
    con.send(var + "='' ; " + marker_command(token) + '\r')
    con.expect([boundary(token)], args.connect_timeout)
    for offset in range(0, len(encoded), 256):
        con.send(f'{var}="${{{var}}}"\'{encoded[offset:offset+256]}\'; '
                 + marker_command(token) + '\r')
        con.expect([boundary(token)], args.connect_timeout)
    begin, end = token + '_BEGIN', token + '_END'
    command = (marker_command(begin) + '; '
               + f'bash -c "$(printf \'%s\' "${{{var}}}" | base64 -d)"; '
               + f'{var}_RC=$?; unset {var}; '
               + "printf '\\n%s%s:%s\\n' "
               + f"'{end[:16]}' '{end[16:]}' \"${{{var}_RC}}\"; unset {var}_RC\r")
    con.send(command)
    con.expect([boundary(begin)], args.connect_timeout)
    _, match, output = con.expect([r'(?m)^' + re.escape(end) + r':(\d+)\n'], args.timeout)
    return int(match.group(1)), output[:-1] if output.endswith("\n") else output


def upload_digest(path, limit=None):
    digest = hashlib.sha256()
    with path.open('rb') as source:
        remaining = limit
        while remaining is None or remaining > 0:
            data = source.read(1024 * 1024 if remaining is None else min(1024 * 1024, remaining))
            if not data:
                break
            digest.update(data)
            if remaining is not None:
                remaining -= len(data)
    return digest.hexdigest()


def upload_stage(args, digest):
    identity = hashlib.sha256((args.remote_path + '\0' + args.transfer + '\0' + digest).encode()).hexdigest()[:32]
    if args.no_resume:
        identity = uuid.uuid4().hex
    return str(pathlib.PurePosixPath(args.remote_path).parent / ('.sol-upload-' + identity))


def upload_already_complete(checked, args, digest):
    if args.no_resume:
        return False
    q = shlex.quote
    token = 'SOL_COMPLETE_' + uuid.uuid4().hex
    output = checked(f'''if test -f {q(args.remote_path)} && test ! -L {q(args.remote_path)}; then
if test "$(sha256sum {q(args.remote_path)} | cut -d ' ' -f 1)" = '{digest}'; then
chmod {args.mode} {q(args.remote_path)} && printf '{token}\\n'
fi
fi
true''')
    if token in output.splitlines():
        print(f'Already uploaded: {args.remote_path}; SHA-256 verified: {digest}')
        return True
    return False


def prepare_upload_stage(checked, staging):
    q = shlex.quote
    checked(f'''set -e
umask 077
test ! -L {q(staging)}
mkdir -p -- {q(staging)}
test -O {q(staging)}
chmod 700 -- {q(staging)}
for f in payload payload.keep payload.b64 prefix receive.sh receiver.stderr receiver.pid; do
  test ! -L {q(staging)}/"$f"
  test ! -e {q(staging)}/"$f" || test -f {q(staging)}/"$f"
done
if test -f {q(staging + '/receiver.pid')}; then
  pid=$(cat -- {q(staging + '/receiver.pid')})
  if kill -0 "$pid" 2>/dev/null; then echo 'Previous receiver still running; retry after it exits' >&2; exit 1; fi
fi
if test ! -f {q(staging + '/payload')} && test -f {q(staging + '/payload.keep')}; then
  mv -- {q(staging + '/payload.keep')} {q(staging + '/payload')}
fi
''')


def resume_offset(checked, staging, source, encoded=False):
    """Verify remote prefix against the local file before trusting any resume data."""
    q = shlex.quote
    partial = staging + ('/payload.b64' if encoded else '/payload')
    binary = staging + '/prefix' if encoded else partial
    decode = f'base64 -d < {q(partial)} > {q(binary)}' if encoded else ':'
    token = 'SOL_PREFIX_' + uuid.uuid4().hex
    output = checked(f'''if test -f {q(partial)}; then
 if {decode}; then
  printf '{token}:%s:%s\\n' "$(wc -c < {q(binary)})" "$(sha256sum {q(binary)} | cut -d ' ' -f 1)"
 else printf '{token}:INVALID\\n'; fi
else printf '{token}:0:{hashlib.sha256(b'').hexdigest()}\\n'; fi''')
    match = re.search(re.escape(token) + r':\s*(\d+):([0-9a-f]{64})', output)
    if match:
        count = int(match.group(1))
        if (count <= source.stat().st_size and (not encoded or count % 3 == 0 or count == source.stat().st_size)
                and upload_digest(source, count) == match.group(2)):
            if count:
                print(f'Resuming upload at verified offset {count} bytes.', file=sys.stderr, flush=True)
            return count
    print('Saved upload prefix is invalid; restarting this file.', file=sys.stderr, flush=True)
    checked(f': > {q(partial)}')
    return 0


class SolEscapeEncoder:
    """Quote ipmitool's line-start ~ escapes across arbitrary packet boundaries."""
    def __init__(self):
        self.line_start = True

    def encode(self, data):
        output = bytearray()
        for byte in data:
            if self.line_start and byte == ord('~'):
                output.append(byte)
            output.append(byte)
            self.line_start = byte in (10, 13)
        return bytes(output)


def zmodem_upload(con, args):
    """Use local lrzsz on a raw PTY, with a binary relay over the existing SOL."""
    sender = shutil.which(args.zmodem_sender) if args.zmodem_sender else (shutil.which('sz') or shutil.which('lsz'))
    if not sender:
        raise RuntimeError('ZMODEM requires local sz/lsz from lrzsz; use --zmodem-sender PATH or --transfer base64')
    q = shlex.quote
    staging = str(pathlib.PurePosixPath(args.remote_path).parent / ('.sol-upload-' + uuid.uuid4().hex))
    token = 'SOL_Z_' + uuid.uuid4().hex
    ready = (token + '_READY\n').encode()
    end_pattern = re.compile(rb'\r?\n' + token.encode() + rb'_END:(\d+)\r?\n')

    def checked(command):
        rc, output = execute(con, command, args)
        if rc:
            raise RuntimeError(f'ZMODEM upload failed (remote exit {rc}): {output.strip()}')
        return output

    checked('command -v stty sha256sum chmod ln mv bash wc cut >/dev/null && '
            '(command -v rz >/dev/null || command -v lrz >/dev/null)')
    synchronized = True
    started_receiver = False
    master = slave = None
    proc = None
    saved_blocking = None
    raw_tail = bytearray()
    status = None
    completed = False
    # Snapshot under the fixed basename payload: rz cannot choose a target path.
    with tempfile.TemporaryDirectory(prefix='sol-zmodem-') as local_dir:
        payload = pathlib.Path(local_dir) / 'payload'
        fd = os.open(payload, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, 'wb') as dest, args.upload.open('rb') as source:
            shutil.copyfileobj(source, dest)
        digest = hashlib.sha256()
        with payload.open('rb') as source:
            while data := source.read(1024 * 1024):
                digest.update(data)
        size = payload.stat().st_size
        if upload_already_complete(checked, args, digest.hexdigest()):
            return 0
        staging = upload_stage(args, digest.hexdigest())
        prepare_upload_stage(checked, staging)
        resume_offset(checked, staging, payload)
        # rz may unlink an incomplete file on CAN. A hard link preserves its data.
        checked(f'touch -- {q(staging + "/payload")}; rm -f -- {q(staging + "/payload.keep")}; '
                f'ln -- {q(staging + "/payload")} {q(staging + "/payload.keep")}')
        receiver_script = f'''#!/bin/bash
cd -- {q(staging)} || exit 1
saved=$(stty -g) || exit 1
finish() {{
    rc=$?
    trap - EXIT
    stty "$saved"
    if test ! -f payload; then mv -- payload.keep payload; else rm -f -- payload.keep; fi
    rm -f receiver.pid
    printf '\\n%s_END:%s\\n' '{token}' "$rc"
}}
trap finish EXIT
printf '%s\\n' "$$" > receiver.pid
receiver=$(command -v rz || command -v lrz) || exit 1
stty raw -echo || exit 1
printf '%s_READY\\n' '{token}'
"$receiver" -b -e -r -q 2>receiver.stderr
'''
        try:
            checked(f'printf %s {q(receiver_script)} > {q(staging + "/receive.sh")}')
            con.buffer = ''
            con.send(f'bash {q(staging + "/receive.sh")}\r')
            synchronized = False
            started_receiver = True
            deadline = time.monotonic() + args.connect_timeout
            pending = bytearray()
            while ready not in pending:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise TimeoutError('Timed out starting remote ZMODEM receiver')
                if not select.select([con.fd], [], [], min(remaining, 0.1))[0]:
                    continue
                data = os.read(con.fd, 65536)
                if not data:
                    raise RuntimeError('SOL disconnected starting ZMODEM')
                pending.extend(data)
                if len(pending) > 1024 * 1024:
                    raise RuntimeError('Unexpected output while starting ZMODEM')
            pending = pending.split(ready, 1)[1]
            master, slave = pty.openpty()
            tty.setraw(slave, when=termios.TCSANOW)
            with tempfile.TemporaryFile() as diagnostics:
                proc = subprocess.Popen([sender, '-b', '-e', '-r', '-q', str(payload)],
                                        stdin=slave, stdout=slave, stderr=diagnostics,
                                        start_new_session=True)
                os.close(slave)
                slave = None
                os.set_blocking(master, False)
                saved_blocking = os.get_blocking(con.fd)
                os.set_blocking(con.fd, False)
                to_sender = bytearray(pending)
                to_remote = bytearray()
                encoder = SolEscapeEncoder()
                local_open = True
                deadline = time.monotonic() + args.timeout
                sent = received = 0
                last_report = time.monotonic()
                if con.session_log:
                    con.session_log.record('EVENT', f'ZMODEM upload started: {size} bytes; binary protocol logging suppressed')
                while status is None or proc.poll() is None:
                    if time.monotonic() >= deadline:
                        raise TimeoutError('ZMODEM transfer exceeded --timeout')
                    readers = [con.fd] if len(to_sender) < 1024 * 1024 else []
                    if local_open and len(to_remote) < 1024 * 1024:
                        readers.append(master)
                    writers = ([con.fd] if to_remote else []) + ([master] if to_sender and local_open else [])
                    readable, writable, _ = select.select(readers, writers, [], 0.1)
                    if con.fd in readable:
                        data = os.read(con.fd, 65536)
                        if not data:
                            raise RuntimeError('SOL disconnected during ZMODEM transfer')
                        received += len(data)
                        raw_tail.extend(data)
                        match = end_pattern.search(raw_tail)
                        if match:
                            status = int(match.group(1))
                            synchronized = True
                            con.buffer = bytes(raw_tail[match.end():]).decode('utf-8', errors='replace').replace('\r', '')
                        if len(raw_tail) > 65536:
                            del raw_tail[:-4096]
                        if local_open:
                            to_sender.extend(data)
                    if master in readable:
                        try:
                            data = os.read(master, 65536)
                        except OSError as exc:
                            if exc.errno != errno.EIO:
                                raise
                            data = b''
                        if data:
                            to_remote.extend(encoder.encode(data))
                        else:
                            local_open = False
                            to_sender.clear()
                    for target in writable:
                        queue = to_remote if target == con.fd else to_sender
                        if not queue or (target == master and not local_open):
                            continue
                        try:
                            count = os.write(target, queue[:65536])
                        except BlockingIOError:
                            continue
                        except OSError as exc:
                            if target == master and exc.errno == errno.EIO:
                                local_open = False
                                to_sender.clear()
                                continue
                            raise
                        del queue[:count]
                        if target == con.fd:
                            sent += count
                    if proc.poll() not in (None, 0):
                        diagnostics.seek(0)
                        detail = diagnostics.read()[-4096:].decode('utf-8', errors='replace').strip()
                        raise RuntimeError(f'Local ZMODEM sender failed (exit {proc.returncode}): {detail}')
                    if time.monotonic() - last_report >= 5:
                        print(f'ZMODEM: {sent} wire bytes sent, {received} received...', file=sys.stderr, flush=True)
                        last_report = time.monotonic()
                if status != 0:
                    os.set_blocking(con.fd, saved_blocking)
                    saved_blocking = None
                    detail = checked(f'cat -- {q(staging + "/receiver.stderr")}').strip()
                    raise RuntimeError(f'Remote ZMODEM receiver failed (exit {status}): {detail}')
            os.set_blocking(con.fd, saved_blocking)
            saved_blocking = None
            action = 'mv -fT' if args.overwrite else 'ln -T'
            checked(f'''set -e
cd -- {q(staging)}
printf '%s  payload\\n' '{digest.hexdigest()}' | sha256sum -c -
chmod {args.mode} payload
{action} -- payload {q(args.remote_path)}
''')
            completed = True
            print(f'Uploaded {size} bytes via ZMODEM to {args.remote_path}; SHA-256 verified: {digest.hexdigest()}')
            if con.session_log:
                con.session_log.record('EVENT', f'ZMODEM upload verified: {size} bytes, SHA-256 {digest.hexdigest()}')
            return 0
        finally:
            if proc is not None:
                if proc.poll() is None:
                    proc.terminate()
                    try:
                        proc.wait(timeout=0.5)
                    except subprocess.TimeoutExpired:
                        proc.kill()
                proc.wait()
            for fd in (master, slave):
                if fd is not None:
                    os.close(fd)
            if started_receiver and not synchronized:
                # CAN cancels rz; wait briefly for its wrapper to restore the TTY.
                try:
                    os.set_blocking(con.fd, False)
                    os.write(con.fd, b'\x18' * 10 + b'\x08' * 10)
                    until = time.monotonic() + 2
                    while time.monotonic() < until:
                        if select.select([con.fd], [], [], 0.1)[0]:
                            data = os.read(con.fd, 65536)
                            if not data:
                                break
                            raw_tail.extend(data)
                            if end_pattern.search(raw_tail):
                                synchronized = True
                                con.buffer = ''
                                break
                            del raw_tail[:-4096]
                except OSError:
                    pass
                finally:
                    os.set_blocking(con.fd, saved_blocking if saved_blocking is not None else True)
            elif saved_blocking is not None:
                os.set_blocking(con.fd, saved_blocking)
            if synchronized and completed:
                try:
                    checked(f'rm -f -- {q(staging + "/payload")} {q(staging + "/payload.keep")} {q(staging + "/receive.sh")} {q(staging + "/receiver.stderr")} {q(staging + "/receiver.pid")}; rmdir -- {q(staging)}')
                except (RuntimeError, OSError, TimeoutError):
                    print(f'Could not clean remote staging directory: {staging}', file=sys.stderr)
            else:
                print(f'ZMODEM progress retained; rerun the same upload to resume. Staging directory: {staging}', file=sys.stderr)


def add_transfer_options(parser):
    parser.add_argument('--no-resume', action='store_true', help='Start a fresh upload; default: verify and reuse saved progress on rerun')
    parser.add_argument('--transfer', choices=('base64', 'zmodem'), default='base64',
                        help='Upload transport (default: base64); zmodem needs local sz/lsz and remote rz/lrz')
    parser.add_argument('--zmodem-sender', help='Local sz/lsz executable path (default: search PATH); requires --transfer zmodem')


def validate_transfer_options(args):
    if not args.upload and (args.transfer != 'base64' or args.zmodem_sender or args.no_resume):
        raise ValueError('--transfer/--zmodem-sender/--no-resume require --upload')
    if args.zmodem_sender and args.transfer != 'zmodem':
        raise ValueError('--zmodem-sender requires --transfer zmodem')
    if args.upload and args.transfer == 'zmodem':
        sender = shutil.which(args.zmodem_sender) if args.zmodem_sender else (shutil.which('sz') or shutil.which('lsz'))
        if not sender:
            raise ValueError('Install local lrzsz (sz/lsz), or specify --zmodem-sender PATH')
        args.zmodem_sender = sender


def upload(con, args):
    if args.transfer == 'zmodem':
        return zmodem_upload(con, args)
    full_digest = upload_digest(args.upload)
    staging = upload_stage(args, full_digest)
    q = shlex.quote

    def checked(command):
        rc, output = execute(con, command, args)
        if rc:
            raise RuntimeError(f'Upload failed (remote exit {rc}): {output.strip()}')
        return output

    # Own a private directory on the destination filesystem; never truncate the target.
    checked('command -v base64 sha256sum chmod ln mv wc cut >/dev/null')
    if upload_already_complete(checked, args, full_digest):
        return 0
    prepare_upload_stage(checked, staging)
    synchronized = True
    completed = False
    try:
        total = resume_offset(checked, staging, args.upload, encoded=True)
        checked(f'touch -- {q(staging + "/payload.b64")}')
        last_report = time.monotonic()
        with args.upload.open('rb') as source:
            source.seek(total)
            while data := source.read(192):
                encoded = base64.b64encode(data).decode('ascii')
                token = 'SOL_' + uuid.uuid4().hex
                # One bounded serial line and status acknowledgement per chunk.
                con.send(f"printf '%s' '{encoded}' >> {q(staging + '/payload.b64')}; "
                         + "printf '\\n%s%s:%s\\n' "
                         + f"'{token[:16]}' '{token[16:]}' \"$?\"\r")
                _, match, _ = con.expect(
                    [r'(?m)^' + re.escape(token) + r':(\d+)\n'], args.connect_timeout)
                if int(match.group(1)):
                    raise RuntimeError('Remote write failed during upload')
                total += len(data)
                if time.monotonic() - last_report >= 5:
                    print(f'Uploaded {total} bytes...', file=sys.stderr)
                    last_report = time.monotonic()
        action = 'mv -fT' if args.overwrite else 'ln -T'
        checked(f'''set -e
base64 -d < {q(staging + '/payload.b64')} > {q(staging + '/payload')}
cd -- {q(staging)}
printf '%s  payload\\n' '{full_digest}' | sha256sum -c -
chmod {args.mode} payload
{action} -- payload {q(args.remote_path)}
''')
        completed = True
        print(f'Uploaded {total} bytes to {args.remote_path}; SHA-256 verified: {full_digest}')
        return 0
    except (TimeoutError, KeyboardInterrupt):
        synchronized = False
        print(f'Upload interrupted; remote state is uncertain. Temporary directory: {staging}', file=sys.stderr)
        raise
    finally:
        if synchronized and completed:
            try:
                checked(f'rm -f -- {q(staging + "/payload.b64")} {q(staging + "/payload")} {q(staging + "/prefix")}; rmdir -- {q(staging)}')
            except (RuntimeError, OSError, TimeoutError):
                print(f'Could not clean remote temporary directory: {staging}', file=sys.stderr)

        if not completed:
            print(f'Upload progress retained; rerun the same upload to resume: {staging}', file=sys.stderr)

def setup_remote_terminal(con, args):
    """Only called after detecting a Linux shell, before interactive handover."""
    if args.no_terminal_setup:
        return
    if args.rows is not None:
        rows, cols = args.rows, args.cols
    else:
        try:
            size = os.get_terminal_size(sys.stdout.fileno())
            rows, cols = size.lines, size.columns
        except OSError:
            raise RuntimeError('Cannot read local terminal size; specify --rows and --cols or --no-terminal-setup') from None
    if rows <= 0 or cols <= 0:
        raise RuntimeError('Local terminal size is zero; specify --rows and --cols')
    term = args.term or 'xterm'
    token = 'SOL_TTY_' + uuid.uuid4().hex
    command = (f'stty rows {rows} cols {cols} && '
               f'{{ unset LINES COLUMNS; export TERM={shlex.quote(term)}; }}; '
               "printf '\\n%s%s:%s\\n' " + f"'{token[:16]}' '{token[16:]}' \"$?\"")
    con.send(command + '\r')
    _, match, _ = con.expect([r'(?m)^' + re.escape(token) + r':(\d+)\n'], args.connect_timeout)
    if int(match.group(1)) != 0:
        raise RuntimeError('Remote terminal setup failed; check stty availability or use --no-terminal-setup')
    message = f'Remote terminal configured: TERM={term}, rows={rows}, cols={cols}'
    print(message, file=sys.stderr, flush=True)
    if con.session_log:
        con.session_log.record('EVENT', message)


def add_bmc_options(parser, operation):
    operation.add_argument('--power', choices=('status', 'on', 'off', 'soft', 'reset', 'cycle'),
                           help='IPMI chassis power: status/on, hard off/reset/cycle, or ACPI soft shutdown; no OS login')
    operation.add_argument('--bmc-log', choices=('list', 'elist', 'info'),
                           help='Read BMC System Event Log (SEL): list, extended list, or repository info')
    parser.add_argument('--sel-last', type=int, metavar='N',
                        help='Show only the last N SEL entries; requires --bmc-log list/elist')


def bmc_operation(args):
    return args.power is not None or args.bmc_log is not None


def bmc_command(args):
    if args.sel_last is not None and (args.sel_last < 1 or args.bmc_log not in ('list', 'elist')):
        raise ValueError('--sel-last must be positive and requires --bmc-log list/elist')
    if args.power is not None:
        return ['chassis', 'power', args.power]
    if args.bmc_log is not None:
        return ['sel', args.bmc_log] + (['last', str(args.sel_last)] if args.sel_last is not None else [])
    return []


def run_bmc(args, password):
    """One bounded IPMI request; never activate SOL or retry a power operation."""
    command = bmc_command(args)
    if not math.isfinite(args.timeout) or args.timeout <= 0:
        raise ValueError('--timeout must be finite and positive')
    validate_ping_options(args)
    if not shutil.which(args.ipmitool):
        raise ValueError('ipmitool is not installed or not on PATH')
    if not args.skip_ping:
        reachable, error = ping_host(args.host, args.ping_timeout, args.ping_attempts, args.ping_interval)
        if not reachable:
            print(f'ERROR: {args.host}: {error}', file=sys.stderr)
            return 125
    env = os.environ.copy()
    env.pop('IPMITOOL_PASSWORD', None)
    env.pop('SOL_OS_PASSWORD', None)
    env['IPMI_PASSWORD'] = password
    argv = [args.ipmitool, '-I', 'lanplus', '-H', args.host, '-U', args.bmc_user,
            '-E', '-C', str(args.cipher), '-L', 'ADMINISTRATOR'] + command
    output = None
    proc = None
    def interrupt(signum, frame):
        raise KeyboardInterrupt
    previous = signal.signal(signal.SIGTERM, interrupt)
    try:
        if args.output:
            output = args.output.open('w', encoding='utf-8')
        proc = subprocess.Popen(argv, env=env, stdin=subprocess.DEVNULL, stdout=output)
        try:
            return proc.wait(timeout=args.timeout)
        except subprocess.TimeoutExpired:
            print('ERROR: IPMI request timed out; completion is unknown. Check power status before retrying a power operation.', file=sys.stderr)
            return 124
    finally:
        if proc is not None and proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=2)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait()
        if output is not None:
            output.close()
        signal.signal(signal.SIGTERM, previous)


def run_bmc_single(args):
    config_path = find_config(args.config, needed=(args.host is None or missing_cli_credentials(args, os_required=False)))
    config = load_config(config_path, args.host) if config_path else {}
    args.host = config.get('host', args.host)
    if not args.host:
        raise ValueError('Specify --host or provide a single-node inventory')
    for field in ('bmc_user', 'bmc_password'):
        value = getattr(args, field)
        if value is None and field == 'bmc_password':
            value = os.environ.get('IPMI_PASSWORD')
        if value is None:
            value = config.get(field)
        if value is None:
            value = prompt_credential(field, args.host)
        if any(c in value for c in '\x00\r\n') or (field == 'bmc_user' and not value.strip()):
            raise ValueError(f'Invalid {field}')
        setattr(args, field, value)
    return run_bmc(args, args.bmc_password)


def run(args, bmc_password, os_password):
    env = os.environ.copy()
    env.pop('IPMITOOL_PASSWORD', None)
    env.pop('SOL_OS_PASSWORD', None)
    env['IPMI_PASSWORD'] = bmc_password
    argv = [args.ipmitool, '-I', 'lanplus', '-H', args.host, '-U', args.bmc_user,
            '-E', '-C', str(args.cipher), '-L', 'ADMINISTRATOR', '-e', '~',
            'sol', 'activate']
    session_log = getattr(args, 'session_log', None)
    if session_log:
        label = f'{args.node_name} ({args.host})' if args.node_name and args.node_name != args.host else args.host
        session_log.record('EVENT', f'Connecting to BMC {label}')
    con = Console(argv, env, session_log)
    try:
        result, _, _ = con.expect([
            r'SOL Session operational',
            r'(?i)(?:SOL payload already active|Error[^\n]*|Unable[^\n]*)'
        ], args.connect_timeout)
        if result:
            raise RuntimeError('SOL activation failed (check BMC credentials, cipher, SOL enablement or an existing session)')
        if args.console:
            return interactive(con)
        con.send('\r')
        if args.interactive and not args.os_user:
            return interactive(con)
        deadline = time.monotonic() + args.connect_timeout
        sent_user = sent_password = False
        while True:
            result, _, _ = con.expect([
                r'(?im)(?:^|\n)[^\n]*login:\s*$',
                r'(?im)(?:^|\n)[^\n]*password:\s*$',
                r'(?i)Login incorrect|Authentication failure',
                args.prompt,
            ], max(0.01, deadline - time.monotonic()))
            if result == 0:
                if sent_user or not args.os_user:
                    raise RuntimeError('Linux login required/failed; supply --os-user and --os-password or SOL_OS_PASSWORD')
                con.send(args.os_user + '\r')
                sent_user = True
            elif result == 1:
                if not sent_user or sent_password or os_password is None:
                    raise RuntimeError('Unexpected password prompt; refusing to retry credentials')
                con.send_password(os_password)
                sent_password = True
            elif result == 2:
                raise RuntimeError('Linux authentication failed')
            else:
                con.auth_private = False
                break

        if args.interactive:
            setup_remote_terminal(con, args)
            con.send('\r')  # Refresh the prompt consumed during automatic login.
            return interactive(con)
        token = 'SOL_' + uuid.uuid4().hex
        con.send(marker_command(token) + '\r')
        con.expect([boundary(token)], args.connect_timeout)
        if args.upload:
            return upload(con, args)
        rc, output = execute(con, args.command, args)
        sys.stdout.write(output)
        sys.stdout.flush()
        if args.output:
            path = pathlib.Path(args.output)
            with path.open('x', encoding='utf-8') as file:
                file.write(output)
        return rc
    finally:
        con.close()
        if session_log:
            session_log.record('EVENT', 'SOL session closed')


def run_with_reconnect(args, bmc_password, os_password):
    try:
        return run(args, bmc_password, os_password)
    except SOLDisconnected:
        if not args.reconnect:
            print('SOL disconnected; automatic reconnection is disabled.', file=sys.stderr)
            return 0

    # Reboot may leave BIOS/GRUB on screen. Never replay login or command input.
    resumed = argparse.Namespace(**vars(args))
    resumed.console = True
    resumed.interactive = False
    resumed.os_user = None
    resumed.os_password = None
    for attempt in range(1, args.reconnect_attempts + 1):
        if getattr(args, 'session_log', None):
            args.session_log.record('EVENT', f'Reconnect attempt {attempt}/{args.reconnect_attempts}')
        print(f'SOL disconnected; reconnecting in {args.reconnect_delay:g}s '
              f'({attempt}/{args.reconnect_attempts}). Ctrl-C cancels.',
              file=sys.stderr, flush=True)
        time.sleep(args.reconnect_delay)
        if not args.skip_ping:
            reachable, error = ping_host(args.host, args.ping_timeout, args.ping_attempts, args.ping_interval)
            if not reachable:
                print(f'{args.host}: {error}; skipping SOL for this reconnect attempt', file=sys.stderr, flush=True)
                if getattr(args, 'session_log', None):
                    args.session_log.record('EVENT', f'ICMP check failed; skipped reconnect attempt {attempt}/{args.reconnect_attempts}')
                continue
        try:
            return run(resumed, bmc_password, None)
        except (RuntimeError, OSError, TimeoutError) as exc:
            print(f'Reconnect attempt ended: {exc}', file=sys.stderr, flush=True)
    raise RuntimeError('SOL reconnect attempts exhausted; check BMC availability and SOL session state')


def print_brief_help(parser):
    """Show common options without changing how normal commands are parsed."""
    brief = {
        'help': 'Show this brief help and exit',
        'help_all': 'Show all parameters, defaults and detailed notes',
        'help_examples': 'Show usage examples only',
        'help_batch': 'Show batch options and examples',
        'power': 'IPMI power status/on/off/soft/reset/cycle (no OS login)',
        'bmc_log': 'Read BMC SEL: list/elist/info (no OS login)',
        'sel_last': 'Show the last N SEL entries',
        'bash_completion': 'Print Bash completion setup (source the output to enable)',
        'check_hosts': 'Check configured BMCs with bounded ping retries',
        'batch': 'Run commands/scripts or upload files on multiple nodes',
        'group': 'Select an inventory group (enables batch mode)',
        'host': 'BMC IP or hostname (not needed for replay)',
        'config': 'Load BMC/Linux credentials from an INI file',
        'bmc_user': 'BMC account with SOL access',
        'bmc_password': 'BMC password; also accepts IPMI_PASSWORD',
        'os_user': 'Linux user for automatic login',
        'os_password': 'Linux password; also accepts SOL_OS_PASSWORD',
        'console': 'Watch boot / use the console without automatic login',
        'interactive': 'Interactive console, optionally with automatic login',
        'command': 'Execute a Bash command',
        'command_file': 'Execute a local UTF-8 script remotely',
        'upload': 'Upload a file; requires --remote-path',
        'transfer': 'Upload method: base64 (default) or zmodem; resume on rerun',
        'no_resume': 'Start a fresh upload without reusing saved progress',
        'remote_path': 'Absolute destination filename for upload',
        'replay': 'Play a recorded JSONL log locally (no connection)',
        'replay_export': 'Export replay OUT as plain text to stdout, without delays (for grep)',
        'replay_speed': 'Playback speed (default: 1; range: 0.125-64)',
        'log_file': 'Set log filename (default: automatic BMC + timestamp name)',
        'no_log': 'Disable I/O logging (enabled by default for remote sessions)',
        'log_compress': 'Gzip logs by default; --no-log-compress writes plain JSONL',
    }
    for action in parser._actions:
        action.help = brief.get(action.dest, argparse.SUPPRESS)
    parser.usage = '%(prog)s [connection options] OPERATION [options]'
    parser.description = 'IPMI SOL console, remote commands, file upload and local log replay.'
    parser.epilog = r'''Quick start:
  python3 sol_exec.py --host 192.0.2.10 --bmc-user admin --console
  python3 sol_exec.py --replay ./node-sol.jsonl --replay-speed 4

Console: Ctrl-] exits; automatic reconnect is enabled by default.
Batch: --config inventory.ini --batch --group beijing -c 'hostname'
More: --help-batch for batch usage; --help-all for every option; --help-examples for complete examples.'''
    parser.print_help()


class HelpAction(argparse.Action):
    def __call__(self, parser, namespace, values, option_string=None):
        if self.const == 'all':
            parser.print_help()
        elif self.const == 'batch':
            parser_for_batch().print_help()
        elif self.const == 'examples':
            print(parser.epilog.split('\nPassword precedence:', 1)[0].rstrip())
        else:
            print_brief_help(parser)
        parser.exit()


def parser_for_batch():
    parser = argparse.ArgumentParser(
        description='Run SOL commands, uploads or IPMI power/SEL operations with bounded concurrency.', formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''Examples (run from the sol directory):
  python3 sol_exec.py --batch --hosts 192.0.2.10,192.0.2.11 --config inventory.ini -c 'hostname'
  python3 sol_exec.py --batch --hosts-file hosts.txt --config inventory.ini \\
    --command-file check_cpu.sh --jobs 4 --timeout 120

Host files contain one BMC IP/hostname per line; blank lines and # comments are ignored.
Inventory credentials inherit: defaults < group < node.
Password precedence: CLI > environment (IPMI_PASSWORD / SOL_OS_PASSWORD) > node > group > all:vars.
Username precedence: CLI > node > group > all:vars.
--hosts/--hosts-file expand numeric hostlists and select inventory names or BMC addresses.
Without inventory, hostlists are BMC addresses. --match searches inventory names/addresses.
With an inventory and no selector, all nodes are selected. --group narrows either selection.
Preview selection: --inventory inventory.ini --group beijing --match '^gpu-' --list-hosts
Missing credentials are prompted before connecting; workers never prompt for passwords.
Each host gets stdout.txt and stderr.txt; SOL operations also get sol.jsonl.gz by default.
results.json summarizes all hosts. Power/SEL needs only BMC credentials and records ipmi-operation.txt.
Exit: 0 all succeeded; 1 one or more failed; 2 invalid input; 130 interrupted.
Upload example: --inventory inventory.ini --group beijing --upload stat.sh --remote-path /tmp/stat.sh --mode 755
ZMODEM: add --transfer zmodem (local sz/lsz, remote rz/lrz). Rerun interrupted uploads to resume; --no-resume starts fresh.
No automatic reconnect/retry. Upload checkpoints resume when the command is rerun. Interruption/timeout does not guarantee remote commands stop.
Uploads are supported; uploading saves files but does not execute them.
Interactive, boot console and replay are NOT batch operations.
For multiple live consoles, run sol_exec.py separately in terminal tabs or tmux panes.
''')
    add_ping_options(parser)
    add_transfer_options(parser)
    parser.add_argument('--config', '--inventory', dest='inventory', type=Path, help='INI inventory; default: inventory.ini beside this script')
    parser.add_argument('--group', action='append', help='Select inventory group; repeat for multiple groups, optionally combine with --match')
    parser.add_argument('--list-hosts', action='store_true', help='Print selected node names/BMC addresses without connecting')
    parser.add_argument('--batch', action='store_true', help='Run commands, uploads or IPMI power/SEL operations on selected nodes')
    hosts = parser.add_mutually_exclusive_group()
    hosts.add_argument('--hosts', help='Inventory node names or BMC hostlist, e.g. \'192.0.2.[10-11],node[001-003,007]\'')
    hosts.add_argument('--hosts-file', type=Path, help='Text file with one node name, BMC address or hostlist expression per line')
    hosts.add_argument('--match', help='Python regex search on inventory node name or BMC host; quote and anchor as needed')
    operation = parser.add_mutually_exclusive_group()
    add_bmc_options(parser, operation)
    operation.add_argument('-c', '--command', help='Noninteractive Bash command run on each host')
    operation.add_argument('--command-file', type=Path, help='Local UTF-8 Bash script run on each host')
    operation.add_argument('--upload', type=Path, help='Upload a local file to each selected host without executing it')
    parser.add_argument('--remote-path', help='Absolute remote destination filename for --upload')
    parser.add_argument('--mode', default='600', help='Remote upload permissions in octal (default: 600)')
    parser.add_argument('--overwrite', action='store_true', help='Replace existing remote files (default: refuse)')
    parser.add_argument('--bmc-user', help='BMC username (overrides config)')
    parser.add_argument('--bmc-password', help='BMC password (overrides environment/config)')
    parser.add_argument('--os-user', help='Linux username (overrides config; required for batch login)')
    parser.add_argument('--os-password', help='Linux password (overrides environment/config)')
    parser.add_argument('--jobs', type=int, default=4, help='Maximum concurrent hosts (default: 4)')
    parser.add_argument('--timeout', type=float, default=300, help='Per-host command timeout in seconds (default: 300)')
    parser.add_argument('--connect-timeout', type=float, default=60, help='Per-stage connection/login timeout (default: 60)')
    parser.add_argument('--cipher', type=int, default=17, help='IPMI cipher suite (default: 17)')
    parser.add_argument('--ipmitool', default='ipmitool', help='ipmitool executable name/path')
    parser.add_argument('--prompt', default=r'(?m)^[^\n]*[#$] ?$', help='Remote shell prompt regex')
    parser.add_argument('--result-dir', type=Path, help='New results directory; default: batch-logs/run_<timestamp>_<id>')
    parser.add_argument('--no-log', action='store_true', help='Disable SOL JSONL logs; retain stdout/stderr and summary')
    compression = parser.add_mutually_exclusive_group()
    compression.add_argument('--log-compress', action='store_true', default=None,
                             help='Write gzip-compressed sol.jsonl.gz logs (default)')
    compression.add_argument('--no-log-compress', action='store_false', dest='log_compress',
                             help='Write uncompressed JSONL logs')
    return parser


def run_batch():
    parser = parser_for_batch()
    args = parser.parse_args()
    try:
        if args.no_log and args.log_compress:
            raise ValueError('--log-compress cannot be combined with --no-log')
        if args.log_compress is None:
            args.log_compress = not args.no_log
        bmc_command(args)
        direct_bmc = bmc_operation(args)
        args.inventory = find_config(args.inventory, needed=(missing_cli_credentials(args, os_required=not direct_bmc) or
            args.group is not None or args.match is not None or
            (args.hosts is None and args.hosts_file is None)))
        inventory = load_inventory(args.inventory) if args.inventory else []
        if args.group:
            if not args.inventory:
                raise ValueError('--group requires --inventory')
            if set(args.group) - {n['group'] for n in inventory}:
                raise ValueError('Unknown inventory group')
        if args.match is not None and not args.inventory:
            raise ValueError('--match requires --inventory; regex does not scan the network')
        if not args.inventory and args.hosts is None and args.hosts_file is None:
            raise ValueError('Supply --inventory, --hosts or --hosts-file')
        raw_hosts = ([args.hosts] if args.hosts is not None else
                     args.hosts_file.read_text().splitlines() if args.hosts_file else [])
        hosts = []
        for line in raw_hosts:
            expression = line.split('#', 1)[0].strip()
            if not expression:
                continue
            for host in expand_hostlist(expression):
                if not re.fullmatch(r'[A-Za-z0-9_.:%-]+', host) or host.startswith('-'):
                    raise ValueError('Host entries must be node names, BMC IPs or hostnames, without whitespace or shell syntax')
                if host not in hosts:
                    hosts.append(host)
            if len(hosts) > MAX_HOSTS:
                raise ValueError(f'Host list exceeds {MAX_HOSTS} nodes')
        if args.inventory:
            if args.hosts is not None or args.hosts_file:
                by_host = {n['host']: n for n in inventory}
                by_name = {n['name']: n for n in inventory}
                nodes, selected = [], set()
                for host in hosts:
                    named, addressed = by_name.get(host), by_host.get(host)
                    if named is not None and addressed is not None and named is not addressed:
                        raise ValueError(f'Ambiguous host selector {host!r}: matches different inventory nodes by name and BMC address')
                    node = named if named is not None else addressed
                    if node is None:
                        raise ValueError(f'Host selector {host!r} does not match any inventory node name or BMC address')
                    if node['host'] not in selected:
                        nodes.append(node)
                        selected.add(node['host'])
            else:
                pattern = re.compile(args.match) if args.match is not None else None
                nodes = [n for n in inventory if pattern is None or
                         pattern.search(n['name']) or pattern.search(n['host'])]
            if args.group:
                nodes = [n for n in nodes if n['group'] in args.group]
            hosts = [n['host'] for n in nodes]
        else:
            nodes = [{'name': h, 'host': h} for h in hosts]
        if not hosts:
            raise ValueError('Host list is empty')
        validate_ping_options(args)
        if args.jobs < 1:
            raise ValueError('--jobs must be positive')
        if args.check_hosts:
            if args.skip_ping or args.list_hosts or args.command is not None or args.command_file or args.upload or direct_bmc:
                raise ValueError('--check-hosts cannot be combined with commands, --list-hosts or --skip-ping')
            failed = 0
            cancelled = threading.Event()
            previous = {sig: signal.signal(sig, lambda signum, frame: cancelled.set())
                        for sig in (signal.SIGINT, signal.SIGTERM)}
            try:
                with ThreadPoolExecutor(max_workers=min(args.ping_jobs, len(hosts))) as pool:
                    futures = {pool.submit(ping_host, n['host'], args.ping_timeout, args.ping_attempts, args.ping_interval, cancelled): n for n in nodes}
                    for future in as_completed(futures):
                        if cancelled.is_set():
                            continue
                        node = futures[future]
                        reachable, error = future.result()
                        print(f'{node["name"]}\t{node["host"]}\t' + ('reachable' if reachable else f'ERROR: {error}'), flush=True)
                        failed += not reachable
            finally:
                for sig, handler in previous.items():
                    signal.signal(sig, handler)
            if cancelled.is_set():
                print('Ping checks interrupted.', file=sys.stderr)
                return 130
            print(f'Ping summary: {len(hosts) - failed} reachable, {failed} failed, {len(hosts)} total', flush=True)
            return 1 if failed else 0
        if args.list_hosts:
            for node in nodes:
                print(f'{node["name"]}\t{node["host"]}\t{node.get("group") or "-"}')
            return 0
        if args.command is None and args.command_file is None and args.upload is None and not direct_bmc:
            raise ValueError('Supply --command, --command-file, --upload, --power or --bmc-log')
        if args.jobs < 1:
            raise ValueError('--jobs must be positive')
        if not all(math.isfinite(t) and t > 0 for t in (args.timeout, args.connect_timeout)):
            raise ValueError('Timeouts must be finite and positive')
        re.compile(args.prompt)
        validate_transfer_options(args)
        if args.upload:
            if not args.upload.is_file():
                raise ValueError('--upload must be a readable regular file')
            if (not args.remote_path or not args.remote_path.startswith('/') or args.remote_path.endswith('/') or
                    any(c in args.remote_path for c in '\x00\r\n') or Path(args.remote_path).name in ('.', '..')):
                raise ValueError('--remote-path must be an absolute destination filename')
            if not re.fullmatch(r'[0-7]{3}', args.mode):
                raise ValueError('--mode must be three octal digits, such as 600 or 755')
        else:
            if args.remote_path or args.overwrite or args.mode != '600':
                raise ValueError('--remote-path, --overwrite and --mode require --upload')
            command = (shlex.join(bmc_command(args)) if direct_bmc else
                       args.command_file.read_text(encoding='utf-8') if args.command_file else args.command)
            if not command or '\x00' in command:
                raise ValueError('Command must be nonempty and contain no NUL')
        credentials_by_host = {}
        prompted = {}
        for node in nodes:
            credentials = {}
            for field in sorted({'bmc_user', 'bmc_password'} if direct_bmc else FIELDS):
                value = getattr(args, field)
                if value is None and field.endswith('_password'):
                    value = os.environ.get('IPMI_PASSWORD' if field == 'bmc_password' else 'SOL_OS_PASSWORD')
                if value is None:
                    value = node.get(field)
                if value is None:
                    # Prompt once per missing group field, before starting any workers.
                    scope = node.get('group') or node['host']
                    key = (node.get('group') is not None, scope, field)
                    if key not in prompted:
                        prompted[key] = prompt_credential(field, f'Group {scope}' if node.get('group') else scope)
                    value = prompted[key]
                if field.endswith('_user') and not value.strip():
                    raise ValueError(f'Empty {field} for {node["host"]}')
                if any(c in value for c in '\x00\r\n'):
                    raise ValueError(f'Invalid control character in {field}')
                credentials[field] = value
            credentials_by_host[node['host']] = credentials
        from shutil import which
        ipmitool = which(args.ipmitool)
        if not ipmitool:
            raise ValueError('ipmitool is not installed or not on PATH')
        directory = args.result_dir or Path('batch-logs') / (
            'run_' + datetime.now().astimezone().strftime('%Y%m%d_%H%M%S%z') + '_' + uuid.uuid4().hex[:8])
        directory = directory.resolve()
        directory.mkdir(mode=0o700, parents=True, exist_ok=False)
        snapshot = directory / ('ipmi-operation.txt' if direct_bmc else 'upload.payload' if args.upload else 'command.sh')
        fd = os.open(snapshot, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, 'wb') as output:
            if args.upload:
                with args.upload.open('rb') as source:
                    shutil.copyfileobj(source, output)
            else:
                output.write(command.encode('utf-8'))
    except (OSError, ValueError, re.error) as exc:
        parser.error(str(exc))

    stopped = threading.Event()
    lock = threading.RLock()
    processes = set()
    results = []
    ping_results = {}

    def worker(index, host):
        credentials = credentials_by_host[host]
        env = os.environ.copy()
        env['IPMI_PASSWORD'] = credentials['bmc_password']
        env.pop('SOL_OS_PASSWORD', None)
        if not direct_bmc:
            env['SOL_OS_PASSWORD'] = credentials['os_password']
        env.pop('IPMITOOL_PASSWORD', None)
        started = time.monotonic()
        node_name = nodes[index - 1]['name']
        folder = directory / f'{index:04d}_{node_file_label(host, node_name)}'
        result = {'host': host, 'name': nodes[index - 1]['name'], 'status': 'cancelled', 'exit_code': None,
                  'duration_seconds': 0, 'directory': str(folder)}
        if stopped.is_set():
            return result
        if not args.skip_ping:
            reachable, error = ping_results[host]
            if not reachable:
                result.update(status='unreachable', exit_code=125, error=error,
                              duration_seconds=round(time.monotonic() - started, 3))
                label = f'{node_name} ({host})' if node_name != host else host
                print(f'ERROR: {label}: {error}', file=sys.stderr, flush=True)
                return result
        try:
            folder.mkdir(mode=0o700)
            stdout_fd = os.open(folder / 'stdout.txt', os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(stdout_fd, 'w') as out:
                stderr_fd = os.open(folder / 'stderr.txt', os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
                with os.fdopen(stderr_fd, 'w') as err:
                    argv = [sys.executable, str(Path(__file__).with_name('sol_exec.py').resolve()),
                            '--host', host, '--node-name=' + node_name, '--skip-ping', '--bmc-user=' + credentials['bmc_user'],
                            '--timeout', str(args.timeout), '--connect-timeout', str(args.connect_timeout),
                            '--cipher', str(args.cipher), '--ipmitool', ipmitool, '--prompt', args.prompt]
                    if not direct_bmc:
                        argv += ['--os-user=' + credentials['os_user']]
                    if direct_bmc:
                        argv += ['--power', args.power] if args.power else ['--bmc-log', args.bmc_log]
                        if args.sel_last is not None:
                            argv += ['--sel-last', str(args.sel_last)]
                    elif args.upload:
                        argv += ['--upload', str(snapshot), '--remote-path', args.remote_path, '--mode', args.mode, '--transfer', args.transfer]
                        if args.no_resume:
                            argv += ['--no-resume']
                        if args.zmodem_sender:
                            argv += ['--zmodem-sender', args.zmodem_sender]
                        if args.overwrite:
                            argv += ['--overwrite']
                    else:
                        argv += ['--command-file', str(snapshot)]
                    log_name = 'sol.jsonl.gz' if args.log_compress else 'sol.jsonl'
                    argv += ['--no-log'] if args.no_log or direct_bmc else ['--log-file', str(folder / log_name)]
                    if not direct_bmc and not args.no_log and not args.log_compress:
                        argv += ['--no-log-compress']
                    with lock:
                        if stopped.is_set():
                            return result
                        proc = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=out, stderr=err,
                                                env=env, start_new_session=True)
                        processes.add(proc)
                    try:
                        rc = proc.wait()
                    finally:
                        with lock:
                            processes.discard(proc)
                    result.update(exit_code=rc, status='ok' if rc == 0 else 'failed')
                    if stopped.is_set() and rc != 0:
                        result['status'] = 'cancelled'
        except OSError as exc:
            result.update(status='failed', error=str(exc))
        result['duration_seconds'] = round(time.monotonic() - started, 3)
        return result

    def stop(signum, frame):
        stopped.set()
        # Children handle SIGTERM and close their SOL transport in finally.
        with lock:
            for proc in list(processes):
                try:
                    proc.terminate()
                except ProcessLookupError:
                    pass

    previous = {sig: signal.signal(sig, stop) for sig in (signal.SIGINT, signal.SIGTERM)}
    print(f'Running on {len(hosts)} hosts, concurrency={min(args.jobs, len(hosts))}; results: {directory}', flush=True)
    try:
        if not args.skip_ping:
            print(f'Checking ICMP: concurrency={min(args.ping_jobs, len(hosts))}', flush=True)
            def probe(host):
                if stopped.is_set():
                    return False, 'Check cancelled'
                return ping_host(host, args.ping_timeout, args.ping_attempts, args.ping_interval, stopped)
            with ThreadPoolExecutor(max_workers=min(args.ping_jobs, len(hosts))) as ping_pool:
                checks = {ping_pool.submit(probe, host): host for host in hosts}
                for future in as_completed(checks):
                    host = checks[future]
                    ping_results[host] = future.result()
        with ThreadPoolExecutor(max_workers=min(args.jobs, len(hosts))) as pool:
            futures = [pool.submit(worker, index, host) for index, host in enumerate(hosts, 1)]
            for future in as_completed(futures):
                result = future.result()
                results.append(result)
                label = (f'{result["name"]} ({result["host"]})'
                         if result.get('name') and result['name'] != result['host'] else result['host'])
                print(f'{label}: {result["status"]} (exit={result["exit_code"]})', flush=True)
                summary = {'hosts': len(hosts), 'completed': len(results),
                           'interrupted': stopped.is_set(), 'results': sorted(results, key=lambda r: hosts.index(r['host']))}
                temp = directory / 'results.tmp'
                fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
                with os.fdopen(fd, 'w') as output:
                    json.dump(summary, output, indent=2)
                    output.write('\n')
                temp.replace(directory / 'results.json')
    finally:
        for sig, handler in previous.items():
            signal.signal(sig, handler)
    return 130 if stopped.is_set() else (0 if all(r['status'] == 'ok' for r in results) else 1)


def bash_completion(parser):
    """Generate standalone Bash 3.2+ completion from argparse's option metadata."""
    actions = [a for a in parser._actions if a.help != argparse.SUPPRESS]
    options = ' '.join(opt for a in actions for opt in a.option_strings)
    cases = []
    for action in actions:
        if action.nargs == 0:
            continue
        pattern = '|'.join(action.option_strings)
        if action.choices:
            command = 'compgen -W {} -- "$cur"'.format(
                shlex.quote(' '.join(str(value) for value in action.choices)))
        elif action.type is Path or action.dest in {'ipmitool', 'zmodem_sender'}:
            kind = '-d' if action.dest in {'log_dir', 'result_dir'} else '-f'
            command = f'compgen {kind} -- "$cur"'
        else:
            cases.append(f'        {pattern}) return ;;')
            continue
        cases.append(f'''        {pattern})
            while IFS= read -r candidate; do
                COMPREPLY+=("$prefix$candidate")
            done < <({command})
            return ;;''')
    script = r'''# Generated by sol_exec.py --bash-completion; source in Bash.
sol_exec() {
    __PYTHON__ __SCRIPT__ "$@"
}
_sol_exec_complete() {
    local cur prev prefix='' candidate i
    COMPREPLY=()
    cur=${COMP_WORDS[COMP_CWORD]}
    prev=${COMP_WORDS[COMP_CWORD-1]}
    # Respect the end-of-options marker.
    for ((i=1; i<COMP_CWORD; i++)); do
        [[ ${COMP_WORDS[i]} == -- ]] && return
    done
    # Bash normally splits '=' into its own completion word. Also support
    # shells that remove '=' from COMP_WORDBREAKS.
    if [[ $cur == --*=* ]]; then
        prev=${cur%%=*}
        prefix=$prev=
        cur=${cur#*=}
    elif [[ $cur == = ]]; then
        cur=''
    elif [[ $prev == = && $COMP_CWORD -ge 2 ]]; then
        prev=${COMP_WORDS[COMP_CWORD-2]}
    fi
    # --log-file takes an optional filename; a new option is also valid.
    if [[ $prev == --log-file && $cur == -* && -z $prefix ]]; then
        prev=''
    fi
    case "$prev" in
__CASES__
    esac
    if [[ -z $cur || $cur == -* ]]; then
        while IFS= read -r candidate; do
            COMPREPLY+=("$candidate")
        done < <(compgen -W __OPTIONS__ -- "$cur")
    fi
}
complete -o filenames -F _sol_exec_complete sol_exec sol_exec.py __SCRIPT__
'''
    return (script.replace('__PYTHON__', shlex.quote(sys.executable))
            .replace('__SCRIPT__', shlex.quote(str(Path(__file__).resolve())))
            .replace('__CASES__', '\n'.join(cases))
            .replace('__OPTIONS__', shlex.quote(options)))


def _main():
    parser = argparse.ArgumentParser(
        add_help=False,
        description=(
            'Connect over IPMI SOL to watch boot, interact with Linux, run commands or upload files.\n'
            'Local: Python 3.9+ and ipmitool. Batch commands: remote Linux, Bash and base64.\n'
            'Uploads also need sha256sum and GNU coreutils. Boot console only needs BMC SOL\n'
            'and serial redirection configured for the boot stages you want to observe.'
        ),
        formatter_class=argparse.RawTextHelpFormatter,
        epilog=r"""Examples (run from the sol directory; replace the host and credentials):
  1. Run a command; missing credentials come from the default inventory.ini:
     python3 sol_exec.py --host 192.0.2.10 --bmc-user admin --os-user root \
       -c 'hostname; uname -r'

  2. Supply both passwords without interactive prompts:
     python3 sol_exec.py --host 192.0.2.10 \
       --bmc-user admin --bmc-password 'BMC_PASSWORD' \
       --os-user root --os-password 'LINUX_PASSWORD' -c 'uptime'

  3. Execute a local script remotely and save its output:
     python3 sol_exec.py --host 192.0.2.10 --bmc-user admin --os-user root \
       --command-file ./check_cpu.sh --timeout 120 --output ./node-result.txt

  4. Upload a file, verify SHA-256 and set executable permissions (does not execute it):
     python3 sol_exec.py --host 192.0.2.10 --bmc-user admin --os-user root \
       --upload ./check_cpu.sh --remote-path /tmp/check_cpu.sh --mode 755
     Add --overwrite to replace an existing destination file.

  5. Use IPMI_PASSWORD / SOL_OS_PASSWORD supplied by your automation environment:
     python3 sol_exec.py --host 192.0.2.10 --bmc-user admin --os-user root \
       -c 'cat /proc/cmdline'

  6. Open an interactive console after automatic Linux login:
     python3 sol_exec.py --host 192.0.2.10 --bmc-user admin --os-user root \
       --interactive
     Ctrl-] disconnects locally. Ctrl-C, Tab and arrow keys go to the remote console.
     Omit --os-user to log in manually (also suitable for MFA or an existing console).

  7. Watch BIOS/bootloader/kernel output before Linux has started:
     python3 sol_exec.py --host 192.0.2.10 --bmc-user admin \
       --bmc-password 'BMC_PASSWORD' --console
     No Linux credentials, prompt detection or automatic Enter key. Ctrl-] disconnects.
     You may type into the boot console or log in manually when Linux is ready.

  8. Log in, type reboot manually, and reconnect if SOL drops during reboot:
     python3 sol_exec.py --host 192.0.2.10 --bmc-user admin --os-user root \
       --interactive --reconnect-attempts 10 --reconnect-delay 3
     Reconnection opens the boot console directly, without automatic OS login.
     Reconnection is enabled by default; add --no-reconnect to disable it.

  9. Record console input, output and reconnect events:
     python3 sol_exec.py --host 192.0.2.10 --bmc-user admin \
       --console --log-dir ./logs
     Auto-name: sol_<BMC-host>_<YYYYMMDD_HHMMSS_microseconds+timezone>.jsonl.gz
     Or specify --log-file ./node-sol.jsonl. Reconnects continue in the same file.
     Logging is enabled by default for remote sessions; --no-log disables it.

  10. Replay a saved log locally at 4x speed (no BMC or passwords required):
      python3 sol_exec.py --replay ./node-sol.jsonl --replay-speed 4
      Space: pause/resume; +/-: speed; f: skip forward 10s; n: next record; q: quit.
      Add --replay-inputs to display recorded input as escaped annotations.

  11. Load saved connection settings and passwords:
      python3 sol_exec.py --config ./inventory.ini --host gpu-bj-01 --interactive --log-file
      python3 sol_exec.py --config ./inventory.ini --host 192.0.2.11 --console
      Shared INI: [all:vars], [group], [group:vars]; select one node with --host.
      A multi-node inventory requires --host; a sole node is selected automatically.
      Protect the plaintext file with chmod 600 inventory.ini.

Password precedence:
  BMC: --bmc-password > IPMI_PASSWORD environment > config bmc_password > terminal prompt (error without a terminal).
  Linux: --os-password > SOL_OS_PASSWORD environment > config os_password > terminal prompt (error without a terminal).
  With a config, --host selects an exact node name/BMC address; usernames: CLI > inventory.
  --console ignores OS credentials in the configuration file; no automatic OS login.
  For passwords starting with a hyphen, use the form --bmc-password='-example'.
  Command-line passwords may appear in shell history and process arguments.
  Default I/O logging redacts automatic OS authentication input and its response until login completes.
  Manually typed passwords and other secrets CAN appear in the log, even with remote echo off.

Behavior:
  Choose one: --command / --command-file / --upload / --interactive / --console / --replay.
  Replay is local playback, never command re-execution. It needs no ipmitool or network.
  Command output is returned on completion; serial output merges stdout/stderr and may include logs.
  Batch commands do not handle interactive prompts; use sudo -n or choose --interactive.
  Interactive mode requires a local terminal, streams output live and has no session timeout.
  Each interactive/boot console handles one BMC; use separate terminal tabs or tmux panes for multiple consoles.
  For concurrent noninteractive commands on multiple BMCs, see: python3 sol_exec.py --help-batch
  Automatic login does not handle MFA; omit --os-user for manual interactive login.
  Automatic interactive login sets remote stty to local rows/cols and TERM=xterm.
  Override with --rows N --cols N --term NAME; disable with --no-terminal-setup.
  Console/manual-login/reconnect modes do not inject terminal setup commands. Window changes are not live-synced.
  --console never powers on or reboots the host; it shows output arriving after connection.
  BIOS, bootloader and kernel each need serial redirection; earlier output is not replayed.
  Interactive/console sessions reconnect by default: at most 10 attempts, with a 3-second delay.
  Each activation also has its own --connect-timeout; retry delays are not a total time limit.
  The attempt budget is shared across the invocation and does not reset after reconnection.
  Reconnection never repeats commands or sends OS credentials; early boot output may be missed.
  Uploads suit small files. The parent directory must exist; files are not executed automatically.
  Timeouts do not retry or guarantee cancellation; disconnects may leave upload temporary directories.
  Exit closes this SOL session only; it does not evict other sessions or log out the Linux shell.

Exit codes:
  Command execution: remote Bash exit code. Successful upload or interactive disconnect: 0.
  Local timeout: 124. Connection, authentication or upload failure: 125. User interruption: 130.
  Remote commands can return these same codes; consult stderr to distinguish them.
""",
    )
    parser.add_argument('-h', '--help', action=HelpAction, nargs=0, const='brief',
                        help='Show brief help and exit')
    parser.add_argument('--help-all', action=HelpAction, nargs=0, const='all',
                        help='Show all options, examples and detailed notes, then exit')
    parser.add_argument('--help-examples', action=HelpAction, nargs=0, const='examples',
                        help='Show usage examples only, then exit')
    parser.add_argument('--help-batch', action=HelpAction, nargs=0, const='batch',
                        help='Show batch parameters and examples, then exit')
    parser.add_argument('--bash-completion', action='store_true',
                        help='Print Bash completion and a sol_exec shell function; source the output to enable')
    batching = parser.add_argument_group('Batch execution (noninteractive only; --help-batch for details)')
    add_ping_options(parser)
    add_transfer_options(parser)
    batching.add_argument('--batch', action='store_true', help='Execute on all selected inventory nodes')
    batching.add_argument('--hosts', help='Inventory names or BMC hostlist (numeric ranges supported); enables batch mode')
    batching.add_argument('--hosts-file', type=pathlib.Path, help='Node name / BMC hostlist file; enables batch mode')
    batching.add_argument('--group', action='append', help='Select inventory group; repeat to select several; enables batch mode')
    batching.add_argument('--match', help='Regex search on node name or BMC address; enables batch mode')
    batching.add_argument('--list-hosts', action='store_true', help='Preview batch selection without connecting')
    batching.add_argument('--jobs', type=int, help='Maximum concurrent hosts (batch default: 4)')
    batching.add_argument('--result-dir', type=pathlib.Path, help='New batch results directory')
    connection = parser.add_argument_group('Connection and login')
    connection.add_argument('--config', '--inventory', type=pathlib.Path, metavar='INI_FILE',
                            help='Load INI inventory (default: inventory.ini beside this script); --host selects a node\n'
                                 'CLI overrides config; password environment variables also override config')
    connection.add_argument('--host', metavar='BMC_HOST',
                            help='Required except for replay: BMC management IP or hostname')
    connection.add_argument('--node-name', help=argparse.SUPPRESS)
    terminal = parser.add_argument_group('Terminal setup after automatic interactive login')
    terminal.add_argument('--rows', type=int, help='Remote terminal rows; use with --cols (default: local window size)')
    terminal.add_argument('--cols', type=int, help='Remote terminal columns; use with --rows')
    terminal.add_argument('--term', help='Remote TERM after shell login (default: xterm)')
    terminal.add_argument('--no-terminal-setup', action='store_true', help='Disable automatic stty/TERM setup for interactive login')
    connection.add_argument('--bmc-user', metavar='USER',
                            help='Required except for replay: BMC account with SOL access; ADMINISTRATOR privilege')
    connection.add_argument('--bmc-password', metavar='PASSWORD',
                            help='BMC password; overrides IPMI_PASSWORD and INI; prompts if still missing')
    connection.add_argument('--os-user', metavar='USER',
                            help='Linux user for automatic login; omit in interactive mode for manual login')
    connection.add_argument('--os-password', metavar='PASSWORD',
                            help='Linux password; overrides SOL_OS_PASSWORD\n'
                                 'Falls back to INI; prompts if a password is still missing with --os-user')
    connection.add_argument('--cipher', type=int, default=17, metavar='ID',
                            help='IPMI cipher suite ID (default: 17); select a suite supported by the BMC')
    connection.add_argument('--ipmitool', default='ipmitool', metavar='PATH',
                            help='ipmitool executable name or path (default: ipmitool found on PATH)')
    operations = parser.add_argument_group('Operation (choose exactly one)')
    group = operations.add_mutually_exclusive_group()
    add_bmc_options(parser, group)
    group.add_argument('--replay', type=pathlib.Path, metavar='LOG_FILE',
                       help='Play a previously recorded JSONL log locally; never connects or executes commands')
    group.add_argument('--console', action='store_true',
                       help='Open the raw SOL console immediately to watch boot or log in manually\n'
                            'No automatic input or OS login; requires a terminal; Ctrl-] disconnects')
    group.add_argument('--interactive', '-i', action='store_true',
                       help='Open a live console; Ctrl-] disconnects, Ctrl-C goes to the remote host\n'
                            'Auto-login with --os-user; otherwise hand over immediately after SOL connects')
    group.add_argument('--command', '-c', metavar='COMMAND',
                       help='Run a noninteractive Bash command; single-quote it to avoid local expansion')
    group.add_argument('--command-file', type=pathlib.Path, metavar='LOCAL_SCRIPT',
                       help='Execute a local UTF-8 script remotely without saving it as a remote file')
    group.add_argument('--upload', type=pathlib.Path, metavar='LOCAL_FILE',
                       help='Upload a local file, including binary or empty files; requires --remote-path')
    transfer = parser.add_argument_group('Upload options (require --upload)')
    transfer.add_argument('--remote-path', metavar='REMOTE_FILE',
                          help='Absolute remote filename, e.g. /tmp/check.sh; parent must exist and be writable')
    transfer.add_argument('--overwrite', action='store_true',
                          help='Replace an existing destination file (default: refuse); cannot replace directories')
    transfer.add_argument('--mode', default='600', metavar='OCTAL',
                          help='Three-digit octal permissions (default: 600); use 755 for executable scripts')
    runtime = parser.add_argument_group('Output and timeouts')
    compression = runtime.add_mutually_exclusive_group()
    compression.add_argument('--log-compress', action='store_true', default=None,
                         help='Compress SOL logs with gzip (default); auto names end in .jsonl.gz\n'
                              'Explicit --log-file gains .gz if needed; replay accepts gzip directly')
    compression.add_argument('--no-log-compress', action='store_false', dest='log_compress',
                             help='Write uncompressed JSONL logs; use a filename without .gz')
    playback = parser.add_argument_group('Local replay options')
    playback.add_argument('--replay-export', action='store_true',
                          help='Export only recorded OUT to stdout immediately; accepts JSONL/gzip\n'
                               'Strip ANSI/control codes and normalize line endings for grep; no playback UI')
    playback.add_argument('--replay-speed', type=float, default=1, metavar='FACTOR',
                          help='Initial playback speed, 0.125 to 64 (default: 1); 4 means four times faster')
    playback.add_argument('--replay-inputs', action='store_true',
                          help='Show recorded IN data as escaped annotations (default: output and events only)')
    logging = runtime.add_mutually_exclusive_group()
    logging.add_argument('--log-file', type=pathlib.Path, nargs='?', const=True, metavar='LOCAL_FILE',
                         help='Record SOL IN/OUT and events as timestamped JSON Lines in all modes\n'
                              'Remote sessions log by default; omit filename for BMC + timestamp naming\n'
                              'New file only, permissions 600; reconnects share it; manual input is logged')
    logging.add_argument('--no-log', action='store_true',
                         help='Disable default SOL I/O logging; replay never creates logs')
    runtime.add_argument('--log-dir', type=pathlib.Path, default=pathlib.Path('logs'), metavar='DIRECTORY',
                         help='Directory for auto-named logs (default: ./logs); created if needed\n'
                              'Applies to default logging or --log-file without a filename')
    runtime.add_argument('--output', type=pathlib.Path, metavar='LOCAL_FILE',
                         help='Save merged command output locally; file must not exist; not for uploads')
    runtime.add_argument('--timeout', type=float, default=300, metavar='SECONDS',
                         help='Remote command completion timeout (default: 300 seconds)\n'
                              'Uploads: per processing command, not whole transfer; ignored during interaction')
    runtime.add_argument('--connect-timeout', type=float, default=60, metavar='SECONDS',
                         help='Wait for SOL activation, login or each chunk acknowledgement (default: 60 seconds)')
    reconnect = runtime.add_mutually_exclusive_group()
    reconnect.add_argument('--reconnect', action='store_true', default=None,
                           help='Enable reconnection (default for --interactive/--console)\n'
                                'Reopens the raw console without OS login; Ctrl-] exits normally')
    reconnect.add_argument('--no-reconnect', action='store_false', dest='reconnect',
                           help='Disable automatic reconnection for interactive/console sessions')
    runtime.add_argument('--reconnect-attempts', type=int, default=10, metavar='N',
                         help='Maximum reconnect attempts across this invocation (default: 10)')
    runtime.add_argument('--reconnect-delay', type=float, default=3, metavar='SECONDS',
                         help='Delay before each reconnect attempt (default: 3 seconds)')
    runtime.add_argument('--prompt', default=r'(?m)^[^\n]*[#$] ?$', metavar='REGEX',
                         help='Python regular expression for the Linux shell prompt\n'
                              'Default: a line ending in # or $, optionally followed by one space')
    if len(sys.argv) == 1:
        print_brief_help(parser)
        return 0
    args = parser.parse_args()
    if args.bash_completion:
        print(bash_completion(parser), end='')
        return 0
    try:
        bmc_command(args)
    except ValueError as exc:
        parser.error(str(exc))
    if (args.batch or args.list_hosts or args.check_hosts or any(value is not None for value in
            (args.hosts, args.hosts_file, args.group, args.match, args.jobs, args.result_dir))):
        if args.interactive or args.console or args.replay:
            parser.error('Batch mode supports commands, uploads and IPMI power/SEL; interactive and boot consoles require one --host in a separate terminal')
        return run_batch()
    if bmc_operation(args):
        try:
            return run_bmc_single(args)
        except (OSError, ValueError) as exc:
            parser.error(str(exc))
    if not any((args.command is not None, args.command_file, args.upload, args.interactive, args.console, args.replay)):
        parser.error('Choose an operation, or use --list-hosts to preview inventory nodes')
    if not math.isfinite(args.replay_speed) or not .125 <= args.replay_speed <= 64:
        parser.error('--replay-speed must be between 0.125 and 64')
    if args.replay:
        if args.transfer != 'base64' or args.zmodem_sender or args.no_resume:
            parser.error('Upload transfer options cannot be used with --replay')
        if args.rows is not None or args.cols is not None or args.term is not None or args.no_terminal_setup:
            parser.error('Terminal setup options are not used with --replay')
        if args.skip_ping or args.ping_jobs != 32 or args.ping_timeout != 2 or args.ping_attempts != 3 or args.ping_interval != 0.5:
            parser.error('Ping options are not used with --replay')
        if args.replay_export and (args.replay_inputs or args.replay_speed != 1):
            parser.error('--replay-export cannot be combined with --replay-inputs or --replay-speed')
        if args.log_compress is not None:
            parser.error('Compression options control recording, not replay; pass the file to --replay')
        if any(value is not None for value in (args.config, args.host, args.bmc_user, args.bmc_password,
                                               args.os_user, args.os_password, args.log_file,
                                               args.output, args.remote_path, args.reconnect)) or args.overwrite or args.mode != '600' or args.log_dir != pathlib.Path('logs'):
            parser.error('--replay cannot be combined with credentials, logging, upload or reconnect options')
        try:
            return replay(args)
        except (OSError, ValueError) as exc:
            print(f'ERROR: {exc}', file=sys.stderr)
            return 125
        except KeyboardInterrupt:
            print('\nReplay interrupted.', file=sys.stderr)
            return 130
    if args.replay_export or args.replay_inputs or args.replay_speed != 1:
        parser.error('--replay-export, --replay-speed and --replay-inputs require --replay')
    args.config = find_config(args.config, needed=(args.host is None or
        missing_cli_credentials(args, os_required=not args.console)))
    config = {}
    if args.config:
        try:
            config = load_config(args.config, args.host)
            args.host = config['host']
            args.node_name = config['name']
        except (OSError, ValueError) as exc:
            parser.error(f'Cannot load configuration: {exc}')
        for field in ('host', 'bmc_user', 'os_user'):
            if field == 'os_user' and args.console:
                continue
            if getattr(args, field) is None:
                setattr(args, field, config.get(field))
    if not args.host:
        parser.error('Specify --host or provide a single-node inventory')
    try:
        if args.bmc_user is None:
            args.bmc_user = prompt_credential('bmc_user', args.host)
    except ValueError as exc:
        parser.error(str(exc))
    bmc_password = args.bmc_password if args.bmc_password is not None else os.environ.get('IPMI_PASSWORD')
    if bmc_password is None:
        bmc_password = config.get('bmc_password')
    if bmc_password is None:
        try:
            bmc_password = prompt_credential('bmc_password', args.host)
        except ValueError as exc:
            parser.error(str(exc))
    os_password = None if args.console else (
        args.os_password if args.os_password is not None else os.environ.get('SOL_OS_PASSWORD'))
    if not args.console and os_password is None:
        os_password = config.get('os_password')
    if args.os_user and os_password is None:
        try:
            os_password = prompt_credential('os_password', args.host)
        except ValueError as exc:
            parser.error(str(exc))
    if any('\n' in v or '\r' in v for v in [args.os_user or '', os_password or '']):
        parser.error('console credentials cannot contain newlines')
    if not args.host or not args.bmc_user:
        parser.error('host and bmc_user are required via CLI or --config, except with --replay')
    if args.no_log and args.log_compress:
        parser.error('--log-compress cannot be combined with --no-log')
    if args.log_compress is None:
        args.log_compress = not args.no_log
    if args.log_compress is False and isinstance(args.log_file, pathlib.Path) and args.log_file.suffix.lower() == '.gz':
        parser.error('--no-log-compress requires a log filename without .gz')
    if not args.no_log and args.log_file is None:
        args.log_file = True
    args.auto_log = args.log_file is True
    if args.log_dir != pathlib.Path('logs') and not args.auto_log:
        parser.error('--log-dir requires automatic log naming; omit --no-log and explicit --log-file paths')
    if args.auto_log:
        args.log_file = automatic_log_path(args.host, args.log_dir, args.log_compress, args.node_name)
    elif args.log_compress and args.log_file and args.log_file.suffix.lower() != '.gz':
        args.log_file = pathlib.Path(str(args.log_file) + '.gz')
    if args.reconnect is not None and not (args.interactive or args.console):
        parser.error('--reconnect/--no-reconnect requires --interactive or --console')
    if args.reconnect is None:
        args.reconnect = bool(args.interactive or args.console)
    if args.reconnect_attempts < 1 or not 0 <= args.reconnect_delay <= 60:
        parser.error('reconnect attempts must be positive and delay must be between 0 and 60 seconds')
    if args.console and (args.os_user is not None or args.os_password is not None):
        parser.error('--console does not use OS credentials; omit --os-user and --os-password')
    if args.interactive or args.console:
        if not sys.stdin.isatty() or not sys.stdout.isatty():
            parser.error('--interactive/--console requires a terminal on stdin and stdout')
        if args.output:
            parser.error('--output is not supported with --interactive or --console')
    terminal_options = args.rows is not None or args.cols is not None or args.term is not None
    if (terminal_options or args.no_terminal_setup) and not args.interactive:
        parser.error('Terminal setup options require --interactive with automatic Linux login')
    if terminal_options and (not args.os_user or args.no_terminal_setup):
        parser.error('--rows/--cols/--term require automatic login and cannot be combined with --no-terminal-setup')
    if (args.rows is None) != (args.cols is None):
        parser.error('--rows and --cols must be supplied together')
    if args.rows is not None and not (1 <= args.rows <= 65535 and 1 <= args.cols <= 65535):
        parser.error('--rows and --cols must be between 1 and 65535')
    if args.term is not None and not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.+-]*', args.term):
        parser.error('Invalid --term value')
    if not shutil.which(args.ipmitool):
        parser.error('ipmitool is not installed or not on PATH')
    try:
        validate_ping_options(args)
    except ValueError as exc:
        parser.error(str(exc))
    if not args.skip_ping:
        reachable, error = ping_host(args.host, args.ping_timeout, args.ping_attempts, args.ping_interval)
        if not reachable:
            print(f'ERROR: {args.host}: {error}', file=sys.stderr)
            return 125
    if args.timeout <= 0 or args.connect_timeout <= 0:
        parser.error('timeouts must be positive')
    re.compile(args.prompt)
    if args.command_file:
        args.command = args.command_file.read_text(encoding='utf-8')
    try:
        validate_transfer_options(args)
    except ValueError as exc:
        parser.error(str(exc))
    if args.upload:
        if not args.upload.is_file():
            parser.error('--upload must be a readable regular file')
        if not args.remote_path or not args.remote_path.startswith('/') or args.remote_path.endswith('/'):
            parser.error('--remote-path must be an absolute destination filename')
        if any(c in args.remote_path for c in '\x00\r\n') or pathlib.PurePosixPath(args.remote_path).name in ('.', '..'):
            parser.error('invalid remote path')
        if not re.fullmatch(r'[0-7]{3}', args.mode):
            parser.error('--mode must be three octal digits, for example 600 or 755')
        if args.output:
            parser.error('--output is for command execution only')
    elif args.remote_path or args.overwrite or args.mode != '600':
        parser.error('--remote-path, --overwrite and --mode require --upload')
    if not (args.upload or args.interactive or args.console) and (not args.command or '\x00' in args.command):
        parser.error('command must be nonempty and contain no NUL')
    if args.output and args.output.exists():
        parser.error('--output already exists')
    if args.log_file and args.log_file.exists():
        parser.error('--log-file already exists; choose a new path')
    if args.log_file and args.output and args.log_file.resolve() == args.output.resolve():
        parser.error('--log-file and --output must use different paths')
    args.session_log = None
    def terminate_session(signum, frame):
        raise KeyboardInterrupt
    previous_sigterm = signal.signal(signal.SIGTERM, terminate_session)
    try:
        if args.log_file:
            if args.auto_log:
                args.log_file.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            args.session_log = SessionLog(args.log_file, host=args.host, name=args.node_name or args.host)
            args.session_log.record('EVENT', 'Logging started')
            print(f'SOL I/O log: {args.log_file.resolve()} (manual input, including passwords, is recorded).',
                  file=sys.stderr, flush=True)
        return run_with_reconnect(args, bmc_password, os_password)
    except TimeoutError as exc:
        print(f'ERROR: {exc}. Remote command may still be running; not retried.', file=sys.stderr)
        return 124
    except (RuntimeError, OSError) as exc:
        print(f'ERROR: {exc}', file=sys.stderr)
        return 125
    except KeyboardInterrupt:
        print('Interrupted; remote command may still be running.', file=sys.stderr)
        return 130
    finally:
        signal.signal(signal.SIGTERM, previous_sigterm)
        if args.session_log:
            args.session_log.close()


def main():
    try:
        return _main()
    except KeyboardInterrupt:
        print('\nInterrupted.', file=sys.stderr)
        return 130


if __name__ == '__main__':
    sys.exit(main())
