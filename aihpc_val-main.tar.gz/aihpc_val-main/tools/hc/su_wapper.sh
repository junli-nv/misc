#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>

#ifndef REALBIN
#define REALBIN "/home/cmsupport/workspace/aihpc_val/tools/hc/sysinfo.sh"
#endif

int main(int argc, char *argv[])
{
  uid_t uid, euid;
  uid = getuid();
  euid = geteuid();
  if (0 != setreuid(euid, uid)) {
    return 1;
  }
  return execv(REALBIN, argv);
}