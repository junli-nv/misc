#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

export PATH=/usr/bin:/bin:/usr/sbin:/sbin

clear(){
  #hcas=($(lspci -D -d 15b3:|grep -e 'Infiniband controller:' -e 'Ethernet controller:'|awk '{print $1}'|while read i; do ret=$(basename $(ls -l /sys/class/infiniband|grep -o ${i}.*) 2>/dev/null); [ ! -z "$ret" ] && echo $ret; done))
  hcas=($(ls -l /sys/class/infiniband|grep -v $((lspci -D | grep -i Infiniband.*ConnectX-7|awk '{print $1}'|cut -d '.' -f 1|sort|uniq -c|grep -w 4||echo NONE)|awk '{print $NF}'|xargs -I {} echo "-e {}.")|grep infiniband|awk -F'/' '{print $NF}'))
  pids=()
  for dev in "${hcas[@]}"; do
    mlxlink -d $dev -p 1 -pc &>/dev/null & pids+=($!)
  done
  wait "${pids[@]}"
}

query(){
  #hcas=($(lspci -D -d 15b3:|grep -e 'Infiniband controller:' -e 'Ethernet controller:'|awk '{print $1}'|while read i; do ret=$(basename $(ls -l /sys/class/infiniband|grep -o ${i}.*) 2>/dev/null); [ ! -z "$ret" ] && echo $ret; done))
  hcas=($(ls -l /sys/class/infiniband|grep -v $((lspci -D | grep -i Infiniband.*ConnectX-7|awk '{print $1}'|cut -d '.' -f 1|sort|uniq -c|grep -w 4||echo NONE)|awk '{print $NF}'|xargs -I {} echo "-e {}.")|grep infiniband|awk -F'/' '{print $NF}'))

  pids=()
  for dev in "${hcas[@]}"; do
    (
    rets=($(mlxlink -d ${dev} -c|grep -e 'Effective Physical Errors ' -e 'Link Down Counter ' | sort | awk '{print $NF}'))
    effective_physical_errors=${rets[0]}
    link_downed=${rets[1]}
    phys_state=$(cat /sys/class/infiniband/${dev}/ports/1/phys_state|tr -d ' ')
    stat=$(cat /sys/class/infiniband/${dev}/ports/1/state|tr -d ' ')
    echo ${dev}:phys_state=${phys_state},stat=${stat},link_downed=${link_downed},effective_physical_errors=${effective_physical_errors}
    ) & pids+=($!)
  done
  wait "${pids[@]}"
}

ber(){
  echo NODE,NIC,Recommendation,Time Since Last Clear,Symbol BER,Effective Physical BER,Raw Physical BER,Link Down Counter
  pids=()
  for dev in $(ls -l /sys/class/infiniband|grep -v $((lspci -D | grep -i Infiniband|awk '{print $1}'|cut -d '.' -f 1|sort|uniq -c|grep -w 4||  echo NONE)|awk '{print $NF}'|xargs -I {} echo "-e {}.")|grep infiniband|awk -F'/' '{print $NF}'|grep -v bond|sort -t'_' -k2n); do
    (
    echo $(hostname),$dev,$(mlxlink -d "$dev" -c| grep -E "Recommendation|(Time Since Last Clear|Symbol BER|Effective Physical BER|Raw   Physical BER[^a-z]*:|Link Down Counter)"|awk -F':' '{print $NF}'|sed -e 's:^ ::g' -e 's: $::g' |paste -s -d ',' -)
    ) & pids+=($!)
  done | sort
  wait "${pids[@]}"
}

action=$1
[ -z $action ] && action="query"
case ${action} in
"clear") 
  clear
  ;;
"query")
  query
  ;;
"ber")
  ber
  ;;
*)
  query
  ;;
esac