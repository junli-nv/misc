#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

export PATH=/usr/bin:/bin:/usr/sbin:/sbin
mst start &>/dev/null

clear(){
  #hcas=($(lspci -D -d 15b3:|grep -e 'Infiniband controller:' -e 'Ethernet controller:'|awk '{print $1}'|while read i; do ret=$(basename $(ls -l /sys/class/infiniband|grep -o ${i}.*) 2>/dev/null); [ ! -z "$ret" ] && echo $ret; done))
  hcas=($(ls -l /sys/class/infiniband|grep -v $((lspci -D | grep -i Infiniband.*ConnectX-7|awk '{print $1}'|cut -d '.' -f 1|sort|uniq -c|grep -w 4||echo NONE)|awk '{print $NF}'|xargs -I {} echo "-e {}.")|grep infiniband|awk -F'/' '{print $NF}'))
  pids=()
  for dev in "${hcas[@]}"; do
    mlxlink -d $dev -p 1 -pc &>/dev/null & pids+=($!)
  done
  wait "${pids[@]}"
}

query(){
  #hcas=($(lspci -D -d 15b3:|grep -e 'Infiniband controller:' -e 'Ethernet controller:'|awk '{print $1}'|while read i; do ret=$(basename $(ls -l /sys/class/infiniband|grep -o ${i}.*) 2>/dev/null); [ ! -z "$ret" ] && echo $ret; done))
  hcas=($(ls -l /sys/class/infiniband|grep -v $((lspci -D | grep -i Infiniband.*ConnectX-7|awk '{print $1}'|cut -d '.' -f 1|sort|uniq -c|grep -w 4||echo NONE)|awk '{print $NF}'|xargs -I {} echo "-e {}.")|grep infiniband|awk -F'/' '{print $NF}'))

  pids=()
  for dev in "${hcas[@]}"; do
    (
    rets=($(mlxlink -d ${dev} -c|grep -e 'Effective Physical Errors ' -e 'Link Down Counter ' | sort | awk '{print $NF}'))
    effective_physical_errors=${rets[0]}
    link_downed=${rets[1]}
    phys_state=$(cat /sys/class/infiniband/${dev}/ports/1/phys_state|tr -d ' ')
    stat=$(cat /sys/class/infiniband/${dev}/ports/1/state|tr -d ' ')
    echo ${dev}:phys_state=${phys_state},stat=${stat},link_downed=${link_downed},effective_physical_errors=${effective_physical_errors}
    ) & pids+=($!)
  done
  wait "${pids[@]}"
}

ber(){
  echo NODE,NIC,Recommendation,Time Since Last Clear,Symbol BER,Effective Physical BER,Raw Physical BER,Link Down Counter
  pids=()
  for dev in $(ls -l /sys/class/infiniband|grep -v $((lspci -D | grep -i Infiniband|awk '{print $1}'|cut -d '.' -f 1|sort|uniq -c|grep -w 4||  echo NONE)|awk '{print $NF}'|xargs -I {} echo "-e {}.")|grep infiniband|awk -F'/' '{print $NF}'|grep -v bond|sort -t'_' -k2n); do
    (
    echo $(hostname),$dev,$(mlxlink -d "$dev" -c| grep -E "Recommendation|(Time Since Last Clear|Symbol BER|Effective Physical BER|Raw   Physical BER[^a-z]*:|Link Down Counter)"|awk -F':' '{print $NF}'|sed -e 's:^ ::g' -e 's: $::g' |paste -s -d ',' -)
    ) & pids+=($!)
  done | sort
  wait "${pids[@]}"
}

cg(){
  for i in $(lspci -D | grep -i Infini.*ConnectX-8 | while read i _; do ls -l /sys/class/infiniband|grep -o ${i}/.*|cut -d'/' -f3; done); do
    a=$(</sys/class/infiniband/${i}/ports/1/counters/port_xmit_wait)
    b=$(</sys/class/infiniband/${i}/ports/1/counters/port_xmit_packets)
    c=$(awk -v a=$a -v b=$b 'BEGIN{if(a==0||b==0){print 0}else{printf("%.2f",a/b)}}')
    d=$(awk -v c=$c 'BEGIN{if(10>c){print "PASSED"}else{printf("FAILED")}}')
    echo "${i##.*/} Status=$d Congestion_Index=$c port_xmit_wait:$a port_xmit_packets:$b "
  done
}

clear_spx_hwmp(){
  mst start &>/dev/null
  hcas=($(lspci | grep -i '^[0-9].*\.0.*ConnectX-8'|awk '{print $1}'|while read i; do ls -l /sys/class/infiniband|grep -o ${i}/.*|cut -f3 -d'/'; done))
  for i in ${hcas[*]}; do 
    mlxlink -d $i -pc &>/dev/null
  done
}

query_spx_hwmp(){
  mst start &>/dev/null
  hcas=($(lspci | grep -i '^[0-9].*\.0.*ConnectX-8'|awk '{print $1}'|while read i; do ls -l /sys/class/infiniband|grep -o ${i}/.*|cut -f3 -d'/'; done))
  for i in ${hcas[*]}; do 
    ret=$(mlxlink -d $i -m -c|grep 'Link Down Counter'|awk '{print $NF}')
    [ "X$ret" == "XN/A" ] && ret=999999
    [ $ret -ne 0 ] && echo "${i}:$ret"
  done | paste -s -d, - | xargs -I {} echo "LINKDOWN: {}"
}

action=$1
[ -z $action ] && action="query"
case ${action} in
"clear")
  clear
  ;;
"query")
  query
  ;;
"ber")
  ber
  ;;
"cg")
  cg
  ;;
"clear_spx_hwmp")
  clear_spx_hwmp
  ;;
"query_spx_hwmp")
  query_spx_hwmp
  ;;
*)
  query
  ;;
esac
