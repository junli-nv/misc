#!/bin/bash

[ "${-#*x}" != "$-" ] && export debug=1 || export debug=0

main(){
  [ $debug -eq 1 ] && set -x || set +x
  channel=1
  id=8
  user=nvis
  password='HelloNvidia3D!'
  ipmitool -I open user list ${channel}
  ipmitool -I open user set name ${id} ${user}
  ipmitool -I open user set password ${id} ${password}
  ipmitool -I open user enable ${id}
  #ipmitool -I open channel getaccess ${channel} ${id}
  ipmitool -I open channel setaccess ${channel} ${id} callin=on ipmi=on link=on privilege=4
  ipmitool -I open sol payload enable ${channel} ${id}
  ipmitool -I open sol set enabled true ${channel}
  #ipmitool -I open sol info ${channel}
  ipmitool -I open user list ${channel}
}

main 2>&1 | xargs -I {} echo "$(hostname): {}"
