#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

nics=($(lspci -D | grep -i Ethernet.*BlueField-3|awk '{print $1}'|xargs -I {} bash -c 'ls -l /sys/class/net|grep -o {}/.*|cut -f3 -d"/"'; lspci -D | grep -i Ethernet.*Mellanox|grep -v BlueField-3|awk '{print $1}'|xargs -I {} bash -c 'ls -l /sys/class/net|grep -o {}/.*|cut -f3 -d"/"'; lspci -D | grep -i Ethernet|grep -v Mellanox|awk '{print $1}'|xargs -I {} bash -c 'ls -l /sys/class/net|grep -o {}/.*|cut -f3 -d"/"'; ))

tmpf=$(mktemp)
efibootmgr > "$tmpf"

target_boots=($(
for i in "${nics[@]}"; do
  if [ -e /sys/class/net/${i}/bonding_slave/perm_hwaddr ]; then
    hwaddr=$(cat /sys/class/net/${i}/bonding_slave/perm_hwaddr)
  else
    hwaddr=$(cat /sys/class/net/${i}/address)
  fi
  ( grep -i -w ${hwaddr} $tmpf || grep -i -w $(echo $hwaddr|tr -d ':') $tmpf ) | awk '{print $1}'|sed -e 's:\*::g' -e 's:Boot::g'
done
))

echo "[INFO] Current Boot Order:"
grep BootOrder $tmpf
OLD_BOOT_ORDER=$(grep BootOrder $tmpf|awk '{print $NF}'|tr ',' '\n')
for i in $OLD_BOOT_ORDER; do
  grep -i -w "Boot${i}" "$tmpf"
done

echo "[INFO] Apply New Boot Order:"
declare -A target_set
for boot in "${target_boots[@]}"; do
  target_set["$boot"]=1
done
pad_boot=""
for boot in $OLD_BOOT_ORDER; do
  if [[ ! -v 'target_set[$boot]' ]]; then
    pad_boot+="${pad_boot:+ }$boot"
  fi
done
NEW_BOOT_ORDER=$(echo ${target_boots[@]} $pad_boot)
efibootmgr --bootorder $(echo ${NEW_BOOT_ORDER[@]}|tr ' ' ',') &>/dev/null

echo "[INFO] New Boot Order:"
efibootmgr &> $tmpf
grep BootOrder $tmpf
for i in $NEW_BOOT_ORDER; do
  grep -i -w "Boot${i}" "$tmpf"
done

rm -f "$tmpf"
