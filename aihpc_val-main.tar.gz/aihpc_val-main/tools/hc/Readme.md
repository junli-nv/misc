# HC - Hardware/System Health Check and Node Management Toolkit

A collection of diagnostic, health checking, and management scripts for NVIDIA AIC cluster nodes. These tools validate and monitor GPUs, NVLinks, InfiniBand adapters, CPUs, memory, and BMC/IPMI subsystems across multi-node clusters.

## Scripts

### Health Checks

| Script | Description |
|--------|-------------|
| `checker.sh` | Primary node health checker for GB200 systems. Validates CPU cores, memory, GPU status, ECC errors, NVLink connectivity, IMEX daemon, IB HCA ports, and dmesg errors. Can automatically drain/undrain SLURM nodes based on results. |
| `checker-B300.sh` | Health checker variant tuned for B300 systems (344 cores, 4096GB memory, 8 GPUs, 8 IB HCAs with ConnectX-8). |
| `sysinfo.sh` | Multi-node cluster information gathering via `pdsh`. Collects BIOS, OS, kernel parameters, CPU frequency, GPU status, NVLink, IB link status, PCIe configuration, IMEX, and dmesg errors across a node list. |

### GPU Management

| Script | Description |
|--------|-------------|
| `gpufreq.sh` | Query, reset, or maximize GPU clock frequencies and power limits. Actions: `query`, `reset`, `max`. |
| `gpureset.sh` | Full GPU driver reset cycle: kills GPU processes, stops NVIDIA services (persistenced, dcgm, imex, fabricmanager), unloads kernel modules, and restarts everything. |

### InfiniBand / Network

| Script | Description |
|--------|-------------|
| `ibcounter.sh` | Query, clear, or report BER (Bit Error Rate) for IB device counters including link_downed and symbol_error. |
| `iblinkreset.sh` | Attempt to recover inactive IB links to ACTIVE state via `mlxlink` reset. |
| `ibtemp.sh` | Display temperatures for all IB HCA devices. |
| `bf3mode.sh` | Check and configure BlueField-3 DPU INTERNAL_CPU_OFFLOAD_ENGINE mode. Requires power cycle to take effect. |

### RoCE / SPX Network Monitoring

| Script | Description |
|--------|-------------|
| `spxmon.sh` | Monitor RoCE pause frames (rx/tx prio3_pause, discards), adaptive routing retransmissions, and CNP counters. |
| `spxlinkcheck.sh` | Validate SPX switch health by checking LLDP neighbor configurations, host-to-switch connectivity, and routing policies. |

### Utilities

| Script | Description |
|--------|-------------|
| `collect-pcie-error.sh` | Collect PCIe AER (Advanced Error Reporting) errors. |
| [`pcal`](pcal) | Self-contained job-scale interruption and recovery calculator. Use `-h` for usage, `-S` for sources, `-D` for model/calibration, and `-l zh` for Chinese. |

### Documentation

| File | Description |
|------|-------------|
| `cx8-smi.md` | Example of enabling RDMA SMI device on ConnectX-8 NICs. |

## checker.sh Usage
The check.sh script requires certain targets to be pre-configured. If the output does not match these targets, the script will issue a warning—or even drain the node.

```
./checker.sh [OPTIONS]
```

Must be run as root on the target node. Options take `1` (enable) or `0` (disable) as values.

| Option | Short | Default | Description |
|--------|-------|---------|-------------|
| `--dry-run` | `-d` | off | Report only, do not drain/undrain SLURM nodes |
| `--extra-check <0\|1>` | `-e` | 1 | Check dmesg for potential issues (NV_ERR, Hardware Error, Xid, etc.) |
| `--check-sys <0\|1>` | `-s` | 1 | Check CPU cores/frequency, memory, NFS mounts, enroot disk |
| `--check-gpu <0\|1>` | `-g` | 1 | Check GPU count, ECC errors, NVLink, CUDA test |
| `--check-imex <0\|1>` | `-i` | 0 | Check IMEX channels, config, and daemon status |
| `--check-ib <0\|1>` | `-b` | 1 | Check IB HCA count, port status, link counters, PCIe width/MRRS |
| `--check-spx <0\|1>` | `-x` | 0 | Check SPX RoCE retransmissions and link errors |
| `--check-process <0\|1>` | `-p` | 0 | Check for stale GPU processes |

### Examples

```bash
# Run all default checks (sys + gpu + ib + dmesg) in dry-run mode (no SLURM drain)
./checker.sh -d

# Run all default checks and auto-drain the node in SLURM if any error is found
./checker.sh -d -e 1

# Don't drain nodes if error met and excluding IB check
./checker.sh -d -e 1 -b 0
```

When errors are found, the script prints `INFO: Health check FAILED` and (unless `-d`) drains the node in SLURM with the failure reason. A passing node prints `INFO: Health check PASSED` and is automatically undrained if it was previously drained.

This tools usually be used with pdsh, like:
```
pdsh -f 100 -R ssh -w $NODELIST <<- EOF
$DIR_TO_CHECKER/checker.sh -d -e 1 | grep -v PASS || true
EOF
```

## sysinfo.sh Usage
The sysinfo.sh script can be either integrated into workload scripts or executed independently. It is designed to automatically capture key factors that may impact the successful execution of a workload, as well as to highlight differences among the involved nodes; consequently, it requires no prior configuration of specific targets.

```
./sysinfo.sh <NODELIST>
```

Must be run as root. Requires passwordless SSH to all target nodes. The `<NODELIST>` argument accepts SLURM-style hostlist expressions, or falls back to `$SLURM_JOB_NODELIST` if not provided.

Runs all checks in sequence across the node list via `pdsh` and groups identical outputs with `dshbak -c`.

### Checks Performed

| Category | What it checks |
|----------|---------------|
| BIOS | BIOS vendor, version, release date |
| OS | Kernel version, installer node detection |
| Kernel params | Boot command line parameters |
| CPU | Architecture, core count, frequency, governor mode (performance >1800MHz) |
| Memory | DIMM sizes per socket, NUMA balancing, THP settings, NUMA topology |
| GPU | Bus ID, name, VBIOS, pstate, power limit, ECC errors, remapped rows |
| NVLink | Link count and speed (72 links expected), fabric state, BER |
| P2P | NVLink and PCIe peer-to-peer capability |
| CUUID | Cluster UUID and Clique ID (same rack = same CUUID on GB200) |
| IB link | Port state, link down recommendations via mlxlink |
| IB counters | link_downed and symbol_error per port |
| IB PKEY | Partition key consistency across nodes |
| IB FW | Firmware version consistency |
| PCIe | LnkCap vs LnkSta mismatch, ACS config, MRRS (expect 4096) |
| Network | Default gateway interface, bond interface status |
| IMEX | Channel devices, config, nodes_config.cfg, service status, readiness, connection status |
| Enroot | Runtime directory writability |
| dmesg | NV_ERR, Call trace, Hardware Error, Xid, knvlinkDiscoverPostRxDetLinks, ipmi_ssif, mlx5_core health |

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `DEBUG` | `0` | Set to `1` to check SSH connectivity before running checks |
| `FANOUT` | `100` | Max parallel pdsh connections |
| `SSH_SSO` | `0` | Set to `1` to enable SSH connection multiplexing (ControlMaster) |
| `PDSH_CONNECT_TIMEOUT` | `10` | SSH connect timeout in seconds (when SSH_SSO=1) |
| `PDSH_COMMAND_TIMEOUT` | `120` | Command timeout in seconds (when SSH_SSO=1) |

### Examples

```bash
# Run independently, out of workload script
./sysinfo.sh node[01-02],node04,node06

# Integrated into workload script
timeout 300 ./sysinfo.sh 2>&1 
```

## Dependencies

- **NVIDIA tools**: `nvidia-smi`, `nvidia-persistenced`, `nvidia-dcgm`, `nvidia-fabricmanager`
- **Mellanox tools**: `ibstatus`, `mlxlink`, `mlxconfig`, `mst`
- **Cluster tools**: `pdsh`, `dshbak`, SLURM (`scontrol`)
- **Remote management**: `ipmitool`, Redfish API
- **Python**: `python3-hostlist` (included in `nodetools/`) for host range expansion

## Supported Hardware

- **GPUs**: NVIDIA L20, H20, RTX6000D, RTX6000, B200, B300, GB200, GB300
- **Interconnects**: NVLink or PCI-E
- **NICs**: ConnectX-7, ConnectX-8
- **DPUs**: BlueField-3
- **Architectures**: x86_64, aarch64 (ARM)

***The tools are written by Junli Zhang <junliz@nvidia.com> and this document maintained by Tina Wang <tinawang@nvidia.com>.***
