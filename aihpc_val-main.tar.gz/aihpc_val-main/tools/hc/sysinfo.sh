#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

[ $(id -u) -ne 0 ] && echo "ERROR: Please run as root" && exit 1
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/cm/local/apps/slurm/current/bin
export topdir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# source /etc/profile && module load slurm

#export PDSH_SSH_ARGS_APPEND="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=quiet -o CheckHostIP=no -o PreferredAuthentications=publickey"
export PDSH_SSH_ARGS_APPEND="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=quiet -o CheckHostIP=no"
export PDSH_RCMD_TYPE=ssh
export FANOUT=100
grep 'next unless "$tag" ne ""' /usr/bin/dshbak >/dev/null && sed -i.ori -e 's#next unless "$tag" ne "";#next unless defined $tag and "$tag" ne "";#g' /usr/bin/dshbak

NODELIST=$1
if [ -z ${NODELIST} ]; then
  NODELIST=${SLURM_JOB_NODELIST}
fi

hosts=($(scontrol show hostname $NODELIST))
[ ${#hosts[@]} -eq 0 ] && echo "ERROR: No hosts found from NODELIST: $NODELIST" && exit 1

echo -e "\n########INFO: Check BIOS"
pdsh -f 100 -R ssh -w $(echo ${hosts[*]}|tr ' ' ',') <<- 'EOF' | dshbak -c
grep -r . /sys/class/dmi/id/{bios_version,bios_release,bios_date}|cut -d'/' -f6-|sort|paste -s -d','
EOF

echo -e "\n########INFO: Check OS"
pdsh -t 5 -u 5 -f 100 -R ssh -w $(echo ${hosts[*]}|tr ' ' ',') <<< "uname -r; df -Th|grep /cm/node-installer &>/dev/null || echo 'OS is READY'" 2>/dev/null | dshbak -c 

echo -e "\n########INFO: Check Kernel Parm"
pdsh -f 100 -R ssh -w $(echo ${hosts[*]}|tr ' ' ',') <<- 'EOF' | dshbak -c
uname -r
cat /proc/cmdline | tr ' ' '\n'|grep -v -E 'ip=|BOOT' | sort | paste -s -d ' '
EOF

echo -e "\n########INFO: Check CPU"
pdsh -f 100 -R ssh -w $(echo ${hosts[*]}|tr ' ' ',') <<- 'EOF' | dshbak -c
lscpu|awk '/Architecture:/,/L3 cache:/{print $0}'|grep -E -v 'GHz|MHz|BogoMIPS|Flags:|cache:'
cat /sys/devices/system/cpu/cpufreq/policy*/scaling_governor|sort|uniq -c
m=; if [ -f /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_cur_freq ]; then m=cpuinfo_cur_freq; else [ -f /sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq ] && m=scaling_cur_freq; fi; [ ! -z ${m} ] && for i in $(ls -1 /sys/devices/system/node|grep node|sed -e 's:node::g'); do cat /sys/devices/system/node/node${i}/cpu*/cpufreq/$m 2>/dev/null|awk -v node=$i 'BEGIN{sum=0}{sum+=$1}END{ret=int(sum/NR/1000); if(ret>500){printf "%s freq PASS\n", node}else{printf "%s freq FAILED\n", node}}'; done
EOF

echo -e "\n########INFO: Check Memory"
pdsh -f 100 -R ssh -w $(echo ${hosts[*]}|tr ' ' ',') <<- 'EOF' | dshbak -c
dmidecode -t memory|grep -P '\tVolatile Size:'|tr -d '\t'|sort|uniq -c
EOF

echo -e "\n########INFO: Check NUMA"
pdsh -f 100 -R ssh -w $(echo ${hosts[*]}|tr ' ' ',') <<- 'EOF' | dshbak -c
numactl -H|grep size:|grep -v ' 0 MB'|awk '{print "N"$2"="int($(NF-1)/1000)"GB"}'|paste -s -d','
EOF

echo -e "\n########INFO: Check GPU basic"
pdsh -f 100 -R ssh -w $(echo ${hosts[*]}|tr ' ' ',') <<- 'EOF' | dshbak -c
nvidia-smi --format=csv --query-gpu gpu_bus_id,gpu_name,vbios_version,pstate,enforced.power.limit,ecc.errors.uncorrected.aggregate.total,remapped_rows.failure,remapped_rows.uncorrectable,remapped_rows.pending
EOF

echo -e "\n#########INFO: Check NVLINK status(Expected: 72 links are up)"
pdsh -f 100 -R ssh -w $(echo ${hosts[*]}|tr ' ' ',') <<- 'EOF' | dshbak -c
nvidia-smi nvlink -s|grep '5[0-9].* GB/s'|wc -l
nvidia-smi --format=csv --query-gpu gpu_bus_id,fabric.state,fabric.status
EOF

echo -e "\n#########INFO: Check P2P nvlink capability status(Expected: All GPU are OK on GBXX/BXX/HXX)"
pdsh -f 100 -R ssh -w $(echo ${hosts[*]}|tr ' ' ',') <<- 'EOF' | dshbak -c
nvidia-smi topo -p2p n 2>&1|grep GPU[0-9].*OK||true
EOF
echo -e "\n#########INFO: Check P2P pcie capability status(Expected: All GPU are OK on RTX/L20)"
pdsh -f 100 -R ssh -w $(echo ${hosts[*]}|tr ' ' ',') <<- 'EOF' | dshbak -c
nvidia-smi topo -p2p p 2>&1|grep GPU[0-9].*OK||true
EOF

echo -e "\n########INFO: Check CUUID"
pdsh -f 100 -R ssh -w $(echo ${hosts[*]}|tr ' ' ',') <<- 'EOF' | dshbak -c
nvidia-smi -q | grep -E 'Bus Id|CliqueId|ClusterUUID'
EOF

echo -e "\n########INFO: Check IB devices status(Expected: All up and active)"
pdsh -f 100 -R ssh -w $(echo ${hosts[*]}|tr ' ' ',') <<- 'EOF' | dshbak -c
ibstatus|grep -E 'Infiniband|state:'|paste - - -|sort -t'_' -k2n
EOF

echo -e "\n########INFO: Check IB Link Down status(Expected: No issue found)"
#Bypass those 4 ports IB HCA is connected to nvswitch on B200/B300.
pdsh -f 100 -R ssh -w $(echo ${hosts[*]}|tr ' ' ',') <<- 'EOF' | dshbak -c
ls -l /sys/class/infiniband|grep -v $((lspci -D | grep -i Infiniband|awk '{print $1}'|cut -d '.' -f 1|sort|uniq -c|grep -w 4||echo NONE)|awk '{print $NF}'|xargs -I {} echo "-e {}.")|grep infiniband|awk -F'/' '{print $(NF-2),$NF}'|while read bdf dev; do ret=$(mlxlink -d $bdf -c|grep Recommendation|cut -f2- -d ':'|grep -v 'No issue was observed'||true); [ "X$ret" != "X" ] && echo "$dev:${ret}"; done|paste -s -d','
EOF

echo -e "\n########INFO: Check IFace device status(Expected: all nodes use the same interface connect to default gateway)"
pdsh -f 100 -R ssh -w $(echo ${hosts[*]}|tr ' ' ',') <<- 'EOF' | dshbak -c
ip r sh|grep default|grep -o dev.*|cut -f2 -d' '
EOF

echo -e "\n########INFO: Check IMEX channel devices(Expected: At least one channel exist on GBXX)"
pdsh -f 100 -R ssh -w $(echo ${hosts[*]}|tr ' ' ',') <<- 'EOF' | dshbak -c
ls -1 /dev/nvidia-caps-imex-channels/ 2>/dev/null || true
EOF

echo -e "\n########INFO: Check IMEX profile"
pdsh -f 100 -R ssh -w $(echo ${hosts[*]}|tr ' ' ',') <<- 'EOF' | dshbak -c
grep -E "^(SERVER_PORT|IMEX_CMD_PORT|IMEX_CMD_ENABLED)=" /etc/nvidia-imex/config.cfg 2>/dev/null|paste -s -d ' '
EOF

echo -e "\n########INFO: Check IMEX nodes_config(Expected: file exist on GBXX)"
pdsh -f 100 -R ssh -w $(echo ${hosts[*]}|tr ' ' ',') <<- 'EOF' | dshbak -c
md5sum /etc/nvidia-imex/nodes_config.cfg 2>/dev/null || true
EOF

echo -e "\n########INFO: Check IMEX service status(Expected: 2 ports up and service is active on GBXX)"
pdsh -f 100 -R ssh -w $(echo ${hosts[*]}|tr ' ' ',') <<- 'EOF' | dshbak -c
netstat -lntp|grep -E ':(50000|50005) '|wc -l
systemctl is-active nvidia-imex.service || true
ls /cm/local/apps/slurm/var/*/*imex* 2>/dev/null||true
EOF

echo -e "\n#########INFO: Check IMEX readiness(Expected: imex is READY on GBXX)"
pdsh -f 100 -R ssh -w $(echo ${hosts[*]}|tr ' ' ',') <<- 'EOF' | dshbak -c
nvidia-imex-ctl -q 2>&1 || true
EOF

echo -e "\n########INFO: Check IMEX connection status(Expected: Node be in READY, all nodes connected and Domain UP on GBXX)"
pdsh -f 100 -R ssh -w $(echo ${hosts[*]}|tr ' ' ',') <<- 'EOF' | dshbak -c
nvidia-imex-ctl -N 2>&1 |awk '/Nodes:/,/Domain State:/{print $0}'|sed -e 's:\*: :g' -e 's:-::g'|tr -s ' '
EOF

echo -e "\n########INFO: Check Enroot runtime directory(Expected: ENROOT_RUNTIME_PATH Writable)"
pdsh -f 100 -u 10 -R ssh -w $(echo ${hosts[*]}|tr ' ' ',') <<- 'EOF' | dshbak -c
a=$(grep ENROOT_RUNTIME_PATH /etc/enroot/enroot.conf 2>/dev/null|grep -o /.\*/); if [ ! -z ${a} ]; then touch ${a}/test &>/dev/null && (echo "${a} is writable"; rm -f ${a}/test) || echo "${a} is read-only"; else echo "ENROOT_RUNTIME_PATH not set"; fi
EOF

echo -e "\n########INFO: Check dmesg - NV_ERR(Expected: No NV_ERR_*)"
pdsh -f 100 -R ssh -w $(echo ${hosts[*]}|tr ' ' ',') <<- 'EOF' | dshbak -c
dmesg|grep -o  NV_ERR_[^\]]*|sort|uniq
EOF

echo -e "\n########INFO: Check dmesg - Call trace(Expected: No Call trace)"
pdsh -f 100 -R ssh -w $(echo ${hosts[*]}|tr ' ' ',') <<- 'EOF' | dshbak -c
dmesg|grep -i "Call trace"|wc -l
EOF

echo -e "\n########INFO: Check dmesg - Hardware Error(Expected: No Hardware Error)"
pdsh -f 100 -R ssh -w $(echo ${hosts[*]}|tr ' ' ',') <<- 'EOF'|dshbak -c
dmesg|grep "Hardware Error"|wc -l
EOF

echo -e "\n########INFO: Check dmesg - Xid(Expected: No Xid)"
pdsh -f 100 -R ssh -w $(echo ${hosts[*]}|tr ' ' ',') <<- 'EOF'|dshbak -c
dmesg|grep -w Xid|grep -o Xid[^pid]*[0-9],|tr -d ','|awk '{print $1":"$NF}'|sort|uniq|paste -s -d','
EOF

echo -e "\n########INFO: Check dmesg - knvlinkDiscoverPostRxDetLinks(Expected: No knvlinkDiscoverPostRxDetLinks)"
pdsh -f 100 -R ssh -w $(echo ${hosts[*]}|tr ' ' ',') <<- 'EOF'|dshbak -c
dmesg|grep "NVRM: knvlinkDiscoverPostRxDetLinks"|wc -l
EOF

echo -e "\n########INFO: Check dmesg - ipmi_ssif(Expected: No ipmi_ssif Not present errors)"
pdsh -f 100 -R ssh -w $(echo ${hosts[*]}|tr ' ' ',') <<- 'EOF'|dshbak -c
ipmitool mc info &>/dev/null||(dmesg --since "8 hour ago" | grep "ipmi_ssif.*i2c-.*Not present"|wc -l)
EOF

echo -e "\n########INFO: Check dmesg - mlx5_core.*Health issue observed.*ERROR(Expected: No mlx5_core Health issue observed errors)"
pdsh -f 100 -R ssh -w $(echo ${hosts[*]}|tr ' ' ',') <<- 'EOF'|dshbak -c
dmesg --since "8 hour ago" | grep "mlx5_core.*Health issue observed.*ERROR"|wc -l
EOF

#echo -e "\n########INFO: Check dmesg - NVRM:.*Assertion failed(Expected: No NVRM Assertion failed errors)"
#pdsh -f 100 -R ssh -w $(echo ${hosts[*]}|tr ' ' ',') <<- 'EOF'|dshbak -c
#dmesg --since "1 hour ago" | grep "NVRM:.*Assertion failed"|wc -l
#EOF

echo