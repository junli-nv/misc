#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'USAGE'
Usage: nvme_audit.sh -f nodes.txt [-u user] [-j jobs] [-o outdir] [-p port] [-t timeout]

Options:
  -f FILE   Node list file, one hostname per line (required)
  -u USER   SSH user (default: current user)
  -j JOBS   Parallel jobs (default: 8)
  -o DIR    Output directory (default: ./nvme_audit_YYYYmmdd_HHMMSS)
  -p PORT   SSH port (default: 22)
  -t SEC    SSH connect timeout seconds (default: 45)
  -h        Show help
USAGE
}

NODE_FILE=""
SSH_USER="${USER:-root}"
JOBS=8
SSH_PORT=22
SSH_TIMEOUT=45
OUTDIR="./nvme_audit_$(date +%Y%m%d_%H%M%S)"

while getopts ":f:u:j:o:p:t:h" opt; do
  case "$opt" in
    f) NODE_FILE="$OPTARG" ;;
    u) SSH_USER="$OPTARG" ;;
    j) JOBS="$OPTARG" ;;
    o) OUTDIR="$OPTARG" ;;
    p) SSH_PORT="$OPTARG" ;;
    t) SSH_TIMEOUT="$OPTARG" ;;
    h) usage; exit 0 ;;
    :) echo "Option -$OPTARG requires an argument" >&2; usage; exit 1 ;;
    \?) echo "Invalid option: -$OPTARG" >&2; usage; exit 1 ;;
  esac
done

if [[ -z "$NODE_FILE" || ! -f "$NODE_FILE" ]]; then
  echo "nodes file is required: -f nodes.txt" >&2
  usage
  exit 1
fi

mkdir -p "$OUTDIR/raw"
CSV="$OUTDIR/nvme_health_report.csv"
SUMMARY="$OUTDIR/summary.txt"

cat > "$CSV" <<'CSVHDR'
node,host,kernel,device,controller,model,serial,firmware,critical_warning,temperature,wctemp,avail_spare,spare_thresh,percent_used,media_errors,num_err_log_entries,unsafe_shutdowns,dmesg_hits,verdict,reasons,dmesg_tail
CSVHDR

run_node() {
  local node="$1"
  local raw="$OUTDIR/raw/${node}.log"
  ssh \
    -o BatchMode=yes \
    -o StrictHostKeyChecking=no \
    -o UserKnownHostsFile=/dev/null \
    -o ConnectTimeout="$SSH_TIMEOUT" \
    -p "$SSH_PORT" \
    "${SSH_USER}@${node}" 'bash -s' > "$raw" 2>&1 <<'REMOTE'
set -euo pipefail
HOST=$(hostname 2>/dev/null || uname -n)
KERNEL=$(uname -r 2>/dev/null || true)
echo "__META__ host=$HOST kernel=$KERNEL"

HAS_SUDO=0
if command -v sudo >/dev/null 2>&1; then
  if sudo -n true >/dev/null 2>&1; then
    HAS_SUDO=1
  fi
fi
run_cmd() {
  if [[ "$HAS_SUDO" -eq 1 ]]; then
    sudo -n "$@"
  else
    "$@"
  fi
}

if ! command -v nvme >/dev/null 2>&1; then
  echo "__ERROR__ nvme_cli_missing"
  exit 0
fi

for dev in /dev/nvme*n1; do
  [[ -b "$dev" ]] || continue
  ctrl="${dev%n1}"
  echo "__DEV__ $dev $ctrl"
  echo "__SMART_BEGIN__ $dev"
  run_cmd nvme smart-log "$ctrl" -o json 2>/dev/null || run_cmd nvme smart-log "$ctrl" 2>/dev/null || true
  echo "__SMART_END__ $dev"
  echo "__IDCTRL_BEGIN__ $dev"
  run_cmd nvme id-ctrl "$ctrl" -o json 2>/dev/null || run_cmd nvme id-ctrl "$ctrl" 2>/dev/null || true
  echo "__IDCTRL_END__ $dev"
  echo "__ERRLOG_BEGIN__ $dev"
  run_cmd nvme error-log "$ctrl" -o json 2>/dev/null || run_cmd nvme error-log "$ctrl" 2>/dev/null || true
  echo "__ERRLOG_END__ $dev"
done

echo "__DMESG_BEGIN__"
(run_cmd journalctl -k -b --no-pager 2>/dev/null || run_cmd dmesg -T 2>/dev/null || dmesg -T 2>/dev/null || true) | tail -4000
echo "__DMESG_END__"
REMOTE
}

export OUTDIR SSH_USER SSH_PORT SSH_TIMEOUT
export -f run_node

while IFS= read -r node; do
  [[ -n "$node" ]] || continue
  [[ "$node" =~ ^# ]] && continue
  while [[ $(jobs -rp | wc -l) -ge $JOBS ]]; do
    sleep 0.2
  done
  run_node "$node" &
done < "$NODE_FILE"
wait

python3 - "$OUTDIR/raw" "$CSV" "$SUMMARY" <<'PY'
import csv
import json
import re
import sys
from pathlib import Path

raw_dir = Path(sys.argv[1])
csv_path = Path(sys.argv[2])
summary_path = Path(sys.argv[3])

fields = [
    'node','host','kernel','device','controller','model','serial','firmware',
    'critical_warning','temperature','wctemp','avail_spare','spare_thresh',
    'percent_used','media_errors','num_err_log_entries','unsafe_shutdowns',
    'dmesg_hits','verdict','reasons','dmesg_tail'
]

hard_fail_patterns = [
    r'\bnvme\b.*\bI/O\s+error\b',
    r'\bnvme\b.*\btimeout\b',
    r'\bnvme\b.*\breset(?:ting)?\b',
    r'\bnvme\b.*\bcontroller is down\b',
    r'\bnvme\b.*\bDevice not ready\b',
    r'\bnvme\b.*\bcritical medium error\b',
    r'\bnvme\b.*\babort(?:ing)?\b',
    r'\bblk_update_request\b.*\bI/O error\b',
    r'\bAER:\b.*\bUncorrectable\b',
    r'\bDPC:\b.*\bcontainment event\b',
    r'\bDPC:\b.*\bunmasked uncorrectable error detected\b',
]
warn_patterns = [
    r'\bnvme\[[0-9]+\]: segfault\b',
    r'\bAER:\b.*\bCorrectable\b',
]
benign_patterns = [
    r'No UUID available providing old NGUID',
    r'_OSC: platform does not support \[SHPCHotplug',
    r'Starting modprobe@nvme_fabrics\.service',
    r'\bnvme\s+nvme\d+: pci function\b',
    r'Shutdown timeout set to',
    r'default/read/poll queues',
    r'\bnvme\d+n\d+: p\d+\b',
    r'NVMe passthru support',
    r'NVME page size',
    r'FW provided TM TaskAbort/Reset timeout',
    r'Online Controller Reset\(OCR\)',
]

hard_fail_re = [re.compile(p, re.IGNORECASE) for p in hard_fail_patterns]
warn_re = [re.compile(p, re.IGNORECASE) for p in warn_patterns]
benign_re = [re.compile(p, re.IGNORECASE) for p in benign_patterns]


def to_int(v, default=0):
    if v is None:
        return default
    if isinstance(v, (int, float)):
        return int(v)
    s = str(v).strip()
    if not s:
        return default
    m = re.search(r'-?\d+', s)
    return int(m.group(0)) if m else default


def load_jsonish(text):
    text = text.strip()
    if not text:
        return {}
    try:
        return json.loads(text)
    except Exception:
        return {}


def extract_sections(content, begin, end):
    out = {}
    current = None
    buf = []
    for line in content.splitlines():
        if line.startswith(begin):
            current = line.split(maxsplit=1)[1].strip() if ' ' in line else ''
            buf = []
            continue
        if line.startswith(end):
            if current is not None:
                out[current] = '\n'.join(buf).strip()
            current = None
            buf = []
            continue
        if current is not None:
            buf.append(line)
    return out


rows = []
summary = {'PASS': 0, 'WARN': 0, 'FAIL': 0, 'ERROR': 0}

for log in sorted(raw_dir.glob('*.log')):
    text = log.read_text(errors='replace')
    node = log.stem
    host = node
    kernel = ''
    m = re.search(r'__META__\s+host=(\S+)\s+kernel=(\S+)', text)
    if m:
      host, kernel = m.group(1), m.group(2)

    if '__ERROR__ nvme_cli_missing' in text:
        rows.append({
            'node': node, 'host': host, 'kernel': kernel, 'device': '', 'controller': '',
            'model': '', 'serial': '', 'firmware': '', 'critical_warning': '', 'temperature': '', 'wctemp': '',
            'avail_spare': '', 'spare_thresh': '', 'percent_used': '', 'media_errors': '',
            'num_err_log_entries': '', 'unsafe_shutdowns': '', 'dmesg_hits': '0', 'verdict': 'ERROR',
            'reasons': 'nvme_cli_missing', 'dmesg_tail': ''
        })
        summary['ERROR'] += 1
        continue

    smart = extract_sections(text, '__SMART_BEGIN__', '__SMART_END__')
    idctrl = extract_sections(text, '__IDCTRL_BEGIN__', '__IDCTRL_END__')
    errlog = extract_sections(text, '__ERRLOG_BEGIN__', '__ERRLOG_END__')
    devs = re.findall(r'^__DEV__\s+(\S+)\s+(\S+)$', text, re.M)

    dmesg = ''
    dm = re.search(r'__DMESG_BEGIN__\n(.*)\n__DMESG_END__', text, re.S)
    if dm:
        dmesg = dm.group(1)
    dmesg_lines = [ln.strip() for ln in dmesg.splitlines() if ln.strip()]

    flagged_lines = []
    hard_hit = False
    warn_hit = False
    for ln in dmesg_lines:
        if any(r.search(ln) for r in benign_re):
            continue
        matched_hard = any(r.search(ln) for r in hard_fail_re)
        matched_warn = any(r.search(ln) for r in warn_re)
        if matched_hard or matched_warn:
            flagged_lines.append(ln)
            hard_hit = hard_hit or matched_hard
            warn_hit = warn_hit or matched_warn

    dmesg_hits = len(flagged_lines)
    dmesg_tail = ' | '.join(flagged_lines[-20:])

    for dev, ctrl in devs:
        s = load_jsonish(smart.get(dev, ''))
        i = load_jsonish(idctrl.get(dev, ''))
        e = load_jsonish(errlog.get(dev, ''))

        critical_warning = to_int(s.get('critical_warning'))
        temperature = to_int(s.get('temperature'))
        wctemp = to_int(i.get('wctemp'))
        avail_spare = to_int(s.get('avail_spare'))
        spare_thresh = to_int(s.get('spare_thresh'))
        percent_used = to_int(s.get('percent_used'))
        media_errors = to_int(s.get('media_errors'))
        unsafe_shutdowns = to_int(s.get('unsafe_shutdowns'))
        num_err_log_entries = to_int(s.get('num_err_log_entries'))
        if not num_err_log_entries and isinstance(e, dict):
            num_err_log_entries = to_int(e.get('num_err_log_entries') or e.get('error_count'))

        model = (i.get('mn') or i.get('model_number') or '').strip()
        serial = (i.get('sn') or i.get('serial_number') or '').strip()
        firmware = (i.get('fr') or i.get('firmware_revision') or '').strip()

        verdict = 'PASS'
        reasons = []

        if critical_warning != 0:
            verdict = 'FAIL'
            reasons.append('critical_warning')
        if media_errors > 0:
            verdict = 'FAIL'
            reasons.append('media_errors')
        if avail_spare and spare_thresh and avail_spare < spare_thresh:
            verdict = 'FAIL'
            reasons.append('avail_spare_below_threshold')
        if hard_hit:
            verdict = 'FAIL'
            reasons.append('dmesg_nvme_hard_error')

        if verdict != 'FAIL':
            if percent_used >= 90:
                verdict = 'WARN'
                reasons.append('percent_used_high')
            if num_err_log_entries > 0:
                verdict = 'WARN'
                reasons.append('num_err_log_entries_nonzero')
            if warn_hit:
                verdict = 'WARN'
                reasons.append('dmesg_nvme_warn_pattern')
            if wctemp and temperature and temperature >= wctemp:
                verdict = 'WARN'
                reasons.append('temperature_at_or_above_wctemp')

        if not reasons:
            reasons = ['healthy_baseline']

        rows.append({
            'node': node,
            'host': host,
            'kernel': kernel,
            'device': dev,
            'controller': ctrl,
            'model': model,
            'serial': serial,
            'firmware': firmware,
            'critical_warning': critical_warning,
            'temperature': temperature,
            'wctemp': wctemp,
            'avail_spare': avail_spare,
            'spare_thresh': spare_thresh,
            'percent_used': percent_used,
            'media_errors': media_errors,
            'num_err_log_entries': num_err_log_entries,
            'unsafe_shutdowns': unsafe_shutdowns,
            'dmesg_hits': dmesg_hits,
            'verdict': verdict,
            'reasons': ';'.join(dict.fromkeys(reasons)),
            'dmesg_tail': dmesg_tail,
        })
        summary[verdict] += 1

with csv_path.open('a', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=fields)
    for row in rows:
        writer.writerow(row)

with summary_path.open('w') as f:
    total = sum(summary.values())
    f.write(f'Total rows: {total}\n')
    for k in ('PASS', 'WARN', 'FAIL', 'ERROR'):
        f.write(f'{k}: {summary[k]}\n')
    f.write('\nTop WARN/FAIL/ERROR rows:\n')
    for row in rows:
        if row['verdict'] in ('WARN', 'FAIL', 'ERROR'):
            f.write(f"{row['node']} {row['device']} {row['verdict']} {row['reasons']}\n")
PY

echo "Done."
echo "CSV:     $CSV"
echo "Summary: $SUMMARY"
echo "Raw:     $OUTDIR/raw"
