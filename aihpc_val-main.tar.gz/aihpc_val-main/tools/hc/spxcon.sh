#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>
export PDSH_SSH_ARGS_APPEND="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=quiet -o CheckHostIP=no"
export PDSH_RCMD_TYPE=ssh

NODELIST=${NODELIST:-$1}
[ -z "$NODELIST" ] && echo "Usage: $0 <nodelist>" && exit 1

echo "=======Bring up the NICS======="
pdsh -f 32 -w ${NODELIST} <<- 'EOF'
for i in $(lspci -D | grep -i eth|awk '{print $1}'|while read i; do basename $(ls -l /sys/class/net/|grep -o ${i}/.*); done); do ip link set ${i} up; done; sleep 1; lldpcli configure system hostname .; lldpcli configure lldp portidsubtype ifname; lldpcli configure system interface pattern eth*,eno*,enp*,ens*,enP*; lldpcli update;
EOF

echo "=======Check cable connection======="
# Assume the port names prefix is eth_p0, eth_p1 or ens. Plane0: 4*eth_p0_xx; Plane1: 4*eth_p1_xx; N/S: 2*ens_xx. 
spxcon_tmpf=$(mktemp)
pdsh -f 32 -t 30 -u 30 -w ${NODELIST} <<- 'EOF'| tee $spxcon_tmpf
tmpf=$(mktemp); for i in $(lspci -D | grep -i ConnectX-8|awk '{print $1}'|while read i; do ls -l /sys/class/net | grep -o "/${i}/.*" | cut -d'/' -f4; done); do lldpcli show neighbors ports $i | awk -v port=$i 'BEGIN{line = "" } /^LLDP neighbors:$/ { next } /Interface:/ { gsub(/,/, " "); line = line" "$2 } /SysName:/ { line = line" "$NF } /PortID:/{line = line" "$NF} END{if(line != ""){ print line}else{print port,"NA","NA"}}'; done > $tmpf; for i in eth_p0 eth_p1 ens; do grep ${i} $tmpf|paste - - - -|awk '{if(NF==12 && ($3 != $6 || $3 != $9 || $3 != $12 )){print $0," <*>"}else{print $0}}'; done; rm -f $tmpf
EOF
echo
echo "=======Cable Mis Wired======="
grep -e '\*' -e NA $spxcon_tmpf | sort | grep -v pdsh |tr '\t' ' '|tr -s ' ' |while read line; do
  printf "WARN: %25s %10s%20s%8s %10s%20s%8s %10s%20s%8s %10s%20s%8s %s\n" $line
done
rm -f $spxcon_tmpf

# E.g. output:
# WARN:    br-chl2-b300-tlv1-109:  eth_p0_r1  br-chl2-spx-leaf22 swp29s0  eth_p0_r2                  NA      NA  eth_p0_r0  br-chl2-spx-leaf21 swp29s0  eth_p0_r3  br-chl2-spx-leaf24 swp29s0 <*>
# WARN:    br-chl2-b300-tlv1-109:  eth_p0_r4  br-chl2-spx-leaf21 swp29s1  eth_p0_r7  br-chl2-spx-leaf24 swp29s1  eth_p0_r5  br-chl2-spx-leaf22 swp29s1  eth_p0_r6                  NA      NA <*>
# WARN:    br-chl2-b300-tlv1-109:  eth_p1_r1  br-chl2-spx-leaf26 swp29s0  eth_p1_r2  br-chl2-spx-leaf27 swp29s0  eth_p1_r0                  NA      NA  eth_p1_r3  br-chl2-spx-leaf28 swp29s0 <*>
# WARN:    br-chl2-b300-tlv1-109:  eth_p1_r4                  NA      NA  eth_p1_r7  br-chl2-spx-leaf28 swp29s1  eth_p1_r5  br-chl2-spx-leaf26 swp29s1  eth_p1_r6  br-chl2-spx-leaf27 swp29s1 <*>