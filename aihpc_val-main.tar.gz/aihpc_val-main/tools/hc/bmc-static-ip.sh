#!/bin/bash

[ "${-#*x}" != "$-" ] && export debug=1 || export debug=0

main(){
  [ $debug -eq 1 ] && set -x || set +x
  
  channel=1

  tmpf=$(mktemp)
  ipmitool -I open lan print ${channel} &> ${tmpf}
  ret=$?
  if [ $ret -ne 0 ]; then
    echo "ERROR: Failed to get lan info, please check if ipmitool is working properly"
    rm -f ${tmpf}
    exit 1
  fi
  
  grep 'IP Address Source.*DHCP Address' $tmpf &> /dev/null
  ret=$?
  if [ $ret -ne 0 ]; then
    echo "INFO: IP is already static, no need to set"
    rm -f ${tmpf}
    exit 0
  fi
  
  ip=$(grep 'IP Address' $tmpf|grep -v Source|awk -F':' '{print $NF}'|tr -d ' ')
  if [ -z "${ip}" ]; then
    echo "ERROR: Failed to get BMC IP address, please check if ipmitool is working properly"
    rm -f ${tmpf}
    exit 1
  fi

  netmask=$(grep 'Subnet Mask' $tmpf|awk -F':' '{print $NF}'|tr -d ' ')
  if [ -z "${netmask}" ]; then
    echo "ERROR: Failed to get BMC netmask, please check if ipmitool is working properly"
    rm -f ${tmpf}
    exit 1
  fi
  
  gateway=$(grep 'Default Gateway IP' $tmpf|awk -F':' '{print $NF}'|tr -d ' ')
  if [ -z "${gateway}" ]; then
    echo "ERROR: Failed to get BMC gateway, please check if ipmitool is working properly"
    rm -f ${tmpf}
    exit 1
  fi
  
  rm -f ${tmpf}
  echo "INFO: $ip $netmask $gateway"
  
  ipmitool -I open lan set ${channel} ipsrc static
  sleep 1
  ipmitool -I open lan set ${channel} ipaddr ${ip}
  ipmitool -I open lan set ${channel} netmask ${netmask}
  ipmitool -I open lan set ${channel} defgw ipaddr ${gateway}
  
  echo "INFO: Successfully set BMC IP to static"
  ipmitool -I open lan print ${channel}
}

main 2>&1 | xargs -I {} echo "$(hostname): {}"
