#include <cuda_runtime.h>
#include <cstdio>

int main(){
  int deviceCount = 0;
  cudaError_t error_id = cudaGetDeviceCount(&deviceCount);

  if (error_id != cudaSuccess) {
    printf("Result = FAILED : error_id=%d (%s)\n", error_id, cudaGetErrorString(error_id));
  }else{
    printf("Result = PASSED, GPU#=%d\n", deviceCount);
  }
  return error_id;
}
