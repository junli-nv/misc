#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>
nodelist=$1
[ -z "$nodelist" ] && echo "Usage: $0 <nodelist>" && exit 1

lldp_conf(){
pdsh -R ssh -f 100 -w $nodelist <<- 'EOF'
lldpcli configure system hostname .
lldpcli configure lldp portidsubtype ifname
lldpcli configure system interface pattern eth*,eno*,enp*,ens*,enP*
systemctl restart lldpd
EOF
}
# lldp_conf && sleep 30

pdsh -R ssh -f 100 -w $nodelist <<- 'EOF' | sort
lldpcli show neighbors | grep -E 'Interface:|SysName:|PortID:'|awk '/Interface:/{print $2} /SysName:/{print $NF} /PortID:/{print $NF}'|tr ',' ' '|paste - - -|sort|paste - -|awk '{if(NF==6 && $3 != $6){print $0," <*>"}else{print $0}}'
EOF
