#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

export PATH=/usr/bin:/bin:/usr/sbin:/sbin

reset(){
  nvidia-smi -rac
  nvidia-smi -rgc
}

max(){
  nvidia-smi -pm 1
  #nvidia-smi -lmcd ${ret[0]}
  ret=($(nvidia-smi -i 0 --query-supported-clocks=mem,gr --format=csv,noheader|head -n 1|awk '{print $1, $3}'))
  nvidia-smi -ac ${ret[0]},${ret[1]}
  nvidia-smi -lgc ${ret[1]},${ret[1]}
}

query(){
  nvidia-smi --format=csv --query-gpu gpu_bus_id,gpu_name,compute_mode,ecc.mode.current,clocks.gr,clocks.max.gr,clocks.sm,clocks.max.sm,clocks.max.mem,clocks.video,clocks.applications.gr,clocks.applications.mem,clocks.default_applications.gr,clocks.default_applications.mem,pstate,power.default_limit
}

action=$1
[ -z $action ] && action="query"
case ${action} in
"reset") 
  reset
  ;;
"max")
  max
  ;;
"query")
  query
  ;;
*)
  query
  ;;
esac
