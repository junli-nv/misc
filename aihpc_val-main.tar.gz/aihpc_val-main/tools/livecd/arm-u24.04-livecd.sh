#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

## Install required packages for building ISO image
apt update
apt install -y gpgv gnupg ubuntu-keyring ca-certificates mtools grub-efi-arm64-bin grub-common xorriso squashfs-tools debootstrap p7zip-full

## Prepare work directories
topdir=/raid/livecd
mkdir -p ${topdir}
export WORK=${topdir}/work
export CD=${topdir}/cd
export FORMAT=squashfs
export FS_DIR=casper
mkdir -p ${CD}/{${FS_DIR},boot/grub} ${WORK}/rootfs

## Create rootfs
rm -rf ${WORK}/rootfs/*
debootstrap --no-check-gpg \
  --arch=arm64 \
  --variant=minbase \
  noble \
  ${WORK}/rootfs \
  http://ports.ubuntu.com/ubuntu-ports

## Copy resolv.conf, hosts, and hostname to the rootfs
/bin/cp -arvf /etc/resolv.conf ${WORK}/rootfs/etc/
/bin/cp -arvf /etc/hosts ${WORK}/rootfs/etc/
/bin/cp -arvf /etc/hostname ${WORK}/rootfs/etc/

## Mount necessary filesystems for chroot
mount -t devtmpfs /dev ${WORK}/rootfs/dev
mount -t devpts devpts ${WORK}/rootfs/dev/pts
mount -t proc proc ${WORK}/rootfs/proc
mount -t sysfs sys ${WORK}/rootfs/sys
mount -t tmpfs tmpfs ${WORK}/rootfs/run
mkdir -p ${WORK}/rootfs/run/{lock,shm}

## Enter chroot environment
chroot ${WORK}/rootfs /bin/bash

export LC_ALL=C LANG="en_US.UTF-8" LANGUAGE=C

cat >> /etc/hosts <<'EOF'
91.189.91.102 ports.ubuntu.com
23.49.105.41 repo.download.nvidia.com
23.49.105.46 developer.download.nvidia.com
168.62.212.37 linux.mellanox.com
EOF

cat > /etc/apt/sources.list <<'EOF'
deb http://ports.ubuntu.com/ubuntu-ports noble main restricted universe multiverse
deb http://ports.ubuntu.com/ubuntu-ports noble-updates main restricted universe multiverse
deb http://ports.ubuntu.com/ubuntu-ports noble-security main restricted universe multiverse
EOF
apt update
apt install -y curl tar gzip

## Add NVIDIA DGX repository
curl https://repo.download.nvidia.com/baseos/ubuntu/noble/arm64/dgx-repo-files.tgz | tar xzf - -C /
mkdir -p /etc/apt/sources.list.d/disabled
mv /etc/apt/sources.list.d/{ai-workbench-desktop.sources,doca-bos8-latest.sources} \
    /etc/apt/sources.list.d/disabled/
cat > /etc/apt/preferences.d/black.pref << 'EOF'
Package: dgx*
Pin: release *
Pin-Priority: -1
EOF
apt update

## Install Linux kernel and headers
kernel_version="6.17.0-1014-nvidia-64k"
apt-get install -y \
  linux-headers-${kernel_version} \
  linux-image-${kernel_version} \
  linux-modules-${kernel_version} \
  linux-tools-${kernel_version}

apt-mark hold linux-image-generic linux-headers-generic linux-generic \
  linux-headers-${kernel_version} linux-image-${kernel_version} linux-modules-${kernel_version} linux-tools-${kernel_version}
apt-mark showhold

## Install basic packages
apt install -y \
  curl dkms \
  ubuntu-minimal \
  ubuntu-standard \
  casper \
  network-manager \
  openssh-server \
  systemd-sysv \
  sudo \
  vim \
  less \
  wget \
  numactl \
  ipmitool lldpd gawk efibootmgr lvm2 \
  iputils-ping isc-dhcp-client isc-dhcp-relay \
  pciutils xfsprogs sshfs ifupdown net-tools lsof \
  nfs-kernel-server environment-modules  \
  bash-completion lftp pdsh nvme-cli nmon ntpsec ntfs-3g squashfs-tools p7zip-full tmux screen \
  busybox-static kexec-tools jq \
  cifs-utils docker-ce ethtool fping gdisk git htop iperf lsof lsscsi mdadm net-tools nfs-common parted pciutils pm-utils powercap-utils quota rasdaemon samba-common samba-libs sg3-utils smartmontools ssh sysstat udev vlan  \
  nvidia-container-toolkit
systemctl enable ssh

## Add bootstrap for building LiveCD
apt install -y gpgv gnupg ubuntu-keyring ca-certificates mtools grub-efi-arm64-bin grub-common xorriso squashfs-tools debootstrap p7zip-full

## https://developer.nvidia.com/doca-downloads?deployment_platform=Host-Server&deployment_package=DOCA-Host&target_os=Linux&Architecture=arm64-sbsa&Profile=doca-ofed&Distribution=Ubuntu&version=24.04&installer_type=deb_online
export DOCA_URL="https://linux.mellanox.com/public/repo/doca/3.4.0/ubuntu24.04/arm64-sbsa/"
curl https://linux.mellanox.com/public/repo/doca/public_keys/nvidia-doca-debian-gpg-public-key.gpg | gpg --dearmor > /etc/apt/trusted.gpg.d/nvidia-doca-debian-gpg-public-key.gpg
echo "deb [signed-by=/etc/apt/trusted.gpg.d/nvidia-doca-debian-gpg-public-key.gpg] $DOCA_URL ./" > /etc/apt/sources.list.d/doca.list
apt-get update
apt-get -y install doca-ofed
systemctl disable srp_daemon.service srptools.service
systemctl enable openibd

## Install NVIDIA driver
ver=580.126.20
target_pkgs=(
libnvidia-nscq
nvidia-fabricmanager
nvidia-driver-580-open
nvidia-dkms-580-open
nvidia-settings
libxnvctrl0
nvidia-modprobe
nvidia-kernel-source-580-open
nvidia-kernel-common-580
libnvidia-gl-580
libnvidia-extra-580
libnvidia-decode-580
libnvidia-encode-580
xserver-xorg-video-nvidia-580
libnvidia-cfg1-580
libnvidia-fbc1-580
libnvidia-common-580
nvidia-firmware-580
libnvidia-gpucomp-580
libnvidia-compute-580
nvidia-persistenced
nvidia-imex
)
pkgs=(
$(
for i in ${target_pkgs[*]}; do
  apt-cache madison $i | grep ${ver}-.*developer.download.nvidia.com
done|awk '{print $1"="$3}'
)
#nvlsm
)
apt install --allow-downgrades -y ${pkgs[@]}
## Fix the slurm can't detect NVML issue
cd /usr/lib/aarch64-linux-gnu/
ln -sf libnvidia-ml.so.1 libnvidia-ml.so
cd /root
## Install NVIDIA datacenter GPU manager
apt install -y datacenter-gpu-manager-4-core datacenter-gpu-manager-4-cuda13 datacenter-gpu-manager-4-multinode-cuda13
systemctl enable nvidia-persistenced nvidia-dcgm nvidia-imex #nvidia-fabricmanager
systemctl disable nvidia-fabricmanager
mkdir -p /var/run/nvidia-fabricmanager
chmod 755 /var/run/nvidia-fabricmanager
## CUDA
apt install -y cuda-nvml-dev-13-0 #cuda-toolkit-13-0
## GDRCOPY #packages from dgx
apt install -y gdrdrv-dkms gdrcopy gdrcopy-tests libgdrapi
## DGX packages
apt install -y \
  nv-cpu-governor nv-limits nvidia-acs-disable nvidia-enable-power-meter-cap nvidia-kernel-defaults \
  nvidia-nvme-options nvidia-pci-bridge-power nvidia-relaxed-ordering-gpu nvidia-relaxed-ordering-nvme

## For Lustre
cat >> /etc/sysctl.conf <<- EOF
### Recommended baseline for multi‑NIC same‑subnet RoCE
## 1) ARP behaviour
#sysctl -w net.ipv4.conf.all.arp_filter=0
#sysctl -w net.ipv4.conf.all.arp_ignore=1
#sysctl -w net.ipv4.conf.all.arp_announce=2
#sysctl -w net.ipv4.conf.all.accept_local=1
#sysctl -w net.ipv4.conf.default.arp_filter=0
#sysctl -w net.ipv4.conf.default.arp_ignore=1
#sysctl -w net.ipv4.conf.default.arp_announce=2
#sysctl -w net.ipv4.conf.default.accept_local=1
## 2) Reverse‑path filtering
#sysctl -w net.ipv4.conf.all.rp_filter=2
#sysctl -w net.ipv4.conf.default.rp_filter=2
###################################################
### Enable Magic SysRq
kernel.sysrq=1
EOF

## Enable NV Profiling for normal users
cat > /etc/modprobe.d/nvprofiling.conf <<- EOF
options nvidia NVreg_RestrictProfilingToAdminUsers=0
EOF
cat > /etc/modprobe.d/nvidia-imex.conf <<- EOF
options nvidia NVreg_CreateImexChannel0=1
EOF
## Enable Coherent GPU Memory Mode(CDMM) on GB200 for K8S
## https://docs.nvidia.com/datacenter/tesla/tesla-release-notes-580-82-07/index.html
cat > /etc/modprobe.d/nvidia-cdmm.conf <<- EOF
#GPU driver manage GPU memory as coherent memory instead of shown as NUMA nodes
options nvidia NVreg_CoherentGPUMemoryMode=driver
EOF

## For GB300 disable nvidia-acs-disable.service but for GB200 enable it
systemctl disable nvidia-acs-disable.service

systemctl set-default multi-user.target
echo 'root:123456'|chpasswd

useradd -m -s /bin/bash ubuntu
echo 'ubuntu:123456' | chpasswd
usermod -aG sudo ubuntu
echo 'ubuntu ALL=(ALL) NOPASSWD:ALL' > /etc/sudoers.d/ubuntu
chmod 0440 /etc/sudoers.d/ubuntu

apt purge -y unattended-upgrades

sed -i.ori -e 's#next unless "$tag" ne "";#next unless defined $tag and "$tag" ne "";#g' /usr/bin/dshbak

apt-mark unhold linux-image-generic linux-headers-generic linux-generic \
  linux-headers-${kernel_version} linux-image-${kernel_version} linux-modules-${kernel_version} linux-tools-${kernel_version} linux-modules-extra-${kernel_version}

#Higher the sshd limits for rsync
cat > /etc/ssh/sshd_config.d/90-rsync.conf <<- EOF
PermitRootLogin yes
MaxStartups 100:30:200
MaxSessions 100
EOF

KVER=$(cd /boot && ls -1 vmlinuz-* | tail -1 | sed 's@vmlinuz-@@')
depmod -a "$KVER"
update-initramfs -u -k "$KVER"

apt clean all
rm -f /etc/hostname

rm -f /var/log/apt/*
rm -rf /tmp/*
truncate -s 0 /etc/machine-id
truncate -s 0 /root/.bash_history
history -c
exit 0

## Umount filesystems after chroot
umount ${WORK}/rootfs/dev/pts
umount ${WORK}/rootfs/run
umount ${WORK}/rootfs/sys/firmware/efi/efivars
umount ${WORK}/rootfs/sys
umount ${WORK}/rootfs/proc
umount ${WORK}/rootfs/dev
mount|grep $WORK

## Prepare files for LiveCD
KVER=$(cd ${WORK}/rootfs/boot && ls -1 vmlinuz-* | tail -1 | sed 's@vmlinuz-@@')
/bin/cp -arvf ${WORK}/rootfs/boot/vmlinuz-${KVER} ${CD}/${FS_DIR}/vmlinuz
/bin/cp -arvf ${WORK}/rootfs/boot/initrd.img-${KVER} ${CD}/${FS_DIR}/initrd
rm -f ${CD}/${FS_DIR}/filesystem.${FORMAT}
mksquashfs ${WORK}/rootfs ${CD}/${FS_DIR}/filesystem.${FORMAT} -noappend
echo -n $(du -s --block-size=1 ${WORK}/rootfs | awk '{print $1}') | tee ${CD}/${FS_DIR}/filesystem.size
find ${CD} -type f -print0 | xargs -0 md5sum | sed "s@${CD}@.@" | grep -v md5sum.txt | tee ${CD}/md5sum.txt

## Create GRUB configuration
## For SMC, ttyS1 is used for serial console, for others ttyS0 should be used.
cat > ${CD}/boot/grub/grub.cfg <<- '__EOF__'
set default=0
set timeout=10

menuentry "Ubuntu 24.04 - LiveCD - GB300 - HWMP" {
    linux /casper/vmlinuz boot=casper nomodeset console=tty0 console=ttyS0,115200n8r earlyprintk=serial,ttyS0,115200,keep rd.driver.blacklist=nouveau nouveau.modeset=0 nvidia_drm.modeset=0 earlycon nvme_core.multipath=n pci=pcie_bus_perf,realloc=on pcie_aspm=off pcie_ports=native init_on_alloc=0 transparent_hugepage=madvise numa_balancing=disable acpi_power_meter.force_cap_on=y namespace.unpriv_enable=1 user_namespace.enable=1 cgroup_enable=memory swapaccount=1 systemd.unified_cgroup_hierarchy=1 systemd.legacy_systemd_cgroup_controller=0 cgroup_no_v1=all iommu.passthrough=1 pci=config_acs="xx111x0@0008:00:00.0;xx110x1@0008:02:00.0;xx101x1@0008:02:03.0;xx111x0@0009:00:00.0;xx110x1@0009:02:00.0;xx101x1@0009:02:01.0;xx111x0@0018:00:00.0;xx110x1@0018:02:00.0;xx101x1@0018:02:03.0;xx111x0@0019:00:00.0;xx110x1@0019:02:00.0;xx101x1@0019:02:01.0" intel_iommu=on hugepagesz=2M default_hugepagesz=2M hugepages=32768 ---
    initrd /casper/initrd
}

menuentry "Ubuntu 24.04 - LiveCD - GB300" {
    linux /casper/vmlinuz boot=casper nomodeset console=tty0 console=ttyS0,115200n8r earlyprintk=serial,ttyS0,115200,keep rd.driver.blacklist=nouveau nouveau.modeset=0 nvidia_drm.modeset=0 earlycon nvme_core.multipath=n pci=pcie_bus_perf,realloc=on pcie_aspm=off pcie_ports=native init_on_alloc=0 transparent_hugepage=madvise numa_balancing=disable acpi_power_meter.force_cap_on=y namespace.unpriv_enable=1 user_namespace.enable=1 cgroup_enable=memory swapaccount=1 systemd.unified_cgroup_hierarchy=1 systemd.legacy_systemd_cgroup_controller=0 cgroup_no_v1=all iommu.passthrough=1 pci=config_acs="xx111x0@0008:00:00.0;xx110x1@0008:02:00.0;xx101x1@0008:02:03.0;xx111x0@0009:00:00.0;xx110x1@0009:02:00.0;xx101x1@0009:02:01.0;xx111x0@0018:00:00.0;xx110x1@0018:02:00.0;xx101x1@0018:02:03.0;xx111x0@0019:00:00.0;xx110x1@0019:02:00.0;xx101x1@0019:02:01.0" ---
    initrd /casper/initrd
}

menuentry "Ubuntu 24.04 - LiveCD - GB200" {
    linux /casper/vmlinuz boot=casper nomodeset console=tty0 console=ttyS0,115200n8r earlyprintk=serial,ttyS0,115200,keep rd.driver.blacklist=nouveau nouveau.modeset=0 nvidia_drm.modeset=0 earlycon nvme_core.multipath=n pci=pcie_bus_perf,realloc=on pcie_aspm=off pcie_ports=native init_on_alloc=0 transparent_hugepage=madvise numa_balancing=disable acpi_power_meter.force_cap_on=y namespace.unpriv_enable=1 user_namespace.enable=1 cgroup_enable=memory swapaccount=1 systemd.unified_cgroup_hierarchy=1 systemd.legacy_systemd_cgroup_controller=0 cgroup_no_v1=all iommu.passthrough=1 ---
    initrd /casper/initrd
}
__EOF__

## Create LiveCD ISO image
rm -f ubuntu-24.04-live.iso
grub-mkrescue -o ubuntu-24.04-live.iso ${CD}
#
## Use xorriso if grub-mkrescue is unstable
#xorriso -as mkisofs \
#  -iso-level 3 \
#  -allow-lowercase \
#  -volid "YOUR_ARM64_ISO" \
#  -J -joliet-long -l \
#  -c boot/boot.cat \
#  -partition_offset 16 \
#  -append_partition 2 0xef ./deb-extract/usr/share/cd-boot-images-arm64/images/boot/grub/efi.img \
#  -e --interval:appended_partition_2:all:: \
#  -no-emul-boot \
#  -partition_cyl_align all \
#  -output ./custom-arm64.iso \
#  ./iso-extract

# /bin/cp -arvf ./ubuntu-24.04-live.iso /var/www/html/isos/ubuntu-24.04-live.iso
# lftp https://localhost/isos/
