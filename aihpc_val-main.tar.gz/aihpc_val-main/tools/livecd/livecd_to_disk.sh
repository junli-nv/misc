#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

target_disk=${1:-"/dev/nvme0n1"}

## 0. 取消挂载和清理磁盘
vgchange -an sysvg
sgdisk --zap-all "$target_disk"
wipefs --no-act "$target_disk"
partprobe "$target_disk"
udevadm settle

## 1. 确认 UEFI和目标磁盘
test -d /sys/firmware/efi &&
      echo "UEFI mode" ||
      echo "Legacy BIOS mode"
lsblk -e7 -o NAME,PATH,SIZE,MODEL,SERIAL,TYPE,FSTYPE,MOUNTPOINTS

## 2. 创建三个 GPT 分区
parted --script "$target_disk" \
    mklabel gpt \
    mkpart ESP fat32 1MiB 1025MiB \
    set 1 esp on \
    mkpart boot ext4 1025MiB 5121MiB \
    mkpart lvm 5121MiB 100% \
    set 3 lvm on
partprobe "$target_disk"
udevadm settle

parted "$target_disk" unit MiB print
lsblk "$target_disk"

## 3. 格式化 EFI和 /boot
mkfs.fat -F 32 -n EFI "${target_disk}p1"
mkfs.ext4 -F -L boot "${target_disk}p2"

## 4. 创建 LVM
pvcreate "${target_disk}p3"
vgcreate sysvg "${target_disk}p3"
lvcreate -L 16G -n lv_swap sysvg
lvcreate -L 100G -n lv_root sysvg

## 5. 创建 XFS和 swap
mkfs.xfs -f -L rootfs /dev/sysvg/lv_root
mkswap -L swap /dev/sysvg/lv_swap

lsblk -f "$target_disk"
blkid

## 6. 按正确层次挂载
## 挂载根文件系统：
mkdir -p /mnt/target
mount /dev/sysvg/lv_root /mnt/target

## 挂载独立 /boot：
mkdir -p /mnt/target/boot
mount "${target_disk}p2" /mnt/target/boot

## 挂载 EFI：
mkdir -p /mnt/target/boot/efi
mount "${target_disk}p1" /mnt/target/boot/efi

## 验证挂载关系：
findmnt -R /mnt/target

## 7. 复制 LiveCD 文件系统
rsync -aHAXx --numeric-ids --info=progress2 / /mnt/target/ \
  --exclude=/dev/ \
  --exclude=/proc/ \
  --exclude=/sys/ \
  --exclude=/run/ \
  --exclude=/tmp/ \
  --exclude=/mnt/target/ \
  --exclude=/media/ \
  --exclude=/lost+found

## 创建必要目录：
mkdir -p /mnt/target/{dev,proc,sys,run,tmp,media}
chmod 1777 /mnt/target/tmp

## 8. 创建 /etc/fstab

##获取 UUID：

## 备份从 LiveCD 复制过来的 fstab：
cp -a /mnt/target/etc/fstab /mnt/target/etc/fstab.livecd

## 编辑：
cat > /mnt/target/etc/fstab << EOF
UUID=$(blkid -s UUID -o value "${target_disk}p2")  /boot      ext4  defaults         0  2
UUID=$(blkid -s UUID -o value "${target_disk}p1")  /boot/efi  vfat  umask=0077       0  1
/dev/mapper/sysvg-lv_root  /     xfs   defaults,noatime 0 0
/dev/mapper/sysvg-lv_swap  none  swap  sw               0 0
EOF
cat /mnt/target/etc/fstab

findmnt --verify --verbose \
      --tab-file /mnt/target/etc/fstab

## 9. 准备 chroot

## 先处理 DNS：
rm -f /mnt/target/etc/resolv.conf
cp -L /etc/resolv.conf /mnt/target/etc/resolv.conf

## 挂载运行时文件系统：
mount --rbind /dev /mnt/target/dev
mount --make-rslave /mnt/target/dev
mount -t proc proc /mnt/target/proc
mount --rbind /sys /mnt/target/sys
mount --make-rslave /mnt/target/sys
mount --rbind /run /mnt/target/run
mount --make-rslave /mnt/target/run

## 进入目标系统：
chroot /mnt/target /bin/bash

## 验证：
findmnt /
findmnt /boot
findmnt /boot/efi
ls /sys/firmware/efi

## 10. 在 chroot 中安装内核、LVM、XFS和 GRUB
## 强制将 XFS 模块加入 initramfs：
grep -qxF xfs /etc/initramfs-tools/modules ||
    echo xfs >> /etc/initramfs-tools/modules

## 11. 配置 swap resume
echo "RESUME=none" > /etc/initramfs-tools/conf.d/resume

## 12. 生成 initramfs
apt-get purge casper
/bin/cp -f /usr/sbin/update-initramfs.distrib /usr/sbin/update-initramfs
update-initramfs -u -k all

## 检查内核和 initramfs：
ls -lh /boot
ls -l /lib/modules

## 检查 initramfs 是否包含 LVM和 XFS：
lsinitramfs /boot/initrd.img-* |
  grep -E '/lvm$|lvm.conf|xfs\.ko' |
  head -30

## 13. 安装 UEFI GRUB
grub-install \
  --target=x86_64-efi \
  --efi-directory=/boot/efi \
  --bootloader-id=ubuntu \
  --recheck

# 配置超时，SOL
cp -a /etc/default/grub /etc/default/grub.backup

sed -i -E \
  -e '/^GRUB_TIMEOUT_STYLE=/d' \
  -e '/^GRUB_TIMEOUT=/d' \
  -e '/^GRUB_RECORDFAIL_TIMEOUT=/d' \
  -e '/^GRUB_HIDDEN_TIMEOUT=/d' \
  -e '/^GRUB_HIDDEN_TIMEOUT_QUIET=/d' \
  -e '/^GRUB_SERIAL_COMMAND=/d' \
  -e '/^GRUB_TERMINAL=/d' \
  -e '/^GRUB_TERMINAL_INPUT=/d' \
  -e '/^GRUB_TERMINAL_OUTPUT=/d' \
  -e '/^GRUB_CMDLINE_LINUX=/d' \
  -e '/^GRUB_CMDLINE_LINUX_DEFAULT=/d' \
  /etc/default/grub

tee -a /etc/default/grub >/dev/null <<'EOF'
# Serial console configuration
GRUB_TIMEOUT_STYLE=menu
GRUB_TIMEOUT=10
GRUB_RECORDFAIL_TIMEOUT=10
GRUB_SERIAL_COMMAND="serial --unit=0 --speed=115200 --word=8 --parity=no --stop=1"
GRUB_TERMINAL_INPUT="console serial"
GRUB_TERMINAL_OUTPUT="console serial"
GRUB_CMDLINE_LINUX="console=tty0 console=ttyS0,115200n8 earlyprintk=serial,ttyS0,115200,keep"
GRUB_CMDLINE_LINUX_DEFAULT="nomodeset rd.driver.blacklist=nouveau nouveau.modeset=0 namespace.unpriv_enable=1 user_namespace.enable=1 systemd.unified_cgroup_hierarchy=1 systemd.legacy_systemd_cgroup_controller=0 cgroup_no_v1=all nvme_core.multipath=n pci=realloc=off numa_balancing=disable transparent_hugepage=madvise intremap=no_x2apic_optout pciehp.pciehp_debug=y intel_iommu=on iommu=pt intel_idle.max_cstate=0 processor.max_cstate=0 intel_pstate=disable nokaslr"
EOF

systemctl enable serial-getty@ttyS0.service

# 然后生成 GRUB 配置：
update-grub
grub-script-check /boot/grub/grub.cfg

#检查生成结果：
ls -l /boot/grub/grub.cfg
grep -E 'linux|initrd|root=' /boot/grub/grub.cfg | head -30

#正常情况下，内核命令行会包含类似：
#root=/dev/mapper/sysvg-lv_root
#也可能使用根文件系统 UUID，两种都可以。

## 14. 检查 EFI 启动项
efibootmgr -v
find /boot/efi/EFI/ubuntu -maxdepth 1 -type f -ls

#一般应看到：
#EFI/ubuntu/shimx64.efi
#EFI/ubuntu/grubx64.efi
#启用 Secure Boot 时，固件启动项通常应指向签名的：
#\EFI\ubuntu\shimx64.efi
#如果 efibootmgr 报 EFI variables 不可用，说明：
#- LiveCD可能以 Legacy BIOS 模式启动；
#- /sys/firmware/efi/efivars 未挂载；
#- 虚拟机或固件禁止写 EFI NVRAM。
# 优先重新以 UEFI 模式启动 LiveCD，而不是混用 Legacy GRUB。

# efibootmgr -c -w -L "ubuntu24.04" -d "$target_disk" -p 1 -l \\EFI\\ubuntu\\grubx64.efi

## 15. 设置系统基本信息
## 为新系统生成 machine ID：
rm -f /etc/machine-id
systemd-machine-id-setup

## 16. 完整验证

## 测试 fstab：
findmnt --verify --verbose
mount -a
swapon -a
swapon --show

## 检查 LVM：
pvs
vgs
lvs

## 检查启动文件：
ls -lh /boot/vmlinuz-*
ls -lh /boot/initrd.img-*
ls -lh /boot/grub/grub.cfg
efibootmgr -v

##退出 chroot：
exit

## 17. 卸载并重启
sync
umount /mnt/target/boot/efi
umount /mnt/target/boot
umount /mnt/target
reboot
