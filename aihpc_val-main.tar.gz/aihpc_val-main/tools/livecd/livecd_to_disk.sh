#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>
# Install the running Ubuntu LiveCD to one disk (UEFI, LVM, no RAID).
set -Eeuo pipefail
export LC_ALL=C

usage() {
    cat <<'EOF'
Usage: sudo bash livecd_to_disk.sh /dev/nvme0n1
       sudo bash livecd_to_disk.sh /dev/sda

ERASES the selected disk after you type its full path to confirm.
Run from an Ubuntu LiveCD booted in UEFI mode, with Secure Boot disabled.
Fully offline: required packages must already be installed in the LiveCD.
Missing dependencies are reported before any disk changes; nothing is downloaded.
Copies the running system, including installed kernels, drivers and accounts.

Layout: 1 GiB EFI + 4 GiB /boot + LVM (XFS root + swap), no RAID.
Environment overrides (use sudo env NAME=value ...):
  VG_NAME=sysvg        Must not already exist on this machine.
  SWAP_GIB=16          Swap size in GiB; 0 disables swap.
  ROOT_GIB=0           0 uses all remaining VG space; otherwise size in GiB.
  KERNEL_CMDLINE=...   Optional replacement for the filtered LiveCD command line.
                      Hardware/console options are retained by default.
The script unmounts its target on exit and never reboots automatically.
EOF
}
die() { echo "ERROR: $*" >&2; exit 1; }
check_required_packages() {
    local package status
    local -a missing=()
    for package in "$@"; do
        status=$(dpkg-query -W -f='${Status}' "$package" 2>/dev/null) || status=''
        [[ $status == *' ok installed' ]] || missing+=("$package")
    done
    if ((${#missing[@]} > 0)); then
        printf 'Missing or incompletely installed LiveCD packages:\n' >&2
        printf '  %s\n' "${missing[@]}" >&2
        die 'Include these packages when building the LiveCD, then retry. Offline installation cannot continue.'
    fi
}

check_disk_unused() {
    local node name swap_device pv vg existing_vgs existing_pvs nodes swaps mount_status
    existing_vgs=$(vgs --noheadings -o vg_name) || die 'Cannot inspect volume groups.'
    while read -r vg; do
        [[ $vg != "$vg_name" ]] || die "VG $vg_name already exists; choose another VG_NAME."
    done <<< "$existing_vgs"
    existing_pvs=$(pvs --noheadings -o pv_name,vg_name) || die 'Cannot inspect physical volumes.'
    nodes=$(lsblk -nrpo NAME "$target_disk") || die 'Cannot inspect disk descendants.'
    [[ -n $nodes ]] || die 'No disk descendants returned.'
    swaps=$(swapon --noheadings --raw --show=NAME) || die 'Cannot inspect active swap.'
    while read -r node; do
        [[ -z $node ]] && continue
        name=${node##*/}
        mount_status=0
        findmnt -rn -S "$node" >/dev/null || mount_status=$?
        [[ $mount_status != 0 ]] || die "$node is mounted (possibly the LiveCD source). Unmount it yourself first."
        [[ $mount_status == 1 ]] || die "Cannot inspect mounts for $node."
        while read -r swap_device; do
            [[ -n $swap_device ]] || continue
            [[ $(readlink -f -- "$swap_device") != "$node" ]] || die "$node is active swap."
        done <<< "$swaps"
        # Do not destroy a VG that might span additional disks, even if inactive.
        while read -r pv vg; do
            [[ -z $pv || -z $vg ]] && continue
            [[ $(readlink -f -- "$pv") != "$node" ]] || die "$node belongs to VG $vg; remove/migrate it explicitly first."
        done <<< "$existing_pvs"
        compgen -G "/sys/class/block/$name/holders/*" >/dev/null && die "$node has active device-mapper/RAID holders."
    done <<< "$nodes"
    return 0
}

filter_cmdline() {
    local word
    local -a words kept
    read -r -a words <<< "$1"
    kept=()
    for word in ${words[@]+"${words[@]}"}; do
        case $word in
            BOOT_IMAGE=*|initrd=*|boot=*|root=*|rootfstype=*|rootflags=*|resume=*|resume_offset=*|\
            live-*|live_*|casper-*|persistent*|nopersistent|toram*|todisk=*|iso-scan/*|findiso=*|\
            fetch=*|netboot=*|nfsroot=*|ip=*|url=*|showmounts|ignore_uuid|uuid=*|\
            only-ubiquity|maybe-ubiquity|automatic-ubiquity|file=*|preseed/*|autoinstall|ds=*|\
            ro|rw|---|--) ;;
            *) kept+=("$word") ;;
        esac
    done
    printf '%s\n' "${kept[*]-}"
}

# Sourcing exposes helper functions without running the installer.
[[ ${BASH_SOURCE[0]} == "$0" ]] || return 0

[[ ${1:-} != -h && ${1:-} != --help ]] || { usage; exit 0; }
[[ $# == 1 ]] || { usage >&2; exit 1; }
[[ $EUID == 0 ]] || die 'Run as root.'
[[ $(uname -s) == Linux ]] || die 'Run this inside the Linux LiveCD.'
[[ -d /sys/firmware/efi ]] || die 'Boot the LiveCD in UEFI mode first.'
[[ $(findmnt -n -o FSTYPE /) == overlay ]] || die 'Expected a LiveCD overlay root filesystem.'

vg_name=${VG_NAME:-sysvg}
swap_gib=${SWAP_GIB:-16}
root_gib=${ROOT_GIB:-0}
[[ $vg_name =~ ^[a-zA-Z][a-zA-Z0-9_]{0,31}$ ]] || die 'Invalid VG_NAME.'
for size in "$swap_gib" "$root_gib"; do
    [[ $size =~ ^(0|[1-9][0-9]{0,5})$ ]] || die 'Sizes must be non-negative whole GiB (at most 999999).'
done
for command in dpkg dpkg-query; do
    command -v "$command" >/dev/null || die "Missing $command in the LiveCD."
done
case $(dpkg --print-architecture) in
    amd64) grub_target=x86_64-efi; grub_package=grub-efi-amd64-bin; efi_file=grubx64.efi; fallback_file=BOOTX64.EFI ;;
    arm64) grub_target=arm64-efi; grub_package=grub-efi-arm64-bin; efi_file=grubaa64.efi; fallback_file=BOOTAA64.EFI ;;
    *) die 'Only amd64 and arm64 Ubuntu are supported.' ;;
esac

# No APT update/install/download: the LiveCD must contain all dependencies.
check_required_packages parted dosfstools e2fsprogs xfsprogs lvm2 rsync util-linux \
    efibootmgr initramfs-tools initramfs-tools-core grub-common grub2-common "$grub_package"

# Fail before touching the disk if LiveCD tools are missing.
for command in readlink lsblk blockdev findmnt swapon pvs vgs pvcreate vgcreate lvcreate \
    parted partprobe udevadm wipefs mkfs.fat mkfs.ext4 mkfs.xfs mkswap blkid \
    rsync mount umount chroot mktemp od awk sed grep du sync efibootmgr apt-get tr dpkg-divert update-initramfs lsinitramfs depmod grub-install update-grub grub-script-check; do
    command -v "$command" >/dev/null || die "Missing $command. Include it when building the LiveCD; offline installation cannot continue."
done
secure_boot=/sys/firmware/efi/efivars/SecureBoot-8be4df61-93ca-11d2-aa0d-00e098032b8c
[[ -r $secure_boot ]] || die 'Cannot read Secure Boot state; mount efivarfs and retry.'
[[ $(od -An -j4 -N1 -tu1 "$secure_boot" | tr -d ' ') == 0 ]] ||
    die 'This installer uses unsigned GRUB. Disable Secure Boot before installing.'

target_disk=$(readlink -f -- "$1")
[[ -b $target_disk ]] || die "Not a block device: $target_disk"
[[ $(lsblk -dn -o TYPE "$target_disk") == disk ]] || die 'Select a whole physical disk, not a partition, RAID or LV.'
[[ $(blockdev --getro "$target_disk") == 0 ]] || die 'Target disk is read-only.'

check_disk_unused

# rsync -x copies the overlay, not unrelated mounts. Reject separate system trees
# rather than silently omitting them. /boot is copied separately below.
while read -r mounted; do
    case $mounted in
        /bin|/bin/*|/sbin|/sbin/*|/lib|/lib/*|/lib64|/lib64/*|/usr|/usr/*|/var|/var/*|/home|/home/*|/opt|/opt/*|/srv|/srv/*|/etc|/etc/*|/root|/root/*)
            die "Separate system mount $mounted would be omitted; consolidate it before installing." ;;
    esac
done < <(findmnt -rn -o TARGET)
shopt -s nullglob
kernels=(/boot/vmlinuz-*)
((${#kernels[@]})) || die 'No installed kernel in /boot; cannot create a bootable disk.'
for kernel in "${kernels[@]}"; do
    [[ -d /lib/modules/${kernel##*/vmlinuz-} ]] || die "Missing modules for $kernel"
done

# Keep hardware-specific parameters (including quoted values), discard LiveCD
# discovery/root parameters. An override is useful when moving to other hardware.
cmdline=${KERNEL_CMDLINE-$(cat /proc/cmdline)}
cmdline=$(filter_cmdline "$cmdline")

# Allow filesystem metadata and at least 4 GiB of free space beyond the source.
source_bytes=$(du -sx --block-size=1 --exclude=/dev --exclude=/proc --exclude=/sys \
    --exclude=/run --exclude=/tmp --exclude=/mnt --exclude=/media --exclude=/cdrom \
    --exclude=/rofs --exclude=/cow --exclude=/boot / | awk '{print $1}')
disk_bytes=$(blockdev --getsize64 "$target_disk")
root_bytes=$((disk_bytes - (swap_gib + 6) * 1024**3))
if ((root_gib > 0)); then
    ((root_bytes >= root_gib * 1024**3)) || die 'Disk is too small for the requested layout.'
    root_bytes=$((root_gib * 1024**3))
fi
((root_bytes >= source_bytes + 4 * 1024**3)) || die 'Insufficient root space for the LiveCD system plus 4 GiB headroom.'
boot_bytes=$(du -sx --block-size=1 --exclude=/boot/efi /boot | awk '{print $1}')
((boot_bytes < 3 * 1024**3)) || die '/boot needs more space than the fixed 4 GiB partition allows.'

lsblk -o NAME,PATH,SIZE,MODEL,SERIAL,TYPE,FSTYPE,MOUNTPOINTS "$target_disk"
echo "ERASE $target_disk: EFI=1GiB /boot=4GiB VG=$vg_name swap=${swap_gib}GiB root=${root_gib}GiB (0=remaining)."
echo "Kernel command line: $cmdline"
read -r -p "Type $target_disk to erase it and install: " confirmation
[[ $confirmation == "$target_disk" ]] || die 'Cancelled.'
check_disk_unused

target=$(mktemp -d /mnt/livecd-install.XXXXXX)
root_mounted=0
cleanup() {
    local status=$?
    trap - EXIT
    if ((root_mounted)); then
        sync
        if ! umount -R "$target"; then
            echo "WARNING: target still mounted at $target; unmount it before rebooting." >&2
            status=1
        fi
    fi
    rmdir "$target" 2>/dev/null || true
    if ((status != 0)); then
        echo 'Installation did not complete. Do not boot from the target disk yet.' >&2
    fi
    exit "$status"
}
trap cleanup EXIT
trap 'echo "ERROR at line $LINENO: $BASH_COMMAND" >&2' ERR
trap 'exit 130' INT
trap 'exit 143' TERM

wipefs --all "$target_disk"
parted --script "$target_disk" mklabel gpt \
    mkpart ESP fat32 1MiB 1025MiB set 1 esp on \
    mkpart boot ext4 1025MiB 5121MiB \
    mkpart lvm 5121MiB 100% set 3 lvm on
partprobe "$target_disk"
udevadm settle
prefix=$target_disk
[[ $target_disk != *[0-9] ]] || prefix=${target_disk}p
esp=${prefix}1
boot=${prefix}2
pv=${prefix}3
for partition in "$esp" "$boot" "$pv"; do
    [[ -b $partition ]] || die "Partition did not appear: $partition"
    wipefs --all "$partition"
done
mkfs.fat -F 32 -n EFI "$esp"
mkfs.ext4 -F -L boot "$boot"
pvcreate "$pv"
vgcreate "$vg_name" "$pv"
if ((swap_gib > 0)); then
    lvcreate -L "${swap_gib}G" -n lv_swap "$vg_name"
    mkswap -L swap "/dev/$vg_name/lv_swap"
fi
if ((root_gib > 0)); then
    lvcreate -L "${root_gib}G" -n lv_root "$vg_name"
else
    lvcreate -l 100%FREE -n lv_root "$vg_name"
fi
root_lv=/dev/$vg_name/lv_root
mkfs.xfs -f -L rootfs "$root_lv"
mount "$root_lv" "$target"
root_mounted=1
mkdir -p "$target/boot"
mount "$boot" "$target/boot"
mkdir -p "$target/boot/efi"
mount "$esp" "$target/boot/efi"

# A live filesystem can lose temporary files during copying (rsync exit 24).
copy_tree() {
    local status=0
    rsync -aHAXx --numeric-ids --info=progress2 "$@" || status=$?
    [[ $status == 0 || $status == 24 ]] || die "rsync failed ($status)."
}
copy_tree --exclude=/dev/ --exclude=/proc/ --exclude=/sys/ --exclude=/run/ \
    --exclude=/tmp/ --exclude=/mnt/ --exclude=/media/ --exclude=/cdrom/ \
    --exclude=/rofs/ --exclude=/cow/ --exclude=/boot/ --exclude=/lost+found \
    / "$target/"
copy_tree --exclude=/efi/ /boot/ "$target/boot/"
mkdir -p "$target"/{dev,proc,sys,run,tmp,mnt,media,cdrom}
chmod 1777 "$target/tmp"
[[ ! -f $target/etc/fstab ]] || cp -a "$target/etc/fstab" "$target/etc/fstab.livecd"
cat > "$target/etc/fstab" <<EOF
UUID=$(blkid -s UUID -o value "$root_lv") /         xfs  defaults,noatime 0 0
UUID=$(blkid -s UUID -o value "$boot")    /boot     ext4 defaults         0 2
UUID=$(blkid -s UUID -o value "$esp")     /boot/efi vfat umask=0077       0 2
EOF
if ((swap_gib > 0)); then
    echo "UUID=$(blkid -s UUID -o value "/dev/$vg_name/lv_swap") none swap sw 0 0" >> "$target/etc/fstab"
fi
# Old crypttab entries must not trigger prompts for unrelated LiveCD disks.
if [[ -f $target/etc/crypttab ]]; then
    mv "$target/etc/crypttab" "$target/etc/crypttab.livecd"
    : > "$target/etc/crypttab"
fi

# /run is private: do not expose the live system's systemd socket to chroot.
mount --rbind /dev "$target/dev"
mount --make-rslave "$target/dev"
mount -t proc proc "$target/proc"
mount --rbind /sys "$target/sys"
mount --make-rslave "$target/sys"
mount -t tmpfs tmpfs "$target/run"
# All installation commands below run in the TARGET, not in the LiveCD shell.
chroot "$target" /bin/bash -s -- "$grub_target" "$cmdline" "$efi_file" "$fallback_file" <<'CHROOT'
set -Eeuo pipefail
export LC_ALL=C DEBIAN_FRONTEND=noninteractive
grub_target=$1; cmdline=$2; efi_file=$3; fallback_file=$4
# Suppress service startup during package operations, restoring any existing policy.
policy=/usr/sbin/policy-rc.d
[[ ! -e $policy && ! -L $policy ]] || mv "$policy" "$policy.livecd-install"
printf '#!/bin/sh\nexit 101\n' > "$policy"
chmod 755 "$policy"
restore_chroot_files() {
    rm -f "$policy"
    if [[ -e $policy.livecd-install || -L $policy.livecd-install ]]; then
        mv "$policy.livecd-install" "$policy"
    fi

}
trap restore_chroot_files EXIT
# Offline removal only: package scripts restore the update-initramfs diversion.
# --no-download prevents fetching any package even if APT proposes a dependency change.
remove=()
for package in casper lupin-casper live-tools; do
    if [[ $(dpkg-query -W -f='${db:Status-Status}' "$package" 2>/dev/null || true) == installed ]]; then
        remove+=("$package")
    fi
done
((${#remove[@]} == 0)) || apt-get --no-download purge -y "${remove[@]}"
[[ $(dpkg-divert --truename /usr/sbin/update-initramfs) == /usr/sbin/update-initramfs ]] || {
    echo 'Unexpected update-initramfs diversion remains; aborting.' >&2; exit 1;
}
mkdir -p /etc/initramfs-tools/conf.d
for module in xfs dm_mod; do
    grep -qxF "$module" /etc/initramfs-tools/modules || echo "$module" >> /etc/initramfs-tools/modules
done
printf 'RESUME=none\n' > /etc/initramfs-tools/conf.d/resume
printf 'MODULES=most\n' > /etc/initramfs-tools/conf.d/driver-policy
# Each copied kernel gets a fresh disk-boot initramfs, including LVM and XFS.
for image in /boot/vmlinuz-*; do
    version=${image#/boot/vmlinuz-}
    depmod -a "$version"
    if [[ -f /boot/initrd.img-$version ]]; then
        update-initramfs -u -k "$version"
    else
        update-initramfs -c -k "$version"
    fi
    listing=$(lsinitramfs "/boot/initrd.img-$version")
    grep -qE '(^|/)scripts/local-top/lvm2$' <<< "$listing"
    # XFS may be built into the kernel instead of a module.
    if ! grep -q '^CONFIG_XFS_FS=y$' "/boot/config-$version"; then
        grep -qE '/xfs\.ko(\.(xz|gz|zst))?$' <<< "$listing"
    fi
done

mkdir -p /etc/default/grub.d
# A late override also replaces any boot=casper settings in earlier snippets.
{
    printf 'GRUB_TIMEOUT_STYLE=menu\nGRUB_TIMEOUT=10\nGRUB_RECORDFAIL_TIMEOUT=10\n'
    printf 'GRUB_DISABLE_OS_PROBER=true\nGRUB_DISABLE_LINUX_UUID=false\n'
    # grub-mkconfig sources this file with /bin/sh; use POSIX single quoting.
    escaped_cmdline=$(printf '%s' "$cmdline" | sed "s/'/'\\\\''/g")
    printf "GRUB_CMDLINE_LINUX='%s'\n" "$escaped_cmdline"
    printf "GRUB_CMDLINE_LINUX_DEFAULT=''\n"
} > /etc/default/grub.d/zzzz-livecd-to-disk.cfg
# Keep the kernel's inherited SOL console; use the UEFI console for the GRUB menu.
grub-install --target="$grub_target" --efi-directory=/boot/efi \
    --bootloader-id=ubuntu --no-uefi-secure-boot --no-nvram --recheck
# Also supply the default UEFI path for firmware without persistent NVRAM entries.
grub-install --target="$grub_target" --efi-directory=/boot/efi \
    --removable --no-uefi-secure-boot --no-nvram --recheck
update-grub
grub-script-check /boot/grub/grub.cfg
test -s "/boot/efi/EFI/ubuntu/$efi_file"
test -s "/boot/efi/EFI/BOOT/$fallback_file"
grep -qE '^[[:space:]]*linux[[:space:]].*root=' /boot/grub/grub.cfg
findmnt --verify --verbose --tab-file /etc/fstab
# Let systemd generate a new ID on the first disk boot, not the live host's ID.
rm -f /etc/machine-id /var/lib/dbus/machine-id
: > /etc/machine-id
mkdir -p /var/lib/dbus
ln -s /etc/machine-id /var/lib/dbus/machine-id
CHROOT

# NVRAM registration is optional: the fallback loader above is already installed.
if ! efibootmgr -c -d "$target_disk" -p 1 -L ubuntu -l "\\EFI\\ubuntu\\$efi_file"; then
    echo "WARNING: NVRAM entry not created; select the disk's UEFI boot option in firmware." >&2
fi
sync
findmnt -R "$target"
echo "Installation completed on $target_disk. Existing LiveCD accounts/passwords were copied."
echo 'After this script exits successfully, remove the LiveCD and reboot; select the target disk in UEFI.'
