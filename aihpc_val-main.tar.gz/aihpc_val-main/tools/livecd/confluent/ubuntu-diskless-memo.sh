#on mgt2
podman run -d -ti --name u2204 ubuntu:22.04 /bin/bash
podman export u2204 > /scratch/repos/ubuntu/22.04/u2204-container.tar
podman rm -f u2204

#on mgt1
osdeploy import /scratch/repos/ubuntu/22.04/iso/ubuntu-22.04.2-live-server-amd64.iso
osdeploy list

rm -rf /install/build/ubuntu-22.04-x86_64-stateless-junli && \
mkdir -p /install/build/ubuntu-22.04-x86_64-stateless-junli && \
cd /install/build/ubuntu-22.04-x86_64-stateless-junli && \
tar xf /scratch/repos/ubuntu/22.04/u2204-container.tar && \
cp -ar /opt/confluent/lib/imgutil/ubuntu/initramfs-tools/ ./etc/ && \
chmod +x ./etc/initramfs-tools/hooks/confluent && \
cd /tmp

imgutil exec -v /var/lib/confluent/ -v /software:/software /install/build/ubuntu-22.04-x86_64-stateless-junli

if ! `echo $PS1|grep 'IMGUTIL' &>/dev/null`; then
  echo "Not in jail, exiting"
  exit 1
fi

cat > /etc/apt/sources.list <<- EOF
#
deb http://172.16.1.2/ftp/repos/ubuntu/22.04/ubuntu jammy           main multiverse restricted universe
deb http://172.16.1.2/ftp/repos/ubuntu/22.04/ubuntu jammy-updates   main multiverse restricted universe
deb http://172.16.1.2/ftp/repos/ubuntu/22.04/ubuntu jammy-security  main multiverse restricted universe
deb http://172.16.1.2/ftp/repos/ubuntu/22.04/ubuntu jammy-proposed  main multiverse restricted universe
deb http://172.16.1.2/ftp/repos/ubuntu/22.04/ubuntu jammy-backports main multiverse restricted universe
EOF

export DEBIAN_FRONTEND=noninteractive

apt-get update -y && apt --fix-broken install -y
apt-get upgrade -y && \
apt-get install -y \
  gawk dkms libc6-dev grub-efi-amd64 grub-efi-amd64-bin \
  shim-signed tpm2-tools efibootmgr lvm2 \
  openssh-server iputils-ping isc-dhcp-client pciutils \
  curl xfsprogs libfuse2 ifupdown net-tools lsof \
  nfs-kernel-server environment-modules numactl  \
  ubuntu-server network-manager netplan.io apt-utils \
  build-essential bison flex tk nasm gcc make cmake pkg-config gdb autoconf automake \
  libnl-3-dev gfortran libgfortran5 libnl-route-3-dev libnuma-dev  \
  libltdl-dev chrpath autotools-dev debhelper pkg-config quilt swig graphviz \
  libatspi2.0-0 libgbm1 libgtk-3-0 libnotify4 libxcb-dri3-0 xdg-utils \
  libdrm-dev alsa-utils xmlrpc-api-utils libjson-c-dev liboping-dev \
  gtk-doc-tools meson libpciaccess-dev libdrm-intel1 libkmod-dev \
  libprocps-dev libdw-dev libpixman-1-dev libcairo2-dev libudev-dev \
  libunwind-dev libgsl-dev libasound2-dev libxmlrpc-core-c3-dev \
  libjson-c-dev libcurl4-openssl-dev libxrandr-dev valgrind peg libnss3 \
  libdrm-intel1 libva-dev libvpl-dev libx264-dev libx265-dev \
  ipmitool lftp \
  expect libconfig9 libfabric1 libpsm-infinipath1 libpsm2-2 lldpad snmpd tcl-expect

apt-get purge -y snapd cloud-guest-utils cloud-initramfs-copymods cloud-initramfs-dyn-netconf

echo 'kernel.printk = 4 4 1 7' >> /etc/sysctl.conf
sed -i 's:managed=.*:managed=true:g' /etc/NetworkManager/NetworkManager.conf
cat > /etc/netplan/00-installer-config.yaml <<- EOF
network:
  version: 2
  renderer: NetworkManager
EOF

systemctl disable snapd.apparmor.service snapd.autoimport.service snapd.core-fixup.service \
  snapd.recovery-chooser-trigger.service \
  snapd.seeded.service snapd.service snapd.aa-prompt-listener.service \
  e2scrub_reap.service lxd-agent.service open-vm-tools.service \
  ubuntu-advantage.service unattended-upgrades.service ua-reboot-cmds.service
systemctl enable getty@ttyS0.service
systemctl enable getty@tty0.service
ls /etc/systemd/system/multi-user.target.wants/
ln -sf /lib/systemd/system/multi-user.target /etc/systemd/system/default.target

export KVER=5.15.0-94-generic 

apt-get install -y \
   linux-image-unsigned-${KVER} \
   linux-headers-${KVER}  \
   linux-modules-extra-${KVER} \
   linux-tools-common \
   linux-tools-generic \
   linux-tools-${KVER}

rm -f /usr/lib/shim/shimx64.efi.signed
cp /usr/lib/shim/shimx64.efi.signed.latest /usr/lib/shim/shimx64.efi.signed

#ln -sf /lib/modules/${KVER} /lib/modules/$(uname -r)
wget http://172.16.1.2/ftp/repos/ubuntu/mlx/MLNX_OFED_LINUX-23.10-1.1.9.0-ubuntu22.04-x86_64.tgz -O - | tar -xzvf - -C /tmp
cd /tmp/MLNX_OFED_LINUX-*
./mlnxofedinstall --kernel ${KVER} --add-kernel-support --enable-affinity --enable-mlnx_tune --without-fw-update --enable-opensm --force --tmpdir /tmp
rm -rf /tmp/MLNX_*
cd /tmp

cat > /etc/apt/sources.list.d/agama.list <<- EOF
deb [trusted=yes arch=amd64] http://172.16.1.2/ftp/repos/agama/hotfix_agama-ci-devel-803.8/ubuntu/gfx-debs-per-build untested/main/agama/hotfix_agama-ci-devel-803/jammy hotfix_agama-ci-devel-803.8
EOF
apt-get update
apt-get install -y -q --no-install-recommends \
    clinfo ocl-icd-opencl-dev ocl-icd-libopencl1 \
    intel-opencl-icd intel-level-zero-gpu level-zero level-zero-dev \
    xpu-smi
apt-get install -y intel-i915-dkms intel-fw-gpu 
dkms status

wget http://172.16.1.2/ftp/os/ubuntu/iefs/IntelEth-Basic.UBUNTU2204-x86_64.11.5.1.1.1.tgz -O - | tar -xzvf - -C /tmp
cd /tmp/IntelEth-Basic*
export MOFED_PATH=/usr/src/ofa_kernel/x86_64/${KVER}
export INTEL_GPU_DIRECT=CURRENT_KERNEL
#./INSTALL -a --without-depcheck -R $KVER --rebuild -vv # -G
apt install ./repos/IEFS_PKGS/DEBS/iefs-kernel-*
sed -i.ori -e '/#include "compat_common.h"/a#define IB_CM_LISTEN_WITHOUT_MASK' /var/lib/dkms/iefs-kernel-updates/6323/source/compat/compat.h
rm -rf /var/lib/dkms/iefs-kernel-updates/6323/build/
dkms build -m iefs-kernel-updates -v 6323 -k $KVER --verbose
dkms install -m iefs-kernel-updates -v 6323 -k $KVER
apt install -y ./repos/IEFS_PKGS/DEBS/libpsm3-fi_11.5.1.1-1_amd64.deb
apt install -y ./repos/IEFS_PKGS/DEBS/eth-tools-basic_11.5.1.1-1_amd64.deb
apt install -y ./repos/IEFS_PKGS/DEBS/iefsconfig_11.5.1.1-1_all.deb
rm -rf /tmp/IntelEth-Basic*
cd /tmp/

chmod -R a+x /etc/initramfs-tools/
chmod -R a+x /usr/share/initramfs-tools/
cat >> /etc/initramfs-tools/hooks/confluent <<- EOF
manual_add_modules i915 i915_spi iaf mei-gs mei-me mei mei_iaf mei_hdcp mei_pxp mei_wdt intel_vsec pmt_class pmt_crashlog pmt_telemetry rv
EOF
update-initramfs -k ${KVER} -u -v 2>&1 | tee /tmp/log.txt 
lsinitramfs /boot/initrd.img-${KVER} | grep -E 'i915.ko|iaf.ko|pvc|mei|rv.ko|mlx5'

mkdir -p /software /scratch
cat > /etc/fstab <<- EOF
172.16.1.1:/install/software /software nfs4 ro,relatime,vers=4.2,rsize=1048576,wsize=1048576,namlen=255,soft,proto=tcp,timeo=600,retrans=2,sec=sys,local_lock=none,nofail 0 0
172.16.1.1:/home /home nfs4 rw,relatime,vers=4.2,rsize=1048576,wsize=1048576,namlen=255,soft,proto=tcp,timeo=600,retrans=2,sec=sys,local_lock=none,nofail 0 0  
172.16.2.141:/data/d01/scratch/ /scratch/ nfs4 rw,noatime,vers=4.2,rsize=1048576,wsize=1048576,namlen=255,soft,proto=tcp,nconnect=4,timeo=600,retrans=2,sec=sys,local_lock=none,_netdev 0 0
EOF

mkdir -p /install
ln -sf /software /install/software
cat >> /etc/profile <<- 'EOF'
export MODULEPATH=/software/intel-comp-rt/modules:/software/oneAPI/nightly/modules/compiler:/software/oneAPI/nightly/modules/libraries:/software/oneAPI/nightly/modules/tools:/software/oneAPI/modules:/software/opencl/modules:/software/utils/modules
EOF

rm -rf /tmp/*
truncate -s 0 /etc/machine-id
truncate -s 0 /root/.bash_history
history -c
exit

rm -rf /var/lib/confluent/public/os/ubuntu-22.04-x86_64-stateless-junli
imgutil pack --unencrypted /install/build/ubuntu-22.04-x86_64-stateless-junli ubuntu-22.04-x86_64-stateless-junli


### Slowing down kernel messages on boot: https://wiki.ubuntu.com/Kernel/KernelDebuggingTricks
#net.ifname=net0:90:2e:16:0c:b3:e7 ip=172.16.1.22:172.16.1.1:255.255.255.0::net0
cat > /var/lib/confluent/public/os/ubuntu-22.04-x86_64-stateless-junli/boot.ipxe <<- EOF
#!ipxe
imgfetch boot/kernel initrd=site.cpio initrd=addons.cpio initrd=distribution confluent_imagemethod=untethered boot_delay=1 net.ifnames=0 biosdevname=0 console=ttyS0 console=tty0 pci=realloc=off debug modprobe.blacklist=ast pci=pcie_bus_perf drm.debug=0xe i915.force_probe=* i915.enable_hangcheck=0 i915.prelim_override_p2p_dist=1 i915.enable_rc6=1 i915.rc6_ignore_steppings=1 i915.enable_iaf=1 i915.enable_fake_int_wa=0
imgfetch boot/initramfs/site.cpio
imgfetch boot/initramfs/addons.cpio
imgfetch boot/initramfs/distribution
imgload kernel
imgexec kernel
EOF

##### Hacking
rm -f /var/lib/confluent/public/os/ubuntu-22.04-x86_64-stateless-junli/boot/initramfs/addons.cpio
cp /opt/confluent/lib/osdeploy/ubuntu20.04-diskless/initramfs/addons.cpio \
     /var/lib/confluent/public/os/ubuntu-22.04-x86_64-stateless-junli/boot/initramfs/addons.cpio
mkdir -p  /var/lib/confluent/public/os/ubuntu-22.04-x86_64-stateless-junli/boot/initramfs/tmp
cd /var/lib/confluent/public/os/ubuntu-22.04-x86_64-stateless-junli/boot/initramfs/tmp
cpio -idv < ../addons.cpio
sed -i -e '/v4meth=/s:ipv6_method:ipv4_method:g' scripts/init-premount/confluent
find . | cpio -H newc -ov --owner root:root > ../addons.cpio
cd /var/lib/confluent/public/os/ubuntu-22.04-x86_64-stateless-junli/

cp -ar /opt/confluent/lib/osdeploy/ubuntu20.04-diskless/profiles/default/* \
     /var/lib/confluent/public/os/ubuntu-22.04-x86_64-stateless-junli/
mv /var/lib/confluent/public/os/ubuntu-22.04-x86_64-stateless-junli/scripts/imageboot.sh{,.ori}
cat > /var/lib/confluent/public/os/ubuntu-22.04-x86_64-stateless-junli/scripts/imageboot.sh <<- 'EOF'
#!/bin/bash
echo "[DEBUG]: Begin to execute imageboot.sh" > /dev/ttyS0
confluent_profile=$(grep ^profile: /etc/confluent/confluent.deploycfg| awk '{print $2}')
confluent_proto=$(grep ^protocol: /etc/confluent/confluent.deploycfg| awk '{print $2}')
confluent_mgr=$(grep ^deploy_server: /etc/confluent/confluent.deploycfg| awk '{print $2}')
EOF
cat /var/lib/confluent/public/os/ubuntu-22.04-x86_64-stateless-junli/scripts/imageboot.sh.ori \
    >> /var/lib/confluent/public/os/ubuntu-22.04-x86_64-stateless-junli/scripts/imageboot.sh
sed -i 's:confluennt_imagemethtod=untethered:confluent_imagemethod=untethered:g' /var/lib/confluent/public/os/ubuntu-22.04-x86_64-stateless-junli/scripts/imageboot.sh

cp -arv /opt/confluent/lib/osdeploy/el9-diskless/profiles/default/scripts/onboot* \
/var/lib/confluent/public/os/ubuntu-22.04-x86_64-stateless-junli/scripts/
sed -i -e 's:^rpm --import:#rpm --import:g' \
   -e 's:^\(run_remote_python.*\):#\1:g' \
   -e 's:#!/bin/sh:#!/bin/bash:g' \
  /var/lib/confluent/public/os/ubuntu-22.04-x86_64-stateless-junli/scripts/onboot.sh

cat > /var/lib/confluent/public/os/ubuntu-22.04-x86_64-stateless-junli/scripts/onboot.d/00_add_users.sh <<- 'EOF'
#!/bin/bash
mkdir -p /opt/home/
useradd -m -d /opt/home/intel -s /bin/bash intel -u 65533 -g sudo -G render,video
echo 'intel:intel@123' | chpasswd
exit 0
EOF

cat > /var/lib/confluent/public/os/ubuntu-22.04-x86_64-stateless-junli/scripts/onboot.d/01_add_packages.sh <<- 'EOF'
#!/bin/bash
x86_energy_perf_policy normal &>/dev/null
cpupower idle-set -E &>/dev/null
cpupower -c all frequency-set -g performance &>/dev/null
echo 'set ssl:verify-certificate no' >> /etc/lftp.conf
exit 0
EOF

cat > /var/lib/confluent/public/os/ubuntu-22.04-x86_64-stateless-junli/scripts/onboot.d/02_fixed_hosts.sh <<- 'EOF'
cat > /etc/hosts << __END__
127.0.0.1       localhost
$(cat /etc/confluent/confluent.deploycfg | grep ipv4_address | awk '{print $2}') $(grep NODENAME /etc/confluent/confluent.info|awk '{print $2}')
__END__
EOF

cp /var/lib/confluent/public/os/sle-15.4-x86_64-stateless-2023-08-28-01/scripts/onboot.d/{03_setup_florence_users.sh,04_setup_ssh_certificates.sh,05_setup_ib_address.sh} \
   /var/lib/confluent/public/os/ubuntu-22.04-x86_64-stateless-junli/scripts/onboot.d/
cat > /var/lib/confluent/public/os/ubuntu-22.04-x86_64-stateless-junli/scripts/onboot.d/06_mod_florence_users.sh <<- 'EOF'
for i in $(grep -E 'lenovo:|intel:|lrz:|epfl:|linaro:' /etc/group|cut -f4 -d':'|tr ',' ' '); do usermod -s /bin/bash -a -G render,video $i; done
EOF

cat > /var/lib/confluent/public/os/ubuntu-22.04-x86_64-stateless-junli/scripts/onboot.d/07_gen_hosts.sh <<- 'EOF'
wget http://172.16.1.2/ftp/os/ubuntu/misc/hosts -O /etc/hosts
EOF

cat > /var/lib/confluent/public/os/ubuntu-22.04-x86_64-stateless-junli/scripts/onboot.d/08_i915_wa.sh <<- 'EOF'
#!/bin/sh
export PATH=/sbin:/bin:/usr/sbin:/usr/bin
for ENGINE in $(find /sys/class/drm/card?/engine -maxdepth 1 -regex '.*/[rc]cs.*'); do
   echo 0 > $ENGINE/preempt_timeout_ms
done

for i in /sys/class/drm/card*/engine/*/heartbeat_interval_ms; do echo 0 > $i; done;
for i in /sys/class/drm/card*/engine/*/preempt_timeout_ms; do echo 0 > $i; done;
for i in /sys/class/drm/card*/engine/*/max_busywait_duration_ns; do echo 0 > $i; done;
for i in /sys/class/drm/card*/engine/*/stop_timeout_ms; do echo 0 > $i; done;

lspci -D|grep Display|awk '{print $1}'|while read i
do
  echo on > /sys/bus/pci/devices/$i/power/control
done

cat >> /etc/sysctl.conf <<- END
kernel.perf_event_paranoid=-1
dev.i915.perf_stream_paranoid=0
vm.max_map_count=131060
# kernel.numa_balancing=0
vm.zone_reclaim_mode=1
kernel.kptr_restrict=0
END

cat >> /etc/security/limits.conf <<- 'END'
* hard stack unlimited
* soft stack unlimited
* hard memlock unlimited
* soft memlock unlimited
* soft nofile 1048575
* hard nofile 1048575
END
sysctl -p
EOF


cat > /var/lib/confluent/public/os/ubuntu-22.04-x86_64-stateless-junli/scripts/onboot.d/09_iefs_settings.sh <<- 'EOF'
cat >> /etc/security/limits.conf <<- __END__
# -- All Intel Eth FS Settings Start here --
# [ICS VERSION STRING: unknown]
# User space Infiniband verbs require memlock permissions
# if desired you can limit these permissions to the users permitted to use Intel Eth FS
# and/or reduce the limits.  Keep in mind this limit is per user
# (not per process)
* hard memlock unlimited
* soft memlock unlimited
* hard stack unlimited
* soft stack unlimited
# -- All Intel Eth FS Settings End here --
* soft nofile 1048575
* hard nofile 1048575
__END__
EOF

chmod +x /var/lib/confluent/public/os/ubuntu-22.04-x86_64-stateless-junli/scripts/onboot.d/*

nodedeploy -n compute22 ubuntu-22.04-x86_64-stateless-junli
nodeconsole compute22

###########################
## IMB-MPI1 Test

for i in compute31 compute35
do
  ssh $i "cpupower -c all frequency-set -g performance && cpupower idle-set -E" &>/dev/null
done

source /software/oneAPI/2024.0/setvars.sh --force

mpirun \
  -genv PATH=$PATH \
  -genv LD_LIBRARY_PATH=$LD_LIBRARY_PATH \
  -genv PSM3_NIC=mlx5_0 \
  -genv I_MPI_HYDRA_BOOTSTRAP=ssh \
  -genv I_MPI_PIN_DOMAIN=auto -genv I_MPI_PIN_ORDER=bunch -genv I_MPI_PIN_CELL=core \
  -genv I_MPI_DEBUG=7 \
  -genv I_MPI_FABRICS=ofi \
  -genv I_MPI_OFI_PROVIDER=psm3 -genv PSM3_IDENTIFY=1 -genv PSM3_RDMA=1 \
  -hosts compute31,compute35 \
  -perhost 4 -np 8 \
  $I_MPI_ROOT/opt/mpi/benchmarks/imb/IMB-MPI1 -iter 1000 -npmin 2 -mem 10 -msglog 13:14 Uniband 

mpirun \
  -genv PATH=$PATH \
  -genv LD_LIBRARY_PATH=$LD_LIBRARY_PATH \
  -genv UCX_NET_DEVICES="mlx5_0:1" \
  -genv I_MPI_HYDRA_BOOTSTRAP=ssh \
  -genv I_MPI_PIN_DOMAIN=auto -genv I_MPI_PIN_ORDER=bunch -genv I_MPI_PIN_CELL=core \
  -genv I_MPI_DEBUG=7 \
  -genv I_MPI_FABRICS=ofi \
  -genv I_MPI_OFI_PROVIDER=mlx \
  -hosts compute31,compute35 \
  -perhost 4 -np 8 \
  $I_MPI_ROOT/opt/mpi/benchmarks/imb/IMB-MPI1 -iter 1000 -npmin 2 -mem 10 -msglog 13:14 Uniband 

#################

## nodeboot compute22 hd

# 
# ISSUE: block at and no progress anymore
# [  114.120418] mlx5_core 0000:b8:00.0 eth1: Link up
# [  114.230030] IPv6: ADDRCONF(NETDEV_CHANGE): eth1: link becomes ready
# [  115.610317] mlx5_core 0000:b8:00.1 eth2: Link down
# [  124.317447] Kernel panic - not syncing: Attempted to kill init! exitcode=0x00000000
# [  124.419756] CPU: 1 PID: 1 Comm: bash Not tainted 5.15.0-83-generic #92-Ubuntu
# [  124.515338] Hardware name: Lenovo ThinkSystem SD650-I V3/SB27B24405, BIOS USE117U-3.11 06/29/2023
# [  124.633747] Call Trace:
# [  124.667473]  <TASK>
# [  124.696578]  show_stack+0x52/0x5c
# [  124.741687]  dump_stack_lvl+0x4a/0x63
# [  124.791340]  dump_stack+0x10/0x16

#HOw to debug:
cd /var/lib/confluent/public/os/ubuntu-22.04-x86_64-stateless-junli/boot/initramfs/
mkdir tmp && cd tmp
mv ../addons.cpio ../addons.cpio.bak
cpio -idv < ../addons.cpio.bak
## No need to configure net as at very early stage, compute node will download /etc/confluent/confluent.deploycfg using ipv6 from confluent manager restfull API
## To simplify this, just set the IP static manully
cat > scripts/init-premount/confluent <<- '__END__'
#!/bin/bash
ip link set eth1 up
ip addr add dev eth1 172.16.1.22/24
ip route add default via 172.16.1.1
echo sshd:x:30:30:SSH User:/var/empty/sshd:/sbin/nologin >> /etc/passwd
mkdir -p /run/sshd
mkdir -p /etc/ssh
cat > /etc/ssh/sshd_config <<- EOF
Port 2222
PermitRootLogin yes
EOF
ssh-keygen -A
/usr/sbin/sshd
mkdir -p /root/.ssh
cat > /root/.ssh/authorized_keys <<- EOF
ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIPAtkFmAErkcvZI1qUxELs+LzlKJlChhs1X7haB7KUEJ Confluent Automation by mgt1
ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQD1o9F8+YqIbRFjXmwMowKtR7VM0n9u3B1h3WISa2YEQnsu+SMUVn/hNheU33IIbaFAPEQrTymGhLsTeZOiNwvsT4WbVJ8ErC0lR3EyYBzKh6xTVY09GyaHzmSN8E3r3vbgxzviiquXioV018q003ojAYIJol1NJBzFS0ZmGHixuQ2c5+LOaSDoeqvzILRh7PNNJCEr08GxRsqm5IaBlFU5ClCZEGkvPqjd1srRRzMnOS/oYrew7fm4hMP8Nr4/8tBJdVftqk2HerE2eNH7+IL367Ne4uK0b03mfVZNVfKobV74D8NGLQH02Z6xrE2jP9B+2SJYqffvAA4qCh6CZxQn8iKU1bcmtdbcgYTNSSDN7HsES1mEiKviogJxXpXWblKzI6tDyY1yB0NwV3V1aPuVVLRZZtDh0wgUwtct2CNolpA8DuW/Wesv7zNXUeS1FNvSauR6lO8u2iayedePKaOgK6h0a07w67oc8221sG/3mai46a2h+ZInzmPB0Fd1eBU= root@mgt1
EOF
__END__
find . | cpio -H newc -ov --owner root:root > ../addons.cpio
nodedeploy -n compute22 ubuntu-22.04-x86_64-stateless-junli

#After the node up, it will stay at
# [  127.547684] mlx5_core 0000:b8:00.0 eth1: Link up
# [  127.654673] IPv6: ADDRCONF(NETDEV_CHANGE): eth1: link becomes ready
## Then use ssh to login to node as root to debug
## Put some text to console
#echo "DEBUG INFO xxxx" > /dev/ttyS0