podman run --rm -ti -v $PWD:/mnt -w /mnt rockylinux:9.2 /bin/bash
yum -y install yum-utils createrepo_c
bash mirror.sh

#on mgt2
podman run -d -ti --name r9u2 rockylinux:9.2 /bin/bash
podman export r9u2 > /scratch/repos/rocky/9.2/rocky9.2-container.tar
podman rm -f r9u2

#on mgt1

# https://hpc.lenovo.com/users/documentation/confluentdiskless.html

osdeploy import /scratch/repos/rocky/9.2/isos/Rocky-9.2-x86_64-minimal.iso
osdeploy list

rm -rf /install/build/rocky-9.2-x86_64-stateless-junli
imgutil build -s rocky-9.2-x86_64 /install/build/rocky-9.2-x86_64-stateless-junli  #This will failed, but diskless conf generated
cd /install/build/rocky-9.2-x86_64-stateless-junli
tar xvf /scratch/repos/rocky/9.2/rocky9.2-container.tar
cd /

imgutil exec -v /var/lib/confluent/ -v /software:/software /install/build/rocky-9.2-x86_64-stateless-junli
if ! `echo $PS1|grep 'IMGUTIL' &>/dev/null`; then
  echo "Not in jail, exiting"
  exit 1
fi

rm -rf /etc/yum.repos.d/*
cat > /etc/yum.repos.d/os.repo <<- EOF
[BaseOS]
name=BaseOS
baseurl=http://172.16.1.2/ftp/repos/rocky/9.2/BaseOS
enabled=1
gpgcheck=0

[AppStream]
name=AppStream
baseurl=http://172.16.1.2/ftp/repos/rocky/9.2/AppStream/
enabled=1
gpgcheck=0

[devel]
name=devel
baseurl=http://172.16.1.2/ftp/repos/rocky/9.2/devel/
enabled=1
gpgcheck=0

[CRB]
name=CRB
baseurl=http://172.16.1.2/ftp/repos/rocky/9.2/CRB/
enabled=1
gpgcheck=0

[extras]
name=extras
baseurl=http://172.16.1.2/ftp/repos/rocky/9.2/extras/
enabled=1
gpgcheck=0

[epel]
name=epel
baseurl=http://172.16.1.2/ftp/repos/epel/Everything
enabled=1
gpgcheck=0
EOF

yum clean all
yum repolist
yum update -y
rm -f /etc/yum.repos.d/rocky*.repo
yum update -y
yum install -y \
  openssh-server openssh-clients bash-completion vim-enhanced vim-common \
  net-tools device-mapper-multipath wget pciutils man man-pages which \
  strace tree sysstat dstat iotop hdparm sg3_utils hwloc \
  file diffutils rsync bc numactl lftp net-tools lshw nfs-utils ipmitool \
  gcc gcc-c++ gcc-gfortran gdb bc iperf3 ncurses-devel openssl openssl-devel \
  bison flex rpm-build libtool autoconf automake cmake libudev-devel \
  binutils perl-generators pkgconfig systemd-devel valgrind-devel \
  libnl3-devel ninja-build pandoc elfutils-libelf-devel \
  gtk3 libXScrnSaver gtk2 pango libstdc++.i686  glibc.i686 libgcc.i686 \
  perl-Math-BigInt expect net-snmp net-snmp-utils perl \
  python3-devel lsof kernel-rpm-macros createrepo_c tk \
  environment-modules libnsl git dkms tcsh libuuid-devel numactl-devel \
  shim grub2 grub2-efi-x64 dracut-network tpm2-tools efibootmgr lvm2 dhclient tuned biosdevname \
  python-unversioned-command NetworkManager-config-server

yum install -y --allowerasing @core

yum install -y --allowerasing {kernel,kernel-devel,kernel-headers,kernel-modules,kernel-tools,kernel-core,kernel-modules-extra,kernel-abi-stablelists,perf,python3-perf}
rm -f /boot/*-rescue-*
#remove old kernels
# rpm -e $(rpm -qa|grep 5.14.0-284.11.1)
export KVER=$(rpm -q kernel-devel|sed 's/kernel-devel-//g')

cat > /etc/yum.repos.d/agama.repo <<- EOF
[hotfix_agama-ci-devel-736.9]
name=hotfix_agama-ci-devel-736.9
baseurl=http://172.16.1.2/ftp/repos/agama/hotfix_agama-ci-devel-736.9/rhel-9.2
enabled=1
gpgcheck=0
EOF
yum install -y intel-i915-dkms  intel-fw-gpu
dkms status

yum install -y xpu-smi intel-opencl intel-media intel-mediasdk libmfxgen1 libvpl2\
  level-zero intel-level-zero-gpu level-zero-devel intel-igc-opencl-devel \
  mesa-dri-drivers mesa-vulkan-drivers \
  mesa-vdpau-drivers libdrm mesa-libEGL mesa-libgbm mesa-libGL \
  mesa-libxatracker  libvpl-tools intel-metrics-discovery \
  intel-metrics-library intel-igc-core intel-igc-cm \
  libva libva-utils  intel-gmmlib libmetee intel-gsc intel-ocloc \
  clinfo opencl-headers ocl-icd-devel

mkdir -p /opt/home/
useradd -b /opt/home intel -u 65533 -g wheel -G render,video
echo 'intel:intel@123' | chpasswd

#Optimize for serial console use
#https://access.redhat.com/documentation/en-us/red_hat_enterprise_linux/9/html/managing_monitoring_and_updating_the_kernel/getting-started-with-kernel-logging_managing-monitoring-and-updating-the-kernel
echo 'kernel.printk = 4 4 1 7' >> /etc/sysctl.conf

wget http://172.16.1.2/ftp/repos/rocky/mlx/MLNX_OFED_LINUX-23.07-0.5.0.0-rhel9.2-x86_64.tgz -O - | tar -xzvf - -C /tmp
cd /tmp/MLNX_OFED_LINUX-*
./mlnxofedinstall --kernel ${KVER} --add-kernel-support --enable-affinity --enable-mlnx_tune --without-fw-update --enable-opensm --force --tmpdir /tmp --distro rhel9.2
rm -rf /tmp/MLNX_*
cd /

#Install the build IEFS packags
cat > /etc/yum.repos.d/iefs.repo <<- EOF
[iefs-11.5.1.1]
name=iefs-11.5.1.1
baseurl=http://172.16.1.2/ftp/repos/rocky/iefs/rpms/11.5.1.1
enabled=1
gpgcheck=0
EOF
yum install -y \
  iefs-kernel-updates-devel iefs-kernel-updates-dkms \
  kmod-iefs-kernel-updates libpsm3-fi
dkms status
export MOFED_PATH=/usr/src/ofa_kernel/x86_64/${KVER}
export INTEL_GPU_DIRECT=CURRENT_KERNEL
export LEX=flex
export YACC=bison1
dkms build -m iefs-kernel-updates -v 5000oneapize -k ${KVER}
dkms install -m iefs-kernel-updates -v 5000oneapize -k ${KVER}
dkms status

### systemd network network-manager conflict with confluent, disable them
### dracut --kver $KVER --list-modules
#####+ diskless base terminfo
dracut --kver ${KVER} -f -N \
  --add "diskless" \
  --omit "systemd network network-manager" \
  --fwdir /lib/firmware/updates:/lib/firmware \
  --add-drivers "compat i915 i915_spi iaf intel_vsec mei-gsc mei-me mei mei_hdcp mei_iaf mei_pxp mei_wdt pmt_class pmt_crashlog pmt_telemetry ipmi_si ipmi_devintf ipmi_msghandler mlx5_core mlx5_ib rv"
lsinitrd /boot/initramfs-${KVER}.img | grep -E 'i915.ko|iaf.ko|pvc|mei|rv.ko|mlx5'

mkdir -p /software /scratch
cat > /etc/fstab <<- EOF
172.16.1.1:/install/software /software nfs4 ro,relatime,vers=4.2,rsize=1048576,wsize=1048576,namlen=255,soft,proto=tcp,timeo=600,retrans=2,sec=sys,local_lock=none,nofail 0 0
172.16.1.1:/home /home nfs4 rw,relatime,vers=4.2,rsize=1048576,wsize=1048576,namlen=255,soft,proto=tcp,timeo=600,retrans=2,sec=sys,local_lock=none,nofail 0 0  
172.16.1.2:/scratch /scratch/ nfs4 rw,relatime,vers=4.2,rsize=1048576,wsize=1048576,namlen=255,soft,proto=tcp,timeo=600,retrans=2,sec=sys,local_lock=none,nofail 0 0
EOF

mkdir -p /install
ln -sf /software /install/software
cat >> /etc/profile <<- 'EOF'
export MODULEPATH=/software/intel-comp-rt/modules:/software/oneAPI/nightly/modules/compiler:/software/oneAPI/nightly/modules/libraries:/software/oneAPI/nightly/modules/tools:/software/oneAPI/modules:/software/opencl/modules:/software/utils/modules
EOF


#systemctl disable firewalld
#rm -f /etc/NetworkManager/system-connections/*
#rm -f /etc/systemd/system/getty.target.wants/getty*
#ln -sf /usr/lib/systemd/system/getty@.service /etc/systemd/system/getty.target.wants/getty@ttyS0.service
#ln -sf /usr/lib/systemd/system/getty@.service /etc/systemd/system/getty.target.wants/getty@tty1.service
#systemctl enable getty@ttyS0.service
#systemctl enable getty@tty1.service
# 
# echo hpc-compute > /etc/tuned/active_profile
# systemctl enable tuned
# 
rm -rf /tmp/*
truncate -s 0 /etc/machine-id
truncate -s 0 /root/.bash_history
history -c
exit

rm -rf /var/lib/confluent/public/os/rocky-9.2-x86_64-stateless-junli
imgutil pack \
  /install/build/rocky-9.2-x86_64-stateless-junli \
  rocky-9.2-x86_64-stateless-junli

cat > /var/lib/confluent/public/os/rocky-9.2-x86_64-stateless-junli/boot.ipxe <<- EOF
#!ipxe
# For Debug: modprobe.blacklist=ast,i915,iaf,compat,mei_me
imgfetch boot/kernel initrd=site.cpio initrd=addons.cpio initrd=distribution confluent_imagemethod=untethered net.ifnames=0 biosdevname=0 console=ttyS0 console=tty1 selinux=0 audit=0 pci=realloc=off modprobe.blacklist=ast,kvm_intel pci=pcie_bus_perf drm.debug=0xe i915.force_probe=* i915.enable_hangcheck=0 i915.prelim_override_p2p_dist=1 i915.enable_rc6=1 i915.rc6_ignore_steppings=1 i915.enable_iaf=1 i915.enable_fake_int_wa=0 numa_zonelist_order=N nosmap intel_pstate=disable kpti edd=off pcie_ports=native efi=nosoftreserve
imgfetch boot/initramfs/site.cpio
imgfetch boot/initramfs/addons.cpio
imgfetch boot/initramfs/distribution
imgload kernel
imgexec kernel
EOF
ln -sf /opt/confluent/lib/osdeploy/el9-diskless/initramfs/addons.cpio \
  /var/lib/confluent/public/os/rocky-9.2-x86_64-stateless-junli/boot/initramfs/addons.cpio
#https://github.com/lenovo/confluent/tree/master/confluent_osdeploy/el9-diskless/profiles/default
cp -ar /opt/confluent/lib/osdeploy/el9-diskless/profiles/default/* \
  /var/lib/confluent/public/os/rocky-9.2-x86_64-stateless-junli/

sed -i.ori -e '/kill .*systemd-udevd .*/i mv /lib/firmware /lib/firmware-ramfs\nln -s /sysroot/lib/firmware /lib/firmware' \
  /var/lib/confluent/public/os/rocky-9.2-x86_64-stateless-junli/scripts/imageboot.sh

cat > /var/lib/confluent/public/os/rocky-9.2-x86_64-stateless-junli/scripts/onboot.d/01_i915_wa.sh <<- 'EOF'
#!/bin/sh
export PATH=/sbin:/bin:/usr/sbin:/usr/bin
for ENGINE in $(find /sys/class/drm/card?/engine -maxdepth 1 -regex '.*/[rc]cs.*'); do
   echo 0 > $ENGINE/preempt_timeout_ms
done

for i in /sys/class/drm/card*/engine/*/heartbeat_interval_ms; do echo 0 > $i; done;
for i in /sys/class/drm/card*/engine/*/preempt_timeout_ms; do echo 0 > $i; done;
for i in /sys/class/drm/card*/engine/*/max_busywait_duration_ns; do echo 0 > $i; done;
for i in /sys/class/drm/card*/engine/*/stop_timeout_ms; do echo 0 > $i; done;

lspci -D|grep Display|awk '{print $1}'|while read i
do
  echo on > /sys/bus/pci/devices/$i/power/control
done

cat >> /etc/sysctl.conf <<- END
kernel.perf_event_paranoid=-1
dev.i915.perf_stream_paranoid=0
vm.max_map_count=131060
# kernel.numa_balancing=0
vm.zone_reclaim_mode=1
kernel.kptr_restrict=0
END

cat >> /etc/security/limits.conf <<- 'END'
* hard stack unlimited
* soft stack unlimited
* hard memlock unlimited
* soft memlock unlimited
* soft nofile 1048575
* hard nofile 1048575
END
sysctl -p
EOF
chmod +x \
  /var/lib/confluent/public/os/rocky-9.2-x86_64-stateless-junli/scripts/onboot.d/*

nodedeploy -n compute34 rocky-9.2-x86_64-stateless-junli
nodeconsole compute34

##############################################################################
# How to build IEFS and PSM3 on RockyLinux9.2

export KVER=$(rpm -q kernel-devel|sed 's/kernel-devel-//g')
#https://github.com/intel/iefs-kernel-updates/archive/refs/heads/hpc-eth-11_5.zip
#wget http://172.16.1.2/ftp/repos/rocky/iefs/source/iefs-kernel-updates.tar.gz -O - | tar -xzvf - -C /tmp
wget http://172.16.1.2/ftp/repos/rocky/iefs/source/iefs-kernel-updates-hpc-eth-11_5_1_1.tar.gz -O - | tar -xzvf - -C /tmp
cd /tmp/iefs-kernel-updates*
sed -e 's|rhel|rocky|g' do-update-makerpm.sh > do-update-makerpm-rocky.sh
cp files/iefs-kernel-updates.spec.{rhel,rocky}
export MOFED_PATH=/usr/src/ofa_kernel/x86_64/${KVER}
export INTEL_GPU_DIRECT=CURRENT_KERNEL
export LEX=flex
export YACC=bison
sed -e 's:UPSTRM_COMPAT_H:RH92_COMPAT_H:g' compat/UPSTRM/compat.h > compat/RH92/compat.h
sed -i '/#include "gdr_ops.h"/aMODULE_IMPORT_NS(DMA_BUF);' ./drivers/infiniband/ulp/rv/rv.h
bash ./do-update-makerpm-rocky.sh -G -S ${PWD} -w ${PWD}/tmp
rpmbuild --rebuild \
   ./tmp/rpmbuild/SRPMS/iefs-kernel-updates-5.14.0_284.25.1.el9_2.x86_64-5000oneapize.src.rpm

yum install -y \
/root/rpmbuild/RPMS/x86_64/iefs-kernel-updates-devel-5.14.0_284.25.1.el9_2.x86_64-5000oneapize.x86_64.rpm \
/root/rpmbuild/RPMS/x86_64/iefs-kernel-updates-dkms-5.14.0_284.25.1.el9_2.x86_64-5000oneapize.x86_64.rpm \
/root/rpmbuild/RPMS/x86_64/kmod-iefs-kernel-updates-5.14.0_284.25.1.el9_2.x86_64-5000oneapize.x86_64.rpm

### libpsm3-fi srpm can be got from IntelEth-Basic.RHEL92-x86_64.11.5.1.1.1.tgz
#https://github.com/intel/eth-psm3-fi/archive/refs/tags/v11.5.0.0.zip
#rpm -ivh http://172.16.1.2/ftp/repos/rocky/iefs/psm3/libpsm3-fi-11.5.0.0-172.src.rpm
rpm -ivh http://172.16.1.2/ftp/repos/rocky/iefs/psm3/libpsm3-fi-11.5.1.1-1oneapize.src.rpm
cd ~/rpmbuild/SPECS/
sed -i.ori -e 's:%global configopts:%global configopts --with-oneapi-ze=/usr:g' libpsm3-fi.spec
rpmbuild -bb libpsm3-fi.spec
#rpm -Uvh /root/rpmbuild/RPMS/x86_64/libpsm3-fi-11.5.0.0-172.x86_64.rpm
rpm -Uvh /root/rpmbuild/RPMS/x86_64/libpsm3-fi-11.5.1.1-1oneapize.x86_64.rpm

##############################################################################
# Demo using GPUDirect

source /software/oneAPI/2023.2/setvars.sh
cp -arv /software/oneAPI/2023.2/mpi/2021.10.0/benchmarks/imb/ $HOME/
cd $HOME/imb
make -j8 IMB-MPI1-GPU

mpirun \
  -genv I_MPI_PIN_PROCESSOR_LIST=0,27 -genv I_MPI_OFFLOAD_TOPOLIB=level_zero  -genv I_MPI_OFFLOAD_CELL_LIST=0,2 \
  -genv I_MPI_HYDRA_BOOTSTRAP=ssh \
  -genv I_MPI_DEBUG=5 \
  -genv I_MPI_FABRICS=ofi \
  -genv I_MPI_OFI_PROVIDER=psm3 -genv PSM3_IDENTIFY=1 -genv PSM3_GPUDIRECT=1 -genv PSM3_RDMA=1 -genv PSM3_PRINT_STATS=1 \
  -genv I_MPI_OFFLOAD=1 -genv I_MPI_OFFLOAD_RDMA=1 -genv I_MPI_OFFLOAD_RDMA_THRESHOLD=0 \
  -genv EnableImplicitScaling=0 -genv NEOReadDebugKeys=1 -genv EnableRecoverablePageFaults=1 \
  -np 2 \
  ./IMB-MPI1-GPU -mem_alloc_type device PingPong SendRecv 2>&1 | tee log.txt

grep -E 'oneapi-ze|Benchmarking|#bytes|4194304' log.txt
# On sucessfull you will see:
# rank0 PSM3_IDENTIFY PSM3 v3.0-oneapi-ze built for IEFS OFA DELTA 11_5_0_0root
# rank0 PSM3_IDENTIFY HAL: verbs (RDMA Verbs (oneapi-ze)) built against rv interface v1.4 gpu v1.3 oneapi-ze
# rank1 PSM3_IDENTIFY PSM3 v3.0-oneapi-ze built for IEFS OFA DELTA 11_5_0_0root
# rank1 PSM3_IDENTIFY HAL: verbs (RDMA Verbs (oneapi-ze)) built against rv interface v1.4 gpu v1.3 oneapi-ze
# rank0 PSM3_IDENTIFY run-time rv interface v1.4 user_mr gpu v1.3 oneapi-ze
# rank1 PSM3_IDENTIFY run-time rv interface v1.4 user_mr gpu v1.3 oneapi-ze
# # Maximum message length in bytes:   4194304
# # Benchmarking PingPong
#        #bytes #repetitions      t[usec]   Mbytes/sec
#       4194304           10       223.90     18733.11
# # Benchmarking Sendrecv
#        #bytes #repetitions  t_min[usec]  t_max[usec]  t_avg[usec]   Mbytes/sec
#       4194304           10       333.20       333.22       333.21     25174.16

