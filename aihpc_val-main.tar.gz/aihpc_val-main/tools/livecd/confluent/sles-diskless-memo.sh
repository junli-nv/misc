
osdeploy import /scratch/repos/sles/15sp5/isos/SLE-15-SP5-Full-x86_64-QU1-Media1.iso
osdeploy list

rm -rf /install/build/sle-15.5-x86_64-stateless-junli
imgutil build -s sle-15.5-x86_64 /install/build/sle-15.5-x86_64-stateless-junli
imgutil exec -v /var/lib/confluent/ -v /software:/software /install/build/sle-15.5-x86_64-stateless-junli
if ! `echo $PS1|grep 'IMGUTIL' &>/dev/null`; then
  echo "Not in jail, exiting"
  exit 1
fi

#####################################################################################################################################
## do installation
rm -fr /etc/zypp/repos.d/* /etc/zypp/services.d/*
for i in \
Module-Basesystem \
Module-Containers \
Module-Development-Tools \
Module-Legacy \
Module-Server-Applications \
Module-HPC \
Product-SLES \
Product-WE
do
cat <<- EOF
[$i]
name=$i
enabled=1
autorefresh=1
baseurl=http://172.16.1.2/ftp/os/sles/15sp5/os/$i
path=/
type=yast2
keeppackages=0
EOF
done > /etc/zypp/repos.d/os.repo
zypper refresh
zypper update -y
zypper lr
zypper install -y  \
  kernel-default kernel-default-devel kernel-source kernel-macros kernel-syms 

zypper install -y net-tools-deprecated iputils sudo vim wget patterns-base-32bit \
  less pciutils expat man man-pages \
  strace tree sysstat dstat iotop perf hdparm sg3_utils \
  hwloc file diffutils rsync bc numactl lftp lshw ipmitool \
  dmraid ntfs-3g biosdevname nvme-cli yast2 yast2-network \
  lsb-release screen bash-completion pciutils expat numactl

#zypper search -s -t pattern
zypper install -y -t pattern  devel_basis devel_kernel
zypper install -y \
   cmake gcc-fortran gcc12* wget ipmitool strace insserv-compat python3-devel rpm-build python-rpm-macros patch createrepo_c emacs curl tar gzip man \
   zsh quota  psmisc net-tools-deprecated libxmlrpc3 libxmlrpc_util4 libxmlrpc_client3 squashfs popt-devel \
   podman \
   libstdc++6-devel-gcc7 tcsh make tk tcl insserv-compat libgfortran4 python-rpm-macros rpm-build python3-devel createrepo_c \
   open-lldp expect libibumad3 net-snmp libibverbs1 libnuma-devel rsyslog logrotate infiniband-diags libibverbs-utils coreutils cpupower iproute2 dmidecode util-linux \
   sysstat iotop tpm2.0-tools ethtool \
   libOpenCL1 meson libkmod-devel procps-devel libunwind-devel libdw-devel libpixman-1-0-devel cairo-devel libudev-devel xrandr valgrind-devel \
   autoconf automake libtool opencl-headers

systemctl enable sshd

cat > /etc/zypp/repos.d/updates.repo <<- EOF
[updates]
name=updates
enabled=1
autorefresh=1
baseurl=http://172.16.1.2/ftp/os/sles/15sp5/updates
path=/
type=yast2
keeppackages=0
gpgcheck=0
EOF
zypper refresh
zypper update -y
export KVER=$(ls -lrth /lib/modules/|tail -n 1|awk '{print $NF}')
ls /lib/modules/|grep -v ${KVER%%-default}|while read i; do zypper remove -y $(rpm -qa|grep ${i%%-default}); done

cat > /etc/zypp/repos.d/opensuse.repo <<- EOF
[opensuse]
name=opensuse
enabled=1
autorefresh=1
baseurl=http://172.16.1.2/ftp/os/sles/opensuse
path=/
type=yast2
keeppackages=0
gpgcheck=0
EOF
zypper install -y dkms
# clinfo clpeak R-base R-base-devel sox nano htop libgsl25 libgslcblas0 

# Install GPU driver
cat > /etc/zypp/repos.d/agama-ci-devel.repo <<- EOF
[hotfix_agama-ci-devel-803.51]
enabled=1
autorefresh=1
baseurl=http://172.16.1.2/ftp/repos/agama/hotfix_agama-ci-devel-803.51/sles-15sp5
gpgcheck=0
EOF
zypper refresh
zypper install -y --allow-vendor-change --allow-unsigned-rpm xpu-smi libdrm2 libdrm-devel intel-ocloc intel-opencl intel-level-zero-gpu level-zero level-zero-devel intel-media-driver libmfx1 intel-metrics-discovery libmetee intel-gsc
## pci_dev_is_disconnected function already be implemented in kernel 5.14.21-150500.55.59
#
## grep -B2 -A3 pci_dev_is_disconnected /var/lib/dkms/intel-i915-dkms/$(dkms status intel-i915-dkms|cut -f1 -d':'|cut -f2 -d'/')/build/drivers/gpu/drm/i915/../../../pci/pci.h
## grep -B2 -A3 pci_dev_is_disconnected /usr/src/linux-5.14.21-150500.55.59/include/linux/pci.h
#
## SOLUTION: comment out pci_dev_is_disconnected definiation of kernel 5.14.21-150500.55.59
zypper install -y  intel-fw-gpu intel-i915-dkms 
dkms status
#dkms build -m intel-i915-dkms -v 1.23.10.32.231129.32 -k $KVER
  
systemctl disable firewalld kdump
systemctl stop firewalld kdump
rm -f /boot/*-kdump
sed -i -e 's:GRUB_CMDLINE_LINUX_DEFAULT=.*:GRUB_CMDLINE_LINUX_DEFAULT="console=ttyS0,115200 console=tty0 mitigations=auto":g' /etc/default/grub
cat > /etc/modprobe.d/i915.conf <<- EOF
# i915.conf
options drm debug=0xe
options i915 force_probe=* enable_hangcheck=0 prelim_override_p2p_dist=1 enable_rc6=1 rc6_ignore_steppings=1
EOF
sed -e 's/allow_unsupported_modules 0/allow_unsupported_modules 1/' /lib/modprobe.d/10-unsupported-modules.conf > /etc/modprobe.d/10-unsupported-modules.conf
sed  -i.org '/GRUB_CMDLINE_LINUX_DEFAULT/ s/"$/ console=ttyS0,115200n8 console=tty1 modprobe.blacklist=ast pci=pcie_bus_perf,noaer iomem=relaxed"/g' /etc/default/grub
#grub2-mkconfig -o /boot/grub2/grub.cfg

### MOFED changed the ib_cm_listen by removing service_mask from 23.07. 
### /usr/src/linux-$(uname -r|sed 's/-default//')/include/rdma/ib_cm.h -> ib_cm_listen
#wget -c http://172.16.1.2/ftp/os/sles/15sp5/mofed/MLNX_OFED_LINUX-23.10-1.1.9.0-sles15sp5-x86_64.tgz -O - | tar -xzvf - -C /tmp
wget -c http://172.16.1.2/ftp/os/sles/15sp5/mofed/MLNX_OFED_LINUX-24.04-0.6.6.0-sles15sp5-x86_64.tgz -O - | tar -xzvf - -C /tmp
cd /tmp/MLNX_OFED_LINUX-*
./mlnxofedinstall --kernel $KVER --add-kernel-support --enable-affinity --enable-mlnx_tune --without-fw-update --enable-opensm --force --tmpdir /tmp
rm -rf /tmp/MLNX_*
cd /tmp

## https://jira.devtools.intel.com/browse/GSD-8575
#dmabuf_peer_mem.c:170:10: error: implicit declaration of function ‘dma_resv_excl_fence’; did you mean ‘dma_resv_add_fence’? 
## the suse/main works in SLES15SP5
# git clone -b suse/main https://github.com/intel-innersource/drivers.gpu.integration.dma-buf-peer-mem-backporting
# make V=1
zypper install -y intel-dmabuf-peer-mem-dkms
#dkms build -m intel-dmabuf-peer-mem-dkms/1.0.0-63 -k $KVER
#rpm -Uvh http://172.16.1.2/ftp/os/sles/15sp5/dma-buf-peer-mem/intel-dmabuf-peer-mem-dkms-1.0.0-61.x86_64.rpm
dkms status

### rv/rv_conn.c
##ifdef IB_CM_LISTEN_WITHOUT_MASK
#        ret = ib_cm_listen(listener->cm_id, cpu_to_be64(service_id));
##else
#        ret = ib_cm_listen(listener->cm_id, cpu_to_be64(service_id), 0);
wget http://172.16.1.2/ftp/os/sles/15sp5/iefs/IntelEth-Basic.SLES155-x86_64.11.6.0.0.231.tgz -O - | tar -xzvf - -C /tmp
cd /tmp/IntelEth-Basic.SLES*
#
export INTEL_GPU_DIRECT=CURRENT_KERNEL
export MOFED_PATH=/usr/src/ofa_kernel/x86_64/$KVER/
./INSTALL -a -G --without-depcheck -R $KVER --rebuild -vv
dkms status
# dkms uninstall -m iefs-kernel-updates -v $(ls -1 /var/lib/dkms/iefs-kernel-updates/|grep oneapize) -k $(uname -r)
# unset INTEL_GPU_DIREC
# dkms build -m iefs-kernel-updates -v $(ls -1 /var/lib/dkms/iefs-kernel-updates/|grep oneapize) -k $KVER
# dkms install -m iefs-kernel-updates -v $(ls -1 /var/lib/dkms/iefs-kernel-updates/|grep oneapize) -k $KVER
# modinfo /lib/modules/$KVER/updates/rv.ko*|grep ^ver

#
### With MOFED from 23.07
# rpm -ivh ./repos/IEFS_PKGS_ONEAPI-ZE/SRPMS/libpsm3-fi-11.5.1.2-1oneapize.src.rpm
# rpm -ivh ./repos/IEFS_PKGS_ONEAPI-ZE/SRPMS/iefs-kernel-updates-5.14.21_150500.53_default-6324oneapize.src.rpm
# #
# cd /usr/src/packages/SOURCES
# tar -xzf iefs-kernel-updates-5.14.21_150500.53_default.tgz
# ## ONLY need with MOED from 23.07
# sed -i.ori -e '/#include "compat_common.h"/a#define IB_CM_LISTEN_WITHOUT_MASK' iefs-kernel-updates-5.14.21_150500.53_default/compat/compat.h
# diff -u iefs-kernel-updates-5.14.21_150500.53_default/compat/compat.h{.ori,}
# tar -czf iefs-kernel-updates-5.14.21_150500.53_default.tgz iefs-kernel-updates-5.14.21_150500.53_default 
# cd /usr/src/packages/SPECS
# sed -i.ori -e "s:%(uname -r):$KVER:g" iefs-kernel-updates.spec
# diff -u iefs-kernel-updates.spec{.ori,}
# export MOFED_PATH=/usr/src/ofa_kernel/x86_64/$KVER/
# export INTEL_GPU_DIRECT=CURRENT_KERNEL
# rpmbuild -bb iefs-kernel-updates.spec
# rpm -Uvh $(ls /usr/src/packages/RPMS/x86_64/iefs-kernel-updates-*.rpm|grep -v debug)
# dkms build -m iefs-kernel-updates/6324oneapize -k $KVER
# dkms install -m iefs-kernel-updates/6324oneapize -k $KVER --force
# dkms status
# cd /usr/src/packages/SPECS
# sed -i.ori -e 's:%global configopts:%global configopts --with-oneapi-ze=/usr:g' libpsm3-fi.spec
# rpmbuild -bb libpsm3-fi.spec
# rpm -Uvh $(ls /usr/src/packages/RPMS/x86_64/libpsm3-fi-*.rpm|grep -v debug) --force
# rm -rf /usr/src/packages/BUILD*/*

zypper install -y nfs-kernel-server
mkdir -p /software /scratch
cat > /etc/fstab <<- EOF
172.16.1.1:/install/software /software nfs4 ro,relatime,vers=4.2,rsize=1048576,wsize=1048576,namlen=255,soft,proto=tcp,timeo=600,retrans=2,sec=sys,local_lock=none,nofail 0 0
172.16.1.1:/home /home nfs4 rw,relatime,vers=4.2,rsize=1048576,wsize=1048576,namlen=255,soft,proto=tcp,timeo=600,retrans=2,sec=sys,local_lock=none,nofail 0 0  
172.16.2.141:/data/d01/scratch/ /scratch/ nfs4 rw,noatime,vers=4.2,rsize=1048576,wsize=1048576,namlen=255,soft,proto=tcp,nconnect=4,timeo=600,retrans=2,sec=sys,local_lock=none,_netdev 0 0
EOF

dracut --kver $KVER -f -N \
  -o "multipath" --add "ssh-client ifcfg diskless" \
  --fwdir /lib/firmware/updates \
  --force-drivers "i915 i915_spi iaf knem mei-gsc mei-me mei mei_hdcp mei_iaf mei_pxp mei_wdt mst_pci mst_pciconf pmt_class pmt_crashlog pmt_telemetry rv ipmi_si ipmi_devintf ipmi_msghandler mlx5_core mlx5_ib dmabuf_peer_mem"
lsinitrd /boot/initrd-$KVER | grep -E 'i915.ko|iaf.ko|pvc|mei|rv.ko|dmabuf_peer_mem'

zypper install -y Modules
mkdir -p /install
ln -sf /software /install/software
cp /software/slurm/modules/modulespath.mgt1 /usr/share/Modules/3.2.10/init/.modulespath

zypper install -y chrony chrony-pool-suse
wget http://172.16.1.2/ftp/os/sles/15sp4/slurm/chrony/chrony.conf.node -O /etc/chrony.conf
ln -sf /usr/share/zoneinfo/America/Los_Angeles /etc/localtime
systemctl enable chronyd

wget http://172.16.1.2/ftp/os/sles/15sp4/slurm/hosts/hosts.mgt1 -O /etc/hosts

cat >> /etc/security/limits.conf <<- 'EOF'
* hard stack unlimited
* soft stack unlimited
* hard memlock unlimited
* soft memlock unlimited
* soft nofile 1048575
* hard nofile 1048575
EOF

cat >> /etc/sysctl.conf <<- EOF
kernel.perf_event_paranoid=-1
dev.i915.perf_stream_paranoid=0
vm.max_map_count=131060
net.ipv4.tcp_rmem = 16384 349520 16777216
net.ipv4.tcp_wmem = 16384 349520 16777216
net.core.rmem_max = 16777216
net.core.wmem_max = 16777216
net.core.rmem_default = 4194304
net.core.wmem_default = 4194304
net.core.optmem_max = 4194304
net.ipv4.tcp_timestamps = 0
net.ipv4.tcp_sack = 1
net.core.netdev_max_backlog = 250000
net.ipv4.tcp_low_latency = 1
net.ipv4.tcp_adv_win_scale = 1
EOF

### Slurm client
groupadd -g 500 wheel
groupadd -g 979 slurm
useradd -u 979 -g 979 -G wheel slurm

zypper modifyrepo --disable Module-HPC
zypper addrepo -G -e -f http://172.16.1.2/ftp/os/sles/15sp4/slurm/RPMS slurm
zypper refresh
zypper install -y \
  munge munge-devel \
  slurm slurm-example-configs \
  slurm-slurmd slurm-pam_slurm lbnl-nhc slurm-devel \
  slurm-contribs slurm-torque slurm-libpmi slurm-openlava slurm-perlapi
zypper modifyrepo --enable Module-HPC
zypper install -y pdsh

#mungekey -c -k /etc/munge/munge.key
wget http://172.16.1.2/ftp/os/sles/15sp4/slurm/munge/munge.key -O /etc/munge/munge.key
chown munge /etc/munge/munge.key
chmod 400 /etc/munge/munge.key
cat > /usr/lib/systemd/system/slurmd.service <<- 'EOF'
[Unit]
Description=Slurm node daemon
After=munge.service network-online.target remote-fs.target
Wants=network-online.target
#ConditionPathExists=/etc/slurm/slurm.conf

[Service]
Type=simple
EnvironmentFile=-/etc/sysconfig/slurmd
EnvironmentFile=-/etc/default/slurmd
ExecStart=/usr/sbin/slurmd -D -s $SLURMD_OPTIONS
ExecReload=/bin/kill -HUP $MAINPID
KillMode=process
LimitNOFILE=1048575
LimitMEMLOCK=infinity
LimitSTACK=infinity
Delegate=yes
TasksMax=infinity

# Uncomment the following lines to disable logging through journald.
# NOTE: It may be preferable to set these through an override file instead.
#StandardOutput=null
#StandardError=null

[Install]
WantedBy=multi-user.target
EOF

systemctl disable munge slurmd

echo '%wheel   ALL=(ALL)       NOPASSWD:ALL' > /etc/sudoers.d/wheel
echo 'slurm ALL = NOPASSWD: /opt/confluent/bin/nodepower' > /etc/sudoers.d/slurm
echo 'ALL ALL = NOPASSWD: /usr/bin/cpupower' > /etc/sudoers.d/cpupower
chown root:root /etc/sudoers.d/*
chmod 0440 /etc/sudoers.d/*
echo slurm > /etc/slurm/slurm_allowed_users
cat > /etc/pam.d/sshd <<- EOF
#%PAM-1.0
auth        requisite   pam_nologin.so
auth        include     common-auth
account     requisite   pam_nologin.so
account     include     common-account
password    include     common-password
#ADD FOR SLURM
-account    sufficient  pam_listfile.so item=user sense=allow onerr=fail file=/etc/slurm/slurm_allowed_users
-account    required    pam_slurm_adopt.so
#DONE
session     required    pam_loginuid.so
session     include     common-session
session     optional    pam_lastlog.so   silent noupdate showfailed
session     optional    pam_keyinit.so   force revoke
EOF
mkdir -p /etc/slurm /var/slurm/storage /var/spool/slurmd
chown -R slurm:slurm /var/slurm /var/spool/slurmd

cat >/etc/init.d/boot.local <<- 'EOF'
#!/bin/bash
exit 0
EOF
chmod +x /etc/init.d/boot.local
ln -sf /usr/lib/systemd/system/rc-local.service /etc/systemd/system/multi-user.target.wants/rc-local.service

echo > /etc/udev/rules.d/70-persistent-net.rules
rm -rf /tmp/*
truncate -s 0 /etc/machine-id
truncate -s 0 /root/.bash_history
history -c
exit
## installation done
#####################################################################################################################################

rm -rf /var/lib/confluent/public/os/sles15.5-stateless-junli
imgutil pack /install/build/sle-15.5-x86_64-stateless-junli sles15.5-stateless-junli
cat > /var/lib/confluent/public/os/sles15.5-stateless-junli/boot.ipxe <<- 'EOF'
#!ipxe
imgfetch boot/kernel initrd=site.cpio initrd=addons.cpio initrd=distribution confluent_imagemethod=untethered console=ttyS0,115200 console=tty1 modprobe.blacklist=ast pci=pcie_bus_perf,noaer iomem=relaxed drm.debug=0xe i915.force_probe=* i915.enable_hangcheck=0 i915.prelim_override_p2p_dist=1 i915.enable_rc6=1 i915.rc6_ignore_steppings=1 i915.enable_iaf=1 i915.enable_fake_int_wa=0
imgfetch boot/initramfs/site.cpio
imgfetch boot/initramfs/addons.cpio
imgfetch boot/initramfs/distribution
imgload kernel
imgexec kernel
EOF

cp /var/lib/confluent/public/os/sle-15.4-x86_64-stateless-2023-12-01-01/scripts/onboot.d/* \
   /var/lib/confluent/public/os/sles15.5-stateless-junli/scripts/onboot.d/

cat > /var/lib/confluent/public/os/sles15.5-stateless-junli/scripts/onboot.d/99-add-local-user.sh <<- 'EOF'
mkdir -p /opt/home/
useradd -m -b /opt/home intel -u 65533 -g wheel
echo 'intel:intel@123' | chpasswd
[ -f /etc/slurm/slurm_allowed_users ] && echo intel >> /etc/slurm/slurm_allowed_users
EOF
sed -i.ori -e '/exec \/opt\/confluent\/bin\/start_root/i mv /lib/firmware /lib/firmware-ramfs\nln -s /sysroot/lib/firmware /lib/firmware' \
  /var/lib/confluent/public/os/sles15.5-stateless-junli/scripts/imageboot.sh

nodedeploy -n compute22 sles15.5-stateless-junli
nodeconsole compute22

###############################################################################################################################################

rm -rf /install/build/sle-15.5-x86_64-stateless-junli
imgutil unpack sle-15.5-x86_64-stateless-hotfix_agama-ci-devel-803.52-20240606-03 /install/build/sle-15.5-x86_64-stateless-junli
imgutil exec -v /software:/software /install/build/sle-15.5-x86_64-stateless-junli
if ! `echo $PS1|grep 'IMGUTIL' &>/dev/null`; then
  echo "Not in jail, exiting"
  exit 1
fi
rpm -e kernel-default-5.14.21-150500.55.28.1.x86_64
rpm -e --nodeps \
  xpu-smi libdrm2 intel-ocloc intel-opencl intel-level-zero-gpu level-zero level-zero-devel intel-media-driver libmfx1 intel-metrics-discovery libmetee intel-gsc \
  intel-fw-gpu intel-i915-dkms \
  intel-dmabuf-peer-mem-dkms 
rm -rf /var/lib/dkms/intel-i915-dkms/
rm -f /root/*.rpm

sed -i -e 's:803.52:803.73:g' /etc/zypp/repos.d/hotfix_agama-ci-devel-803.52.repo
export KVER=$(ls -lrth /lib/modules/|tail -n 1|awk '{print $NF}')
zypper mr -d source-1
zypper refresh
zypper install -y --allow-vendor-change --allow-unsigned-rpm xpu-smi libdrm2 intel-ocloc intel-opencl intel-level-zero-gpu level-zero level-zero-devel intel-media-driver libmfx1 intel-metrics-discovery libmetee intel-gsc
zypper install -y intel-fw-gpu intel-i915-dkms 
dkms status
#dkms build -m intel-i915-dkms -v $(rpm -qa|grep intel-i915-dkms|cut -f4 -d'-') -k $KVER
zypper install -y intel-dmabuf-peer-mem-dkms
dkms status

dracut --kver $KVER -f -N \
  -o "multipath" --add "ssh-client ifcfg diskless" \
  --fwdir /lib/firmware/updates \
  --force-drivers "i915 i915_spi iaf knem mei-gsc mei-me mei mei_hdcp mei_iaf mei_pxp mei_wdt mst_pci mst_pciconf pmt_class pmt_crashlog pmt_telemetry rv ipmi_si ipmi_devintf ipmi_msghandler mlx5_core mlx5_ib dmabuf_peer_mem"
lsinitrd /boot/initrd-$KVER | grep -E 'i915.ko|iaf.ko|pvc|mei|rv.ko|dmabuf_peer_mem'
ls -lh /boot/initrd-$KVER
rm -rf /tmp/*
truncate -s 0 /etc/machine-id
truncate -s 0 /root/.bash_history
history -c
exit
rm -rf /var/lib/confluent/public/os/sles15.5-stateless-junli
imgutil pack /install/build/sle-15.5-x86_64-stateless-junli sles15.5-stateless-junli
cat > /var/lib/confluent/public/os/sles15.5-stateless-junli/boot.ipxe <<- 'EOF'
#!ipxe
imgfetch boot/kernel initrd=site.cpio initrd=addons.cpio initrd=distribution confluent_imagemethod=untethered console=ttyS0,115200 console=tty1 modprobe.blacklist=ast pci=pcie_bus_perf,noaer,realloc iomem=relaxed drm.debug=0xe i915.force_probe=* i915.enable_hangcheck=0 i915.prelim_override_p2p_dist=1 i915.enable_rc6=1 i915.rc6_ignore_steppings=1 i915.enable_iaf=1 i915.enable_fake_int_wa=0
imgfetch boot/initramfs/site.cpio
imgfetch boot/initramfs/addons.cpio
imgfetch boot/initramfs/distribution
imgload kernel
imgexec kernel
EOF
cp /var/lib/confluent/public/os/sle-15.5-x86_64-stateless-hotfix_agama-ci-devel-803.52-20240606-03/scripts/onboot.d/* \
   /var/lib/confluent/public/os/sles15.5-stateless-junli/scripts/onboot.d/

nodedeploy -n compute[25,35] sles15.5-stateless-junli

###################################

rm -rf /install/build/sle-15.5-x86_64-stateless-junli
imgutil unpack sle-15.5-x86_64-stateless-hotfix_agama-ci-devel-803.73-20240701-02 /install/build/sle-15.5-x86_64-stateless-junli
imgutil exec -v /software:/software -v /scratch:/scratch /install/build/sle-15.5-x86_64-stateless-junli
rpm -e intel-i915-dkms
rm -rf /var/lib/dkms/intel-i915-dkms /usr/src/intel-i915-dkms-*
dkms status
rpm -qa|grep intel-i915-dkms
rpm -ivh /scratch/repos/agama/GSD-9418/intel-i915-dkms-1.23.10.53.231129.54-84.x86_64.rpm
grep -r slin14 /usr/src/intel-i915-dkms-1.23.10.53.231129.53
dkms status
export KVER=$(ls -lrth /lib/modules/|tail -n 1|awk '{print $NF}')
rm -f /boot/initrd-*
ls -lh /boot/
dracut --kver $KVER -f -N \
  -o "multipath" --add "ssh-client ifcfg diskless" \
  --fwdir /lib/firmware/updates \
  --force-drivers "i915 i915_spi iaf knem mei-gsc mei-me mei mei_hdcp mei_iaf mei_pxp mei_wdt mst_pci mst_pciconf pmt_class pmt_crashlog pmt_telemetry rv ipmi_si ipmi_devintf ipmi_msghandler mlx5_core mlx5_ib dmabuf_peer_mem"
lsinitrd /boot/initrd-$KVER | grep -E 'i915.ko|iaf.ko|pvc|mei|rv.ko|dmabuf_peer_mem'
ls -lh /boot/initrd-$KVER
rm -rf /tmp/*
truncate -s 0 /etc/machine-id
truncate -s 0 /root/.bash_history
history -c
exit
rm -rf /var/lib/confluent/public/os/sles15.5-stateless-junli
imgutil pack /install/build/sle-15.5-x86_64-stateless-junli sles15.5-stateless-junli
cp -arv \
   /var/lib/confluent/public/os/sle-15.5-x86_64-stateless-hotfix_agama-ci-devel-803.73-20240701-02/{boot.ipxe,scripts} \
   /var/lib/confluent/public/os/sles15.5-stateless-junli/
nodedeploy -n compute44 sles15.5-stateless-junli
/usr/bin/dmesg |grep slin14

######################################

rm -rf /install/build/sle-15.5-x86_64-stateless-hotfix_agama-ci-devel-803.75-20240731-01
imgutil unpack sle-15.5-x86_64-stateless-hotfix_agama-ci-devel-803.73-20240701-02 /install/build/sle-15.5-x86_64-stateless-hotfix_agama-ci-devel-803.75-20240731-01
imgutil exec -v /var/lib/confluent/distributions:/var/lib/confluent/distributions -v /software:/software \
        /install/build/sle-15.5-x86_64-stateless-hotfix_agama-ci-devel-803.75-20240731-01
export KVER=$(ls -lrth /lib/modules/|tail -n 1|awk '{print $NF}')
rm -f /etc/zypp/repos.d/hotfix_agama-ci-devel-803.73.repo
cat > /etc/zypp/repos.d/hotfix_agama-ci-devel-803.75.repo <<- 'EOF'
[hotfix_agama-ci-devel-803.75]
enabled=1
autorefresh=1
baseurl=dir:/software/agama/agama/sles15sp5/hotfix_agama-ci-devel-803.75
gpgcheck=0
EOF
zypper refresh
zypper update -y --allow-vendor-change xpu-smi libdrm2 intel-ocloc intel-opencl intel-level-zero-gpu level-zero level-zero-devel intel-media-driver libmfx1 intel-metrics-discovery libmetee intel-gsc
zypper remove -y intel-fw-gpu intel-i915-dkms
rm -rf /var/lib/dkms/intel-i915-dkms/*
zypper install -y intel-fw-gpu intel-i915-dkms 
dkms status
#dkms build -m intel-i915-dkms -v $(rpm -qa|grep intel-i915-dkms|cut -f4 -d'-') -k $KVER
zypper install -y intel-oobmsm-dummy
dkms build -m intel-oobmsm-dummy -v 0.1.0-505 -k $KVER
dkms install -m intel-oobmsm-dummy -v 0.1.0-505 -k $KVER
rm -f /boot/initrd-*
ls -lh /boot/
dracut --kver $KVER -f -N \
  -o "multipath" --add "ssh-client ifcfg diskless" \
  --fwdir /lib/firmware/updates \
  --force-drivers "i915 i915_spi iaf knem mei-gsc mei-me mei mei_hdcp mei_iaf mei_pxp mei_wdt mst_pci mst_pciconf pmt_class pmt_crashlog pmt_telemetry rv ipmi_si ipmi_devintf ipmi_msghandler mlx5_core mlx5_ib dmabuf_peer_mem intel_oobmsm_dummy"
lsinitrd /boot/initrd-$KVER | grep -E 'i915.ko|iaf.ko|pvc|mei|rv.ko|dmabuf_peer_mem|intel_oobmsm_dummy'
ls -lh /boot/initrd-$KVER
rm -rf /tmp/*
truncate -s 0 /etc/machine-id
truncate -s 0 /root/.bash_history
history -c
exit
rm -rf /var/lib/confluent/public/os/sle-15.5-x86_64-stateless-hotfix_agama-ci-devel-803.75-20240731-01
imgutil pack /install/build/sle-15.5-x86_64-stateless-hotfix_agama-ci-devel-803.75-20240731-01 sle-15.5-x86_64-stateless-hotfix_agama-ci-devel-803.75-20240731-01
cp -arv \
   /var/lib/confluent/public/os/sle-15.5-x86_64-stateless-hotfix_agama-ci-devel-803.73-20240701-02/{boot.ipxe,scripts} \
   /var/lib/confluent/public/os/sle-15.5-x86_64-stateless-hotfix_agama-ci-devel-803.75-20240731-01/
cat > /var/lib/confluent/public/os/sle-15.5-x86_64-stateless-hotfix_agama-ci-devel-803.75-20240731-01/boot.ipxe <<- EOF
#!ipxe
imgfetch boot/kernel initrd=site.cpio initrd=addons.cpio initrd=distribution confluent_imagemethod=untethered   console=ttyS0,115200n8 console=tty1 modprobe.blacklist=ast pci=pcie_bus_perf,realloc iomem=relaxed  drm.debug=0xe i915.force_probe=* i915.enable_hangcheck=0 i915.prelim_override_p2p_dist=1  i915.enable_rc6=1 i915.pvc_fw_put_delay_ms=1000
imgfetch boot/initramfs/site.cpio
imgfetch boot/initramfs/addons.cpio
imgfetch boot/initramfs/distribution
imgload kernel
imgexec kernel
EOF
cat > /var/lib/confluent/public/os/sle-15.5-x86_64-stateless-hotfix_agama-ci-devel-803.75-20240731-01/scripts/onboot.d/99_load_dummy.sh <<- 'EOF'
#!/bin/bash
modprobe intel_oobmsm_dummy
EOF
nodedeploy -n compute25 sle-15.5-x86_64-stateless-hotfix_agama-ci-devel-803.75-20240731-01
