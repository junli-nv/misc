#!/bin/bash
## Author: Junli Zhang<junliz@nvidia.com>

bcm_usb=${1:-"/dev/sda"}
mount $bcm_usb /mnt
cd /mnt/boot
mkdir /var/www/html/iso
./mkiso.sh /mnt/ /var/www/html/iso bcm.iso
umount /mnt


cat > /dev/null << 'EOF'
if [ $# -ne 3 ];then
  echo "Usage: $0 <SOURCE_DIR> <DEST_DIR> <ISO_NAME>"
  exit 1
fi

SOURCE_DIR=`readlink -e $1`
DEST_DIR=`readlink -e $2`
ISO_NAME=$3
MODIFICATION_DATE=`date +"%Y%m%d%H%M%S00"`

xorriso -as mkisofs \
    -b isolinux/isolinux.bin \
    --modification-date=$MODIFICATION_DATE \
    -no-emul-boot \
    -boot-load-size 4 \
    -boot-info-table \
    -c isolinux/boot.cat \
    --embedded-boot $SOURCE_DIR/efi.img \
    --efi-boot efi.img \
    -isohybrid-gpt-basdat \
    -volid BCMINSTALLERHEAD \
    -o $DEST_DIR/$ISO_NAME \
    $SOURCE_DIR

isohybrid -u $DEST_DIR/$ISO_NAME
EOF
