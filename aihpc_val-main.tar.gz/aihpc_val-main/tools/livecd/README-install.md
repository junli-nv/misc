# 从 Ubuntu LiveCD 安装到单块磁盘

`livecd_to_disk.sh` 是纯 Bash 脚本，用于将当前运行的 Ubuntu LiveCD 系统复制到磁盘，安装磁盘启动所需的 initramfs 和 GRUB。不创建 RAID。

## 条件与使用

- Ubuntu LiveCD，根文件系统为 overlay；支持 amd64、arm64。
- LiveCD 必须以 UEFI 启动，关闭 Secure Boot；不支持 Legacy BIOS。
- 完全离线运行，无需网络或 APT 仓库。所有依赖必须已经安装在 LiveCD 中；缺失或未配置完成时，脚本在清盘前列出包名并退出。
- 目标是整块空闲磁盘，不能包含已挂载分区、活动 swap、已有 VG 或活动 RAID/device-mapper 成员。
- 停止数据库、容器等持续写入任务后再复制；运行中的系统复制不提供应用一致性快照。

制作 LiveCD 时需预装以下包（安装到镜像内，而不仅是缓存 `.deb`）：

```text
parted dosfstools e2fsprogs xfsprogs lvm2 rsync util-linux efibootmgr
initramfs-tools initramfs-tools-core grub-common grub2-common
```

此外，amd64 预装 `grub-efi-amd64-bin`，arm64 预装 `grub-efi-arm64-bin`。安装脚本不会执行 APT update、安装或下载，也不会尝试联网补齐依赖。

安装示例（**会清空指定磁盘**）：

```bash
sudo bash tools/livecd/livecd_to_disk.sh /dev/nvme0n1
# SATA/SAS 磁盘也支持：
sudo bash tools/livecd/livecd_to_disk.sh /dev/sda
```

脚本显示目标磁盘型号、序列号和分区，并要求输入目标盘的完整路径确认。没有默认目标盘。

默认 GPT 布局：

| 用途 | 大小 | 格式 |
| --- | --- | --- |
| `/boot/efi` | 1 GiB | FAT32 |
| `/boot` | 4 GiB | ext4 |
| `sysvg/lv_swap` | 16 GiB | swap |
| `sysvg/lv_root` | VG 剩余全部空间 | XFS |

指定根卷 100 GiB、swap 16 GiB，保留剩余 VG 空间：

```bash
sudo env ROOT_GIB=100 SWAP_GIB=16 VG_NAME=sysvg \
  bash tools/livecd/livecd_to_disk.sh /dev/nvme0n1
```

`SWAP_GIB=0` 不创建 swap。已有同名 VG 时，可通过 `VG_NAME` 指定新名称；脚本不会自动停用或删除已有 VG。目标磁盘本身属于已有 VG 时，必须先另行迁移/清理，改名称不能绕过保护。

## 复制和启动行为

- 复制当前系统的内核、模块、驱动、软件、用户、密码和网络设置；排除 LiveCD 介质和运行时挂载目录。
- `/boot` 单独复制；发现其他独立挂载的主要系统目录时终止，避免漏复制。
- 仅在目标 chroot 中通过 `apt-get --no-download purge` 离线移除 casper/live-tools，使用复制过来的已安装依赖重建每个内核的 initramfs，并检查 LVM/XFS 启动支持。
- 使用 UUID 写入 fstab，不激活目标 swap，不执行自动重启。
- 默认从 `/proc/cmdline` 继承硬件和串口参数，移除 LiveCD、旧 root/resume 和网络启动参数。也可使用 `KERNEL_CMDLINE='...'` 覆盖；传入空字符串可清空继承参数。
- 同时安装 Ubuntu EFI 引导程序和 UEFI 默认路径引导程序，并尝试注册 NVRAM 启动项；注册失败时提示在固件中选择目标磁盘。
- 新系统首次启动生成 machine-id；其他身份配置（包括 SSH host keys）保持复制所得内容。
- 成功或失败退出时，尝试递归卸载本次创建的目标挂载。失败不会回滚分区和已写入的数据，也不能断点续装。

脚本成功退出后，移除 LiveCD 并手动重启，必要时在 UEFI 启动菜单选择目标盘。若提示卸载失败，先处理目标挂载再重启；若安装失败，不应尝试从未完成的目标系统启动。

## 验证

```bash
bash -n tools/livecd/livecd_to_disk.sh
shellcheck tools/livecd/livecd_to_disk.sh
```

上述检查不会访问或格式化真实磁盘，不能替代在测试机/虚拟机上的安装和拔除 LiveCD 后的冷启动验证。

实现参考：[Ubuntu casper](https://manpages.ubuntu.com/manpages/questing/man7/casper.7.html)、[GNU GRUB 配置](https://www.gnu.org/software/grub/manual/grub/html_node/Simple-configuration.html)。
