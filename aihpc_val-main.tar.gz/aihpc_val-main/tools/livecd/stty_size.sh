#!/bin/bash

# 将 50、180 换成本地实际尺寸。TERM 应与本地终端能力相符；关键是 stty rows ... cols ...。
stty size
stty rows 50 cols 180
unset LINES COLUMNS
export TERM=xterm
clear

# 先在远端 SOL 会话中确认设备：
# 假设输出 /dev/ttyS0：
stty -F /dev/ttyS0 rows 50 cols 180
#-F 指定要设置的终端设备，否则启动脚本的标准输入通常不是串口。
