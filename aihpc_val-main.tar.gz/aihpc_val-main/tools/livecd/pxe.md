# Ubuntu 24.04 自定义 LiveCD：通过 PXE 启动

本指南复用 [x86-u24.04-livecd.sh](x86-u24.04-livecd.sh) 生成的 ISO，保留光盘启动能力，同时增加网络启动。先完成 HTTP ISO 启动，再按需配置 NFS。

适用环境：Ubuntu 24.04 x86_64 服务端、客户端使用 **x86_64 UEFI PXE IPv4**。本指南生成的 GRUB 未签名，客户端需关闭 Secure Boot；需要保留 Secure Boot 时，应改用受信任的 shim/签名 GRUB 链，并验证内核及驱动签名，不能直接使用这里生成的 `core.efi`。Legacy BIOS 和 ARM 不适用这套引导文件。

启动链：UEFI PXE → DHCP → TFTP 加载 GRUB、内核和 initrd → Casper 经 HTTP 下载 ISO → 启动 Live 系统。这里启动的是自定义 Live 环境，不是自动安装到磁盘。

## 1. 确认环境与地址

下文以独立 PXE 网段为例，执行前替换变量。服务端接口应已配置静态地址，客户端与服务端处于同一二层网段。

| 项目 | 示例 |
|---|---|
| PXE 服务端 IP | `192.168.10.10` |
| PXE 服务端接口 | `enp1s0` |
| 网段 | `192.168.10.0/24` |
| DHCP 地址池 | `192.168.10.100`–`192.168.10.200` |
| TFTP 根目录 | `/srv/tftp` |
| HTTP 根目录 | `/var/www/html` |
| ISO | `/home/livecd/ubuntu-24.04-live.iso` |

**已有 BCM、Confluent 或其他 DHCP/PXE 服务时，不要再启动第二套 DHCP。** 第 6 步提供现有服务接入方式和独立服务方式，二选一。以下生成配置文件的步骤针对新部署；已有同名配置时先备份并合并。

## 2. 在构建环境准备 initrd

这一步在 **LiveCD 构建 rootfs 的 chroot 内**执行，不是在 PXE 服务端的系统根目录执行。位置在构建脚本的 `depmod` / `update-initramfs` 之前。

```bash
# 在构建 rootfs 的 chroot 内
mkdir -p /etc/initramfs-tools/conf.d
echo 'MODULES=most' > /etc/initramfs-tools/conf.d/pxe

# 使用这次镜像实际安装的内核版本
KVER=6.8.0-106-generic
test -d "/lib/modules/$KVER"
depmod -a "$KVER"
update-initramfs -u -k "$KVER"
```

在目标硬件已运行的 Linux 上，可用 `ethtool -i <启动网口名称>` 确认实际网卡驱动。若该驱动没有进入 initrd，在构建 chroot 内将其模块名加入 `/etc/initramfs-tools/modules`，再执行上述生成命令。还要检查对应固件和依赖，不能仅凭 `MODULES=most` 判断已满足要求。

之后按原构建流程重新复制内核/initrd、制作 squashfs 和 ISO。内核、initrd 和根文件系统必须来自同一版本。若现有 ISO 已包含所需驱动与 Casper，可先执行第 4 步检查，无需盲目重建。

## 3. 准备 PXE 服务端

除第 2 步外，后续 Bash 命令均在 **PXE 服务端同一个 root Bash 会话**中逐段执行；遇到错误先修复，不要继续后面的步骤。

```bash
sudo /bin/bash

PXE_IP=192.168.10.10
PXE_IF=enp1s0
PXE_CIDR=192.168.10.0/24
DHCP_START=192.168.10.100
DHCP_END=192.168.10.200
ISO=/home/livecd/ubuntu-24.04-live.iso
TFTP_ROOT=/srv/tftp
HTTP_ROOT=/var/www/html
NFS_DIR=/srv/livecd/ubuntu2404
ISO_URL="http://${PXE_IP}/livecd/ubuntu-24.04-live.iso"

ip -br address show "$PXE_IF"
test -r "$ISO"
apt-get update
apt-get install -y grub-common grub-efi-amd64-bin nginx initramfs-tools-core curl rsync tftp-hpa
mkdir -p "$TFTP_ROOT/ubuntu2404" "$HTTP_ROOT/livecd"
```

若已经有 HTTP/TFTP 服务，复用现有服务，将这里的根目录调整为实际目录，不必另起冲突服务。新装 nginx 的默认站点应以 `/var/www/html` 为根目录；用 `nginx -T` 核对。第 6 步的独立方案使用 dnsmasq 同时提供 DHCP/TFTP，因此不要再启动 tftpd-hpa 服务。

## 4. 从同一个 ISO 发布文件

使用专用临时挂载目录，失败时停止，退出时清理挂载。不占用公共 `/media`。

```bash
(
  set -euo pipefail
  PXE_MOUNT=$(mktemp -d /tmp/livecd-pxe.XXXXXX)
  cleanup() {
    if mountpoint -q "$PXE_MOUNT"; then
      umount "$PXE_MOUNT" || return
    fi
    rmdir "$PXE_MOUNT"
  }
  trap cleanup EXIT
  trap 'exit 130' INT
  trap 'exit 143' TERM
  mount -o loop,ro "$ISO" "$PXE_MOUNT"
  test -s "$PXE_MOUNT/casper/vmlinuz"
  test -s "$PXE_MOUNT/casper/initrd"
  test -s "$PXE_MOUNT/casper/filesystem.squashfs"
  test -s "$PXE_MOUNT/boot/grub/grub.cfg"
  install -m 0644 "$PXE_MOUNT/casper/vmlinuz" "$TFTP_ROOT/ubuntu2404/vmlinuz"
  install -m 0644 "$PXE_MOUNT/casper/initrd" "$TFTP_ROOT/ubuntu2404/initrd"
  install -m 0644 "$PXE_MOUNT/boot/grub/grub.cfg" "$TFTP_ROOT/ubuntu2404/grub-cdrom.cfg"
  install -m 0644 "$ISO" "$HTTP_ROOT/livecd/ubuntu-24.04-live.iso"
)
```

检查**实际发布的 initrd**，不要检查其他镜像目录下的文件：

```bash
lsinitramfs "$TFTP_ROOT/ubuntu2404/initrd" > /tmp/livecd-initrd-contents.txt
grep 'scripts/casper' /tmp/livecd-initrd-contents.txt
# 以下模块名只是示例，按启动网卡的实际驱动检查
grep -E 'mlx5_core|mlx4_core|igb|ixgbe|i40e|ice' /tmp/livecd-initrd-contents.txt
```

预期看到 Casper 启动脚本，以及目标网卡驱动（若编译进内核则需检查内核配置）、依赖和所需固件。只在 squashfs 中有驱动不够，下载 ISO 前必须能配置网络。

## 5. 生成 UEFI GRUB 和 HTTP 菜单

```bash
grub-mknetdir --net-directory="$TFTP_ROOT" --subdir=/boot/grub \
  -d /usr/lib/grub/x86_64-efi
test -s "$TFTP_ROOT/boot/grub/x86_64-efi/core.efi"
```

该命令生成网络启动 GRUB 及模块，不是向服务端磁盘安装 GRUB。TFTP 根目录下的引导文件为 `boot/grub/x86_64-efi/core.efi`，配置入口为 `boot/grub/grub.cfg`。[GNU GRUB 网络启动说明](https://www.gnu.org/software/grub/manual/grub/html_node/Network.html)

从 ISO 自带菜单生成网络菜单，保留原来的 `ttyS0` / `ttyS1` 及 IOMMU、PCIe、NVMe 等参数：

```bash
# 此转换适用于本仓库 x86 构建脚本生成的 GRUB 菜单。
# 示例 URL 使用普通 IP/路径，不含 sed 特殊字符 & 或 |。
sed \
  -e 's|/casper/vmlinuz|/ubuntu2404/vmlinuz|g' \
  -e 's|/casper/initrd|/ubuntu2404/initrd|g' \
  -e "s|boot=casper |boot=casper ip=dhcp iso-url=${ISO_URL} |g" \
  -e 's|LiveCD|PXE HTTP|g' \
  "$TFTP_ROOT/ubuntu2404/grub-cdrom.cfg" > "$TFTP_ROOT/ubuntu2404/grub.cfg"

cat > "$TFTP_ROOT/boot/grub/grub.cfg" <<'GRUB'
configfile /ubuntu2404/grub.cfg
GRUB

grub-script-check "$TFTP_ROOT/boot/grub/grub.cfg"
grub-script-check "$TFTP_ROOT/ubuntu2404/grub.cfg"
cat "$TFTP_ROOT/ubuntu2404/grub.cfg"
```

确认两条 `linux` 命令都包含 `boot=casper ip=dhcp iso-url=...`，且参数位于 `---` 之前。不要修改 ISO 内的光盘菜单。若原菜单结构已改变，应手动调整转换命令。

Casper 的 `iso-url` 指向**完整 ISO**，不是 squashfs。HTTP 模式会下载 ISO，需要为 ISO、initrd、系统和可写层留足内存；先测量 ISO 大小和单节点启动峰值，不必额外添加 `toram`。具体选项见 [Ubuntu 24.04 Casper 手册](https://manpages.ubuntu.com/manpages/noble/man7/casper.7.html)。

## 6. 接入 DHCP/TFTP（二选一）

### A. 已有 DHCP/PXE 服务

使用既有 DHCP 配置入口，为目标 x86_64 UEFI 客户端设置：

```text
next-server: 192.168.10.10
boot filename: boot/grub/x86_64-efi/core.efi
TFTP root: /srv/tftp
```

将这里生成的 GRUB 文件、模块、配置和 `ubuntu2404` 目录部署到实际 TFTP 根目录。不能只复制 `core.efi`。保留其他架构的原有分流规则；BCM/Confluent 等环境应通过其受管理的配置方式修改，避免覆盖已有 PXE 入口。若沿用已有 GRUB，在其菜单中添加 `configfile /ubuntu2404/grub.cfg`，无需替换 DHCP 引导文件。

### B. 独立测试网段：dnsmasq 提供 DHCP 和 TFTP

仅在该网段没有其他 DHCP 服务时执行。配置绑定 `$PXE_IF`，不提供 DNS，也不宣告默认网关/DNS；镜像服务与客户端处于同一网段即可完成启动。如运行后需要访问其他网段，另行填写正确的网关和 DNS。

```bash
apt-get install -y dnsmasq
systemctl stop dnsmasq
cat > /etc/dnsmasq.d/livecd-pxe.conf <<EOF_DNS
port=0
interface=${PXE_IF}
bind-interfaces
dhcp-range=${DHCP_START},${DHCP_END},255.255.255.0,12h
dhcp-option=option:router
dhcp-option=option:dns-server
dhcp-match=set:efi64,option:client-arch,7
dhcp-match=set:efi64,option:client-arch,9
dhcp-boot=tag:efi64,boot/grub/x86_64-efi/core.efi,,${PXE_IP}
enable-tftp
tftp-root=${TFTP_ROOT}
log-dhcp
EOF_DNS

dnsmasq --test
systemctl enable dnsmasq
systemctl restart dnsmasq
systemctl enable nginx
nginx -t
systemctl restart nginx
```

架构码 7/9 用于常见 x86 UEFI PXE 客户端；此配置不提供 Legacy BIOS/ARM 的启动文件。检查 `/etc/dnsmasq.conf` 及其他片段，确保没有冲突的地址池、接口或 TFTP 配置。

## 7. 在启动客户端前检查服务

```bash
curl -fI "$ISO_URL"
sha256sum "$ISO" "$HTTP_ROOT/livecd/ubuntu-24.04-live.iso"
# 测试 TFTP，从另一台同网段 Linux 机器执行更能验证网络可达性
# 将下方 IP 改成实际服务端地址
tftp 192.168.10.10 -m binary -c get boot/grub/x86_64-efi/core.efi /tmp/pxe-core.efi
ls -lh /tmp/pxe-core.efi
```

HTTP 应返回 `200`，两个 ISO 校验和应相同，TFTP 应成功下载非空引导文件。防火墙/ACL 需允许 PXE 网段的 DHCP、TFTP 和 HTTP：UDP 67/68、UDP 69 及 TFTP 后续数据流、TCP 80。不要仅检查本机端口；跨主机验证路由、ACL 和服务绑定。

单台客户端选择 UEFI IPv4 网络启动。预期先出现 HTTP 菜单，再选择与服务器串口一致的 `ttyS0` 或 `ttyS1`。先跑通一台，再扩大并发，避免大量节点同时下载大 ISO 压满服务端带宽。

启动后检查：

```bash
cat /proc/cmdline
findmnt /
findmnt /cdrom
ip -br address
```

命令行应含正确 `iso-url`，根文件系统应为 Live 的 overlay，`/cdrom` 对应已挂载镜像。完整网络配置可在进入系统后再由 NetworkManager 接管；初始化网络的成功不代表最终网络配置已符合业务需求。

## 8. 可选：NFS 启动

仅在 HTTP 已验证或确实需要 NFS 时执行。NFS 使用解开的 ISO 目录，通常持续依赖服务端，不需要每台客户端下载整份 ISO。

```bash
apt-get install -y nfs-kernel-server nfs-common
mkdir -p "$NFS_DIR"
(
  set -euo pipefail
  PXE_MOUNT=$(mktemp -d /tmp/livecd-nfs.XXXXXX)
  cleanup() {
    if mountpoint -q "$PXE_MOUNT"; then
      umount "$PXE_MOUNT" || return
    fi
    rmdir "$PXE_MOUNT"
  }
  trap cleanup EXIT
  trap 'exit 130' INT
  trap 'exit 143' TERM
  mount -o loop,ro "$ISO" "$PXE_MOUNT"
  cp -a "$PXE_MOUNT/." "$NFS_DIR/"
)
test -s "$NFS_DIR/casper/filesystem.squashfs"
mkdir -p /etc/exports.d
cat > /etc/exports.d/livecd.exports <<EOF_NFS
${NFS_DIR} ${PXE_CIDR}(ro,sync,no_subtree_check,root_squash)
EOF_NFS
systemctl enable --now nfs-kernel-server
exportfs -ra
exportfs -v
```

用新的空目录发布新版本，避免旧 ISO 文件混入。目录和 squashfs 需要让客户端匿名只读访问；不需要 `no_root_squash`。网络需放通 NFS 实际使用的协议和 RPC 端口；NFSv3 除 2049 外还涉及 rpcbind/mountd 等端口，按服务端配置检查。

从保留的光盘菜单生成独立 NFS 菜单，只有完成导出后才加入主菜单：

```bash
sed \
  -e 's|/casper/vmlinuz|/ubuntu2404/vmlinuz|g' \
  -e 's|/casper/initrd|/ubuntu2404/initrd|g' \
  -e "s|boot=casper |boot=casper ip=dhcp netboot=nfs nfsroot=${PXE_IP}:${NFS_DIR} |g" \
  -e 's|LiveCD|PXE NFS|g' \
  "$TFTP_ROOT/ubuntu2404/grub-cdrom.cfg" > "$TFTP_ROOT/ubuntu2404/grub-nfs.cfg"

cat > "$TFTP_ROOT/boot/grub/grub.cfg" <<'GRUB'
set default=0
set timeout=10
menuentry "Ubuntu 24.04 Live - HTTP ISO" {
    configfile /ubuntu2404/grub.cfg
}
menuentry "Ubuntu 24.04 Live - NFS" {
    configfile /ubuntu2404/grub-nfs.cfg
}
GRUB
grub-script-check "$TFTP_ROOT/boot/grub/grub.cfg"
grub-script-check "$TFTP_ROOT/ubuntu2404/grub-nfs.cfg"
```

在另一台客户端先用 `mount -t nfs -o ro 服务端IP:/srv/livecd/ubuntu2404 临时挂载目录` 验证导出可读，并在验证后卸载。NFS 启动后不要删除导出内容，也不要让网络管理服务切断根文件系统依赖的网络连接。Casper 的 NFS 参数见 [官方手册](https://manpages.ubuntu.com/manpages/noble/man7/casper.7.html)。

## 9. 按启动阶段排查

| 现象 | 优先检查 |
|---|---|
| 没有获得 IP | UEFI IPv4、VLAN、网口链路、DHCP 服务与地址池 |
| 获得 IP 但没有下载 GRUB | DHCP boot filename/next-server、客户端架构、TFTP 可达性 |
| GRUB 被固件拒绝 | Secure Boot 状态；本文生成的 core.efi 未签名 |
| 进入 GRUB 命令行而没有菜单 | GRUB 中 `echo $prefix`、`echo $root`，以及 `boot/grub/grub.cfg` 是否可读 |
| GRUB 找不到内核 | TFTP 根目录与 `/ubuntu2404/` 路径是否一致 |
| initrd 阶段没有网卡或 DHCP 超时 | 实际启动网卡驱动、固件、依赖是否进入 initrd；多网口 DHCP 选择 |
| ISO 下载失败或 HTTP 404 | `iso-url`、HTTP root、客户端网络、内存余量 |
| 找不到 Live 文件系统 | ISO 与内核/initrd 是否一致、Casper 是否存在、ISO 内 `/casper/filesystem.squashfs` |
| NFS 挂载失败 | exports、客户端子网、读权限、NFS 版本及 RPC 防火墙 |
| SOL 没输出 | ttyS0/ttyS1 与服务器串口配置是否一致 |

服务端可以同时观察 `journalctl -fu dnsmasq` 和 `tail -f /var/log/nginx/access.log /var/log/nginx/error.log`。使用已有服务时替换为对应日志。

本指南是在原构建脚本基础上整理的部署步骤，尚未在目标服务器执行启动验证。UEFI PXE 服务端的通用背景可参考 [Ubuntu 官方指南](https://ubuntu.com/server/docs/how-to/installation/netboot-the-server-installer-via-uefi-pxe-on-arm-aarch64-arm64-and-x86-64-amd64/)。
