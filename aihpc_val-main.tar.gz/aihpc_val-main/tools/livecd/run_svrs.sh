#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

## Configure eth0 for services
ip addr add 192.168.10.1/24 dev eth0 2>/dev/null
ip link set eth0 up

## Syslogd server configuration
#mkdir -p /var/log
#busybox syslogd -O /var/log/messages
#busybox klogd -n

## Httpd server configuration
mkdir -p /www
echo ok > /www/index.html
busybox httpd -p 8080 -h /www

## Tftpd server configuration
mkdir -p /tftpboot
busybox tftpd -l -a 0.0.0.0:69 -u nobody /tftpboot

## DHCP server configuration
mkdir -p /var/lib/misc
touch /var/lib/misc/udhcpd.leases
cat > /etc/udhcpd.conf <<- EOF
start       192.168.10.100
end         192.168.10.150
interface   eth0

opt subnet  255.255.255.0
opt router  192.168.10.1
opt dns     192.168.10.1

static_lease aa:bb:cc:dd:ee:ff 192.168.10.10
static_lease 11:22:33:44:55:66 192.168.10.11

option lease 3600

# May not work
# opt tftp    192.168.10.1
# opt bootfile grubnetaa64.efi.signed

pidfile     /var/run/udhcpd.pid
lease_file  /var/lib/misc/udhcpd.leases
EOF
busybox udhcpd /etc/udhcpd.conf

## DHCP client test
# busybox udhcpc -i eth0 -f
