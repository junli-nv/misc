### 1. 先确认阵列详情和使用状态

cat /proc/mdstat

mdadm --detail /dev/md127
mdadm --detail /dev/md126

lsblk -f
findmnt
swapon --show

特别检查：

- md126、md127 没有挂载
- 没有作为 swap
- 没有 LVM、加密卷或安装程序正在使用
- mdadm --detail 显示的成员盘与下面列表一致

可以保存现场信息：

mdadm --detail /dev/md127 > /root/md127-before-delete.txt
mdadm --detail /dev/md126 > /root/md126-before-delete.txt
mdadm --examine --scan > /root/mdadm-scan-before-delete.txt

### 2. 停止阵列

mdadm --stop /dev/md127
mdadm --stop /dev/md126

然后确认它们已经消失或处于 inactive：

cat /proc/mdstat
lsblk

如果提示 busy，不要强制处理。先用以下命令找占用者：

findmnt
swapon --show
fuser -vm /dev/md127
fuser -vm /dev/md126

### 3. 清除 RAID superblock

清除 27.9T RAID0 的八个成员：

mdadm --zero-superblock /dev/nvme0n1p1
mdadm --zero-superblock /dev/nvme1n1p1
mdadm --zero-superblock /dev/nvme2n1p1
mdadm --zero-superblock /dev/nvme3n1p1
mdadm --zero-superblock /dev/nvme6n1p1
mdadm --zero-superblock /dev/nvme7n1p1
mdadm --zero-superblock /dev/nvme8n1p1
mdadm --zero-superblock /dev/nvme9n1p1

清除 1.7T RAID1 的两个成员：

mdadm --zero-superblock /dev/nvme4n1p2
mdadm --zero-superblock /dev/nvme5n1p2

不要对 /dev/md126 或 /dev/md127 执行 --zero-superblock；目标应是成员分区。

### 4. 验证

mdadm --examine /dev/nvme0n1p1
mdadm --examine /dev/nvme4n1p2
cat /proc/mdstat
lsblk

正常情况下，mdadm --examine 会报告没有可识别的 MD superblock。重启后也不应再出现 md126/md127。

如果你接下来要重新安装系统，安装器仍可能把这些分区识别为“Linux RAID”类型。此时可在安装器中删除并重新创建相应分区；不要额外执行 wipefs -a，除非你还确定要清除文件系统等其他签名。

mdadm --stop 只是停用阵列，而 --zero-superblock 才会覆盖成员设备上的 RAID 元数据，相关定义可见 Ubuntu mdadm 手册 和 Linux 内核 MD 文档。
