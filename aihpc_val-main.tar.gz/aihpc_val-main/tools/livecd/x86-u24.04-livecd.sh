#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

## Install required packages for building ISO image
apt update
apt install -y grub2 xorriso squashfs-tools debootstrap p7zip-full mtools grub-common grub-pc-bin

## Prepare work directories
topdir=/home/livecd
mkdir -p ${topdir}
export WORK=${topdir}/work
export CD=${topdir}/cd
export FORMAT=squashfs
export FS_DIR=casper
mkdir -p ${CD}/{${FS_DIR},boot/grub} ${WORK}/rootfs

## Create rootfs
debootstrap \
  --arch=amd64 \
  --variant=minbase \
  noble \
  ${WORK}/rootfs \
  http://archive.ubuntu.com/ubuntu/

## Copy resolv.conf, hosts, and hostname to the rootfs
rm -f ${WORK}/rootfs/etc/resolv.conf
cat /etc/resolv.conf > ${WORK}/rootfs/etc/resolv.conf
cat /etc/hosts > ${WORK}/rootfs/etc/hosts
cat /etc/hostname > ${WORK}/rootfs/etc/hostname

## Mount necessary filesystems for chroot
mount -t devtmpfs /dev ${WORK}/rootfs/dev
mount -t devpts devpts ${WORK}/rootfs/dev/pts
mount -t proc proc ${WORK}/rootfs/proc
mount -t sysfs sys ${WORK}/rootfs/sys
mount -t tmpfs tmpfs ${WORK}/rootfs/run
mkdir -p ${WORK}/rootfs/run/{lock,shm}

## Enter chroot environment
chroot ${WORK}/rootfs /bin/bash

export LC_ALL=C LANG="en_US.UTF-8" LANGUAGE=C

cat > /etc/apt/sources.list <<'EOF'
deb http://archive.ubuntu.com/ubuntu noble main restricted universe multiverse
deb http://archive.ubuntu.com/ubuntu noble-updates main restricted universe multiverse
deb http://security.ubuntu.com/ubuntu noble-security main restricted universe multiverse
EOF
apt update

## Install Linux kernel and headers
kernel_version="6.8.0-106-generic"
apt-get install -y \
  linux-headers-${kernel_version} \
  linux-image-${kernel_version} \
  linux-modules-${kernel_version} \
  linux-tools-${kernel_version} \
  linux-modules-extra-${kernel_version} \
  linux-tools-common=${kernel_version%%-generic}.*
apt-mark hold linux-image-generic linux-headers-generic linux-generic \
  linux-headers-${kernel_version} linux-image-${kernel_version} linux-modules-${kernel_version} linux-tools-${kernel_version} linux-modules-extra-${kernel_version}
apt-mark showhold

## Install basic packages
apt install -y \
  curl dkms \
  ubuntu-minimal \
  ubuntu-standard \
  casper \
  network-manager \
  openssh-server \
  systemd-sysv \
  sudo \
  vim \
  less \
  wget \
  numactl \
  ipmitool lldpd gawk \
  iputils-ping isc-dhcp-client isc-dhcp-relay \
  pciutils sshfs ifupdown net-tools lsof \
  nfs-kernel-server nfs-common samba smbclient samba-common samba-libs cifs-utils \
  environment-modules  \
  bash-completion lftp pdsh nvme-cli nmon ntpsec ntfs-3g squashfs-tools p7zip-full tmux screen \
  busybox-static kexec-tools jq bc sipcalc expect hwloc gnuplot-nox \
  ethtool fping gdisk git htop iperf lsof lsscsi mdadm pm-utils powercap-utils quota rasdaemon  \
  sg3-utils smartmontools ssh sysstat udev vlan iotop minicom \
  parted dosfstools e2fsprogs xfsprogs lvm2 rsync util-linux efibootmgr initramfs-tools initramfs-tools-core grub-common grub2-common grub-efi-amd64-bin
systemctl enable ssh
systemctl disable ufw
## Install required packages for building ISO image
apt install -y grub2 xorriso squashfs-tools debootstrap p7zip-full mtools grub-common grub-pc-bin
apt-get install -y qemu-kvm ovmf libvirt-daemon-system libvirt-clients bridge-utils virtinst 
apt-get purge -y swtpm swtpm-tools snapd

apt-get install -y initramfs-tools lvm2 xfsprogs grub-efi-amd64 grub-efi-amd64-signed grub-efi-amd64-bin shim-signed efibootmgr 

## https://developer.nvidia.com/doca-downloads?deployment_platform=Host-Server&deployment_package=DOCA-Host&target_os=Linux&Architecture=x86_64&Profile=doca-ofed&Distribution=Ubuntu&version=24.04&installer_type=deb_online
export DOCA_URL="https://linux.mellanox.com/public/repo/doca/3.4.0/ubuntu24.04/x86_64/"
curl https://linux.mellanox.com/public/repo/doca/public_keys/nvidia-doca-debian-gpg-public-key.gpg | gpg --dearmor > /etc/apt/trusted.gpg.d/nvidia-doca-debian-gpg-public-key.gpg
echo "deb [signed-by=/etc/apt/trusted.gpg.d/nvidia-doca-debian-gpg-public-key.gpg] $DOCA_URL ./" > /etc/apt/sources.list.d/doca.list
apt-get update
apt-get -y install doca-ofed
systemctl disable srp_daemon.service srptools.service
systemctl enable openibd

## Add NVIDIA DGX repository
curl https://repo.download.nvidia.com/baseos/ubuntu/noble/x86_64/dgx-repo-files.tgz | tar xzf - -C /
mkdir -p /etc/apt/sources.list.d/disabled
mv /etc/apt/sources.list.d/{ai-workbench-desktop.sources,doca-bos8-latest.sources} \
   /etc/apt/sources.list.d/disabled/
cat > /etc/apt/preferences.d/black.pref << 'EOF'
Package: dgx*
Pin: release *
Pin-Priority: -1
EOF
apt update
apt install -y docker-ce nvidia-container-toolkit

## Install NVIDIA driver
ver=580.126.20
target_pkgs=(
libnvidia-nscq
nvidia-fabricmanager
nvidia-driver-580-open
nvidia-dkms-580-open
nvidia-settings
libxnvctrl0
nvidia-modprobe
nvidia-kernel-source-580-open
nvidia-kernel-common-580
libnvidia-gl-580
libnvidia-extra-580
libnvidia-decode-580
libnvidia-encode-580
xserver-xorg-video-nvidia-580
libnvidia-cfg1-580
libnvidia-fbc1-580
libnvidia-common-580
nvidia-firmware-580
libnvidia-gpucomp-580
libnvidia-compute-580
nvidia-persistenced
)
pkgs=(
$(
for i in ${target_pkgs[*]}; do
  apt-cache madison $i | grep ${ver}-.*developer.download.nvidia.com
done|awk '{print $1"="$3}'
)
nvlsm
)
apt install --allow-downgrades -y ${pkgs[@]}
#
## Fix the slurm can't detect NVML issue
cd /usr/lib/x86_64-linux-gnu/
ln -sf libnvidia-ml.so.1 libnvidia-ml.so
cd /root
## Install NVIDIA datacenter GPU manager
apt install -y datacenter-gpu-manager-4-core datacenter-gpu-manager-4-cuda13 datacenter-gpu-manager-4-multinode-cuda13
systemctl enable nvidia-persistenced nvidia-dcgm nvidia-fabricmanager #nvidia-imex
mkdir -p /var/run/nvidia-fabricmanager
chmod 755 /var/run/nvidia-fabricmanager
## CUDA
apt install -y cuda-nvml-dev-13-0 #cuda-toolkit-13-0
## GDRCOPY #packages from dgx
apt install -y gdrdrv-dkms gdrcopy gdrcopy-tests libgdrapi
## DGX packages
apt install -y \
  nv-cpu-governor nv-limits nvidia-acs-disable nvidia-enable-power-meter-cap nvidia-kernel-defaults \
  nvidia-nvme-options nvidia-pci-bridge-power nvidia-relaxed-ordering-gpu nvidia-relaxed-ordering-nvme

## For Lustre
cat >> /etc/sysctl.conf <<- EOF
### Recommended baseline for multi‑NIC same‑subnet RoCE
## 1) ARP behaviour
#sysctl -w net.ipv4.conf.all.arp_filter=0
#sysctl -w net.ipv4.conf.all.arp_ignore=1
#sysctl -w net.ipv4.conf.all.arp_announce=2
#sysctl -w net.ipv4.conf.all.accept_local=1
#sysctl -w net.ipv4.conf.default.arp_filter=0
#sysctl -w net.ipv4.conf.default.arp_ignore=1
#sysctl -w net.ipv4.conf.default.arp_announce=2
#sysctl -w net.ipv4.conf.default.accept_local=1
## 2) Reverse‑path filtering
#sysctl -w net.ipv4.conf.all.rp_filter=2
#sysctl -w net.ipv4.conf.default.rp_filter=2
###################################################
### Enable Magic SysRq
kernel.sysrq=1
EOF

## Enable NV Profiling for normal users
cat > /etc/modprobe.d/nvprofiling.conf <<- EOF
options nvidia NVreg_RestrictProfilingToAdminUsers=0
EOF

#Issue: With uvm_disable_hmm=N, simple CUDA failed with cudaGetDeviceCount -> 3 (initialization error)
#https://nvbugspro.nvidia.com/bug/5550341
#Disable HMM for UVM
cat > /etc/modprobe.d/uvm.conf <<- EOF
options nvidia_uvm uvm_disable_hmm=1
EOF


cat > /etc/rc.local <<- 'EOF'
#!/bin/bash
export PATH=/usr/sbin:/usr/bin:/sbin:/bin:/usr/local/sbin:/usr/local/bin:$PATH

ret=$(ipmitool lan print 1|grep 'IP Address.*:'|grep -v Source|awk '{print $NF}'|tr -s '.' '-')
if [[ "X${ret}" != "X" ]]; then
  name="cn-${ret}"
else
  ret=$(cat /sys/class/dmi/id/product_serial)
  if [[ "X${ret}" != "X" ]]; then
    name="cn-${ret}"
  else
    ret=$(lspci -D | grep -i 'Ethernet controller:'|awk '{print $1}'|xargs -I {} bash --norc -c "ls -l /sys/class/net|grep {}|grep -o {}/.*|cut -f3 -d'/'"|sort|head -n 1|xargs -I {} bash --norc -c "cat /sys/class/net/{}/address"|tr -d ':')
    if [[ "X${ret}" != "X" ]]; then
      name=name="cn-${ret}"
    else
      name="cn-$(echo $RANDOM|md5sum -|awk '{print $1}'|cut -c1-12)"
    fi
  fi
fi
hostnamectl set-hostname "${name}"

nics=($(lspci -D | grep -i eth|awk '{print $1}'|while read i; do basename $(ls -l /sys/class/net/|grep -o ${i}/.*); done))
for i in ${nics[*]}; do ip link set ${i} up; done
lldpcli configure system hostname .
lldpcli configure lldp portidsubtype ifname
lldpcli configure system interface pattern eth*,eno*,enp*,ens*,enP*
# lldpcli show running-configuration
lldpcli update
# lldpcli show neighbors

start_rdma-ndd(){
  while : ; do
    if [[ $(lsmod | grep mlx5_ib | wc -l) -ne 0 && $(grep -r HCA- /sys/class/infiniband/*/node_desc|wc -l) -ne 0 ]]; then
      break
    else
      sleep 10
    fi
  done
  pkill -9 rdma-ndd &>/dev/null
  sleep 10
  export RDMA_NDD_ND_FORMAT="%h %d"
  nohup /usr/sbin/rdma-ndd  -f --debug &
}
export -f start_rdma-ndd
nohup bash -c "start_rdma-ndd" &>/tmp/rdma-ndd.txt &

## Set the Mellanox/NVIDIA HCAs' MaxReadReq to 4K
lspci -d 15b3: -nn|awk '{print $1}'|awk '{print $1}'|xargs -I {} setpci -v -s {} cap_exp+8.w=5000:7000
#lspci -d 15b3: -nn|awk '{print $1}'|xargs -I {} lspci -s {} -vvv|grep -o MaxReadReq.*|sort|uniq -c

## Enable SysRq key
sysctl -w kernel.sysrq=1
echo 8 > /proc/sysrq-trigger
## Trigger sysrq via SOL over IPMI:
# 1. Press Enter+~B+8 to set log level to debug if sysrq-trigger not been set
# 2. Press Enter+~B+m to dump memory information
# 3. Press Enter+~B+0 to set log level back to previous level
## Trigger sysrq via SOL over SSH:
# Replace break signal generated with Enter+~~B, then follow the same steps as above.

## CPU tunning
cpupower -c all frequency-set -g performance &>/dev/null
x86_energy_perf_policy performance &>/dev/null
sudo sysctl -w kernel.perf_event_paranoid=2 &>/dev/null ## for nsight
cpupower -c all idle-set -D 5 &>/dev/null # Enable Poll/C0/C1/C1E by default
# cpupower monitor | tail -n +7 | awk -F '|' '($11>=4000){print $1,$2,$3,$11}' #PCT

exit 0
EOF
chmod 755 /etc/rc.local

systemctl set-default multi-user.target
echo 'root:123456'|chpasswd

useradd -m -s /bin/bash ubuntu
echo 'ubuntu:123456' | chpasswd
usermod -aG sudo ubuntu
echo 'ubuntu ALL=(ALL) NOPASSWD:ALL' > /etc/sudoers.d/ubuntu
chmod 0440 /etc/sudoers.d/ubuntu

apt purge -y unattended-upgrades

sed -i.ori -e 's#next unless "$tag" ne "";#next unless defined $tag and "$tag" ne "";#g' /usr/bin/dshbak

apt-mark unhold linux-image-generic linux-headers-generic linux-generic \
  linux-headers-${kernel_version} linux-image-${kernel_version} linux-modules-${kernel_version} linux-tools-${kernel_version} linux-modules-extra-${kernel_version}

#Higher the sshd limits for rsync
cat > /etc/ssh/sshd_config.d/90-rsync.conf <<- EOF
PermitRootLogin yes
MaxStartups 100:30:200
MaxSessions 100
EOF

echo 'kernel.printk = 4 4 1 7' >> /etc/sysctl.conf
sed -i 's:managed=.*:managed=true:g' /etc/NetworkManager/NetworkManager.conf
cat > /etc/netplan/00-installer-config.yaml <<- EOF
network:
  version: 2
  renderer: NetworkManager
EOF

KVER=$(cd /boot && ls -1 vmlinuz-* | tail -1 | sed 's@vmlinuz-@@')
depmod -a "$KVER"
update-initramfs -u -k "$KVER"

apt clean all
rm -f /etc/hostname
rm -f /etc/resolv.conf
cd /etc/
ln -sf ../run/systemd/resolve/stub-resolv.conf /etc/resolv.conf

cd /root && apt download initramfs-tools initramfs-tools-core

rm -f /var/log/apt/*
rm -rf /tmp/*
truncate -s 0 /etc/machine-id
truncate -s 0 /root/.bash_history
history -c
exit 0

## Umount filesystems after chroot
umount ${WORK}/rootfs/dev/pts
umount ${WORK}/rootfs/run
umount ${WORK}/rootfs/sys/firmware/efi/efivars
umount ${WORK}/rootfs/sys
umount ${WORK}/rootfs/proc
umount ${WORK}/rootfs/dev/pts
umount ${WORK}/rootfs/dev
mount|grep $WORK

## Prepare files for LiveCD
KVER=$(cd ${WORK}/rootfs/boot && ls -1 vmlinuz-* | tail -1 | sed 's@vmlinuz-@@')
/bin/cp -arvf ${WORK}/rootfs/boot/vmlinuz-${KVER} ${CD}/${FS_DIR}/vmlinuz
/bin/cp -arvf ${WORK}/rootfs/boot/initrd.img-${KVER} ${CD}/${FS_DIR}/initrd
rm -f ${CD}/${FS_DIR}/filesystem.${FORMAT}
mksquashfs ${WORK}/rootfs ${CD}/${FS_DIR}/filesystem.${FORMAT} -noappend
echo -n $(du -s --block-size=1 ${WORK}/rootfs | awk '{print $1}') | tee ${CD}/${FS_DIR}/filesystem.size
find ${CD} -type f -print0 | xargs -0 md5sum | sed "s@${CD}@.@" | grep -v md5sum.txt | tee ${CD}/md5sum.txt

## Create GRUB configuration
## For SMC, ttyS1 is used for serial console, for others ttyS0 should be used.
cat > ${CD}/boot/grub/grub.cfg <<- '__EOF__'
set default=0
set timeout=10

menuentry "Ubuntu 24.04 - LiveCD - ttyS0" {
    linux /casper/vmlinuz boot=casper nomodeset console=tty0 console=ttyS0,115200n8r earlyprintk=serial,ttyS0,115200,keep rd.driver.blacklist=nouveau nouveau.modeset=0 namespace.unpriv_enable=1 user_namespace.enable=1 systemd.unified_cgroup_hierarchy=1 systemd.legacy_systemd_cgroup_controller=0 cgroup_no_v1=all nvme_core.multipath=n pci=realloc=off numa_balancing=disable transparent_hugepage=madvise intremap=no_x2apic_optout pciehp.pciehp_debug=y intel_iommu=on iommu=pt intel_idle.max_cstate=9 nohz=on ---
    initrd /casper/initrd
}

menuentry "Ubuntu 24.04 - LiveCD - ttyS1" {
    linux /casper/vmlinuz boot=casper nomodeset console=tty0 console=ttyS1,115200n8r earlyprintk=serial,ttyS1,115200,keep rd.driver.blacklist=nouveau nouveau.modeset=0 namespace.unpriv_enable=1 user_namespace.enable=1 systemd.unified_cgroup_hierarchy=1 systemd.legacy_systemd_cgroup_controller=0 cgroup_no_v1=all nvme_core.multipath=n pci=realloc=off numa_balancing=disable transparent_hugepage=madvise intremap=no_x2apic_optout pciehp.pciehp_debug=y intel_iommu=on iommu=pt intel_idle.max_cstate=9 nohz=on ---
    initrd /casper/initrd
}
__EOF__

## Create LiveCD ISO image
rm -f ubuntu-24.04-live.iso
grub-mkrescue -o ubuntu-24.04-live.iso ${CD}
#
## Use xorriso if grub-mkrescue is unstable
# xorriso -as mkisofs -r \
#  -V 'Ubuntu 24.04 Custom Live' \
#  -o /tmp/u24/ubuntu-24.04-custom-live.iso \
#  --grub2-mbr /tmp/u24/iso/'[BOOT]'/1-Boot-NoEmul.img \
#  -partition_offset 16 \
#  --mbr-force-bootable \
#  -append_partition 2 28732ac11ff8d211ba4b00a0c93ec93b \
#    /tmp/u24/iso/'[BOOT]'/2-Boot-NoEmul.img \
#  -appended_part_as_gpt \
#  -iso_mbr_part_type a2a0d0ebe5b9334487c068b6b72699c7 \
#  -c '/boot.catalog' \
#  -b '/boot/grub/i386-pc/eltorito.img' \
#  -no-emul-boot -boot-load-size 4 -boot-info-table --grub2-boot-info \
#  -eltorito-alt-boot \
#  -e '--interval:appended_partition_2:::' \
#  -no-emul-boot \
#  /tmp/u24/iso

# mkdir -p /var/www/html/isos
# /bin/cp -arvf ./ubuntu-24.04-live.iso /var/www/html/isos/ubuntu-24.04-live.iso
# lftp http://localhost/isos/
