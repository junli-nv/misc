#!/bin/bash

image_name=b300-image-u2404

cmsh -c "softwareimage; clone default-image ${image_name}; commit"
cmsh -c "watch -n 3 task list"

################################################################################################

cm-chroot-sw-img /cm/images/${image_name}

## Clean up
rm -rf /var/lib/command-not-found /var/cache/swcatalog
apt purge -y command-not-found appstream update-notifier-common
dpkg -l|grep -E 'command-not-found|appstream|update-notifier-common'
## Remove nvidia driver 570.x installed in base image
apt purge $(dpkg -l|grep 570.[0-9]|awk '{print $2,$3}'|sed 's#:arm64##'|tr ' ' '=')

## Add nvidia dgx repositories
## https://docs.nvidia.com/dgx/dgx-os-7-user-guide/installing_on_ubuntu.html#installing-dgx-system-configurations-and-tools
curl https://repo.download.nvidia.com/baseos/ubuntu/noble/x86_64/dgx-repo-files.tgz | tar xzf - -C /
mv /etc/apt/sources.list.d/cm-cuda-ubuntu2404-x86_64.list /etc/apt/sources.list.d/cm-cuda-ubuntu2404-sbsa.list.disabled
#Disable dgx packages
cat > /etc/apt/preferences.d/black.pref << 'EOF'
Package: dgx*
Pin: release *
Pin-Priority: -1
EOF

#rm -f /dev/null; mknod -m 666 /dev/null c 1 3
apt update
kernel_version="6.8.0-87-generic"
apt-get install -y \
  linux-headers-${kernel_version} \
  linux-image-${kernel_version} \
  linux-modules-${kernel_version} \
  linux-tools-${kernel_version}
dkms status

apt-mark hold linux-image-generic linux-headers-generic linux-generic \
  linux-headers-${kernel_version} linux-image-${kernel_version} linux-modules-${kernel_version} linux-tools-${kernel_version}
apt-mark showhold

apt-get install -y wget numactl ipmitool lldpd needrestart

## DGX packages: apt depends nvidia-system-core
apt install -y \
  cuda-compute-repo hpc-sdk-repo nv-grubmenu nv-grubserial ipmitool msecli nv-common-apis nv-cpu-governor nv-env-paths nv-iommu nv-ipmi-devintf nv-limits nv-update-disable nvgpu-services-list nvidia-acs-disable nvidia-disable-init-on-alloc nvidia-disable-numa-balancing nvidia-earlycon nvidia-enable-power-meter-cap nvidia-esm-hook-epilogue nvidia-fs-loader nvidia-kernel-defaults nvidia-nvme-options nvidia-pci-bridge-power nvidia-pci-realloc nvidia-raid-config nvidia-relaxed-ordering-gpu nvidia-redfish-config nvidia-relaxed-ordering-nvme nvme-cli nvidia-repo-keys nvidia-ipmisol tpm2-tools #dgx-release dgx-repo nvidia-crashdump nvidia-mig-manager

## DGX packages: apt depends nvidia-system-utils
apt install -y \
  nv-persistence-mode nvidia-modprobe nvidia-container-toolkit nvidia-fs-loader nvidia-logrotate nvidia-conf-cachefilesd #nvsm nvidia-motd
systemctl disable nvsm.service

## DGX packages: apt depends nvidia-system-extra
apt install -y \
  automake bash-completion bison build-essential chrpath cifs-utils cmake cryptsetup cryptsetup-initramfs curl docker-ce ethtool flex fping gdb gdisk git htop iperf libelf-dev libltdl-dev lsof lsscsi m4 mdadm net-tools nfs-common nv-docker-options openssh-server parted pciutils perftest pm-utils powercap-utils quota rasdaemon samba-common samba-libs sg3-utils shim-signed smartmontools sosreport ssh ssh-import-id swig sysstat udev vim vlan witalian wngerman wogerman wportuguese wspanish wswiss xserver-xorg #command-not-found

## GPU Driver: !!! It's important to make sure the all the nvidia.*580 packages' version the same !!!
dpkg -l|grep 'nvidia.*580' 
# As GPU driver packages already been installed in base image, if all the packages align each other, then no action needed.
# If not, uninstall the current ones
apt purge $(dpkg -l|grep 'nvidia.*580'|awk '{print $2}')
# Then install GPU driver from nvidia repo ONLY!!! The better to set the version explicitly.
mv /etc/apt/sources.list.d/ai-workbench-desktop.sources /etc/apt/sources.list.d/ai-workbench-desktop.sources.disabled
apt update
apt-cache madison nvidia-driver-580-open | grep developer.download.nvidia.com
ver=580.126.09
apt install -y --allow-downgrades \
  libnvidia-nscq=${ver}-1  \
  nvidia-fabricmanager=${ver}-1  \
  nvidia-driver-580-open=${ver}-0ubuntu1 \
  nvidia-dkms-580-open=${ver}-0ubuntu1 \
  nvidia-settings=${ver}-0ubuntu1 \
  libxnvctrl0=${ver}-0ubuntu1 \
  nvidia-modprobe=${ver}-0ubuntu1 \
  nvidia-kernel-source-580-open=${ver}-0ubuntu1 \
  nvidia-kernel-common-580=${ver}-0ubuntu1 \
  libnvidia-gl-580=${ver}-0ubuntu1 \
  libnvidia-extra-580=${ver}-0ubuntu1 \
  libnvidia-decode-580=${ver}-0ubuntu1 \
  libnvidia-encode-580=${ver}-0ubuntu1 \
  xserver-xorg-video-nvidia-580=${ver}-0ubuntu1 \
  libnvidia-cfg1-580=${ver}-0ubuntu1 \
  libnvidia-fbc1-580=${ver}-0ubuntu1 \
  libnvidia-common-580=${ver}-0ubuntu1 \
  nvidia-firmware-580=${ver}-0ubuntu1 \
  libnvidia-gpucomp-580=${ver}-0ubuntu1 \
  libnvidia-compute-580=${ver}-0ubuntu1 \
  nvidia-imex=${ver}-1

## Fix the slurm can't detect NVML issue
cd /usr/lib/x86_64-linux-gnu/
ln -sf libnvidia-ml.so.1 libnvidia-ml.so
cd /root

apt install -y \
  libnvidia-container-tools libnvidia-container1 nvidia-container-toolkit nvidia-container-toolkit-base
apt install -y \
  datacenter-gpu-manager-4-core datacenter-gpu-manager-exporter \
  datacenter-gpu-manager-4-cuda13 datacenter-gpu-manager-4-multinode-cuda13
systemctl enable nvidia-persistenced nvidia-dcgm nvidia-fabricmanager #nvidia-imex
mkdir -p /var/run/nvidia-fabricmanager
chmod 755 /var/run/nvidia-fabricmanager

## CUDA
apt install -y cuda-nvml-dev-13-0 #cuda-toolkit-13-0

## DOCA
apt install -y doca-all
systemctl disable srp_daemon.service srptools.service
systemctl enable openibd
apt install -y mft netplan.io 
ln -sf /usr/lib/mft /usr/lib64/mft

## nvidia-peermem
apt install -y nvidia-peermem-loader

## Install additional packages
apt install -y \
 nv-common-apis \
 nv-cpu-governor \
 nvdebug \
 nv-docker-options \
 nv-env-paths \
 nvfwupd \
 nvgpu-services-list \
 nv-hugepage \
 nvidia-acs-disable  \
 nvidia-conf-cachefilesd \
 nvidia-crashdump \
 nvidia-disable-opensm  \
 nvidia-ipmisol \
 nvidia-kbd-udev \
 nvidia-logrotate \
 nvidia-mig-manager \
 nvidia-mlnx-names \
 nvidia-mlnx-ofed-netdev-rename \
 nvidia-mstflint-loader  \
 nvidia-nvme-smartd \
 nvidia-oem-config-bmc \
 nvidia-oem-config-crypt-passwd \
 nvidia-oem-config-eula \
 nvidia-oem-config-grub-passwd \
 nvidia-oem-config-postact  \
 nvidia-pci-bridge-power \
 nvidia-pci-no-realloc \
 nvidia-peermem-loader \
 nvidia-raid-config \
 nvidia-redfish-config \
 nvidia-relaxed-ordering-nvme  \
 nvidia-repo-keys \
 nv-iommu-pt \
 nv-ipmi-devintf \
 nvipmitool \
 nv-update-disable

## GDRCOPY #packages from dgx
apt install -y gdrdrv-dkms gdrcopy gdrcopy-tests libgdrapi

## For Lustre
cat >> /etc/sysctl.conf <<- EOF
### Add for DDN/Lustre
net.ipv4.conf.all.accept_local=1
net.ipv4.conf.all.arp_announce=2
net.ipv4.conf.all.arp_filter=0
net.ipv4.conf.all.arp_ignore=1
net.ipv4.conf.all.rp_filter=0
net.ipv4.conf.default.accept_local=1
net.ipv4.conf.default.arp_announce=2
net.ipv4.conf.default.arp_filter=0
net.ipv4.conf.default.arp_ignore=1
net.ipv4.conf.default.rp_filter=0
EOF

systemctl set-default multi-user.target
echo 'root:123456'|chpasswd
rm -rf /var/lib/command-not-found /var/cache/swcatalog
apt purge -y command-not-found appstream update-notifier-common
dpkg -l|grep -E 'command-not-found|appstream|update-notifier-common'

apt purge -y unattended-upgrades

sed -i.ori -e 's#next unless "$tag" ne "";#next unless defined $tag and "$tag" ne "";#g' /usr/bin/dshbak

systemctl mask rdma-ndd.service
mv /usr/lib/udev/rules.d/60-rdma-ndd.rules /usr/lib/udev/rules.d/60-rdma-ndd.rules.disabled

#Workaround for CVE-2026-31431 - Copy Fail
echo -e 'install algif_aead /bin/false\nblacklist algif_aead' > /etc/modprobe.d/disable-algif-aead.conf

cat > /etc/rc.local <<- 'EOF'
#!/bin/bash
export PATH=/usr/sbin:/usr/bin:/sbin:/bin:/usr/local/sbin:/usr/local/bin:$PATH

##https://nvbugspro.nvidia.com/bug/6130494
modprobe -r algif_aead
find /lib/modules/$(uname -r) -iname 'algif_aead.ko*' -delete || true

nics=($(lspci -D | grep -i eth|awk '{print $1}'|while read i; do basename $(ls -l /sys/class/net/|grep -o ${i}/.*); done))
for i in ${nics[*]}; do ip link set ${i} up; done
lldpcli configure system hostname .
lldpcli configure lldp portidsubtype ifname
lldpcli configure system interface pattern eth*,eno*,enp*,ens*,enP*
systemctl restart lldpd
# lldpcli show neighbors

start_rdma-ndd(){
  while : ; do
    if [[ $(lsmod | grep mlx5_ib | wc -l) -ne 0 && $(grep -r HCA- /sys/class/infiniband/mlx5_*/node_desc|wc -l) -ne 0 ]]; then
      break
    else
      sleep 10
    fi
  done
  pkill -9 rdma-ndd &>/dev/null
  sleep 10
  export RDMA_NDD_ND_FORMAT="%h %d"
  nohup /usr/sbin/rdma-ndd  -f --debug &
}
export -f start_rdma-ndd
nohup bash -c "start_rdma-ndd" &>/tmp/rdma-ndd.txt &

#echo performance > /sys/module/pcie_aspm/parameters/policy

exit 0
EOF
chmod 755 /etc/rc.local

## Workaround for /usr and /etc permission changed during image creation
chown -R root:root /usr/ /etc/

apt-mark unhold linux-image-generic linux-headers-generic linux-generic \
  linux-headers-${kernel_version} linux-image-${kernel_version} linux-modules-${kernel_version} linux-tools-${kernel_version}

systemctl disable cachefilesd
rm -f /var/log/apt/*
rm -rf /tmp/*
history -c
truncate -s 0 /etc/machine-id
truncate -s 0 /root/.bash_history
exit 0

# umount /cm/images/${image_name}/sys/firmware/efi/efivars 
# umount /cm/images/${image_name}/sys

################################# Image Change
image_name=b300-image-u2404

cm-chroot-sw-img /cm/images/${image_name} <<- '__END__'
ln -sf /cm/shared/apps/slurm/var/cm/prolog-enroot.sh /cm/local/apps/slurm/var/prologs/50-prolog-enroot.sh
ln -sf /cm/shared/apps/slurm/var/cm/epilog-enroot.sh /cm/local/apps/slurm/var/epilogs/50-epilog-enroot.sh
__END__

#Load Slurm module at login
echo "module load -s slurm" > /cm/images/${image_name}/etc/profile.d/zz-slurm-module.sh

#Add enroot directories in DGX image
mkdir -p  /cm/images/${image_name}/raid/local/containers/{enroot-runtime,enroot-cache,enroot-data}
chmod 777 /cm/images/${image_name}/raid/local/containers/{enroot-runtime,enroot-cache,enroot-data}

#Enroot PyTorch hook
cp /cm/local/apps/bcm-post-install/etc/slurm_pytorch_hook /cm/images/${image_name}/etc/enroot/hooks.d/50-slurm-pytorch.sh
chmod 755 /cm/images/${image_name}/etc/enroot/hooks.d/50-slurm-pytorch.sh

#Slurm PMIX profile
cp /cm/local/apps/bcm-post-install/etc/slurm_pmix /cm/images/${image_name}/etc/profile.d/pmix.sh
chmod 755 /cm/images/${image_name}/etc/profile.d/pmix.sh

#Enroot MLNX profile. 
cp /cm/local/apps/bcm-post-install/etc/enroot_mlnx_env /cm/images/${image_name}/etc/enroot/environ.d/20-mlx.env
chmod 755 /cm/images/${image_name}/etc/enroot/environ.d/20-mlx.env
sed -i \
  -e 's:^MELLANOX_VISIBLE_DEVICES=.*:MELLANOX_VISIBLE_DEVICES=all:g' \
  -e 's:\(^OMPI_MCA_btl_tcp_if_include=.*\):#\1:g' \
  /cm/images/${image_name}/etc/enroot/environ.d/20-mlx.env

#Slurmd config
cat > /cm/images/${image_name}/etc/sysconfig/slurmd << EOF
PMIX_MCA_ptl=^usock
PMIX_MCA_psec=none
PMIX_SYSTEM_TMPDIR=/var/empty
PMIX_MCA_gds=hash
EOF

cat > /cm/images/${image_name}/etc/sudoers.d/cmsupport << EOF
# Allow members of group cmsupport to execute any command
#%cmsupport ALL=(ALL:ALL) ALL
%cmsupport ALL=NOPASSWD: ALL
EOF

sed -i.ori -e "s:131072:$[1024*1024]:g" /cm/images/${image_name}/etc/security/limits.d/91-cm-limits.conf
sed -i.ori -e "s:131072:$[1024*1024*1024]:g" /cm/images/${image_name}/etc/sysctl.d/90-cm-sysctl.conf

image_name=b300-image-u2404
#kvers=($(ls -1 /cm/images/${image_name}/lib/modules|sort -n))
kvers=6.8.0-87-generic

#Make sure don't add ast.modeset=0 otherwise nodeinstaller can't output to tty0 
#SuperMicro: ttyS1, other vendors: ttyS0
cmsh <<- __END__
softwareimage
use ${image_name}
set kernelversion ${kvers[0]}
set kernelparameters "rd.driver.blacklist=nouveau nouveau.modeset=0 namespace.unpriv_enable=1 user_namespace.enable=1 systemd.unified_cgroup_hierarchy=1 systemd.legacy_systemd_cgroup_controller=0 cgroup_no_v1=all nvme_core.multipath=n pci=realloc=off earlyprintk=serial,ttyS1,115200,keep numa_balancing=disable transparent_hugepage=madvise intremap=no_x2apic_optout pciehp.pciehp_debug=y intel_iommu=on iommu=pt intel_idle.max_cstate=0 processor.max_cstate=0 intel_pstate=disable"
set enablesol yes
set solport ttyS1
set solflowcontrol no
set kerneloutputconsole ttyS1,115200n8r
commit
kernelmodules
add bonding; add ib_umad; add mlx5_core; add raid0; add raid1
commit
__END__

cmsh -c 'watch task list'

## Check the initrd and vmlinuz used for tftp
ls -l /cm/images/${image_name}/{initrd.img,vmlinuz}  /tftpboot/images/${image_name}/

## Cleanup mounts
umount /cm/images/${image_name}/{/run/systemd/resolve/resolv.conf,/dev/pts,/dev,/proc,/sys/firmware/efi/efivars,/sys,/run}

