#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

apt install -y squid
grep -v -e '^#' -e '^$' /etc/squid/squid.conf
mv /etc/squid/squid.conf /etc/squid/squid.conf.ori
cat > /etc/squid/squid.conf <<- 'EOF'
# ===== Basic Squid forward proxy configuration =====

# Port Squid listens on
http_port 3128

# Prefer IPv4 DNS first (optional but often useful)
dns_v4_first on

# ---------- Access control lists (ACLs) ----------

# Local networks that are allowed to use the proxy
# CHANGE THESE to match your own LAN ranges
acl localnet src 10.0.0.0/8
acl localnet src 172.16.0.0/12
acl localnet src 192.168.0.0/16

# Always allow localhost
acl localhost src 127.0.0.1/32 ::1

# Safe destination ports
acl SSL_ports port 443
acl Safe_ports port 80          # http
acl Safe_ports port 21          # ftp
acl Safe_ports port 443         # https
acl Safe_ports port 70          # gopher
acl Safe_ports port 210         # wais
acl Safe_ports port 1025-65535  # unregistered ports
acl Safe_ports port 280         # http-mgmt
acl Safe_ports port 488         # gss-http
acl Safe_ports port 591         # filemaker
acl Safe_ports port 777         # multiling http

acl CONNECT method CONNECT

# ---------- Security rules ----------

# Deny requests to unsafe ports
http_access deny !Safe_ports

# Deny CONNECT to non-SSL ports
http_access deny CONNECT !SSL_ports

# Allow localhost and LAN clients
http_access allow localhost
http_access allow localnet

# Finally deny all other access
http_access deny all

# ---------- Caching (simple defaults) ----------

# In‑RAM cache
cache_mem 256 MB
maximum_object_size_in_memory 512 KB

# On‑disk cache (adjust size/path for your system)
cache_dir ufs /var/spool/squid 10000 16 256

# Logs
access_log /var/log/squid/access.log
cache_log  /var/log/squid/cache.log

# Optional: keep logs quieter
logfile_rotate 10
EOF
systemctl restart squid
ss -lntp|grep 3128