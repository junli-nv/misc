#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

##https://nvbugspro.nvidia.com/bug/6130494
#Workaround for CVE-2026-31431 - Copy Fail
echo -e 'install algif_aead /bin/false\nblacklist algif_aead' > /etc/modprobe.d/disable-algif-aead.conf
modprobe -r algif_aead
find /lib/modules/ -iname 'algif_aead.ko*' | xargs -I{} mv {} {}.disabled
find /cm/images/ -iname 'algif_aead.ko*' | xargs -I{} mv {} {}.disabled
for i in /cm/images/*; do mkdir -p ${i}/etc/modprobe.d; echo "install algif_aead /bin/false" > ${i}/etc/modprobe.d/disable-algif-aead.conf; done

grep '^[a-z]' /etc/cm-install-release
#date:       Jul 16 2025 09:38AM +0000
#medium:     ISO
#release:    11.25.05
#installer:  baremetal

apt update
apt --yes --assume-yes --allow-unauthenticated -o Dpkg::Options::="--force-confold" upgrade
sudo apt purge -y unattended-upgrades
rm -f /var/log/apt/*
rm -rf /tmp/*
truncate -s 0 /etc/machine-id
truncate -s 0 /root/.bash_history

reboot

