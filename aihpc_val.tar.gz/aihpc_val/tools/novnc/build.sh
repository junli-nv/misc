#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

cat > start.sh <<- 'EOF'
#!/bin/bash
set +x
export USER=root
rm -rf $HOME/.vnc
mkdir $HOME/.vnc
chmod 700 $HOME/.vnc
echo "${VNC_PASSWORD:-P@ssw0rd}" | vncpasswd -f > $HOME/.vnc/passwd
chmod 0600 $HOME/.vnc/passwd
cat > $HOME/.vnc/xstartup << '__END__'
#!/bin/bash
xrdb $HOME/.Xresources
xsetroot -solid grey
export XKL_XMODMAP_DISABLE=1
/usr/bin/startlxde
__END__
chmod 755 $HOME/.vnc/xstartup

while :
do
  vncserver -kill :1 &>/dev/null
  vncserver -depth 24 -geometry ${GEOMOTRY:-1400x700} :1
  /usr/share/novnc/utils/launch.sh --listen 80 --vnc 127.0.0.1:5901 --web /usr/share/novnc/ &>/tmp/novnc.log &
  novncpid=$!
  vncpid=$(ps -ef|grep 'Xtightvnc.*:1'|grep -v grep|awk '{print $2}')
  while :; do [ -e /proc/${vncpid}/exe ] && sleep 10 || break; done
  kill $novncpid &>/dev/null
  pkill -9 ssh-agent &>/dev/null
  pkill -9 pcmanfm &>/dev/null
  rm -f /tmp/.X1-lock /tmp/.X11-unix/X1 $HOME/.vnc/*.log
done
EOF

cat > novnc-u2204.df <<- 'EOF'
FROM ubuntu:22.04
MAINTAINER JunLi Zhang<junliz@nvidia.com>

ENV DEBIAN_FRONTEND=noninteractive

RUN \
  apt update && \
  apt install -y --no-install-recommends \
    software-properties-common curl sudo \
    net-tools zenity xz-utils gpg-agent \
    dbus-x11 x11-utils alsa-utils \
    mesa-utils libgl1-mesa-dri \
    xvfb x11vnc vim-tiny firefox \
    ttf-wqy-zenhei xfonts-wqy \
    lxde gtk2-engines-murrine gnome-themes-standard \
    gtk2-engines-pixbuf gtk2-engines-murrine arc-theme \
    novnc tightvncserver websockify \
    net-tools wget curl openssh-client git \
    python3-numpy \
    xserver-xorg-core xfonts-base && \
  apt autoclean -y && \
  apt autoremove -y && \
  rm -rf /var/lib/apt/lists/* && \
  ln -s /usr/share/novnc/vnc_lite.html /usr/share/novnc/index.html

RUN \
  wget -c https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb && \
  apt update && \
  apt install -y ./google-chrome-stable_current_amd64.deb && \
  apt autoclean -y && \
  rm -rf /var/lib/apt/lists/*

RUN \
  wget https://download.operachina.com/ftp/pub/opera/desktop/118.0.5461.60/linux/opera-stable_118.0.5461.60_amd64.deb && \
  apt update && \
  apt install -y ./opera-stable_118.0.5461.60_amd64.deb && \
  apt autoclean -y && \
  rm -rf /var/lib/apt/lists/*

#For "No session for pid xxxx" problem when connect to VNC
#Ref: https://github.com/meefik/linuxdeploy/issues/978
RUN \
  mv /usr/bin/lxpolkit /usr/bin/lxpolkit.ori
USER root
ADD start.sh /start.sh
CMD ["/bin/bash", "/start.sh"]
EOF
docker build --network=host -f novnc-u2204.df -t novnc .

docker rm -f desktop
docker run -d -ti \
  --cpuset-cpus 1-4 \
  --cpuset-mems 0 \
  -m 8G \
  --name desktop \
  -p 6080:80 \
  -e VNC_PASSWORD="R00tp@55" \
  -e GEOMOTRY="1600x900" \
  -v /dev/shm:/dev/shm \
  novnc

docker exec desktop /bin/bash -c "DISPLAY=:1.0 google-chrome --no-sandbox"

# URL: http://${HOSTIP}:6080/
