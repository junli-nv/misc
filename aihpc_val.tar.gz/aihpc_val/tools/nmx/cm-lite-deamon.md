## Symptom

Lots of full rack compute trays met nvlink issue, after examine the switch, saw cm-lite-daemon OOM.
```
[170996.085844] cm-lite-daemon invoked oom-killer: gfp_mask=0xcc0(GFP_KERNEL), order=0, oom_score_adj=0
[170996.085854] CPU: 2 PID: 1585097 Comm: cm-lite-daemon Kdump: loaded Tainted: G           O       6.1.0-22-2-amd64 #1  Debian 6.1.94-1
[170996.085859] Hardware name: Nvidia N5500_LD/VMOD0021, BIOS 5.13 06/30/2025
[170996.085862] Call Trace:
[170996.085866]  <TASK>
[170996.085870]  dump_stack_lvl+0x44/0x5c
[170996.085877]  dump_header+0x4a/0x211
[170996.085884]  out_of_memory.cold+0x42/0x7e
[170996.085889]  mem_cgroup_out_of_memory+0x134/0x150
[170996.085898]  try_charge_memcg+0x696/0x780
[170996.085906]  charge_memcg+0x39/0xf0
[170996.085911]  __mem_cgroup_charge+0x28/0x80
[170996.085916]  __handle_mm_fault+0x948/0xf60
[170996.085927]  handle_mm_fault+0xdb/0x2d0
[170996.085932]  do_user_addr_fault+0x191/0x550
[170996.085938]  exc_page_fault+0x70/0x170
[170996.085944]  asm_exc_page_fault+0x22/0x30
[170996.085949] RIP: 0033:0x7f67ac442ed0
[170996.085953] Code: 10 49 c7 44 24 18 ff ff ff ff 41 c6 44 1c 20 00 48 85 ed 74 8a 49 8d 7c 24 20 48 89 ee 48 83 fb 08 72 0a 48 89 d9 48 c1 e9 03 <f3> 48 a5 31 c0 f6 c3 04 75 46 f6 c3 02 75 21 83 e3 01 0f 84 5d ff
[170996.085956] RSP: 002b:00007f6776ffc9e0 EFLAGS: 00010213
[170996.085961] RAX: 0000000000000000 RBX: 0000000007b55d5d RCX: 0000000000c60db1
[170996.085963] RDX: 0000000007b56002 RSI: 00007f6731500008 RDI: 00007f67299aa000
[170996.085966] RBP: 00007f672fcb1038 R08: 00000000ffffffff R09: 0000000000000000
[170996.085969] R10: 0000000000000022 R11: 0000000000000246 R12: 00007f672815b010
[170996.085971] R13: 00007f672fcb1010 R14: 0000000000000005 R15: 00007f67aa472df2
[170996.085979]  </TASK>
[170996.085981] memory: usage 524288kB, limit 524288kB, failcnt 86
[170996.085983] memory+swap: usage 524288kB, limit 9007199254740988kB, failcnt 0
[170996.085986] kmem: usage 2056kB, limit 9007199254740988kB, failcnt 0
[170996.085988] Memory cgroup stats for /system.slice/cm-lite-daemon.service:
[170996.086009] anon 534753280
```

## Resolution

- Disable cm-lite-daemon completely
Remove cm-lite-daemon from NVSwitches via BCM
```
cmsh
device
litedaemon remove --field kind=nvlink
```
Prevent BCM from reinstalling cm-lite-daemon (ZTP)
```
cmsh
device
use <switch_hostname>
ztpsettings
# In this submode, change "Install lite daemon" from yes → no
# (interactive: edit the *Install lite daemon* field to "no")
commit
```

- Keep cm-lite-daemon but disable metrics
```
monitoring setup
set sample-nv-metrics disabled yes; commit
set procnetdev disabled yes; commit
```
