## Symptom

Using the same racks the same nodes, NCCL hang with NVLS enabled but worked fine with NVLS disabled. 
```
root@bcm11-headnode:/home/cmsupport/workspace/aihpc_val/validation/nccl# diff -u nccl.sbatch.1 nccl.sbatch.2
--- nccl.sbatch.1       2026-02-10 13:29:15.913800404 +0000
+++ nccl.sbatch.2       2026-02-10 13:30:48.978038642 +0000
@@ -49,7 +49,7 @@
 export SLURM_CPU_BIND=none
 #
 export NCCL_P2P_LEVEL=NVL
-export NCCL_NVLS_ENABLE=1
+export NCCL_NVLS_ENABLE=0
 export NCCL_CUMEM_ENABLE=1
 export NCCL_MIN_CTAS=16
 export NCCL_MNNVL_ENABLE=1
root@bcm11-headnode:/home/cmsupport/workspace/aihpc_val/validation/nccl# grep -e NODELIST -e 1717.*float -e NCCL_NVLS_ENABLE slurm-1157.out slurm-1158.out
slurm-1157.out:NODELIST: p5-r01-ct[01-18]
slurm-1157.out:+ export NCCL_NVLS_ENABLE=1
slurm-1157.out:+ NCCL_NVLS_ENABLE=1
slurm-1158.out:NODELIST: p5-r01-ct[01-18]
slurm-1158.out:+ export NCCL_NVLS_ENABLE=0
slurm-1158.out:+ NCCL_NVLS_ENABLE=0
slurm-1158.out: 17179869184    4294967296     float     sum      -1  47980.5  358.06  706.17       0  48054.3  357.51  705.09       0
```

## Narrow Down
By examining the nvlsm.log file, it can be seen that the IB_TIMEOUT and IB_UNKNOWN_ERROR errors occur periodically.
```
admin@p5-r01-nvsw-01:~$ grep -Ei 'ERROR|WARN' /var/log/nmx/nmx-c/nvlsm.log | tail -n 50
Feb 10 09:52:01 632670 [88FF9640] 0x01 -> log_send_error: ERR 5411: DR SMP Send completed with error (IB_TIMEOUT) -- dropping
Feb 10 09:52:01 632681 [88FF9640] 0x01 -> sm_mad_ctrl_send_err_cb: ERR 3113: MAD completed in error (IB_TIMEOUT): SubnGet(P_KeyTable), attr_mod 0x0, TID 0x5232d, dest_guid 0x3a8fe300f87371c9
Feb 10 09:52:01 632698 [88FF9640] 0x01 -> log_send_error: ERR 5411: DR SMP Send completed with error (IB_TIMEOUT) -- dropping
Feb 10 09:52:01 632705 [88FF9640] 0x01 -> sm_mad_ctrl_send_err_cb: ERR 3113: MAD completed in error (IB_TIMEOUT): SubnGet(P_KeyTable), attr_mod 0x0, TID 0x52357, dest_guid 0x8a2f49d24906791d
Feb 10 09:52:01 632722 [88FF9640] 0x01 -> log_send_error: ERR 5411: DR SMP Send completed with error (IB_TIMEOUT) -- dropping
Feb 10 09:52:01 632729 [88FF9640] 0x01 -> sm_mad_ctrl_send_err_cb: ERR 3113: MAD completed in error (IB_TIMEOUT): SubnGet(P_KeyTable), attr_mod 0x0, TID 0x52359, dest_guid 0x2c405515789567ef
Feb 10 09:52:01 632745 [88FF9640] 0x01 -> log_send_error: ERR 5411: DR SMP Send completed with error (IB_TIMEOUT) -- dropping
Feb 10 09:52:01 632752 [88FF9640] 0x01 -> sm_mad_ctrl_send_err_cb: ERR 3113: MAD completed in error (IB_TIMEOUT): SubnGet(P_KeyTable), attr_mod 0x0, TID 0x5235b, dest_guid 0x3a8fe300f87371c9
Feb 10 09:52:01 632768 [88FF9640] 0x01 -> log_send_error: ERR 5411: DR SMP Send completed with error (IB_TIMEOUT) -- dropping
Feb 10 09:52:01 632776 [88FF9640] 0x01 -> sm_mad_ctrl_send_err_cb: ERR 3113: MAD completed in error (IB_TIMEOUT): SubnGet(P_KeyTable), attr_mod 0x0, TID 0x5235f, dest_guid 0xcf9924c5a01fa9a4
Feb 10 09:52:02 380569 [88FF9640] 0x01 -> log_send_error: ERR 5411: DR SMP Send completed with error (IB_TIMEOUT) -- dropping
Feb 10 09:52:02 380598 [88FF9640] 0x01 -> sm_mad_ctrl_send_err_cb: ERR 3113: MAD completed in error (IB_TIMEOUT): SubnGet(P_KeyTable), attr_mod 0x0, TID 0x52360, dest_guid 0x8428dba386091633
Feb 10 09:52:02 380645 [88FF9640] 0x01 -> log_send_error: ERR 5411: DR SMP Send completed with error (IB_TIMEOUT) -- dropping
Feb 10 09:52:02 380655 [88FF9640] 0x01 -> sm_mad_ctrl_send_err_cb: ERR 3113: MAD completed in error (IB_TIMEOUT): SubnGet(P_KeyTable), attr_mod 0x0, TID 0x52361, dest_guid 0x04ae5b0f8fd32441
Feb 10 09:52:02 380677 [88FF9640] 0x01 -> log_send_error: ERR 5411: DR SMP Send completed with error (IB_TIMEOUT) -- dropping
Feb 10 09:52:02 380686 [88FF9640] 0x01 -> sm_mad_ctrl_send_err_cb: ERR 3113: MAD completed in error (IB_TIMEOUT): SubnGet(P_KeyTable), attr_mod 0x0, TID 0x52362, dest_guid 0xac77a246f4ea7908
Feb 10 09:52:02 380702 [88FF9640] 0x01 -> log_send_error: ERR 5411: DR SMP Send completed with error (IB_TIMEOUT) -- dropping
Feb 10 09:52:02 380710 [88FF9640] 0x01 -> sm_mad_ctrl_send_err_cb: ERR 3113: MAD completed in error (IB_TIMEOUT): SubnGet(P_KeyTable), attr_mod 0x0, TID 0x52363, dest_guid 0x6a0b64f1aa209720
Feb 10 09:52:02 380730 [88FF9640] 0x01 -> log_send_error: ERR 5411: DR SMP Send completed with error (IB_TIMEOUT) -- dropping
Feb 10 09:52:02 380738 [88FF9640] 0x01 -> sm_mad_ctrl_send_err_cb: ERR 3113: MAD completed in error (IB_TIMEOUT): SubnGet(P_KeyTable), attr_mod 0x0, TID 0x52364, dest_guid 0x828c218896bd7a1b
Feb 10 09:52:02 380755 [88FF9640] 0x01 -> log_send_error: ERR 5411: DR SMP Send completed with error (IB_TIMEOUT) -- dropping
Feb 10 09:52:02 380763 [88FF9640] 0x01 -> sm_mad_ctrl_send_err_cb: ERR 3113: MAD completed in error (IB_TIMEOUT): SubnGet(P_KeyTable), attr_mod 0x0, TID 0x52365, dest_guid 0x9256602e63272689
Feb 10 09:52:02 380780 [88FF9640] 0x01 -> log_send_error: ERR 5411: DR SMP Send completed with error (IB_TIMEOUT) -- dropping
Feb 10 09:52:02 380787 [88FF9640] 0x01 -> sm_mad_ctrl_send_err_cb: ERR 3113: MAD completed in error (IB_TIMEOUT): SubnGet(P_KeyTable), attr_mod 0x0, TID 0x52369, dest_guid 0xa09f3db72566e39b
Feb 10 12:07:00 625064 [BE3E5640] 0x02 -> do_sweep: Entering heavy sweep with flags: force_heavy_sweep 1, coming out of standby 0, subnet initialization error 0, sm port change 0
Feb 10 12:07:00 810031 [BE3E5640] 0x02 -> do_sweep: Entering heavy sweep with flags: force_heavy_sweep 1, coming out of standby 0, subnet initialization error 0, sm port change 0
Feb 10 12:07:01 132798 [BE3E5640] 0x02 -> do_sweep: Entering heavy sweep with flags: force_heavy_sweep 1, coming out of standby 0, subnet initialization error 0, sm port change 0
Feb 10 12:07:01 585878 [BE3E5640] 0x02 -> do_sweep: Entering heavy sweep with flags: force_heavy_sweep 1, coming out of standby 0, subnet initialization error 0, sm port change 0
Feb 10 12:07:02 176981 [C33EF640] 0x01 -> vl15_send_mad: ERR 3E03: MAD send failed (IB_UNKNOWN_ERROR)
Feb 10 12:07:02 372219 [BE3E5640] 0x02 -> do_sweep: Entering heavy sweep with flags: force_heavy_sweep 1, coming out of standby 0, subnet initialization error 0, sm port change 0
Feb 10 12:07:03 696987 [BE3E5640] 0x02 -> do_sweep: Entering heavy sweep with flags: force_heavy_sweep 1, coming out of standby 0, subnet initialization error 0, sm port change 0
Feb 10 12:07:04 764818 [BE3E5640] 0x02 -> do_sweep: Entering heavy sweep with flags: force_heavy_sweep 1, coming out of standby 0, subnet initialization error 0, sm port change 0
Feb 10 12:07:05 273420 [BE3E5640] 0x02 -> do_sweep: Entering heavy sweep with flags: force_heavy_sweep 1, coming out of standby 0, subnet initialization error 0, sm port change 0
Feb 10 12:07:22 623864 [BE3E5640] 0x02 -> do_sweep: Entering heavy sweep with flags: force_heavy_sweep 1, coming out of standby 0, subnet initialization error 0, sm port change 0
Feb 10 12:07:23 448313 [BE3E5640] 0x02 -> do_sweep: Entering heavy sweep with flags: force_heavy_sweep 1, coming out of standby 0, subnet initialization error 0, sm port change 0
Feb 10 12:07:24 018242 [BE3E5640] 0x02 -> do_sweep: Entering heavy sweep with flags: force_heavy_sweep 1, coming out of standby 0, subnet initialization error 0, sm port change 0
Feb 10 12:07:24 972533 [BE3E5640] 0x02 -> do_sweep: Entering heavy sweep with flags: force_heavy_sweep 1, coming out of standby 0, subnet initialization error 0, sm port change 0
Feb 10 12:07:26 856492 [BE3E5640] 0x02 -> do_sweep: Entering heavy sweep with flags: force_heavy_sweep 1, coming out of standby 0, subnet initialization error 0, sm port change 0
Feb 10 12:07:27 617069 [BE3E5640] 0x02 -> do_sweep: Entering heavy sweep with flags: force_heavy_sweep 1, coming out of standby 0, subnet initialization error 0, sm port change 0
Feb 10 12:07:28 172716 [C33EF640] 0x01 -> vl15_send_mad: ERR 3E03: MAD send failed (IB_UNKNOWN_ERROR)
Feb 10 12:07:28 241878 [BE3E5640] 0x02 -> do_sweep: Entering heavy sweep with flags: force_heavy_sweep 1, coming out of standby 0, subnet initialization error 0, sm port change 0
Feb 10 12:07:29 431083 [BE3E5640] 0x02 -> do_sweep: Entering heavy sweep with flags: force_heavy_sweep 1, coming out of standby 0, subnet initialization error 0, sm port change 0
Feb 10 12:07:36 214372 [BE3E5640] 0x02 -> do_sweep: Entering heavy sweep with flags: force_heavy_sweep 1, coming out of standby 0, subnet initialization error 0, sm port change 0
Feb 10 12:07:37 633543 [BE3E5640] 0x02 -> do_sweep: Entering heavy sweep with flags: force_heavy_sweep 1, coming out of standby 0, subnet initialization error 0, sm port change 0
Feb 10 12:07:38 446360 [C33EF640] 0x01 -> vl15_send_mad: ERR 3E03: MAD send failed (IB_UNKNOWN_ERROR)
Feb 10 12:07:38 555497 [BE3E5640] 0x02 -> do_sweep: Entering heavy sweep with flags: force_heavy_sweep 1, coming out of standby 0, subnet initialization error 0, sm port change 0
Feb 10 12:07:39 506579 [C33EF640] 0x01 -> vl15_send_mad: ERR 3E03: MAD send failed (IB_UNKNOWN_ERROR)
Feb 10 12:07:39 607661 [BE3E5640] 0x02 -> do_sweep: Entering heavy sweep with flags: force_heavy_sweep 1, coming out of standby 0, subnet initialization error 0, sm port change 0
Feb 10 12:07:39 997377 [BE3E5640] 0x02 -> do_sweep: Entering heavy sweep with flags: force_heavy_sweep 1, coming out of standby 0, subnet initialization error 0, sm port change 0
Feb 10 12:07:40 629068 [BE3E5640] 0x02 -> do_sweep: Entering heavy sweep with flags: force_heavy_sweep 1, coming out of standby 0, subnet initialization error 0, sm port change 0
```


