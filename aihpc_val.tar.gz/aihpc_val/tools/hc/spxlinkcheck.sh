#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>
export DEBUG=${DEBUG:-0}
export SWEEP=${SWEEP:-0}

lldpcli show running-configuration|grep 'Interface pattern:'|grep enP >/dev/null
if [ $? -ne 0 ]; then
  echo "=======Configure LLDP======="
  #lldpcli configure system hostname .
  lldpcli configure system hostname "$(hostname -f)"
  lldpcli configure lldp portidsubtype ifname
  lldpcli configure system interface pattern eth*,eno*,enp*,ens*,enP*
  # lldpcli show running-configuration
  lldpcli update
fi

echo "=======Show LLDP Neighbors======="
tmpf=$(mktemp)
lldpcli show neighbors | awk -v hostname=$(hostname) '
/^[-]+$/ { if (line != "") { print hostname":"line; line = "" }; next }
/^LLDP neighbors:$/ { next }
/Interface:/ { gsub(/,/, " "); line = line" "$2 }
/SysName:/ { line = line" "$NF }
/PortID:/{line = line" "$NF}
END { if (line != "") print hostname":"line }
' | sort -k1,1 -k2,2 -k3,3 | tee $tmpf
[ $DEBUG -eq 1 ] && {
echo "=======Check cable connection======="
cut -f2- -d' ' $tmpf | grep p[0-4] | grep r[0-7] | paste - - - -|awk '{
s=0
for(i=3;i<=NF;i+=3) {
  if ($i != $3) { s += 1; break }
}
if (s == 0){
   print $0
} else {
   print $0" <*>"
}
}'|tr -s '\t' ' '|tr -s ' '
}
rm -f $tmpf

echo "=======Check NIC connectivity======="
declare -A ip_dict
while read gw a iface b c d e f ip; do
  rdma_if=$(rdma link|grep -w $iface|awk '{print $2}'|cut -f1 -d'/')
  #gateway=${gw%%/31}
  gateway=$(ip route show|grep "via .* dev $iface"|awk '{print $3}'|sort -u|paste -s -d',')
  ip_dict[$iface]="$rdma_if,$ip,$gateway"
done < <(ip route show|grep /31)
#gws=($(echo ${ip_dict[@]}|tr ' ' '\n'|awk -F',' '{print $NF}'|sort -t'.' -k1,1n -k2,2n -k3,3n -k4,4n))
gws=($(echo ${ip_dict[@]}|tr ' ' '\n'|cut -d',' -f3-|tr ',' '\n'|sort -t'.' -k1,1n -k2,2n -k3,3n -k4,4n))
tmpf=$(mktemp)
(
pids=""
for i in ${!ip_dict[@]}; do
(
  IFS=, read -r rdma_if ip gateway < <(echo ${ip_dict[$i]})
  bdf=$(readlink /sys/class/infiniband/${rdma_if}/device|awk -F'/' '{print $NF}')
  stat=$({ cat /sys/class/infiniband/${rdma_if}/ports/1/{state,phys_state}|awk '{print $NF}'; cat /sys/class/net/${i}/operstate; }|paste -s -d',')
  
  for j in ${gws[@]}; do
    #If nic has multiple ips, ping with nic name may use the wrong ip, so ping with ip address to make sure the source ip is correct. But if nic has only one ip, ping with nic name or ip address is the same.
    ret=$(ping -M do -f -c 1 -W 1 -w 1 -I $ip $j 2>&1 | grep transmitted)
    cat <<- EOF
$(hostname): [$bdf/${i}/$rdma_if/$stat/$ip]: ping -I $ip $j => $ret
EOF
  done
) & pids="$pids $!"
done
wait $pids
) &>$tmpf
#cat $tmpf | sort -t'.' -k1,1n -k2,2n -k3,3n -k7,7n -k8,8n -k9,9n -k10,10n
while read line; do
  ret=$(echo $line | grep -w ' 1 received' &>/dev/null && echo PASSED || echo FAILED)
  echo "$(echo $line|sed 's#=>.*##g') => $ret"
done < $tmpf | sort -t'.' -k1,1n -k2,2n -k3,3n -k7,7n -k8,8n -k9,9n -k10,10n
rm -f $tmpf

[ $SWEEP -eq 1 ] && {
echo "=======Cross Rail Sweep======="
ew_nics=($(
for i in ${!ip_dict[@]}; do
  IFS=, read -r rdma_if ip gateway < <(echo ${ip_dict[$i]})
  echo ${rdma_if}
done|sort -u
))
mid=$((${#ew_nics[@]}/2))
src_nics=(
  ${ew_nics[0]}
  ${ew_nics[$mid]}
)
for i in ${src_nics[@]}; do
  for j in ${ew_nics[@]}; do
    if [ $i != $j ]; then
      inode=$(cat /sys/class/infiniband/${i}/device/numa_node)
      jnode=$(cat /sys/class/infiniband/${j}/device/numa_node)
      pkill -9 ib_write_bw &> /dev/null
      numactl -N $inode -m $inode ib_write_bw -d $i -F --report_gbits --qp 8 &> /dev/null &
      sleep 1
      ret=$(timeout 5 numactl -N $jnode -m $jnode ib_write_bw -d $j -F --report_gbits --qp 8 localhost 2>&1 | grep 65536 | awk '{print $4}')
      [ -z "$ret" ] && ret="N/A"
      echo "Testing $i <-> $j: $ret"
    fi
  done
done
}
