#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>
NODELIST=$1
[ -z "$NODELIST" ] && echo "Usage: $0 <NODELIST>" && exit 1

lldp_conf(){
pdsh -R ssh -f 100 -w $NODELIST <<- 'EOF'
lldpcli configure system hostname .
lldpcli configure lldp portidsubtype ifname
lldpcli configure system interface pattern eth*,eno*,enp*,ens*,enP*
systemctl restart lldpd
EOF
}
# lldp_conf && sleep 30

pdsh -R ssh -f 100 -w $NODELIST <<- 'EOF' | sort
lldpcli show neighbors | grep -E 'Interface:|SysName:|PortID:'|awk '/Interface:/{print $2} /SysName:/{print $NF} /PortID:/{print $NF}'|tr ',' ' '|paste - - -|sort|paste - -|awk '{if(NF==6 && $3 != $6){print $0," <*>"}else{print $0}}'
EOF

####### Host to Switches check ########
cat > /home/cmsupport/workspace/spx-ping.sh <<- 'EOF'
#!/bin/bash
for i in $(ip -4 -br addr show | grep '/31' | awk '{print $3}'); do
  local_ip=${i%%/31}
  peer_ip=$(echo "$local_ip" | awk -F '.' '{printf "%d.%d.%d.%d\n", $1, $2, $3, $4 + 1}')
  iface=$(ip -4 -br addr show | grep $local_ip/31|awk '{print $1}')
  timeout 5 ping -I ${iface} -c 1 -W 3 "$peer_ip" &>/dev/null \
    && echo "${iface}@[PASSED]${local_ip}->${peer_ip}" \
    || echo "${iface}@[FAILED]${local_ip}->${peer_ip}"
done | sort | paste -s -d ' '
EOF
pdsh -f 100 -u 60 -t 60 -R ssh -w ${NODELIST} <<- 'EOF'
bash /home/cmsupport/workspace/spx-ping.sh
EOF

####### Route policies check ########
pdsh -f 100 -R ssh -w ${NODELIST} <<- 'EOF' | sort
ip route show|grep -E '/14|/18|/31'|sort -t'/' -k2|wc -l
EOF
