#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

eth_nics=($(
for i in /sys/class/infiniband/*; do
  [ "$(< ${i}/ports/1/link_layer)" == "Ethernet" ] && echo ${i##*/}
done |grep -v bond
))

action=$1
[ -z "$action" ] && action=status
case $action in
  clear)
    echo "=======Clear RoCE Pause and Errors======="
    for i in ${eth_nics[@]}; do mlxlink -d ${i} -p 1 --pc &>/dev/null; done
    ;;
  debug)
    for i in ${eth_nics[@]}; do ret=$(mlxlink -d ${i} -c|grep Recommendation|cut -f2- -d ':'|grep -v 'No issue was observed'||true); [ "X$ret" != "X" ] && echo $i,$ret || true; done
    ;;
  status|*)
    echo "=======Show RoCE Pause and Errors======="
    (
    pids=""
    for i in ${eth_nics[@]}; do
      (
      ifdev=$(ls -1 /sys/class/infiniband/${i}/device/net/)
      ret=($(mlxlink -d ${i} -c 2>/dev/null|grep -E 'Effective Physical Errors|Link Down Counter'|awk '{print $NF}'))
      [ ${#ret[@]} -eq 0 ] && ret=(NA NA)
      cat <<- EOF | paste -s -d ','
$i
$(ethtool -S $ifdev 2>/dev/null|grep -E 'rx_prio3_pause:|tx_prio3_pause:|rx_prio3_discards:'|tr -d ' '|paste -s -d ',')
link_downed:${ret[1]}
effective_error:${ret[0]}
roce_adp_retrans:$(cat /sys/class/infiniband/${i}/ports/1/hw_counters/roce_adp_retrans 2>/dev/null)
np_cnp_sent:$(cat /sys/class/infiniband/${i}/ports/1/hw_counters/np_cnp_sent 2>/dev/null)
rp_cnp_handled:$(cat /sys/class/infiniband/${i}/ports/1/hw_counters/rp_cnp_handled 2>/dev/null)
EOF
      ) & pids="$pids $!"
    done
    wait $pids
    ) | sort 
    ;;
esac

# ./spxmon.sh | grep ',rx_prio3_pause'|sort -t':' -n -k6
