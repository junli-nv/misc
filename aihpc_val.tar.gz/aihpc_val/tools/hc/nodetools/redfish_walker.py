#!/usr/bin/env python3
# Author: Junli Zhang<junliz@nvidia.com>

import argparse
import requests
from urllib.parse import urljoin

requests.packages.urllib3.disable_warnings()

def traverse_redfish_tree(session, base_url, url, visited, depth=0, max_depth=10):
    full_url = urljoin(base_url, url)

    if full_url in visited or depth > max_depth:
        return

    visited.add(full_url)
    indent = "  " * depth
    print(f"{indent}{full_url}")

    try:
        resp = session.get(full_url, timeout=10, verify=False)
        resp.raise_for_status()
    except Exception as e:
        print(f"{indent}Request failed: {e}")
        return

    try:
        data = resp.json()
    except ValueError:
        return

    def walk_json(obj):
        if isinstance(obj, dict):
            if "@odata.id" in obj:
                child = obj["@odata.id"]
                if isinstance(child, str) and child.startswith("/redfish/"):
                    traverse_redfish_tree(
                        session, base_url, child, visited, depth + 1, max_depth
                    )
            for v in obj.values():
                walk_json(v)
        elif isinstance(obj, list):
            for item in obj:
                walk_json(item)

    walk_json(data)

def main():
    parser = argparse.ArgumentParser(
        description="Traverse Redfish tree"
    )
    parser.add_argument("--bmc", required=True, help="BMC IP or hostname, e.g., 192.168.0.100")
    parser.add_argument("-u", "--user", required=True, help="BMC username")
    parser.add_argument("-p", "--password", required=True, help="BMC password")
    parser.add_argument(
        "--max-depth", type=int, default=6, help="Maximum recursion depth (default 6)"
    )

    args = parser.parse_args()

    base_url = f"https://{args.bmc}"
    root_url = "/redfish/v1"

    sess = requests.Session()
    sess.auth = (args.user, args.password)

    visited = set()

    try:
        traverse_redfish_tree(
            sess, base_url, root_url, visited, max_depth=args.max_depth
        )
    except KeyboardInterrupt:
        print("\nDetected Ctrl+C, aborting traversal, exiting gracefully...")
    finally:
        sess.close()

if __name__ == "__main__":
    main()