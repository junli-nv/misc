#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

node_prefix="gb200"
sw_prefix="nvsw"
ps_prefix="ps"

rm -f hosts.list

cmsh -c 'device; foreach -t PhysicalNode ( get hostname; interfaces; list bmc)' \
  | paste - - | grep -e ${node_prefix} | awk '{print $1, $4}' | tee -a hosts.list

cmsh -c 'device; foreach -t Switch ( get hostname; interfaces; list bmc)' \
  | paste - - | grep -E "${sw_prefix}" | awk '{print $1,$4}' | tee -a hosts.list

cmsh -c 'device; foreach -t PowerShelf ( get hostname; interfaces; list bmc)' \
  | paste - - | grep -E "${ps_prefix}" | awk '{print $1,$4}' | tee -a hosts.list
