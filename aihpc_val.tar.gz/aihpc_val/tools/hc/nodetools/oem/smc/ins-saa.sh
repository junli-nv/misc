
# https://www.supermicro.com/en/support/resources/downloadcenter/smsdownload
# SuperServer Automation Assistant (SAA)

curl -O https://www.supermicro.com/Bios/sw_download/1072/saa_1.5.0_Linux_x86_64_20260210.tar.gz

tar xzvf saa_1.5.0_Linux_x86_64_20260210.tar.gz
cd saa_1.5.0_Linux_x86_64/
 
# saa -h 
