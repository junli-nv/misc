#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>
#
#Ref: https://docs.nvidia.com/dgx/dgxgb200-user-guide/compute-tray-redfish-commands.html
#
topdir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source $topdir/passwd.sh
export hostlist=$topdir/hosts.list

export SYSTEM_ID=System_0 
#export SYSTEM_ID=system
export CHASSIS_ID=Chassis_0
export BMC_ID=BMC_0
export HGX_BASEBOARD_ID=HGX_Baseboard_0
export HGX_BMC_ID=HGX_BMC_0
#export BIOS_SD=Settings
export BIOS_SD=SD

export TIMEOUT=10
query_hgx_bmc_log_gb200(){
  [ $debug -eq 1 ] && set -x || set +x
  timeout $[6*$TIMEOUT] curl -k -s --user "${bmc_username}:${bmc_password}" "https://${bmc_ip}/redfish/v1/Systems/${HGX_BASEBOARD_ID}/LogServices/EventLog/Entries"|jq -r '.Members[]|[.Created,.Severity,.Message]|@tsv'|sort -n
  #curl -k -s --user "${bmc_username}:${bmc_password}" "https://${bmc_ip}/redfish/v1/Systems/${HGX_BASEBOARD_ID}/LogServices/EventLog/#Entries"|jq '.Members[]."Id"'|tr -d '"'|sort -n|tail -n 300|while read i
  ##curl -k -s --user "${bmc_username}:${bmc_password}" "https://${bmc_ip}/redfish/v1/Systems/${HGX_BASEBOARD_ID}/LogServices/EventLog/#Entries"|jq '.Members[]."Id"'|tr -d '"'|sort -n|while read i
  #do
  #  curl -k -s --user "${bmc_username}:${bmc_password}" "https://${bmc_ip}/redfish/v1/Systems/${HGX_BASEBOARD_ID}/LogServices/EventLog/Entries/${i}"|jq '.Created,.Severity,."CPER"."Oem"."Nvidia"."Nvidia"."Signature",.Message'|paste - - - -|tr -s '[:space:]'
  #done
}
export -f query_hgx_bmc_log_gb200

clear_hgx_bmc_log_gb200(){
  [ $debug -eq 1 ] && set -x || set +x
  timeout $TIMEOUT curl -k -s --user "${bmc_username}:${bmc_password}" -H 'Content-Type: application/json' -X POST -d '{}' "https://${bmc_ip}/redfish/v1/Systems/${HGX_BASEBOARD_ID}/LogServices/EventLog/Actions/LogService.ClearLog" | jq
}
export -f clear_hgx_bmc_log_gb200

query_sys_bmc_log_gb200(){
  [ $debug -eq 1 ] && set -x || set +x
  timeout $[6*$TIMEOUT] curl -k -s --user "${bmc_username}:${bmc_password}" "https://${bmc_ip}/redfish/v1/Systems/${SYSTEM_ID}/LogServices/EventLog/Entries"|jq -r '.Members[]|[.Created,.Severity,.Message]|@tsv'|sort -n
  #curl -k -s --user "${bmc_username}:${bmc_password}" "https://${bmc_ip}/redfish/v1/Systems/${SYSTEM_ID}/LogServices/EventLog/Entries"|jq '.Members[]."Id"'|tr -d '"'|sort -n|tail -n 300|while read i
  ##curl -k -s --user "${bmc_username}:${bmc_password}" "https://${bmc_ip}/redfish/v1/Systems/${SYSTEM_ID}/LogServices/EventLog/Entries"|#jq '.Members[]."Id"'|tr -d '"'|sort -n|while read i
  #do
  #  curl -k -s --user "${bmc_username}:${bmc_password}" "https://${bmc_ip}/redfish/v1/Systems/${SYSTEM_ID}/LogServices/EventLog/Entries/${i}"|jq '.Created,.Severity,.Message'|paste - - -|tr -s '[:space:]'
  #done
}
export -f query_sys_bmc_log_gb200

clear_sys_bmc_log_gb200(){
  [ $debug -eq 1 ] && set -x || set +x
  timeout $TIMEOUT curl -k -s --user "${bmc_username}:${bmc_password}" -H 'Content-Type: application/json' -X POST -d '{}' "https://${bmc_ip}/redfish/v1/Systems/${SYSTEM_ID}/LogServices/EventLog/Actions/LogService.ClearLog" | jq
}
export -f clear_sys_bmc_log_gb200

cycle_gb200(){
  [ $debug -eq 1 ] && set -x || set +x
  echo "power off"
  timeout $TIMEOUT curl -k -s --user "${bmc_username}:${bmc_password}" -H 'Content-Type: application/json' -X POST https://${bmc_ip}/redfish/v1/Systems/${SYSTEM_ID}/Actions/ComputerSystem.Reset -d '{"ResetType": "ForceOff"}' &>/dev/null
  sleep 3
  echo "AC power cycle"
  if [ $(timeout $TIMEOUT curl -k -s --user "${bmc_username}:${bmc_password}" https://${bmc_ip}/redfish/v1/Chassis/${CHASSIS_ID}|jq|grep 'was not found'|wc -l) -eq 0 ]; then
    timeout $TIMEOUT curl -k -s --user "${bmc_username}:${bmc_password}" -H 'Content-Type: application/json' -X POST https://${bmc_ip}/redfish/v1/Chassis/${CHASSIS_ID}/Actions/Oem/NvidiaChassis.AuxPowerReset -d '{"ResetType": "AuxPowerCycle"}' | jq
  fi
  if [ $(timeout $TIMEOUT curl -k -s --user "${bmc_username}:${bmc_password}" https://${bmc_ip}/redfish/v1/Chassis/${BMC_ID}|jq|grep 'was not found'|wc -l) -eq 0 ]; then
    timeout $TIMEOUT curl -k -s --user "${bmc_username}:${bmc_password}" -H 'Content-Type: application/json' -X POST https://${bmc_ip}/redfish/v1/Chassis/${BMC_ID}/Actions/Oem/NvidiaChassis.AuxPowerReset -d '{"ResetType": "AuxPowerCycle"}' | jq
  fi
  echo "Ping ${bmc_ip}"
  #sleep 3
  #echo "power on"
  #curl -k -s --user "${bmc_username}:${bmc_password}" -H 'Content-Type: application/json' -X POST https://${bmc_ip}/redfish/v1/Systems/${SYSTEM_ID}/Actions/ComputerSystem.Reset -d '{"ResetType": "On"}' &>/dev/null
}
export -f cycle_gb200

configure_bf3(){
  [ $debug -eq 1 ] && set -x || set +x
  #1. Set “EnablePcieNicTopology“ to true and "Socket0Pcie6DisableOptionROM“ to false
  timeout $TIMEOUT curl -k -s --user "${bmc_username}:${bmc_password}" -X PATCH https://${bmc_ip}/redfish/v1/Systems/${SYSTEM_ID}/Bios/${BIOS_SD} -d '{"Attributes": {"EGM": true, "Socket0Pcie0MaxPayloadSize": "Auto", "Socket0Pcie6DisableOptionROM": false , "Socket1Pcie6DisableOptionROM": false, "EnablePcieNicTopology": false}}'
  sleep 3
  #2. Check the pending settings
  timeout $TIMEOUT curl -k -s --user "${bmc_username}:${bmc_password}" -X GET -H "Content-Type: application/json" https://${bmc_ip}/redfish/v1/Systems/${SYSTEM_ID}/Bios/${BIOS_SD} | jq '.Attributes|{EGM, Socket0Pcie0MaxPayloadSize, Socket0Pcie6DisableOptionROM, Socket1Pcie6DisableOptionROM, EnablePcieNicTopology}'
  #sleep 10
  ##3. Reboot system
  #timeout $TIMEOUT curl -k -s --user "${bmc_username}:${bmc_password}" -X POST https://${bmc_ip}/redfish/v1/Systems/${SYSTEM_ID}/Actions/#ComputerSystem.Reset -d '{"ResetType":"PowerCycle"}'
  ##4. Check the modified items
  #timeout $TIMEOUT curl -k -s --user "${bmc_username}:${bmc_password}" -X GET -H "Content-Type: application/json" https://${bmc_ip}/redfish/v1/Systems/${SYSTEM_ID}/Bios | jq '.Attributes|{EGM, Socket0Pcie0MaxPayloadSize, Socket0Pcie6DisableOptionROM, Socket1Pcie6DisableOptionROM, EnablePcieNicTopology}'
}
export -f configure_bf3

query_gb200_macs(){
  [ $debug -eq 1 ] && set -x || set +x
  #timeout $TIMEOUT curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip/redfish/v1/Systems/${SYSTEM_ID}/BootOptions?\$expand=.|jq '.Members[]|.Id,.DisplayName'|paste - -|grep PXEv4|awk '{print $NF}'|tr ')' ':'|cut -f2 -d':'|sort|while read i; do
  #echo $i | sed 's/../&:/g'|cut -c 1-17
  #done
  timeout $TIMEOUT curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip/redfish/v1/Systems/${SYSTEM_ID}/BootOptions?\$expand=.|jq '.Members[]|.Id,.DisplayName,.UefiDevicePath'|paste - - -|grep -e PXEv4 -e 'PXE.*IPv4' \
  |sed -e 's:/MAC:"MAC:g' -e 's:/IPv4:"IPv4:g'|awk -F'"' '{print $2, $7, $6}'|while read boot macA busB
  do
    echo OS ${boot} $(echo ${macA}|cut -c5-16|sed 's/../&:/g'|cut -c 1-17) ${busB}
  done
  timeout $TIMEOUT curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip/redfish/v1/Managers/${BMC_ID}/EthernetInterfaces|jq '.Members[]."@odata.id"'|tr -d '"'|while read i
  do
    timeout $TIMEOUT curl -s -k -u $bmc_username:$bmc_password "https://${bmc_ip}$i"|jq '.Id,.MACAddress' | paste - - | tr -s ' ' | xargs -I {} echo BMC {}
  done
}
export -f query_gb200_macs

query_gb200_bootorder(){
  [ $debug -eq 1 ] && set -x || set +x
  tmpf=$(mktemp)
  timeout $TIMEOUT curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip/redfish/v1/Systems/${SYSTEM_ID}/BootOptions?\$expand=.|jq '.Members[]|.Id,.DisplayName,.UefiDevicePath'|paste - - - > $tmpf
  timeout $TIMEOUT curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip/redfish/v1/Systems/${SYSTEM_ID}?\$select=Boot/BootOrder|jq -r '.Boot.BootOrder[]'|while read i; do
    grep -w ${i##Boot} $tmpf || grep -w ${i} $tmpf
  done
  rm -f $tmpf
}
export -f query_gb200_bootorder

network_boot_gb200(){
  [ $debug -eq 1 ] && set -x || set +x
  echo "INFO: power off node"
  task_id=$(timeout $TIMEOUT curl -s -k -u $bmc_username:$bmc_password -X POST -H 'Content-Type: application/json' https://${bmc_ip}/redfish/v1/Systems/${SYSTEM_ID}/Actions/ComputerSystem.Reset -d '{"ResetType": "ForceOff"}'|jq -r .Id)
  if [ ! -z ${task_id} ]; then
    ret=$(timeout $TIMEOUT curl -k -s --user "${bmc_username}:${bmc_password}" https://${bmc_ip}/redfish/v1/TaskService/Tasks/${task_id}|jq -r .TaskState)
    while :; do if [ "X${ret}X" == "XRunningX" ]; then sleep 2; else break; fi; done && echo "INFO: done"
  fi
  echo "Wait 5s" && sleep 5
  timeout $TIMEOUT ipmitool -I lanplus -H "$bmc_ip" -U "$ipmi_bmc_username" -P "$ipmi_bmc_password" chassis bootparam set bootflag none

  #target_boots=($(timeout $TIMEOUT curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip/redfish/v1/Systems/${SYSTEM_ID}/BootOptions?\$expand=.|jq '.Members[]|.Id,.DisplayName,.UefiDevicePath'|paste - - -|grep -e PXEv4 -e 'PXE.*IPv4'|grep -v USB|awk '{print $1}'))
  #target_pci="PciRoot(0x5)"  ##enP5p9s0
  #target_pci="PciRoot(0x6)"  ##enP6p3s0f0np0
  target_pci="PciRoot(0x16)"  ##enP22s22f0np0
  target_boots=($(timeout $TIMEOUT curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip/redfish/v1/Systems/${SYSTEM_ID}/BootOptions?\$expand=.|jq '.Members[]|.Id,.DisplayName,.UefiDevicePath'|paste - - -|grep ${target_pci}|awk '{print $1}'))
  all_pxev4_boots=($(timeout $TIMEOUT curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip/redfish/v1/Systems/${SYSTEM_ID}/BootOptions?\$expand=.|jq '.Members[]|.Id,.DisplayName'|paste - -|grep -e PXEv4 -e 'PXE.*IPv4'|awk '{print $1}'))
  pxev4_boots=(${target_boots[*]} $(echo ${all_pxev4_boots[*]} ${target_boots[*]}|tr ' ' '\n'|sort|uniq -c|grep -v -w ' 2 '|awk '{print $NF}'))
  old_boots=($(timeout $TIMEOUT curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip/redfish/v1/Systems/${SYSTEM_ID}?\$select=Boot/BootOrder|jq '.Boot.BootOrder[]'))
  o_prefix=$(echo ${old_boots[*]}|grep Boot &>/dev/null && echo 1 || echo 0)
  n_prefix=$(echo ${pxev4_boots[*]}|grep Boot &>/dev/null && echo 1 || echo 0)
  if [ $o_prefix -ne $n_prefix ]; then
    n_pxev4_boots=($(echo ${pxev4_boots[*]}|tr ' ' '\n'|xargs -I {} echo "\"Boot{}\""))
  else
    n_pxev4_boots=($(echo ${pxev4_boots[*]}))
  fi
  #echo ${pxev4_boots[*]}|tr ' ' '\n'|xargs -I {} echo "\"Boot{}\""
  pad_boots=($(echo ${n_pxev4_boots[*]} ${old_boots[*]}|tr ' ' '\n'|sort|uniq -c|grep -v -w ' 2 '|awk '{print $NF}'))
  new_boots=$(echo ${n_pxev4_boots[*]} ${pad_boots[*]}|tr -s ' ' ',')
  echo OLD_BOOT_ORDER=${old_boots[*]}|tr ' ' ','
  echo NEW_BOOT_ORDER=$new_boots

  #timeout $TIMEOUT curl -s -k -u $bmc_username:$bmc_password -X PATCH -H 'Content-Type: application/json' -H 'If-None-Match: "123456"' https://$bmc_ip/redfish/v1/Systems/${SYSTEM_ID}/${BIOS_SD} -d "{\"Boot\":{\"BootOrder\": [${new_boots}]}}" | jq 
  timeout $TIMEOUT curl -s -k -u $bmc_username:$bmc_password -X PATCH -H 'Content-Type: application/json' -H 'If-Match:*' https://$bmc_ip/redfish/v1/Systems/${SYSTEM_ID}/${BIOS_SD} -d "{\"Boot\":{\"BootOrder\": [${new_boots}]}}" | jq 

  echo "Pending BootOrder:"
  timeout $TIMEOUT curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip/redfish/v1/Systems/${SYSTEM_ID}/${BIOS_SD}|jq -r '.Boot.BootOrder[]?' | paste -s -d','
  
  echo "Enable continuous PXE boot override option"
  timeout "$[6*TIMEOUT]" curl -s -k \
  -u "$bmc_username:$bmc_password" \
  -X PATCH \
  -H 'Content-Type: application/json' \
  -H 'If-Match:*' \
  "https://$bmc_ip/redfish/v1/Systems/${SYSTEM_ID}" \
  -d '{
    "Boot": {
      "BootSourceOverrideEnabled": "Continuous",
      "BootSourceOverrideMode": "UEFI",
      "BootSourceOverrideTarget": "Pxe"
    }
  }'
  echo "Wait 15s" && sleep 15
  timeout $TIMEOUT curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip/redfish/v1/Systems/${SYSTEM_ID}|jq -r '"\(.Boot.BootSourceOverrideEnabled),\(.Boot.BootSourceOverrideMode),\(.Boot.BootSourceOverrideTarget)"'

  timeout $TIMEOUT ipmitool -I lanplus -H "$bmc_ip" -U "$ipmi_bmc_username" -P "$ipmi_bmc_password" chassis bootdev pxe options=persistent
  echo "reboot node"
  echo "Wait 5s" && sleep 5
  timeout $TIMEOUT curl -s -k -u $bmc_username:$bmc_password -X POST -H 'Content-Type: application/json' https://${bmc_ip}/redfish/v1/Systems/${SYSTEM_ID}/Actions/ComputerSystem.Reset -d '{"ResetType": "On"}'|jq
}
export -f network_boot_gb200

sensors(){
  [ $debug -eq 1 ] && set -x || set +x
  timeout $TIMEOUT curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip/redfish/v1/TelemetryService/MetricReports|jq '.Members[]."@odata.id"'|tr -d '"'|while read i; do
    timeout $TIMEOUT curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip${i}|jq -r '.MetricValues[]|[.Timestamp,.MetricProperty,.MetricValue]|@tsv' | column -t
  done
}
export -f sensors

query_gpu_uuid_sn(){
  [ $debug -eq 1 ] && set -x || set +x
  timeout $TIMEOUT curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip/redfish/v1/Systems/${HGX_BASEBOARD_ID}/Processors|jq -r '.Members[]."@odata.id"'|grep GPU_|while read i; do echo ${i##*/} $(timeout $TIMEOUT curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip${i}|jq '.UUID,.SerialNumber,.PartNumber'|paste -s -d' '); done
}
export -f query_gpu_uuid_sn

query_firmware(){
  [ $debug -eq 1 ] && set -x || set +x
  timeout $TIMEOUT curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip/redfish/v1/UpdateService/FirmwareInventory|jq '.Members[]."@odata.id"'|tr -d '"'|while read i; do
  timeout $TIMEOUT curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip${i}|jq -r '[.Id,.Version]|@tsv'|column -t
done
}
export -f query_firmware

power_ac_cycle(){
  [ $debug -eq 1 ] && set -x || set +x
  timeout $TIMEOUT curl -k -s --user "${bmc_username}:${bmc_password}" \
  -X POST \
  -d '{"ResetType":"AuxPowerCycleForce"}' \
  https://${bmc_ip}/redfish/v1/Chassis/${BMC_ID}/Actions/Oem/NvidiaChassis.AuxPowerReset
}
export -f power_ac_cycle

power_graceful_shutdown(){
  [ $debug -eq 1 ] && set -x || set +x
  timeout $TIMEOUT curl -k -s --user "${bmc_username}:${bmc_password}" \
  -X POST \
  -d '{"ResetType": "GracefulShutdown"}' \
  https://${bmc_ip}/redfish/v1/Systems/${SYSTEM_ID}/Actions/ComputerSystem.Reset
}
export -f power_graceful_shutdown

power_force_off(){
  [ $debug -eq 1 ] && set -x || set +x
  timeout $TIMEOUT curl -k -s --user "${bmc_username}:${bmc_password}" \
  -X POST \
  -d '{"ResetType": "ForceOff"}' \
  https://${bmc_ip}/redfish/v1/Systems/${SYSTEM_ID}/Actions/ComputerSystem.Reset
}
export -f power_force_off

power_on(){
  [ $debug -eq 1 ] && set -x || set +x
  timeout $TIMEOUT curl -k -s --user "${bmc_username}:${bmc_password}" \
  -X POST \
  -d '{"ResetType": "On"}' \
  https://${bmc_ip}/redfish/v1/Systems/${SYSTEM_ID}/Actions/ComputerSystem.Reset
}
export -f power_on

power_cycle(){
  [ $debug -eq 1 ] && set -x || set +x
  timeout $TIMEOUT curl -k -s --user "${bmc_username}:${bmc_password}" \
  -X POST \
  -d '{"ResetType": "PowerCycle"}' \
  https://${bmc_ip}/redfish/v1/Systems/${SYSTEM_ID}/Actions/ComputerSystem.Reset 
}
export -f power_cycle

power_status(){
  [ $debug -eq 1 ] && set -x || set +x
  timeout $TIMEOUT curl -k -s --user "${bmc_username}:${bmc_password}" \
  https://${bmc_ip}/redfish/v1/Systems/${SYSTEM_ID}|jq '.PowerState' 
}
export -f power_status

hmc_graceful_restart(){
  [ $debug -eq 1 ] && set -x || set +x
  timeout $TIMEOUT curl -k -s --user "${bmc_username}:${bmc_password}" \
  -X POST \
  -d '{"ResetType": "GracefulRestart"}' \
  https://${bmc_ip}/redfish/v1/Managers/${HGX_BMC_ID}/Actions/Manager.Reset
}
export -f hmc_graceful_restart

hmc_force_restart(){
  [ $debug -eq 1 ] && set -x || set +x
  timeout $TIMEOUT curl -k -s --user "${bmc_username}:${bmc_password}" \
  -X POST \
  -d '{"ResetType": "ForceRestart"}' \
  https://${bmc_ip}/redfish/v1/Managers/${HGX_BMC_ID}/Actions/Manager.Reset
}
export -f hmc_force_restart

bmc_restart(){
  [ $debug -eq 1 ] && set -x || set +x
  timeout $TIMEOUT curl -k -s --user "${bmc_username}:${bmc_password}" \
  -X POST \
  -d '{"ResetType": "ForceRestart", "Description": "BMC bundle update curl"}' \
  https://${bmc_ip}/redfish/v1/Managers/${BMC_ID}/Actions/Manager.Reset
}
export -f bmc_restart

add_user(){
  [ $debug -eq 1 ] && set -x || set +x
  timeout $TIMEOUT curl -k -s --user "${bmc_username}:${bmc_password}" \
  -H "Content-Type: application/json" \
  -X POST \
  -d '{"UserName": "supperuser", "Password": "P@ss$1234", "RoleId": "Operator"}' \
  https://${bmc_ip}/redfish/v1/AccountService/Accounts
}
export -f add_user

update_passwd(){
  [ $debug -eq 1 ] && set -x || set +x
  timeout $TIMEOUT curl -k -s --user "${bmc_username}:${bmc_password}" \
  -H "Content-Type: application/json" \
  https://${bmc_ip}/redfish/v1/AccountService/Accounts/${bmc_username} \
  --data '{ "Attributes": { "Password": "NEW_PASSWORD" } }'
}
export -f update_passwd

enable_ipmi(){
  [ $debug -eq 1 ] && set -x || set +x
  timeout $TIMEOUT curl -k -s --user "${bmc_username}:${bmc_password}" \
  -X PATCH \
  -d '{ "IPMI": {"ProtocolEnabled": true} }' \
  https://${bmc_ip}/redfish/v1/Managers/${BMC_ID}/NetworkProtocol
}
export -f enable_ipmi

check_ipmi(){
  [ $debug -eq 1 ] && set -x || set +x
  timeout $TIMEOUT curl -k -s --user "${bmc_username}:${bmc_password}" \
  https://${bmc_ip}/redfish/v1/Managers/${BMC_ID}/NetworkProtocol | jq '.IPMI'
}
export -f check_ipmi

get_serial_number(){
  [ $debug -eq 1 ] && set -x || set +x
  (
    timeout $TIMEOUT curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip/redfish/v1/Systems/${SYSTEM_ID}|jq -r '"\(.Id)=\(.SerialNumber)"'
    timeout $TIMEOUT curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip/redfish/v1/Chassis|jq -r '.Members[]."@odata.id"'|grep HGX_ProcessorModule|while read i; do
      timeout $TIMEOUT curl -s -k -u $bmc_username:$bmc_password https://$bmc_ip${i}|jq -r '"\(.Id)=\(.PartNumber),\(.SerialNumber)"'
    done
  )| paste -s -d ';'
}
export -f get_serial_number

get_task_status(){
  [ $debug -eq 1 ] && set -x || set +x
  timeout $TIMEOUT curl -k -s --user "${bmc_username}:${bmc_password}" https://${bmc_ip}/redfish/v1/TaskService/Tasks|jq -r '.Members[]."@odata.id"'|while read i; do
    timeout $TIMEOUT curl -k -s --user "${bmc_username}:${bmc_password}" https://${bmc_ip}${i}|jq -r '[.Id,.Description,.StartTime,.EndTime,.TaskState]|@tsv'
  done
}
export -f get_task_status
