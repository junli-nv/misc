
# https://www.dell.com/support/product-details/en-us/product/poweredge-xe9780/drivers
# Search Dell iDRAC Tools

# Dell iDRAC Tools for Linux, v11.4.0.0
wget -c \
  --user-agent="Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36" \
  --header="Referer: https://www.dell.com/support/product-details/en-uk/product/poweredge-xe9680/drivers" \
  "https://dl.dell.com/FOLDER13988164M/1/Dell-iDRACTools-Web-LX-11.4.0.0-1435_A00.tar.gz"

tar xzvf Dell-iDRACTools-Web-LX-11.4.0.0-1435_A00.tar.gz
cd iDRACTools/racadm/UBUNTU24/x86_64/
apt install -y ./srvadmin-hapi_*.deb ./srvadmin-idracadm7_*.deb ./srvadmin-idracadm8_*.deb
ln -sf /opt/dell/srvadmin/sbin/racadm /usr/local/bin/racadm

## Out of band: 
# racadm -u ${bmc_username} -p ${bmc_password} -r ${bmc_ip} help

## Inband: 
# racadm help

