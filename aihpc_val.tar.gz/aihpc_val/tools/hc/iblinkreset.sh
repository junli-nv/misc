#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

export PATH=/usr/bin:/bin:/usr/sbin:/sbin
ibstatus|grep -E 'Infiniband|state:'|paste - - -
hcas=($(lspci -D|grep 'Infiniband controller'|awk '{print $1}'|while read i; do echo $(basename $(ls -l /sys/class/infiniband|grep -o ${i}.*));done))
gstatus=0
for i in ${hcas[@]}; do
  ret=$(mlxlink -d $i|awk -F':' '/State/{print $NF}'|grep Active|wc -l)
  if [ ${ret} -eq 0 ]; then
    echo "INFO: trying to reset ${i}..."
    mlxlink -d ${i} -p 1 -aTG &>/dev/null &
    gstatus=$((gstatus+1))
  fi
done
wait
if [ ${gstatus} -ne 0 ]; then
  echo "INFO: waiting 30s..."
  sleep 30
  for i in ${hcas[@]}; do
    ret=$(mlxlink -d $i|grep -e State -e Recommendation|cut -d':' -f2|paste -s -d ' ')
    echo "INFO: ${i}: $ret"
  done
  ibstatus|grep -E 'Infiniband|state:'|paste - - -
fi
