## Enabled SMI interface on CX8 NIC
```
root@p1-r01-ct01:~# /opt/mellanox/iproute2/sbin/rdma dev add smi1 type SMI parent mlx5_0
root@p1-r01-ct01:~# ibstat
...
'smi1'                                                                                                                                                                                                                                                                                 
        CA type: MT4131                                                                                                                                                                                                                                                                   
        Number of ports: 4                                                                                                                                                                                                                                                                
        Firmware version: 40.46.3048                                                                                                                                                                                                                                                      
        Hardware version: 0                                                                                                                                                                                                                                                               
        Node GUID: 0x549b240300dbfa5e                                                                                                                                                                                                                                                     
        System image GUID: 0x549b240300dbfa5e
        Port 1:
                State: Active
                Physical state: LinkUp
                Rate: 200
                Base lid: 1
                LMC: 0
                SM lid: 3407
                Capability mask: 0xa750e848
                Port GUID: 0x549b240300dbfa5e
                Link layer: InfiniBand
        Port 2:
                State: Active
                Physical state: LinkUp
                Rate: 200
                Base lid: 1
                LMC: 0
                SM lid: 3407
                Capability mask: 0xa750e848
                Port GUID: 0x549b240300dbfa5e
                Link layer: InfiniBand
        Port 3:
                State: Active
                Physical state: LinkUp
                Rate: 200
                Base lid: 1
                LMC: 0
                SM lid: 3407
                Capability mask: 0xa750e848
                Port GUID: 0x549b240300dbfa5e
                Link layer: InfiniBand
        Port 4:
                State: Active
                Physical state: LinkUp
                Rate: 200
                Base lid: 1
                LMC: 0
                SM lid: 3407
                Capability mask: 0xa750e848
                Port GUID: 0x549b240300dbfa5e
                Link layer: InfiniBand
```


```
root@p1-r01-ct01:~# mst status -v
MST modules:
------------
    MST PCI module is not loaded
    MST PCI configuration module is not loaded
PCI devices:
------------
DEVICE_TYPE                         MST      PCI             RDMA            NET                                     NUMA  VFIO  
ConnectX8(rev:0)                    NA       0000:03:00.0    smi1,mlx5_0     net-ibp3s0                              0      

GB100(rev:0)                        NA       0008:06:00.0                                                            0      

ConnectX8(rev:0)                    NA       0002:03:00.0    mlx5_1          net-ibP2p3s0                            0      

ConnectX8(rev:0)                    NA       0010:03:00.0    mlx5_2          net-ibP16p3s0                           1      

GB100(rev:0)                        NA       0018:06:00.0                                                            1      

ConnectX8(rev:0)                    NA       0012:03:00.0    mlx5_3          net-ibP18p3s0                           1      

BlueField3(rev:1)                   NA       0016:01:00.1                    mlx5_bond_0     net-bond0                               1      

GB100(rev:0)                        NA       0009:06:00.0                                                            0      

GB100(rev:0)                        NA       0019:06:00.0                                                            1      

BlueField3(rev:1)                   NA       0016:01:00.0    mlx5_bond_0     net-bond0                               1      
```

```
root@p1-r01-ct01:~# sminfo
sminfo: sm lid 3407 sm guid 0xcc40f303001e178c, activity count 21728341 priority 15 state 3 SMINFO_MASTER
```
