#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

export PATH=/usr/bin:/bin:/usr/sbin:/sbin
hcas=($(ls -l /sys/class/infiniband|grep -v $((lspci -D | grep -i Infiniband|awk '{print $1}'|cut -d '.' -f 1|sort|uniq -c|grep -w 4||echo NONE)|awk '{print $NF}'|xargs -I {} echo "-e {}.")|grep infiniband|awk -F'/' '{print $NF}'|sort -t'_' -k2n))
ret=$(
for i in ${hcas[@]}; do
  printf "%15s%3s" ${i}:$(mget_temp -d $i||echo NA)
done
)
echo ${ret[@]}
