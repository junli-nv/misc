#!/bin/bash

systemctl status rshim.service &>/dev/null || systemctl start rshim.service
lsmod | grep mst_pciconf &>/dev/null || mst start &>/dev/null

echo 'Check BF3 mode...'
printf "%20s %45s\n" "" "MODE: ENABLED(0)=DPU, DISABLED(1)=NIC"
printf "%20s %15s %15s %15s\n" "Device" "Default" "Current" "Next Boot"
mst status -v|grep BlueField3|awk '{print $2,$3}'|while read i j; do
  printf "%20s %15s %15s %15s\n" $(ls -l /sys/class/net|grep -o "/${j}/.*"|cut -f4 -d'/') $(mlxconfig -d ${i} -e query INTERNAL_CPU_OFFLOAD_ENGINE | grep INTERNAL_CPU_OFFLOAD_ENGINE|awk '{print $2,$3,$4}');
done

echo 'Change DPU to NiC Mode...'
for i in $(mst status -v|grep BlueField3|awk '{print $2}'); do echo "$i $(mlxconfig -d ${i} -e -y set INTERNAL_CPU_OFFLOAD_ENGINE=1 ROCE_ADAPTIVE_ROUTING_EN=1 USER_PROGRAMMABLE_CC=1)"; done

sleep 5

echo 'Please DC/AC cycle the server to take effect...'
# ipmitool power cycle

#identify port:
#ethtool -p enp13s0f0np0 3600
