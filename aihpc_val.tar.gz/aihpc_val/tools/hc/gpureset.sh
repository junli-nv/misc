#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>
#
set -x
export PATH=/bin:/sbin:/usr/bin:/usr/sbin
kill -9 $(nvidia-smi --query-compute-apps=pid --format=csv,noheader,nounits) &>/dev/null || true
module load shared docker &>/dev/null || true
docker stop cables_agent &>/dev/null || true
systemctl isolate multi-user.target
srvs=""
for i in cmd munge slurmd nvidia-persistenced nvidia-dcgm nvidia-imex nvsm nvidia-fabricmanager cuda-dcgm; do
  ret=$(systemctl is-active $i)
  if [ "$ret" == "active" ]; then
    systemctl stop $i
    srvs="$srvs $i"
  fi
done
  ret=$(systemctl is-active $i)
  if [ "$ret" == "active" ]; then
    systemctl stop $i
    srvs="$srvs $i"
  fi
done
if [ $(lsof|grep /dev/nvidia|wc -l) -ne 0 ]; then
  kill -9 $(lsof|grep /dev/nvidia|awk '{print $2}'|sort|uniq) &>/dev/null
fi
ret=$(for i in nvidia_uvm nvidia_drm nvidia_modeset nvidia_cspmu nvidia_fs gdrdrv nvidia; do lsmod | awk '{print $1}' | grep -w $i; done)
modprobe -r $ret &>/dev/null || true
nvidia-smi -r
systemctl start $srvs
#docker start cables_agent &>/dev/null || true
set +x
