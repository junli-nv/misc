#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

#SBATCH -p defq
#SBATCH --exclusive
#SBATCH --ntasks-per-node=8
#SBATCH --cpus-per-task=43
#SBATCH --gpus-per-node=8
#SBATCH -N 1

module load slurm
cd ${SLURM_SUBMIT_DIR}

topdir=/home/cmsupport/workspace
source ${topdir}/hpcx-v2.26-gcc-doca_ofed-ubuntu24.04-cuda13-x86_64/hpcx-mt-init-ompi.sh
hpcx_load

echo "NODELIST=$SLURM_JOB_NODELIST"
hosts=($(scontrol show hostname $SLURM_JOB_NODELIST))

nic=bond0

duration_sec=$[SLURM_JOB_END_TIME-SLURM_JOB_START_TIME-600]
[ $duration_sec -le 0 ] && duration_sec=86000
STD="--dynamic_adj --MM_max_workload 65536 --max_workload 65536 --time_to_run ${duration_sec} --workload GNC"
MM="--MM_M 0 --MM_N 4096 --MM_sm_count 112 --MM_type SX_SX_SSS —MM_force_cublas_algo SQAAABQAAAAiAAAAAQAAAAAAAAAAAAAAAAAAAAAACQAAAAAARdgBAAAAAAAAAAAAAAAAAE0AAAAAAAAAAAAAAA=="
NET="--NET_sm_count 32 --NET_link_order scatter_sum --NET_size 20480000"
CE="--CE_type H --CE_size 2048000"
FREQQ="--freq 400 --duty 0.9 --dual_mode --dual_freq 0.0013888889 --dual_duty 0.50"

ns_nic=bond0
ew_nics=(mlx5_0 mlx5_1 mlx5_8 mlx5_9 mlx5_10 mlx5_11 mlx5_12 mlx5_13)

if [ ${#hosts[*]} -gt 1 ]; then
  #Multiple nodes connected with IB
  export UCX_TLS=rc
  export UCX_NET_DEVICES="$(echo ${ew_nics[@]}|tr ' ' '\n'|xargs -I {} echo {}:1|paste -s -d',')"
  export NCCL_IB_HCA="=$(echo ${ew_nics[@]}|tr ' ' '\n'|xargs -I {} echo {}|paste -s -d',')"
else
  #Single node
  export UCX_TLS=tcp
  export UCX_NET_DEVICES=${ns_nic}
  export NCCL_IB_HCA=${ns_nic}
fi

set -x
#1. Check nodes status
timeout 120 bash ${topdir}/aihpc_val/tools/hc/sysinfo.sh
#2. Run mnubergemm
ldd /usr/libexec/datacenter-gpu-manager-4/plugins/cuda13/mnubergemm
mpirun --allow-run-as-root \
  --mca coll ^hcoll --mca btl ^openib,smcuda \
  --map-by ppr:4:socket:PE=21 \
  --display-map --display-topo --report-bindings \
  -x PATH=$PATH \
  -x LD_LIBRARY_PATH=$LD_LIBRARY_PATH \
\
  -x UCX_TLS=${UCX_TLS} \
  -x UCX_NET_DEVICES=${UCX_NET_DEVICES} \
  -x NCCL_IB_HCA=${NCCL_IB_HCA} \
  -x NCCL_SOCKET_IFNAME=${ns_nic} \
  -x OMPI_MCA_btl_tcp_if_include=${ns_nic} \
  -x OMPI_MCA_oob_tcp_if_include=${ns_nic} \
  -x OMPI_ALLOW_RUN_AS_ROOT=1 \
  -x OMPI_ALLOW_RUN_AS_ROOT_CONFIRM=1 \
  -x OMPI_MCA_btl_openib_warn_default_gid_prefix=0 \
  -x OMPI_MCA_coll_hcoll_enable=0 \
  -x SLURM_CPU_BIND=none \
\
  -H $(for i in ${hosts[*]}; do echo ${i}:8; done|paste -s -d ',') \
  -np $[8*${#hosts[*]}] \
   /usr/libexec/datacenter-gpu-manager-4/plugins/cuda13/mnubergemm ${STD} ${FREQQ} ${MM} ${NET} ${CE}
