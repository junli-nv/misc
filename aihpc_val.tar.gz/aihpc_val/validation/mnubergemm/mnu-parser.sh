#!/bin/bash

for i in *.txt; do
perfG=$(grep 'GLOBAL PERF G' $i|awk '{print int($NF/1000)}')
perfN=$(grep 'GLOBAL PERF N' $i|awk '{print int($NF)}')
perfC=$(grep 'GLOBAL PERF C' $i|awk '{print int($NF)}')
nodes=$(grep NODELIST $i)
xid=$(grep 'XID MONITOR' $i|awk '{print $NF}')
nvlink=$(grep 'NVLINK stats buckets' $i |grep -v '\.\.'| awk '{print $NF}' | paste -s -d',')
echo $i G[TF]=$perfG N=$perfN C=$perfC XID=$xid NVLINK=$nvlink $nodes
done
