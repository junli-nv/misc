#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

for i in $(ls -1 *.txt); do printf "%100s : %s\n" $i "$(grep WC $i)"; done

