## Performance results got on BoostRun B300

![](./sample_perf.png)

```
==========LLM  PERF============
     deepseekv3-BF16-64N-21250.txt: Step[s]=14.62 perGPU[TFLOPs]=559.88 Sstd=0.21515 Pstd=8.05452
      deepseekv3-FP8-64N-21252.txt: Step[s]=11.84 perGPU[TFLOPs]=719.43 Sstd=0.09973 Pstd=5.94785 
    LLAMA31_405B-FP8-72N-21246.txt: Step[s]=5.81 perGPU[TFLOPs]=1778.00 Sstd=0.02870 Pstd=8.62066
      LLAMA3_70B-FP8-72N-21244.txt: Step[s]=4.30 perGPU[TFLOPs]=1713.70 Sstd=0.05700 Pstd=21.55556
       LLAMA3_8B-FP8-72N-21245.txt: Step[s]=4.12 perGPU[TFLOPs]=1637.35 Sstd=0.00453 Pstd=1.84320
  Nemotron4_15B-BF16-72N-21241.txt: Step[s]=1.34 perGPU[TFLOPs]=1086.45 Sstd=0.00326 Pstd=2.56443
 Nemotron4_340B-BF16-72N-21242.txt: Step[s]=2.17 perGPU[TFLOPs]=974.82 Sstd=0.00256 Pstd=1.14995
  Nemotron5H_56B-FP8-72N-21239.txt: Step[s]=5.58 perGPU[TFLOPs]=1476.69 Sstd=0.00951 Pstd=2.63117 
   Qwen3_30B_A3B-FP8-72N-21247.txt: Step[s]=11.39 perGPU[TFLOPs]=539.18 Sstd=1.66202 Pstd=70.00978
```

### GPU Topology

```
# nvidia-smi topo -m
        GPU0    GPU1    GPU2    GPU3    GPU4    GPU5    GPU6    GPU7    NIC0    NIC1    NIC2    NIC3    NIC4    NIC5    NIC6    NIC7    NIC8    NIC9    NIC10   CPU Affinity    NUMA Affinity   GPU NUMA ID
GPU0     X      NV18    NV18    NV18    NV18    NV18    NV18    NV18    PXB     NODE    NODE    NODE    NODE    NODE    SYS     SYS     SYS     SYS     SYS     0-85,172-257    0               N/A
GPU1    NV18     X      NV18    NV18    NV18    NV18    NV18    NV18    NODE    PXB     NODE    NODE    NODE    NODE    SYS     SYS     SYS     SYS     SYS     0-85,172-257    0               N/A
GPU2    NV18    NV18     X      NV18    NV18    NV18    NV18    NV18    NODE    NODE    NODE    NODE    PXB     NODE    SYS     SYS     SYS     SYS     SYS     0-85,172-257    0               N/A
GPU3    NV18    NV18    NV18     X      NV18    NV18    NV18    NV18    NODE    NODE    NODE    NODE    NODE    PXB     SYS     SYS     SYS     SYS     SYS     0-85,172-257    0               N/A
GPU4    NV18    NV18    NV18    NV18     X      NV18    NV18    NV18    SYS     SYS     SYS     SYS     SYS     SYS     PXB     NODE    NODE    NODE    NODE    86-171,258-343  1               N/A
GPU5    NV18    NV18    NV18    NV18    NV18     X      NV18    NV18    SYS     SYS     SYS     SYS     SYS     SYS     NODE    PXB     NODE    NODE    NODE    86-171,258-343  1               N/A
GPU6    NV18    NV18    NV18    NV18    NV18    NV18     X      NV18    SYS     SYS     SYS     SYS     SYS     SYS     NODE    NODE    PXB     NODE    NODE    86-171,258-343  1               N/A
GPU7    NV18    NV18    NV18    NV18    NV18    NV18    NV18     X      SYS     SYS     SYS     SYS     SYS     SYS     NODE    NODE    NODE    PXB     NODE    86-171,258-343  1               N/A
NIC0    PXB     NODE    NODE    NODE    SYS     SYS     SYS     SYS      X      NODE    NODE    NODE    NODE    NODE    SYS     SYS     SYS     SYS     SYS
NIC1    NODE    PXB     NODE    NODE    SYS     SYS     SYS     SYS     NODE     X      NODE    NODE    NODE    NODE    SYS     SYS     SYS     SYS     SYS
NIC2    NODE    NODE    NODE    NODE    SYS     SYS     SYS     SYS     NODE    NODE     X      PIX     NODE    NODE    SYS     SYS     SYS     SYS     SYS
NIC3    NODE    NODE    NODE    NODE    SYS     SYS     SYS     SYS     NODE    NODE    PIX      X      NODE    NODE    SYS     SYS     SYS     SYS     SYS
NIC4    NODE    NODE    PXB     NODE    SYS     SYS     SYS     SYS     NODE    NODE    NODE    NODE     X      NODE    SYS     SYS     SYS     SYS     SYS
NIC5    NODE    NODE    NODE    PXB     SYS     SYS     SYS     SYS     NODE    NODE    NODE    NODE    NODE     X      SYS     SYS     SYS     SYS     SYS
NIC6    SYS     SYS     SYS     SYS     PXB     NODE    NODE    NODE    SYS     SYS     SYS     SYS     SYS     SYS      X      NODE    NODE    NODE    NODE
NIC7    SYS     SYS     SYS     SYS     NODE    PXB     NODE    NODE    SYS     SYS     SYS     SYS     SYS     SYS     NODE     X      NODE    NODE    NODE
NIC8    SYS     SYS     SYS     SYS     NODE    NODE    PXB     NODE    SYS     SYS     SYS     SYS     SYS     SYS     NODE    NODE     X      NODE    NODE
NIC9    SYS     SYS     SYS     SYS     NODE    NODE    NODE    PXB     SYS     SYS     SYS     SYS     SYS     SYS     NODE    NODE    NODE     X      NODE
NIC10   SYS     SYS     SYS     SYS     NODE    NODE    NODE    NODE    SYS     SYS     SYS     SYS     SYS     SYS     NODE    NODE    NODE    NODE     X

Legend:

  X    = Self
  SYS  = Connection traversing PCIe as well as the SMP interconnect between NUMA nodes (e.g., QPI/UPI)
  NODE = Connection traversing PCIe as well as the interconnect between PCIe Host Bridges within a NUMA node
  PHB  = Connection traversing PCIe as well as a PCIe Host Bridge (typically the CPU)
  PXB  = Connection traversing multiple PCIe bridges (without traversing the PCIe Host Bridge)
  PIX  = Connection traversing at most a single PCIe bridge
  NV#  = Connection traversing a bonded set of # NVLinks

NIC Legend:

  NIC0: mlx5_0
  NIC1: mlx5_1
  NIC2: mlx5_2
  NIC3: mlx5_3
  NIC4: mlx5_8
  NIC5: mlx5_9
  NIC6: mlx5_10
  NIC7: mlx5_11
  NIC8: mlx5_12
  NIC9: mlx5_13
  NIC10: mlx5_bond_0
```

### Infiniband Mapping

```
# mst status -v|sed '/^$/d'
MST modules:
------------
    MST PCI module loaded
    MST PCI configuration module loaded
PCI devices:
------------
DEVICE_TYPE                         MST                           PCI             RDMA            NET                                     NUMA  VFIO
GB100(rev:0)                        /dev/mst/mt12674_pciconf7     0001:db:00.0                                                            1
GB100(rev:0)                        /dev/mst/mt12674_pci_cr7      0001:db:00.0                                                            1
GB100(rev:0)                        /dev/mst/mt12674_pciconf6     0001:b5:00.0                                                            1
GB100(rev:0)                        /dev/mst/mt12674_pci_cr6      0001:b5:00.0                                                            1
GB100(rev:0)                        /dev/mst/mt12674_pciconf5     0001:69:00.0                                                            1
GB100(rev:0)                        /dev/mst/mt12674_pci_cr5      0001:69:00.0                                                            1
GB100(rev:0)                        /dev/mst/mt12674_pciconf4     0001:1a:00.0                                                            1
GB100(rev:0)                        /dev/mst/mt12674_pci_cr4      0001:1a:00.0                                                            1
GB100(rev:0)                        /dev/mst/mt12674_pciconf3     0000:db:00.0                                                            0
GB100(rev:0)                        /dev/mst/mt12674_pci_cr3      0000:db:00.0                                                            0
GB100(rev:0)                        /dev/mst/mt12674_pciconf2     0000:b5:00.0                                                            0
GB100(rev:0)                        /dev/mst/mt12674_pci_cr2      0000:b5:00.0                                                            0
GB100(rev:0)                        /dev/mst/mt12674_pciconf1     0000:69:00.0                                                            0
GB100(rev:0)                        /dev/mst/mt12674_pci_cr1      0000:69:00.0                                                            0
GB100(rev:0)                        /dev/mst/mt12674_pciconf0     0000:1a:00.0                                                            0
GB100(rev:0)                        /dev/mst/mt12674_pci_cr0      0000:1a:00.0                                                            0
BlueField3(rev:1)                   /dev/mst/mt41692_pciconf1.1   0001:95:00.1                    mlx5_bond_0     net-bond0                               1
BlueField3(rev:1)                   /dev/mst/mt41692_pciconf1     0001:95:00.0    mlx5_bond_0     net-bond0                               1
BlueField3(rev:1)                   /dev/mst/mt41692_pciconf0.1   0000:94:00.1    mlx5_3          net-eno17305np1                         0
BlueField3(rev:1)                   /dev/mst/mt41692_pciconf0     0000:94:00.0    mlx5_2          net-eno17295np0                         0
ConnectX8(rev:0)                    /dev/mst/mt4131_pciconf7      0001:d8:00.0    mlx5_13         net-ibP1p216s0                          1
ConnectX8(rev:0)                    /dev/mst/mt4131_pciconf6      0001:b2:00.0    mlx5_12         net-ibP1p178s0                          1
ConnectX8(rev:0)                    /dev/mst/mt4131_pciconf5      0001:66:00.0    mlx5_11         net-ibP1p102s0                          1
ConnectX8(rev:0)                    /dev/mst/mt4131_pciconf4      0001:17:00.0    mlx5_10         net-ibP1p23s0                           1
ConnectX8(rev:0)                    /dev/mst/mt4131_pciconf3      0000:d8:00.0    mlx5_9          net-ibp216s0                            0
ConnectX8(rev:0)                    /dev/mst/mt4131_pciconf2      0000:b2:00.0    mlx5_8          net-ibp178s0                            0
ConnectX8(rev:0)                    /dev/mst/mt4131_pciconf1      0000:66:00.0    mlx5_1          net-ibp102s0                            0
ConnectX8(rev:0)                    /dev/mst/mt4131_pciconf0      0000:17:00.0    mlx5_0          net-ibp23s0                             0
ConnectX7(rev:0)                    /dev/mst/mt4129_pciconf0.3    0000:95:00.3    mlx5_7          net-ibo6                                0
ConnectX7(rev:0)                    /dev/mst/mt4129_pciconf0.2    0000:95:00.2    mlx5_6          net-ibo5                                0
ConnectX7(rev:0)                    /dev/mst/mt4129_pciconf0.1    0000:95:00.1    mlx5_5          net-ibo4                                0
ConnectX7(rev:0)                    /dev/mst/mt4129_pciconf0      0000:95:00.0    mlx5_4          net-ibo1                                0
```

### CPU Topology

```
# lscpu
Architecture:             x86_64
  CPU op-mode(s):         32-bit, 64-bit
  Address sizes:          52 bits physical, 57 bits virtual
  Byte Order:             Little Endian
CPU(s):                   344
  On-line CPU(s) list:    0-343
Vendor ID:                GenuineIntel
  BIOS Vendor ID:         Intel
  Model name:             Intel(R) Xeon(R) 6787P
    BIOS Model name:      Intel(R) Xeon(R) 6787P  CPU @ 2.0GHz
    BIOS CPU family:      179
    CPU family:           6
    Model:                173
    Thread(s) per core:   2
    Core(s) per socket:   86
    Socket(s):            2
    Stepping:             1
    BogoMIPS:             4000.00
    Flags:                fpu vme de pse tsc msr pae mce cx8 apic sep mtrr pge mca cmov pat pse36 clflush dts acpi mmx fxsr sse sse2 ss ht tm pbe syscall nx pdpe1gb rdtscp lm constant_tsc art arch_perfmon pebs bts rep_good nopl xtopology nonstop_tsc cpuid aperfmperf tsc_known_
                          freq pni pclmulqdq dtes64 monitor ds_cpl vmx smx est tm2 ssse3 sdbg fma cx16 xtpr pdcm pcid dca sse4_1 sse4_2 x2apic movbe popcnt tsc_deadline_timer aes xsave avx f16c rdrand lahf_lm abm 3dnowprefetch cpuid_fault epb cat_l3 cat_l2 cdp_l3 intel_ppin cd
                          p_l2 ssbd mba ibrs ibpb stibp ibrs_enhanced tpr_shadow flexpriority ept vpid ept_ad fsgsbase tsc_adjust bmi1 avx2 smep bmi2 erms invpcid cqm rdt_a avx512f avx512dq rdseed adx smap avx512ifma clflushopt clwb intel_pt avx512cd sha_ni avx512bw avx512vl x
                          saveopt xsavec xgetbv1 xsaves cqm_llc cqm_occup_llc cqm_mbm_total cqm_mbm_local split_lock_detect user_shstk avx_vnni avx512_bf16 wbnoinvd dtherm ida arat pln pts vnmi avx512vbmi umip pku ospke waitpkg avx512_vbmi2 gfni vaes vpclmulqdq avx512_vnni avx
                          512_bitalg tme avx512_vpopcntdq la57 rdpid bus_lock_detect cldemote movdiri movdir64b enqcmd fsrm md_clear serialize tsxldtrk pconfig arch_lbr ibt amx_bf16 avx512_fp16 amx_tile amx_int8 flush_l1d arch_capabilities ibpb_exit_to_user
Virtualization features:
  Virtualization:         VT-x
Caches (sum of all):
  L1d:                    8.1 MiB (172 instances)
  L1i:                    10.8 MiB (172 instances)
  L2:                     344 MiB (172 instances)
  L3:                     672 MiB (2 instances)
NUMA:
  NUMA node(s):           2
  NUMA node0 CPU(s):      0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,32,34,36,38,40,42,44,46,48,50,52,54,56,58,60,62,64,66,68,70,72,74,76,78,80,82,84,86,88,90,92,94,96,98,100,102,104,106,108,110,112,114,116,118,120,122,124,126,128,130,132,134,136,138,140,142,144,146,148,150,15
                          2,154,156,158,160,162,164,166,168,170,172,174,176,178,180,182,184,186,188,190,192,194,196,198,200,202,204,206,208,210,212,214,216,218,220,222,224,226,228,230,232,234,236,238,240,242,244,246,248,250,252,254,256,258,260,262,264,266,268,270,272,274,276,2
                          78,280,282,284,286,288,290,292,294,296,298,300,302,304,306,308,310,312,314,316,318,320,322,324,326,328,330,332,334,336,338,340,342
  NUMA node1 CPU(s):      1,3,5,7,9,11,13,15,17,19,21,23,25,27,29,31,33,35,37,39,41,43,45,47,49,51,53,55,57,59,61,63,65,67,69,71,73,75,77,79,81,83,85,87,89,91,93,95,97,99,101,103,105,107,109,111,113,115,117,119,121,123,125,127,129,131,133,135,137,139,141,143,145,147,149,151,15
                          3,155,157,159,161,163,165,167,169,171,173,175,177,179,181,183,185,187,189,191,193,195,197,199,201,203,205,207,209,211,213,215,217,219,221,223,225,227,229,231,233,235,237,239,241,243,245,247,249,251,253,255,257,259,261,263,265,267,269,271,273,275,277,2
                          79,281,283,285,287,289,291,293,295,297,299,301,303,305,307,309,311,313,315,317,319,321,323,325,327,329,331,333,335,337,339,341,343
Vulnerabilities:
  Gather data sampling:   Not affected
  Itlb multihit:          Not affected
  L1tf:                   Not affected
  Mds:                    Not affected
  Meltdown:               Not affected
  Mmio stale data:        Not affected
  Reg file data sampling: Not affected
  Retbleed:               Not affected
  Spec rstack overflow:   Not affected
  Spec store bypass:      Mitigation; Speculative Store Bypass disabled via prctl
  Spectre v1:             Mitigation; usercopy/swapgs barriers and __user pointer sanitization
  Spectre v2:             Mitigation; Enhanced / Automatic IBRS; IBPB conditional; RSB filling; PBRSB-eIBRS Not affected; BHI BHI_DIS_S
  Srbds:                  Not affected
  Tsx async abort:        Not affected
  Vmscape:                Mitigation; IBPB before exit to userspace

# numactl -H
available: 2 nodes (0-1)
node 0 cpus: 0 2 4 6 8 10 12 14 16 18 20 22 24 26 28 30 32 34 36 38 40 42 44 46 48 50 52 54 56 58 60 62 64 66 68 70 72 74 76 78 80 82 84 86 88 90 92 94 96 98 100 102 104 106 108 110 112 114 116 118 120 122 124 126 128 130 132 134 136 138 140 142 144 146 148 150 152 154 156 158 160 162 164 166 168 170 172 174 176 178 180 182 184 186 188 190 192 194 196 198 200 202 204 206 208 210 212 214 216 218 220 222 224 226 228 230 232 234 236 238 240 242 244 246 248 250 252 254 256 258 260 262 264 266 268 270 272 274 276 278 280 282 284 286 288 290 292 294 296 298 300 302 304 306 308 310 312 314 316 318 320 322 324 326 328 330 332 334 336 338 340 342
node 0 size: 2063811 MB
node 0 free: 2046757 MB
node 1 cpus: 1 3 5 7 9 11 13 15 17 19 21 23 25 27 29 31 33 35 37 39 41 43 45 47 49 51 53 55 57 59 61 63 65 67 69 71 73 75 77 79 81 83 85 87 89 91 93 95 97 99 101 103 105 107 109 111 113 115 117 119 121 123 125 127 129 131 133 135 137 139 141 143 145 147 149 151 153 155 157 159 161 163 165 167 169 171 173 175 177 179 181 183 185 187 189 191 193 195 197 199 201 203 205 207 209 211 213 215 217 219 221 223 225 227 229 231 233 235 237 239 241 243 245 247 249 251 253 255 257 259 261 263 265 267 269 271 273 275 277 279 281 283 285 287 289 291 293 295 297 299 301 303 305 307 309 311 313 315 317 319 321 323 325 327 329 331 333 335 337 339 341 343
node 1 size: 2064310 MB
node 1 free: 1914204 MB
node distances:
node   0   1
  0:  10  21
  1:  21  10
```
