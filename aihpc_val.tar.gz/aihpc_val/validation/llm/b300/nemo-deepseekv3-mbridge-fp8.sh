#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

#SBATCH -p defq
#SBATCH --exclusive
#SBATCH --ntasks-per-node=8
#SBATCH --cpus-per-task=43
#SBATCH --gpus-per-node=8
#SBATCH -N 16

CONT=/raid/nemo-25.11.01.sqsh
HUGGINGFACE_CACHE=/home/cmsupport/workspace/nemo/huggingface

if [[ $((8*${SLURM_NNODES}%128)) -ne 0 ]]; then
  echo "ERROR: TP*PP*EP*VP*ET=1*16*8*1*1=128"
  echo "ERROR: num_gpus % (ep * et * tp * pp) == 0, but $((8*${SLURM_NNODES})) % 128) != 0"
  exit 1
fi

module load slurm
cd ${SLURM_SUBMIT_DIR}

echo
echo "NODELIST: ${SLURM_JOB_NODELIST}"
echo

s_time=$(date +%s)
echo "INFO: cleaning work begin"
pdsh -f 64 -R ssh -w ${SLURM_JOB_NODELIST} <<- 'EOF'|dshbak -c
pkill -9 python &>/dev/null || true
ps -ef|grep python|grep -E 'torch|nemo'|grep -v grep || true
enroot list -f|grep pyxis && enroot remove -f $(enroot list -f|grep pyxis) || true
rm -f /var/lib/systemd/coredump/* &>/dev/null || true
EOF
echo "INFO: cleaning work done"

echo "INFO: checking hardware status"
timeout 100 bash /home/cmsupport/workspace/aihpc_val/tools/hc/sysinfo.sh 2>&1

set -x
ns_nic=bond0
ew_nics=(mlx5_0 mlx5_1 mlx5_8 mlx5_9 mlx5_10 mlx5_11 mlx5_12 mlx5_13)
export MELLANOX_VISIBLE_DEVICES=all
export PMIX_MCA_gds=hash
#
#export UCX_TLS=tcp NCCL_IB_DISABLE=1
export UCX_TLS=rc
export UCX_NET_DEVICES="$(echo ${ew_nics[@]}|tr ' ' '\n'|xargs -I {} echo {}:1|paste -s -d',')"
export NCCL_IB_HCA="=$(echo ${ew_nics[@]}|tr ' ' '\n'|xargs -I {} echo {}|paste -s -d',')"
#
eth_nic=bond0
export NCCL_SOCKET_IFNAME=${eth_nic}
export MCA_btl_tcp_if_include=${eth_nic}
export MCA_oob_tcp_if_include=${eth_nic}
export NVTE_UB_SOCKET_IFNAME=${eth_nic}
export GLOO_SOCKET_IFNAME=${eth_nic}
#
export OMPI_ALLOW_RUN_AS_ROOT=1
export OMPI_ALLOW_RUN_AS_ROOT_CONFIRM=1
export OMPI_MCA_btl_openib_warn_default_gid_prefix=0
export OMPI_MCA_coll_hcoll_enable=0
export SLURM_CPU_BIND=none

## For SPX
#export NCCL_IB_GID_INDEX=3
#export NCCL_IB_TC=96
#export NCCL_IB_TC=96
#export NCCL_IB_GID_INDEX=3

srun -N ${SLURM_NNODES} --ntasks-per-node=1 enroot remove -f pyxis_nemo &>/dev/null

## test nccl
export NCCL_DEBUG=WARN
export NCCL_NVLS_ENABLE=1
######### NOTES: The following params combination help NCCL but hurt nemo performance.
export NCCL_IB_ADAPTIVE_ROUTING=1
export NCCL_IB_SL=1
export NCCL_IB_QPS_PER_CONNECTION=8 #help raw bandwidth in nccl-tests but adds NIC-side overhead and queue depth/latency
export NCCL_MIN_NCHANNELS=32 #increases the number of CUDA blocks/CTAs used for communication and therefore consumes more SMs
export NCCL_MIN_CTAS=64 #The max is 64, forces NCCL to burn more SMs on comm will hurt real workloads (NeMo) by reducing compute/comm overlap or starving the model’s kernels
export NCCL_P2P_LEVEL=NVL
######### END NOTES
timeout 300 \
srun --export=ALL --cpu-bind=none --mpi=pmix \
--container-name=nemo \
--container-writable \
--container-image=$CONT \
--container-mounts=/dev:/dev \
all_reduce_perf_mpi -dfloat -b 8 -f 2 -g 1 -e 16G --iters 20
exitcode=$?
if [ $exitcode -ne 0 ]; then
  echo "*********************************************"
  echo "* ERROR: NCCL failed to run!!!              *"
  echo "*********************************************"
  srun -N ${SLURM_NNODES} --ntasks-per-node=1 enroot remove -f pyxis_nemo &>/dev/null
  exit 1
fi

sleep 10
########  run nemo test
#
## Workaround for unstable or not robust enough NVLINK:
# With unstable or not robust enough NVLINK, you may encounter error like:
# RuntimeError: /opt/TransformerEngine/transformer_engine/common/comm_gemm_overlap/userbuffers/userbuffers-host.cpp:331 in function create_communicator_grouped2: CUDA Error: unknown error
# To workaround this issue, we can set UB_SKIPMC=1 to disables the NVSwitch/CUDA multicast path and makes Userbuffers fall back to a slower IPC-based scheme.
# It's usually better than turning off tp_comm_overlap entirely, but worse than full multicast on a healthy, supported fabric.
# UB_SKIPMC: UserBuffers Skip Multicast
# UB = UserBuffers (the TP-overlap communication backend in TransformerEngine)
# SKIPMC = skip multicast (don't use CUDA/NVLS multicast for UB collectives)
## export NCCL_NVLS_ENABLE=0
## export UB_SKIPMC=1
### For optimal performance, it's recommended to keep NVLS enabled and let UB use multicast if possible.
export NCCL_DEBUG=INFO
export NCCL_NVLS_ENABLE=1
export UB_SKIPMC=0
######### NOTES: The following params combination help NCCL but hurt nemo performance.
unset NCCL_IB_ADAPTIVE_ROUTING #default: 1 on IB, 0 on SPX
unset NCCL_IB_SL #defailt: 0
unset NCCL_IB_QPS_PER_CONNECTION #defualt: 1
unset NCCL_MIN_NCHANNELS #defualt: 32
unset NCCL_MIN_CTAS #defualt: undefined, up to 32
unset NCCL_P2P_LEVEL
######### END NOTES
export NCCL_MIN_CTAS=16
#
nodes=( $( scontrol show hostnames $SLURM_JOB_NODELIST ) )
nodes_array=($nodes)
head_node=${nodes_array[0]}
head_node_ip=$(srun --nodes=1 --ntasks=1 -w "$head_node" hostname --ip-address)
#
srun --export=ALL --cpu-bind=none --mpi=pmix \
--container-name=nemo \
--container-writable \
--container-image=${CONT} \
--container-mounts=/dev:/dev,${HUGGINGFACE_CACHE}:/root/.cache/huggingface \
bash <<- '__END__'
set -ex
export PYTHONUNBUFFERED=1
export SLURM_UNBUFFEREDIO=1
export TORCHX_MAX_RETRIES=0

export HF_HUB_OFFLINE=1
export HF_HOME=/root/.cache/huggingface
export CPATH=/usr/local/cuda/include
export TRITON_PTXAS_PATH=/usr/local/cuda/bin/ptxas
export TRITON_LIB_DIR=/usr/local/cuda/lib64

export TORCH_NCCL_AVOID_RECORD_STREAMS=1
export TRANSFORMERS_OFFLINE=1
export TOKENIZERS_PARALLELISM=False
export TORCH_NCCL_HIGH_PRIORITY=1
export CUDA_DEVICE_MAX_CONNECTIONS=32
export NVTE_FWD_LAYERNORM_SM_MARGIN=16
export NVTE_BWD_LAYERNORM_SM_MARGIN=16

export NEMORUN_HOME=/mnt/nemo
export NEMO_HOME=${NEMORUN_HOME}/experiments
export PYTHONPATH=/opt/Megatron-Bridge/scripts/performance:$PYTHONPATH

#### TP/PP/CP/EP/VP tunning -> https://docs.nvidia.com/nemo-framework/user-guide/latest/performance/performance-guide.html
#
## Rule: 
#1. num_gpus % (ep * et * tp * pp) == 0
#2. dp=$[num_gpus/(tp*pp*cp)]
#3. ga=$[gb/(mb*dp)] 
#
## For 128 B300 GPUs: 
##  --use_tokendrop 0 --recompute_modules mla_up_proj,mlp --cuda_graph_impl none
#  tp=1,pp=16,cp=1,ep=8,vp=1,et=1,mb=1,gb=1024 => dp=8,ga=128 => OOM
#  tp=1,pp=8,cp=1,ep=8,vp=2,et=1,mb=1,gb=1024  => dp=16,ga=64 => OK and perf is good (11.9s/step) and has some variations
#  tp=1,pp=4,cp=1,ep=32,vp=4,et=1,mb=1,gb=1024 => dp=32,ga=32 => OK but perf is low  (18.9s/step)
##  --use_tokendrop 0 --cuda_graph_impl none
#  tp=1,pp=8,cp=1,ep=8,vp=2,et=1,mb=1,gb=1024  => dp=16,ga=64 => OK and perf is good (12.2s/step) and has some variations
##  --use_tokendrop 0 --recompute_modules mla_up_proj,mlp --cuda_graph_impl transformer_engine --cuda_graph_scope moe_router,moe_preprocess
#  tp=1,pp=8,cp=1,ep=8,vp=2,et=1,mb=1,gb=1024  => dp=16,ga=64 => OOM
## --use_tokendrop 1 --recompute_modules mla_up_proj,mlp --cuda_graph_impl none
#  tp=1,pp=8,cp=1,ep=8,vp=2,et=1,mb=1,gb=1024  => dp=16,ga=64 => OK and perf is good and stable (11.1s/step)
## --use_tokendrop 1 --recompute_modules mlp,moe_act --cuda_graph_impl transformer_engine --cuda_graph_scope moe_router,moe_preprocess,attn
#  tp=1,pp=8,cp=1,ep=8,vp=2,et=1,mb=1,gb=1024  => dp=16,ga=64 => OOM
## --use_tokendrop 1 --recompute_modules mlp,moe_act --cuda_graph_impl transformer_engine --cuda_graph_scope attn
#  tp=1,pp=8,cp=1,ep=8,vp=2,et=1,mb=1,gb=1024  => dp=16,ga=64 => OOM

numactl --cpunodebind=$[SLURM_LOCALID/4] --membind=$[SLURM_LOCALID/4] \
python /opt/Megatron-Bridge/scripts/performance/run_script.py \
  --account root \
  --partition defq \
  --log_dir ${NEMORUN_HOME} \
  --container_image ${NEMORUN_HOME}/nemo-25.11.sqsh \
  --nemo_home ${NEMORUN_HOME}/experiments \
  --gpu b200 \
  --num_gpus $[8*${SLURM_NNODES}] \
  --gpus_per_node 8 \
  --compute_dtype fp8_mx \
  --model_name deepseek --model_size v3 \
  --use_megatron_fsdp 0 \
  -tp 1 \
  -pp 8 \
  -cp 1 \
  -ep 8 \
  -vp 2 \
  -et 1 \
  -mb 1 \
  -gb $[1024*${SLURM_NNODES}/16] \
  --use_tokendrop 1 --recompute_modules mla_up_proj,mlp --cuda_graph_impl none \
  --max_steps 110 \
  train.manual_gc=true train.manual_gc_interval=100
__END__

srun -N ${SLURM_NNODES} --ntasks-per-node=1 enroot remove -f pyxis_nemo &>/dev/null
set +x

e_time=$(date +%s)
echo "INFO: timelimit=$[(SLURM_JOB_END_TIME-SLURM_JOB_START_TIME)](s), real_took=$[e_time-s_time](s)"

## Another way to run the test
## Create config files and run experiments automatically
## Reference: https://github.com/NVIDIA-NeMo/Megatron-Bridge/tree/v0.2.0/scripts/performance
# python -m venv llm
# source llm/bin/activate
# pip install git+https://github.com/NVIDIA-NeMo/Run.git
# git clone https://github.com/NVIDIA-NeMo/Megatron-Bridge.git
# cd Megatron-Bridge
## branch needs align with container, refer https://docs.nvidia.com/nemo-framework/user-guide/latest/softwarecomponentversions.html
# git switch r0.2.0 
# python3 /opt/Megatron-Bridge/scripts/performance/setup_experiment.py ... ... #the same args with run_script.py
