#!/bin/bash
#SBATCH -p defq
#SBATCH --exclusive
#SBATCH --ntasks-per-node=8
#SBATCH --cpus-per-task=32
#SBATCH --gpus-per-node=8
#SBATCH --time=04:00:00
#SBATCH --mem=0
#SBATCH -N 16
#SBATCH -x aic-gb3a-[310004,310010,310015]

module load slurm
cd ${SLURM_SUBMIT_DIR}

echo
echo "NODELIST: ${SLURM_JOB_NODELIST}"
echo

s_time=$(date +%s)
echo "INFO: cleaning work begin"
pdsh -f 64 -R ssh -w ${SLURM_JOB_NODELIST} <<- 'EOF'|dshbak -c
pkill -9 python &>/dev/null || true
ps -ef|grep python|grep -E 'torch|nemo'|grep -v grep || true
enroot list -f|grep pyxis && enroot remove -f $(enroot list -f|grep pyxis) || true
rm -f /var/lib/systemd/coredump/* &>/dev/null || true
EOF
echo "INFO: cleaning work done"

echo "INFO: checking hardware status"
pdsh -t 3 -u 3 -R ssh -f 36 -w $SLURM_NODELIST  <<- 'EOF' | dshbak -c
nvidia-smi -L|wc -l
nvidia-smi nvlink -s|grep [0-9].*GB|wc -l
ibstatus|grep -E 'Infiniband|state:'|paste - - -|grep roce|tr -s ' '
EOF

set -x
ew_nics=($(echo roce_p{0,1}_rail{0..7}))
export MELLANOX_VISIBLE_DEVICES=all
export PMIX_MCA_gds=hash
#
#export UCX_TLS=tcp NCCL_IB_DISABLE=1
export UCX_TLS=rc
export UCX_NET_DEVICES="$(echo ${ew_nics[@]}|tr ' ' '\n'|xargs -I {} echo {}:1|paste -s -d',')"
export NCCL_IB_HCA="=$(echo ${ew_nics[@]}|tr ' ' '\n'|xargs -I {} echo {}|paste -s -d',')"
#
export NCCL_SOCKET_IFNAME=bond0
export OMPI_MCA_btl_tcp_if_include=bond0
export OMPI_MCA_oob_tcp_if_include=bond0
export NVTE_UB_SOCKET_IFNAME=bond0
export GLOO_SOCKET_IFNAME=bond0
export OMPI_ALLOW_RUN_AS_ROOT=1
export OMPI_ALLOW_RUN_AS_ROOT_CONFIRM=1
export OMPI_MCA_btl_openib_warn_default_gid_prefix=0
export OMPI_MCA_coll_hcoll_enable=0
export NCCL_IB_GID_INDEX=3
export NCCL_IB_TC=96
export NCCL_IB_ADAPTIVE_ROUTING=1
export NCCL_IB_SL=1
export NCCL_IB_QPS_PER_CONNECTION=8
export NCCL_IB_TC=96
export NCCL_IB_GID_INDEX=3
export NCCL_MIN_NCHANNELS=32
export NCCL_NVLS_ENABLE=1
export NCCL_P2P_LEVEL=NVL
export NCCL_MIN_CTAS=64
export SLURM_CPU_BIND=none

srun -N ${SLURM_NNODES} --ntasks-per-node=1 enroot remove -f pyxis_nemo &>/dev/null

## test nccl
srun --export=ALL --cpu-bind=none --mpi=pmix \
--container-name=nemo \
--container-writable \
--container-image=/home/cmsupport/workspace/nemo-25.11.sqsh \
--container-mounts=/dev:/dev \
all_reduce_perf_mpi -dfloat -b 8 -f 2 -g 1 -e 16G --iters 20
exitcode=$?
if [ $exitcode -ne 0 ]; then
  srun -N ${SLURM_NNODES} --ntasks-per-node=1 enroot remove -f pyxis_nemo &>/dev/null
  exit 1
fi

############ Nemo Run ############

nodes=( $( scontrol show hostnames $SLURM_JOB_NODELIST ) )
nodes_array=($nodes)
head_node=${nodes_array[0]}
head_node_ip=$(srun --nodes=1 --ntasks=1 -w "$head_node" hostname --ip-address)

srun --export=ALL --cpu-bind=none --mpi=pmix \
--container-name=nemo \
--container-writable \
--container-image=/home/cmsupport/workspace/nemo-25.11.sqsh \
--container-mounts=/dev:/dev,/raid/nemo/huggingface:/root/.cache/huggingface \
bash <<- '__END__'
set -ex
export PYTHONUNBUFFERED=1
export SLURM_UNBUFFEREDIO=1
export TORCHX_MAX_RETRIES=0

export NCCL_DEBUG=INFO
export HF_HUB_OFFLINE=1
export HF_HOME=/root/.cache/huggingface
export CPATH=/usr/local/cuda/include
export TRITON_PTXAS_PATH=/usr/local/cuda/bin/ptxas
export TRITON_LIB_DIR=/usr/local/cuda/lib64

export TORCH_NCCL_AVOID_RECORD_STREAMS=1
export TRANSFORMERS_OFFLINE=1
export TOKENIZERS_PARALLELISM=False
export NCCL_NVLS_ENABLE=0
export TORCH_NCCL_HIGH_PRIORITY=1
export CUDA_DEVICE_MAX_CONNECTIONS=32
export NVTE_FWD_LAYERNORM_SM_MARGIN=16
export NVTE_BWD_LAYERNORM_SM_MARGIN=16

export NEMORUN_HOME=/mnt/nemo
export NEMO_HOME=${NEMORUN_HOME}/experiments
export PYTHONPATH=/opt/Megatron-Bridge/scripts/performance:$PYTHONPATH

#### TP/PP/CP/EP/VP tunning -> https://docs.nvidia.com/nemo-framework/user-guide/latest/performance/performance-guide.html
#
## Rule: 
#1. num_gpus % (ep * et * tp * pp) == 0
#2. dp=$[num_gpus/(tp*pp*et)]
#3. ga=$[gb/(mb*dp)] 
#
## For 128 B300 GPUs: 
##  --use_tokendrop 0 --recompute_modules mla_up_proj,mlp --cuda_graph_impl none
#  tp=1,pp=16,cp=1,ep=8,vp=1,et=1,mb=1,gb=1024 => dp=8,ga=128 => OOM
#  tp=1,pp=8,cp=1,ep=8,vp=2,et=1,mb=1,gb=1024  => dp=16,ga=64 => OK and perf is good (11.9s/step) and has some variations
#  tp=1,pp=4,cp=1,ep=32,vp=4,et=1,mb=1,gb=1024 => dp=32,ga=32 => OK but perf is low  (18.9s/step)
##  --use_tokendrop 0 --cuda_graph_impl none
#  tp=1,pp=8,cp=1,ep=8,vp=2,et=1,mb=1,gb=1024  => dp=16,ga=64 => OK and perf is good (12.2s/step) and has some variations
##  --use_tokendrop 0 --recompute_modules mla_up_proj,mlp --cuda_graph_impl transformer_engine --cuda_graph_scope moe_router,moe_preprocess
#  tp=1,pp=8,cp=1,ep=8,vp=2,et=1,mb=1,gb=1024  => dp=16,ga=64 => OOM
## --use_tokendrop 1 --recompute_modules mla_up_proj,mlp --cuda_graph_impl none
#  tp=1,pp=8,cp=1,ep=8,vp=2,et=1,mb=1,gb=1024  => dp=16,ga=64 => OK and perf is good and stable (11.1s/step)
## --use_tokendrop 1 --recompute_modules mlp,moe_act --cuda_graph_impl transformer_engine --cuda_graph_scope moe_router,moe_preprocess,attn
#  tp=1,pp=8,cp=1,ep=8,vp=2,et=1,mb=1,gb=1024  => dp=16,ga=64 => OOM
## --use_tokendrop 1 --recompute_modules mlp,moe_act --cuda_graph_impl transformer_engine --cuda_graph_scope attn
#  tp=1,pp=8,cp=1,ep=8,vp=2,et=1,mb=1,gb=1024  => dp=16,ga=64 => OOM

numactl --cpunodebind=$[SLURM_LOCALID/4] --membind=$[SLURM_LOCALID/4] \
python /opt/Megatron-Bridge/scripts/performance/run_script.py \
  --account root \
  --partition defq \
  --log_dir ${NEMORUN_HOME} \
  --container_image ${NEMORUN_HOME}/nemo-25.11.sqsh \
  --nemo_home ${NEMORUN_HOME}/experiments \
  --gpu b200 \
  --num_gpus $[8*${SLURM_NNODES}] \
  --gpus_per_node 8 \
  --compute_dtype fp8_mx \
  --model_name deepseek --model_size v3 \
  --use_megatron_fsdp 0 \
  -tp 1 \
  -pp 8 \
  -cp 1 \
  -ep 8 \
  -vp 2 \
  -et 1 \
  -mb 1 \
  -gb $[1024*${SLURM_NNODES}/16] \
  --use_tokendrop 1 --recompute_modules mla_up_proj,mlp --cuda_graph_impl none \
  --max_steps 210 \
  train.manual_gc=true train.manual_gc_interval=100
__END__

srun -N ${SLURM_NNODES} --ntasks-per-node=1 enroot remove -f pyxis_nemo &>/dev/null
set +x

e_time=$(date +%s)
echo "INFO: timelimit=$[(SLURM_JOB_END_TIME-SLURM_JOB_START_TIME)](s), real_took=$[e_time-s_time](s)"

## Another way to run the test
## Create config files and run experiments automatically
## Reference: https://github.com/NVIDIA-NeMo/Megatron-Bridge/tree/v0.2.0/scripts/performance
# python -m venv llm
# source llm/bin/activate
# pip install git+https://github.com/NVIDIA-NeMo/Run.git
# git clone https://github.com/NVIDIA-NeMo/Megatron-Bridge.git
# cd Megatron-Bridge
## branch needs align with container, refer https://docs.nvidia.com/nemo-framework/user-guide/latest/softwarecomponentversions.html
# git switch r0.2.0 
# python3 /opt/Megatron-Bridge/scripts/performance/setup_experiment.py ... ... #the same args with run_script.py
