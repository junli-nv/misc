#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

log_files=($@)

log_parser(){
 grep -o 'train_step_timing.*consumed_samples' $1|tr '|' ' ' \
   | awk -v min_iter=150 -v max_iter=180 -v fname=$1 '
BEGIN{ct=0; ts=0; ps=0;}
{if(min_iter<=NR && NR<max_iter){ct+=1; tv[ct]=$4; ts+=$4; pv[ct]=$6; ps+=$6;}}
END{
  if(ct>0){
    t_mean=ts/ct
    t_var=0
    for (i = 1; i <= ct; i++) t_var += (tv[i] - t_mean)^2
    t_std = (ct > 1 ? sqrt(t_var / (ct - 1)) : 0)

    p_mean=ps/ct
    p_var=0
    for (i = 1; i <= ct; i++) p_var += (pv[i] - p_mean)^2
    p_std = (ct > 1 ? sqrt(p_var / (ct - 1)) : 0)
    printf "%30s: Step[s]=%.2f perGPU[TFLOPs]=%.2f Sstd=%.5f Pstd=%.5f \n", fname, ts/ct, ps/ct, t_std, p_std
  }
}
'
}
for i in ${log_files[@]}; do
 log_parser $i
done

plot_file(){
  echo $1
  grep -o 'train_step_timing.*consumed_samples' $1|tr '|' ' ' |awk '{print $6}' \
    | gnuplot -e "set term dumb size 300,50; set yrange [0:1800]; plot '-' with linespoints" 2>/dev/null
}
for i in ${log_files[@]}; do
 plot_file $i
done
