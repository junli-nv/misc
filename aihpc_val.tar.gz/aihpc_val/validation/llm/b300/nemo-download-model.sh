#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

## Method1: download the pre-packed huggingface cache repos. Recommended.
wget -c https://github.com/junli-nv/misc/raw/refs/heads/main/huggingface.squashfs
unsquashfs -f -d /home/cmsupport/workspace/nemo/huggingface huggingface.squashfs
## When shared via NFS, make sure the directory is writable as nemo will create some file like .megatron_config_lock_xxxxx.lock in it.

## Method2: download the model on bare metal
curl -LsSf https://astral.sh/uv/install.sh | sh
source $HOME/.local/bin/env bash
cd /local/nemo/
export HF_HOME=$PWD/huggingface
uv venv --python 3.12.0
source .venv/bin/activate
uvx hf
uvx hf auth login --token $HF_TOKEN --add-to-git-credential
uvx hf auth list
export HF_HUB_OFFLINE=0
# https://gitlab-master.nvidia.com/unified-cloud-benchmarking/llm-benchmarking-collection-internal/-/blob/dev/cli/llmb-install/src/llmb_install/downloads/huggingface.py
for repo in deepseek-ai/DeepSeek-V3 Qwen/Qwen3-235B-A22B Qwen/Qwen3-30B-A3B nvidia/Nemotron-4-340B-Base # meta-llama/Meta-Llama-3-8B meta-llama/Meta-Llama-3-70B meta-llama/Meta-Llama-3.1-405B
do
  hf download \
  --repo-type model \
  ${repo} \
  --include "*.json" "*.txt" "*.model" "*.yaml" "*.md" "*.py" \
  --exclude "*.safetensors" "*.bin" "*.pt" "*.ckpt" "*.pth" "*.onnx" "*.engine" "*.plan" "*.engine" "*.plan" "*.zip" "*.tar" "*.tar.gz" "*.tgz" "*.7z"
done
uvx auth hf logout
deactivate
mksquashfs huggingface huggingface.squashfs

# ## Method3: Download in container. Not recommended.
# ## Configure squid proxy on bcm head node(10.36.201.200)
# sed -i.ori "/acl localnet src fe80::\/10/aacl localnet src 10.36.201.0\/24" /etc/squid/squid.conf
# systemctl start squid
# 
# mkdir -p /home/cmsupport/workspace/nemo/huggingface
# srun -N 1 --ntasks-per-node=1 --gpus-per-node=1 \
# --container-writable \
# --container-image=/home/cmsupport/workspace/nemo-25.11.sqsh \
# --container-mounts=/home/cmsupport/workspace/nemo/huggingface:/nemo/huggingface \
# bash <<- '__END__'
# cp -ar /root/.cache/huggingface/* /nemo/huggingface/
# export http_proxy=http://10.36.201.200:3128
# export https_proxy=http://10.36.201.200:3128
# export HF_HOME=/nemo/huggingface
# 
# hf auth login --token $YOUR_HF_TOKEN --add-to-git-credential
# hf auth list
# export HF_HUB_OFFLINE=0
# 
# ## Download Qwen3-30B-A3B model from Hugging Face
# #-> ${HF_HOME}/hub/models--Qwen--Qwen3-30B-A3B
# hf download --repo-type model Qwen/Qwen3-30B-A3B
# 
# ## Download DeepSeek-V3-Base model from Hugging Face
# #-> ${HF_HOME}/hub/models--deepseek-ai--DeepSeek-V3-Base
# hf download --repo-type model deepseek-ai/DeepSeek-V3-Base
# 
# cd ${HF_HOME}/hub && ln -sf models--deepseek-ai--DeepSeek-V3-Base models--deepseek-ai--DeepSeek-V3
# 
# ## Download DeepSeek-V3 model from Hugging Face
# #-> ${HF_HOME}/hub/models--deepseek-ai--DeepSeek-V3
# #hf download --repo-type model deepseek-ai/DeepSeek-V3
# __END__
# ## Scatter huggingface cache to all nodes
# cd /home/cmsupport/workspace/nemo
# mksquashfs huggingface huggingface.squashfs
# pdcp -R ssh -w ${NODELIST} <<- EOF
# nohup cp /home/cmsupport/workspace/nemo/huggingface.squashfs /raid/nemo/ &>/dev/null &
# EOF
# #After copy work done, uncompress the huggingface.squashfs on each node
# pdcp -R ssh -w ${NODELIST} <<- EOF
# nohup unsquashfs -f -d /raid/nemo/huggingface /raid/nemo/huggingface.squashfs &>/dev/null &
# EOF
