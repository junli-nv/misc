#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

#SBATCH -p defq
#SBATCH --exclusive
#SBATCH --ntasks-per-node=8
#SBATCH --cpus-per-task=43
#SBATCH --gpus-per-node=8
#SBATCH -N 8

####
# CUDA Graphs is known to be faulty on in nemo:25.11.01, disable it for now.
####

CONT=/raid/nemo-25.11.01.sqsh
GPUMON=0
HUGGINGFACE_CACHE=/home/cmsupport/workspace/nemo/huggingface

module load slurm
cd ${SLURM_SUBMIT_DIR}

echo
echo "NODELIST: ${SLURM_JOB_NODELIST}"
echo

s_time=$(date +%s)
echo "INFO: cleaning work begin"
pdsh -f 64 -R ssh -w ${SLURM_JOB_NODELIST} <<- 'EOF'|dshbak -c
pkill -9 python &>/dev/null || true
ps -ef|grep python|grep -E 'torch|nemo'|grep -v grep || true
rm -f /var/lib/systemd/coredump/* &>/dev/null || true
mount /home
EOF
echo "INFO: cleaning work done"

echo "INFO: checking hardware status"
timeout 100 bash /home/cmsupport/workspace/aihpc_val/tools/hc/sysinfo.sh 2>&1

set -x
ew_nics=(mlx5_0 mlx5_1 mlx5_8 mlx5_9 mlx5_10 mlx5_11 mlx5_12 mlx5_13)
export MELLANOX_VISIBLE_DEVICES=all
export PMIX_MCA_gds=hash
#
#export UCX_TLS=tcp NCCL_IB_DISABLE=1
export UCX_TLS=rc
export UCX_NET_DEVICES="$(echo ${ew_nics[@]}|tr ' ' '\n'|xargs -I {} echo {}:1|paste -s -d',')"
export NCCL_IB_HCA="=$(echo ${ew_nics[@]}|tr ' ' '\n'|xargs -I {} echo {}|paste -s -d',')"
#
eth_nic=bond0
export NCCL_SOCKET_IFNAME=${eth_nic}
export MCA_btl_tcp_if_include=${eth_nic}
export MCA_oob_tcp_if_include=${eth_nic}
export NVTE_UB_SOCKET_IFNAME=${eth_nic}
export GLOO_SOCKET_IFNAME=${eth_nic}
#
export OMPI_ALLOW_RUN_AS_ROOT=1
export OMPI_ALLOW_RUN_AS_ROOT_CONFIRM=1
export OMPI_MCA_btl_openib_warn_default_gid_prefix=0
export OMPI_MCA_coll_hcoll_enable=0
export NCCL_NVLS_ENABLE=1
# export NCCL_P2P_LEVEL=NVL #Let NCCL choose the best P2P level
export NCCL_MIN_CTAS=16
export SLURM_CPU_BIND=none

### IMPORTANT: Then following params affect nemotron perf a lot.
### Comment out firstly, need narrow down later
#export NCCL_IB_ADAPTIVE_ROUTING=1
#export NCCL_IB_SL=1
#export NCCL_IB_QPS_PER_CONNECTION=8
#export NCCL_MIN_NCHANNELS=32

## For SPX
#export NCCL_IB_GID_INDEX=3
#export NCCL_IB_TC=96
#export NCCL_IB_TC=96
#export NCCL_IB_GID_INDEX=3

srun -N ${SLURM_NNODES} --ntasks-per-node=1 enroot remove -f pyxis_nemo &>/dev/null

if [ $GPUMON -eq 1 ]; then
## GPU monitoring during job execution
mkdir -p ${SLURM_SUBMIT_DIR}/${SLURM_JOB_ID}
pdsh -f 64 -R ssh -w ${SLURM_JOB_NODELIST} <<- 'EOF'
kill -9 $(ps -ef|grep gpumon|grep -v grep|awk '{print $2}') &>/dev/null || true
EOF
pdsh -f 64 -R ssh -w ${SLURM_JOB_NODELIST} <<- EOF
nohup bash /home/cmsupport/workspace/aihpc_val/tools/gpumon 5 &> ${SLURM_SUBMIT_DIR}/${SLURM_JOB_ID}/mon-\$(hostname).log &
EOF
fi

# test nccl
srun --export=ALL --cpu-bind=none --mpi=pmix \
--container-name=nemo \
--container-writable \
--container-image=${CONT} \
--container-mounts=/dev:/dev \
all_reduce_perf_mpi -dfloat -b 8 -f 2 -g 1 -e 16G --iters 20
exitcode=$?
if [ $exitcode -ne 0 ]; then
  srun -N ${SLURM_NNODES} --ntasks-per-node=1 enroot remove -f pyxis_nemo &>/dev/null
  exit 1
fi

# generate config files
srun -N ${SLURM_NNODES} --ntasks-per-node=1 --gpus-per-node=1 \
--container-name=nemo \
--container-writable \
--container-image=${CONT} \
--container-mounts=/dev:/dev \
bash <<- '__END__'
set -ex
cat > /usr/local/bin/sbatch <<- 'EOF'
#!/bin/bash
echo "sbatch $@"
EOF
chmod a+x /usr/local/bin/sbatch
cd /opt/NeMo
rm -f scripts/performance/recommended_model_configs/*.csv
export NEMORUN_HOME=/mnt/nemo
rm -rf ${NEMORUN_HOME}
mkdir -p ${NEMORUN_HOME}
## Rule: num_gpus % (ep * et * tp * pp) == 0
python -m scripts.performance.llm.pretrain_qwen3_30b_a3b \
  --account root \
  --partition defq \
  --log_dir ${NEMORUN_HOME} \
  --container_image ${NEMORUN_HOME}/nemo-25.11.sqsh \
  --nemo_home ${NEMORUN_HOME}/experiments \
  --gpu b200 \
  --compute_dtype fp8 --fp8_recipe mxfp8 \
  --num_gpus $[8*${SLURM_NNODES}] \
  -ol 0 \
  -fsdp 0 \
  -tp 1 \
  -pp 1 \
  -cp 1 \
  -ep 8 \
  -vp 1 \
  -et 1 \
  -mb 8 \
  -gb $[512*${SLURM_NNODES}] \
  --gpus_per_node 8 \
  --max_steps 110 || true
find ${NEMORUN_HOME} -name '*_fn_or_script'
CASE=$(find ${NEMORUN_HOME} -name '*_fn_or_script' 2>/dev/null | head -1)
ls -l ${CASE}
__END__
exitcode=$?
if [ $exitcode -ne 0 ]; then
  srun -N ${SLURM_NNODES} --ntasks-per-node=1 enroot remove -f pyxis_nemo &>/dev/null
  exit 1
fi

# run nemo test
srun --export=ALL --cpu-bind=none --mpi=pmix \
--container-name=nemo \
--container-writable \
--container-image=${CONT} \
--container-mounts=/dev:/dev,${HUGGINGFACE_CACHE}:/root/.cache/huggingface \
bash <<- '__END__'
set -ex
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
export NEMORUN_HOME=/mnt/nemo
CASE=$(find ${NEMORUN_HOME} -name '*_fn_or_script' 2>/dev/null | head -1)
ls -l ${CASE}
export CPATH=/usr/local/cuda/include
export TRITON_PTXAS_PATH=/usr/local/cuda/bin/ptxas
export TRITON_LIB_DIR=/usr/local/cuda/lib64
export TORCH_NCCL_AVOID_RECORD_STREAMS=1
export TRANSFORMERS_OFFLINE=1
export TOKENIZERS_PARALLELISM=False
export NCCL_NVLS_ENABLE=0
export NVTE_FLASH_ATTN=1
export NVTE_FUSED_ATTN=1
export NEMO_LOG_MEMORY_USAGE=1
export NEMO_HOME=${NEMORUN_HOME}
export CUDA_DEVICE_MAX_CONNECTIONS=32
export NVTE_FWD_LAYERNORM_SM_MARGIN=16
export NVTE_BWD_LAYERNORM_SM_MARGIN=16
export NCCL_P2P_NET_CHUNKSIZE=2097152
export TORCH_NCCL_HIGH_PRIORITY=1
export NCCL_DEBUG=INFO
python -m nemo_run.core.runners.fdl_runner -n $(basename ${CASE}|sed -e 's:_fn_or_script::g') ${CASE} 2>&1 | tee log.txt
__END__

srun -N ${SLURM_NNODES} --ntasks-per-node=1 enroot remove -f pyxis_nemo &>/dev/null
set +x

e_time=$(date +%s)
echo "INFO: timelimit=$[(SLURM_JOB_END_TIME-SLURM_JOB_START_TIME)](s), real_took=$[e_time-s_time](s)"

if [ $GPUMON -eq 1 ]; then
## Kill the gpumon process after job done
mkdir -p ${SLURM_SUBMIT_DIR}/${SLURM_JOB_ID}
pdsh -f 64 -R ssh -w ${SLURM_JOB_NODELIST} <<- 'EOF'
kill -9 $(ps -ef|grep gpumon|grep -v grep|awk '{print $2}') &>/dev/null || true
EOF
fi