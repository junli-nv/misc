#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

#SBATCH -p defq
#SBATCH --exclusive
#SBATCH --ntasks-per-node=8
#SBATCH --cpus-per-task=28
#SBATCH --gpus-per-node=8
#SBATCH --time=00:30:00
#SBATCH -N 16

####
# This script is customized for DGX B200.
# To align with Nemo tracker, CUDA Graphs be in this script.
## Known issue:
# 8xB200(64 GPUs totally) will met OOM. Disable CUDA Graphs will help.
# Nemo framework's CUDA Graphs is faulty in nemo:25.11.01, disable CUDA Graphs or use MBrige framework instead.
####

#CONT=/home/cmsupport/workspace/nemo-25.11.01.sqsh
CONT=/home/cmsupport/workspace/nemo-25.04.rc2.m2.sqsh

module load slurm
cd ${SLURM_SUBMIT_DIR}

echo
echo "NODELIST: ${SLURM_JOB_NODELIST}"
echo

s_time=$(date +%s)
echo "INFO: cleaning work begin"
pdsh -f 64 -R ssh -w ${SLURM_JOB_NODELIST} <<- 'EOF'|dshbak -c
pkill -9 python &>/dev/null || true
ps -ef|grep python|grep -E 'torch|nemo'|grep -v grep || true
rm -f /var/lib/systemd/coredump/* &>/dev/null || true
mount /home
EOF
echo "INFO: cleaning work done"

echo "INFO: checking hardware status"
pdsh -t 3 -u 3 -R ssh -f 36 -w $SLURM_NODELIST  <<- 'EOF' | dshbak -c
nvidia-smi -L|wc -l
nvidia-smi nvlink -s|grep [0-9].*GB|wc -l
ibstatus|grep -E 'Infiniband|state:'|paste - - -|grep roce|tr -s ' '
EOF

set -x
ew_nics=(mlx5_4 mlx5_7 mlx5_8 mlx5_9 mlx5_10 mlx5_13 mlx5_14 mlx5_15)
export MELLANOX_VISIBLE_DEVICES=all
export PMIX_MCA_gds=hash
#
#export UCX_TLS=tcp NCCL_IB_DISABLE=1
export UCX_TLS=rc
export UCX_NET_DEVICES="$(echo ${ew_nics[@]}|tr ' ' '\n'|xargs -I {} echo {}:1|paste -s -d',')"
export NCCL_IB_HCA="=$(echo ${ew_nics[@]}|tr ' ' '\n'|xargs -I {} echo {}|paste -s -d',')"
#
eth_nic=bond0
export NCCL_SOCKET_IFNAME=${eth_nic}
export MCA_btl_tcp_if_include=${eth_nic}
export MCA_oob_tcp_if_include=${eth_nic}
export NVTE_UB_SOCKET_IFNAME=${eth_nic}
export GLOO_SOCKET_IFNAME=${eth_nic}
#
export OMPI_ALLOW_RUN_AS_ROOT=1
export OMPI_ALLOW_RUN_AS_ROOT_CONFIRM=1
export OMPI_MCA_btl_openib_warn_default_gid_prefix=0
export OMPI_MCA_coll_hcoll_enable=0
export NCCL_NVLS_ENABLE=1
export NCCL_P2P_LEVEL=NVL
export NCCL_MIN_CTAS=16
export SLURM_CPU_BIND=none

### IMPORTANT: Then following params affect nemotron perf a lot.
### Comment out firstly, need narrow down later
#export NCCL_IB_ADAPTIVE_ROUTING=1
#export NCCL_IB_SL=1
#export NCCL_IB_QPS_PER_CONNECTION=8
#export NCCL_MIN_NCHANNELS=32

srun -N ${SLURM_NNODES} --ntasks-per-node=1 enroot remove -f pyxis_nemo &>/dev/null

# test nccl
srun --export=ALL --cpu-bind=none --mpi=pmix \
--container-name=nemo \
--container-writable \
--container-image=${CONT} \
--container-mounts=/dev:/dev \
all_reduce_perf_mpi -dfloat -b 8 -f 2 -g 1 -e 16G --iters 20
exitcode=$?
if [ $exitcode -ne 0 ]; then
  srun -N ${SLURM_NNODES} --ntasks-per-node=1 enroot remove -f pyxis_nemo &>/dev/null
  exit 1
fi

# generate config files
srun -N ${SLURM_NNODES} --ntasks-per-node=1 --gpus-per-node=1 \
--container-name=nemo \
--container-writable \
--container-image=${CONT} \
--container-mounts=/dev:/dev \
bash <<- '__END__'
set -ex
cat > /usr/local/bin/sbatch <<- 'EOF'
#!/bin/bash
echo "sbatch $@"
EOF
chmod a+x /usr/local/bin/sbatch
cd /opt/NeMo
rm -f scripts/performance/recommended_model_configs/*.csv
export NEMORUN_HOME=/mnt/nemo
rm -rf ${NEMORUN_HOME}
mkdir -p ${NEMORUN_HOME}
## Rule: num_gpus % (ep * et * tp * pp) == 0
python -m scripts.performance.llm.pretrain_nemotron4_340b \
  --account root \
  --partition defq \
  --log_dir ${NEMORUN_HOME} \
  --container_image ${NEMORUN_HOME}/nemo-25.04.rc2.m2.sqsh \
  --nemo_home ${NEMORUN_HOME}/experiments \
  --gpu b200 \
  --compute_dtype bf16 \
  --num_gpus $[8*${SLURM_NNODES}] \
  -tp 8 \
  -pp 4 \
  -cp 1 \
  -ep 1 \
  -vp 12 \
  -mb 1 \
  -gb $[8*${SLURM_NNODES}/4] \
  -cg \
  --gpus_per_node 8 \
  --max_steps 100
find ${NEMORUN_HOME} -name '*_fn_or_script'
CASE=$(find ${NEMORUN_HOME} -name '*_fn_or_script' 2>/dev/null | head -1)
ls -l ${CASE}
__END__
exitcode=$?
if [ $exitcode -ne 0 ]; then
  srun -N ${SLURM_NNODES} --ntasks-per-node=1 enroot remove -f pyxis_nemo &>/dev/null
  exit 1
fi

# run nemo test
export PYTHONUNBUFFERED=1
export SLURM_UNBUFFEREDIO=1
export TORCHX_MAX_RETRIES=0
nodes=( $( scontrol show hostnames $SLURM_JOB_NODELIST ) )
nodes_array=($nodes)
head_node=${nodes_array[0]}
head_node_ip=$(srun --nodes=1 --ntasks=1 -w "$head_node" hostname --ip-address)
export TORCH_NCCL_AVOID_RECORD_STREAMS=1
export TRANSFORMERS_OFFLINE=1
export TOKENIZERS_PARALLELISM=False
export NVTE_FLASH_ATTN=1
export NVTE_FUSED_ATTN=1
export NEMO_LOG_MEMORY_USAGE=1
#export NVTE_NORM_FWD_USE_CUDNN=1
#export NVTE_NORM_BWD_USE_CUDNN=1
export CUDA_DEVICE_MAX_CONNECTIONS=32
export NVTE_FWD_LAYERNORM_SM_MARGIN=16
export NVTE_BWD_LAYERNORM_SM_MARGIN=16
export NCCL_P2P_NET_CHUNKSIZE=2097152
export NCCL_DEBUG=INFO
srun --export=ALL --cpu-bind=none --mpi=pmix \
--container-name=nemo \
--container-writable \
--container-image=${CONT} \
--container-mounts=/dev:/dev \
bash <<- '__END__'
set -ex
export NEMORUN_HOME=/mnt/nemo
export NEMO_HOME=${NEMORUN_HOME}
CASE=$(find ${NEMORUN_HOME} -name '*_fn_or_script' 2>/dev/null | head -1)
ls -l ${CASE}
export CPATH=/usr/local/cuda/include
export TRITON_PTXAS_PATH=/usr/local/cuda/bin/ptxas
export TRITON_LIB_DIR=/usr/local/cuda/lib64
numactl --cpunodebind=$[SLURM_LOCALID/4] --membind=$[SLURM_LOCALID/4] \
python -m nemo_run.core.runners.fdl_runner -n $(basename ${CASE}|sed -e 's:_fn_or_script::g') ${CASE} 2>&1 | tee log.txt
__END__

srun -N ${SLURM_NNODES} --ntasks-per-node=1 enroot remove -f pyxis_nemo &>/dev/null
set +x

e_time=$(date +%s)
echo "INFO: timelimit=$[(SLURM_JOB_END_TIME-SLURM_JOB_START_TIME)](s), real_took=$[e_time-s_time](s)"
