#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

## Method1: download the pre-packed huggingface cache repos. Recommended.
wget -c https://github.com/junli-nv/misc/raw/refs/heads/main/huggingface.squashfs
unsquashfs -f -d /home/cmsupport/workspace/nemo/huggingface huggingface.squashfs
## When shared via NFS, make sure the directory is writable as nemo will create some file like .megatron_config_lock_xxxxx.lock in it.

## Method2: download the model on bare metal
curl -LsSf https://astral.sh/uv/install.sh | sh
source $HOME/.local/bin/env bash
cd /local/nemo/
export HF_HOME=$PWD/huggingface
uv venv --python 3.12.0
source .venv/bin/activate
uvx hf
uvx hf auth login --token $HF_TOKEN --add-to-git-credential
uvx hf auth list
export HF_HUB_OFFLINE=0
# https://gitlab-master.nvidia.com/unified-cloud-benchmarking/llm-benchmarking-collection-internal/-/blob/dev/cli/llmb-install/src/llmb_install/downloads/huggingface.py
for repo in deepseek-ai/DeepSeek-V3 Qwen/Qwen3-235B-A22B Qwen/Qwen3-30B-A3B nvidia/Nemotron-4-340B-Base # meta-llama/Meta-Llama-3-8B meta-llama/Meta-Llama-3-70B meta-llama/Meta-Llama-3.1-405B
do
  hf download \
  --repo-type model \
  ${repo} \
  --include "*.json" "*.txt" "*.model" "*.yaml" "*.md" "*.py" \
  --exclude "*.safetensors" "*.bin" "*.pt" "*.ckpt" "*.pth" "*.onnx" "*.engine" "*.plan" "*.engine" "*.plan" "*.zip" "*.tar" "*.tar.gz" "*.tgz" "*.7z"
done
uvx auth hf logout
deactivate
mksquashfs huggingface huggingface.squashfs

# ## Method3: Download in container. Not recommended.
# mkdir -p /local/enroot/{data,runtime}
# export ENROOT_DATA_PATH=/local/enroot/data/$(id -u)
# export ENROOT_RUNTIME_PATH=/local/enroot/runtime/$(id -u)
# enroot remove -f nemo
# enroot create -n nemo /local/nemo/nemo-25.11.01.sqsh
# enroot list -f
# mkdir -p /local/nemo/huggingface
# enroot start -w -e HF_TOKEN=$YOUR_HF_TOKEN -m /local/nemo:/local/nemo nemo \
# bash <<- '__END__'
# export HF_HOME=/local/nemo/huggingface/
# mv /root/.cache/huggingface/* $HF_HOME/
# hf auth login --token $HF_TOKEN --add-to-git-credential
# hf auth list
# export HF_HUB_OFFLINE=0
# ## Download DeepSeek-V3-Base model from Hugging Face
# #-> ${HF_HOME}/hub/models--deepseek-ai--DeepSeek-V3-Base
# hf download --repo-type model deepseek-ai/DeepSeek-V3-Base
# cd ${HF_HOME}/hub && ln -sf models--deepseek-ai--DeepSeek-V3-Base models--deepseek-ai--DeepSeek-V3
# __END__
# cd /local/nemo/
# mksquashfs huggingface huggingface.squashfs
