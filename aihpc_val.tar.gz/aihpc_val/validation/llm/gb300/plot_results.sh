#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>
# apt install -y gnuplot-nox

# SACCT_FORMAT="User,JobID,Start,End,Elapsed,AllocNodes,WorkDir%30,NodeList%100" sacct -j ${JOBID}
logs=($@)
for i in ${logs[*]}; do
echo $i
cat $i | grep -o 'Step Time.*MODEL_TFLOP/s/GPU' $1|sed -e 's:s GPU: s GPU:g' -e 's:MODEL_TFLOP: MODEL_TFLOP:g' |awk '{print $4}' \
  | gnuplot -e "set title '$(basename $i|tr '_' '+')'; set term dumb size 300,50; set yrange [0:10]; set ytics 0.5; plot '-' with linespoints" 2>/dev/null
done
