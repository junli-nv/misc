#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>
#
#SBATCH -p defq
#SBATCH --exclusive
#SBATCH --ntasks-per-node=4
#SBATCH --cpus-per-task=36
#SBATCH --gpus-per-node=4
#SBATCH --time=00:08:00
#SBATCH -N 1
#SBATCH -o %u-cublasMatmulBench-%N-%j.txt

module load slurm
cd ${SLURM_SUBMIT_DIR}

echo
echo "NODELIST: ${SLURM_JOB_NODELIST}"
echo

source /home/cmsupport/workspace/cuda13/env.sh

## https://apps.nvidia.com/pid/contentlibraries/detail?id=1149366
bin=./cublasMatmulBench

ga=( 0 1 2 3 )
ma=( 0 0 1 1 )
ca=( 0-35 36-71 72-107 108-143 )

ret=($(nvidia-smi -i 0 --query-supported-clocks=mem,gr --format=csv | head -n 2 | tail -n 1 | awk '{print $1, $3}'))
nvidia-smi -ac ${ret[0]},${ret[1]}
nvidia-smi -lgc ${ret[1]},${ret[1]}
# nvidia-smi -lmc ${ret[0]}
sleep 1
t0=$(date +%s)
set -ex
nvidia-smi --format=csv --query-gpu gpu_bus_id,gpu_name,compute_mode,ecc.mode.current,clocks.gr,clocks.max.gr,clocks.sm,clocks.max.sm,clocks.max.mem,clocks.video,clocks.applications.gr,clocks.applications.mem,clocks.default_applications.gr,clocks.default_applications.mem,pstate,power.default_limit
ldd ${bin}
pids=""
for d in ${ga[@]}; do
  (
  export CUDA_VISIBLE_DEVICES=${d}
  timeout 300 \
  numactl -C${ca[d]} -m ${ma[d]} \
  ${bin} -P=qqssq -m=8192 -n=9472 -k=16384 -ta=1 -tb=0 -A=1 -B=0 -T=200000 -W=150000 -p=t \
    | tee /tmp/cublasMatmulBench-$(hostname)-${d}.log
  ) & pids="$pids $!"
done
wait $pids
set +x
t1=$(date +%s)
nvidia-smi -rac
nvidia-smi -rgc
# nvidia-smi -rmc

printf "\n==== cublasMatmulBench results ====\n"
perfs=()
for d in ${ga[@]}; do
  p=$(grep CUDA.*Gflops /tmp/cublasMatmulBench-$(hostname)-${d}.log|awk '{print int($NF/1000)}')
  [ -z "$p" ] && p=0
  perfs+=($p)
done
min=$(printf "%d\n" "${perfs[@]}" | sort -n | head -1)
max=$(printf "%d\n" "${perfs[@]}" | sort -n | tail -1)
echo "INFO[NODE]: $(hostname)"
echo "INFO[EachGPU]: ${perfs[@]}"
echo "INFO[MIN]: ${min} Tflops"
echo "INFO[MAX]: ${max} Tflops"
echo "INFO[VARI]: $((100 * (max - min) / max)) %"
echo "INFO[ElapsedTime]: $((t1 - t0)) seconds"
rm -f  /tmp/cublasMatmulBench-$(hostname)-*.log
printf "==== End of cublasMatmulBench ====\n"

# scontrol show hostname $(sinfo -al|grep 'idle '|awk '{print $NF}')|while read i; do sbatch -w $i -o CB-%N-%j.txt ./cublasMatmulBench.sh; done
