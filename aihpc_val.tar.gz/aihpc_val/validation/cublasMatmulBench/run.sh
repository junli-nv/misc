#!/bin/bash
#

module load slurm
reservation=ROWC
hosts=(
#$(scontrol show hostname $(sinfo -al|grep 'idle '|awk '{print $NF}'))
$(scontrol show hostname $(sinfo -al|grep "reserved .*${reservation}"|awk '{print $NF}'))
)
mkdir -p ${reservation}
for h in ${hosts[*]}
do
  sbatch \
    -N 1 \
    -w "${h}" \
    -t 10:00 \
    --job-name=cublasMatmulBench-${h} \
    --output=${reservation}/${USER}-cublasMatmulBench-${h}-%j.txt \
    cublasMatmulBench.sh
done
