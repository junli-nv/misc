#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

for i in *.txt; do
echo $i $(grep EachGPU $i|awk -F':' '{print $NF}')
done | sort -k2nr | tail -n 30

for i in *.txt; do
  node=$(grep NODELIST $i|awk -F':' '{print $NF}')
  ret=$(grep EachGPU $i|awk -F':' '{print $NF}')
  [ -z "$ret" ] && ret='0 0 0 0'
  printf "%20s%10s%10s%10s%10s\n" "$node" $ret
done

for i in *.txt; do
  ret=$(grep EachGPU $i|awk -F':' '{print $NF}')
  [ -z "$ret" ] && echo '0 0 0 0' || echo $ret
done \
 | awk '{print $NF}' \
 | gnuplot -e "set term dumb size 300,50; set yrange [2000:*]; plot '-' with linespoints"
