#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

if [ $# -lt 1 ]; then
  echo "Usage: $(basename $0) logdir"
  exit 0
fi
logdir=$1
cd $logdir

for i in *.txt; do
 #awk '/^{/,/^}/{print $0}' $i|grep -Ev 'INFO|^\+'|jq -r '."DCGM Diagnostic".test_categories[].tests[]|"\(.name),\(.results[])"'| grep -i Fail|sort|tr '\n' '\0' |xargs -0 -I {} echo "$logdir/$i:{}"
 jq -r '
  .["DCGM Diagnostic"].test_categories[]
  | .category as $a
  | .tests[]
  | .name as $b
  | .test_summary.status as $c
  | select( $c == "Fail")
  | (.test_summary.warnings[]?.warning // "No warning") as $d
  | .results[]
  | "\($a),\($b)=\($c),GPU\(.entity_id)=\(.status),\($d)"
' < <(awk '/^{/,/^}/{print $0}' "$i"|grep -Ev 'INFO|^\+')|sort|tr '\n' '\0' |xargs -0 -I {} echo "$logdir/$i:{}"
done 

 
