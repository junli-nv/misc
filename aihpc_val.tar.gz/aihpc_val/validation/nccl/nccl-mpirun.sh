#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

#SBATCH -p defq
#SBATCH --exclusive
#SBATCH --ntasks-per-node=4
#SBATCH --cpus-per-task=36
#SBATCH --gpus-per-node=4

echo NODELIST=$SLURM_JOB_NODELIST
cd $SLURM_SUBMIT_DIR
source /home/cmsupport/workspace/aihpc_val/validation/envs/global_env.sh
timeout 100 bash /home/cmsupport/workspace/aihpc_val/tools/hc/sysinfo.sh 2>&1

hosts=($(scontrol show hostname $SLURM_JOB_NODELIST))

set -x
ldd `which all_reduce_perf`
ns_nic=bond0
ew_nics=($(echo mlx5_{0..3}))
mpirun --allow-run-as-root \
  --mca pml ucx --mca coll ^hcoll --mca btl ^openib,smcuda \
  --map-by ppr:2:socket:PE=36 \
  --display-map --display-topo --report-bindings \
  -x PATH=$PATH \
  -x LD_LIBRARY_PATH=$LD_LIBRARY_PATH \
\
  -x UCX_TLS=rc \
  -x UCX_NET_DEVICES="$(echo ${ew_nics[@]}|tr ' ' '\n'|xargs -I {} echo {}:1|paste -s -d',')" \
  -x NCCL_IB_HCA="=$(echo ${ew_nics[@]}|tr ' ' '\n'|xargs -I {} echo {}|paste -s -d',')" \
  -x NCCL_SOCKET_IFNAME=${ns_nic} \
  -x OMPI_MCA_btl_tcp_if_include=${ns_nic} \
  -x OMPI_MCA_oob_tcp_if_include=${ns_nic} \
  -x OMPI_ALLOW_RUN_AS_ROOT=1 \
  -x OMPI_ALLOW_RUN_AS_ROOT_CONFIRM=1 \
  -x OMPI_MCA_btl_openib_warn_default_gid_prefix=0 \
  -x OMPI_MCA_coll_hcoll_enable=0 \
  -x SLURM_CPU_BIND=none \
  -x NCCL_DEBUG=INFO \
  -x NCCL_NVLS_ENABLE=1 \
  -x NCCL_MNNVL_ENABLE=1 \
  -x NCCL_MIN_CTAS=16 \
  -x NCCL_RUNTIME_CONNECT=0 \
  -x NCCL_IB_QPS_PER_CONNECTION=2 \
  -x CUDA_MODULE_LOADING=EAGER \
  -x NCCL_P2P_NET_CHUNKSIZE=262144 \
\
  -H $(for i in ${hosts[*]}; do echo ${i}:4; done|paste -s -d ',') \
  -np $[4*${#hosts[*]}] \
  `which all_reduce_perf` -b 16G -f 2 -g 1 -e 16G --iters 50
set +x
