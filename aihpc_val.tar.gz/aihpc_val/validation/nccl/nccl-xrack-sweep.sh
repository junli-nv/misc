#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

export PDSH_SSH_ARGS_APPEND="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=quiet -o CheckHostIP=no -o PreferredAuthentications=publickey"

need_validate_nodes=(
#RowA
p1-r01-ct[01-18],p1-r02-ct[01-18],p1-r03-ct[01-18],p1-r04-ct[01-18]
p2-r05-ct[01-18],p2-r06-ct[01-18],p2-r07-ct[01-18],p2-r08-ct[01-18]
p3-r15-ct[01-18],p3-r16-ct[01-18],p3-r17-ct[01-18],p3-r18-ct[01-18]
p4-r19-ct[01-18],p4-r20-ct[01-18],p4-r21-ct[01-18],p4-r22-ct[01-18]
##RowB
#p5-r01-ct[01-18],p5-r02-ct[01-18],p5-r03-ct[01-18],p5-r04-ct[01-18]
#p6-r05-ct[01-18],p6-r06-ct[01-18],p6-r07-ct[01-18],p6-r08-ct[01-18]
#p7-r15-ct[01-18],p7-r16-ct[01-18],p7-r17-ct[01-18],p7-r18-ct[01-18]
#p8-r19-ct[01-18],p8-r20-ct[01-18],p8-r21-ct[01-18],p8-r22-ct[01-18]
##RowC
#p9-r01-ct[01-18],p9-r02-ct[01-18],p9-r03-ct[01-18],p9-r04-ct[01-18]
#p10-r05-ct[01-18],p10-r06-ct[01-18],p10-r07-ct[01-18],p10-r08-ct[01-18]
#p11-r15-ct[01-18],p11-r16-ct[01-18],p11-r17-ct[01-18],p11-r18-ct[01-18]
#p12-r19-ct[01-18],p12-r20-ct[01-18],p12-r21-ct[01-18],p12-r22-ct[01-18]
##RowD
#p13-r01-ct[01-18],p13-r02-ct[01-18],p13-r03-ct[01-18],p13-r04-ct[01-18]
#p14-r05-ct[01-18],p14-r06-ct[01-18],p14-r07-ct[01-18],p14-r08-ct[01-18]
#p15-r15-ct[01-18],p15-r16-ct[01-18],p15-r17-ct[01-18],p15-r18-ct[01-18]
#p16-r19-ct[01-18],p16-r20-ct[01-18],p16-r21-ct[01-18],p16-r22-ct[01-18]
)
scontrol create reservation=junli_val nodes=$(scontrol show hostname $(echo ${need_validate_nodes[*]}|tr ' ' ',')|paste -s -d ',') starttime=now duration=7- users=root flags=flex,overlap,magnetic

known_bad_nodes=(
##OPENSM
p1-r01-ct01
#NVLINK issue
p2-r05-ct08
p2-r07-ct18
p2-r08-ct01
#Xid errors
p3-r18-ct02 #Xid154
### in provisioning
p2-r08-ct08
## NFS not mounted
#p3-r18-ct17
#p3-r18-ct18
## mount /home && mount /cm/shared && systemctl restart cmd.service && sleep 3 && systemctl restart munge.service && sleep 3 && systemctl restart slurmd.service 
)

pdsh -f 100 -R ssh -w $(scontrol show hostname $(echo ${need_validate_nodes[*]}|tr ' ' ',')|paste -s -d ',') -x $(scontrol show hostname $(echo ${known_bad_nodes[*]}|tr ' ' ',')|paste -s -d ',') <<- 'EOF'|dshbak -c
mount|grep /cm/node-installer||true
EOF

## Clear the ib counters
pdsh -f 100 -R ssh -w $(scontrol show hostname $(echo ${need_validate_nodes[*]}|tr ' ' ',')|paste -s -d ',') -x $(scontrol show hostname $(echo ${known_bad_nodes[*]}|tr ' ' ',')|paste -s -d ',') <<- 'EOF'|dshbak -c
lspci -D | grep -i Infiniband | awk '{print $1}'|xargs -I {} mlxlink -d {} -pc &>/dev/null||true
EOF

## Filter the nodes without issues, find out the bad nodes.
pdsh -f 100 -R ssh -w $(scontrol show hostname $(echo ${need_validate_nodes[*]}|tr ' ' ',')|paste -s -d ',') -x $(scontrol show hostname $(echo ${known_bad_nodes[*]}|tr ' ' ',')|paste -s -d ',') <<- 'EOF'|dshbak -c
bash /home/cmsupport/workspace/aihpc_val/tools/hc/checker.sh -e 1
EOF

pdsh -f 100 -R ssh -w $(scontrol show hostname $(echo ${need_validate_nodes[*]}|tr ' ' ',')|paste -s -d ',') -x $(scontrol show hostname $(echo ${known_bad_nodes[*]}|tr ' ' ',')|paste -s -d ',') <<- 'EOF'|dshbak -c
dmesg|grep Xid.*149|wc -l
EOF

pdsh -f 100 -R ssh -w $(scontrol show hostname $(echo ${need_validate_nodes[*]}|tr ' ' ',')|paste -s -d ',') -x $(scontrol show hostname $(echo ${known_bad_nodes[*]}|tr ' ' ',')|paste -s -d ',') <<- 'EOF'|dshbak -c
grep -e 'Bonding Mode' -e 'Slave Interface' /proc/net/bonding/bond0|sort|paste -s -d ','
ethtool bond0|grep Speed:
ls /sys/class/infiniband|sort|paste -s -d','
lspci -D | grep -i Ethernet.*BlueField-3 | awk '{print $1}'|xargs -I {} mlxconfig -d {} -e q INTERNAL_CPU_OFFLOAD_ENGINE|grep -e Device: -e Configurations: -e INTERNAL_CPU_OFFLOAD_ENGINE
EOF
#lspci -D | grep -i Ethernet.*BlueField-3 | awk '{print $1}'|xargs -I {} mlxconfig -d {} -e -y set INTERNAL_CPU_OFFLOAD_ENGINE=1

pdsh -f 100 -R ssh -w $(scontrol show hostname $(echo ${need_validate_nodes[*]}|tr ' ' ',')|paste -s -d ',') -x $(scontrol show hostname $(echo ${known_bad_nodes[*]}|tr ' ' ',')|paste -s -d ',') <<- 'EOF'|dshbak -c
uname -r
cat /proc/cmdline | tr ' ' '\n'|grep -v -E 'ip=|BOOT' | sort | paste -s -d ' '
EOF

nodelist=p1-r01-ct[01-04,06-18],p1-r02-ct[01-18],p1-r03-ct[01-04,06-18],p1-r04-ct[01-18],p2-r05-ct[01-18],p2-r06-ct[01-18],p2-r07-ct[01-18],p2-r08-ct[01-18],p3-r15-ct[01-18],p3-r16-ct[01-18],p3-r17-ct[01-18],p3-r18-ct[01,03-18],p4-r19-ct[01-18],p4-r20-ct[01-18],p4-r21-ct[01-18],p4-r22-ct[01-18],p5-r01-ct[01-17],p5-r02-ct[01-18],p5-r03-ct[01-18],p5-r04-ct[01-18],p6-r05-ct[01-18],p6-r06-ct[01-04,06-18],p6-r07-ct[01-18],p6-r08-ct[01-18],p7-r15-ct[01-18],p7-r16-ct[01-18],p7-r17-ct[01-18],p7-r18-ct[01,03-18],p8-r19-ct[01-18],p8-r20-ct[01-18],p8-r21-ct[01-18],p8-r22-ct[01-06,08-18],p9-r01-ct[01-18],p9-r02-ct[01-18],p9-r03-ct[01-18],p9-r04-ct[01-18],p10-r05-ct[01-05,07,09-18],p10-r06-ct[01-03,05-07,09-18],p10-r07-ct[01-18],p10-r08-ct[01-02,04-08,10-18],p11-r15-ct[01-18],p11-r16-ct[01-18],p11-r17-ct[01-18],p11-r18-ct[01-18],p12-r19-ct[01-11,13-18],p12-r20-ct[01-18],p12-r21-ct[01-12,14-18],p12-r22-ct[01-11,13-18],p13-r01-ct[01-18],p13-r02-ct[01-18],p13-r03-ct[01-18],p13-r04-ct[01-11,13-18],p14-r05-ct[01-18],p14-r06-ct[01-03,05-18],p14-r07-ct[01-09,11-18],p14-r08-ct[01-18],p15-r15-ct[01-05,07-18],p15-r16-ct[01-18],p15-r17-ct[01-18],p15-r18-ct[01-18],p16-r19-ct[01-18],p16-r20-ct[01-18],p16-r21-ct[01-18],p16-r22-ct[01-02,04-18]

pdsh -f 100 -R ssh -w $nodelist <<- 'EOF'|dshbak -c
sudo kill -9 $(nvidia-smi --query-compute-apps=pid --format=csv,noheader,nounits) &>/dev/null || true
find /cm/local/apps/slurm/var/pre-post-job-logs -type f -exec rm -f {} \;
bash /home/cmsupport/workspace/aihpc_val/tools/hc/ibcounter.sh clear
bash /home/cmsupport/workspace/aihpc_val/tools/hc/checker.sh -e 1
EOF

pdsh -f 100 -R ssh -w $nodelist <<- 'EOF'|dshbak -c
uname -r
cat /proc/cmdline | tr ' ' '\n'|grep -v -E 'ip=|BOOT' | sort | paste -s -d ' '
EOF

a=(
$(echo $nodelist|sed 's:],:] :g')
)

scontrol show node $(echo ${a[*]}|tr ' ' ',') |grep -E 'NodeName|CfgTRES='|paste - -|sed -e 's# Arch=#:Arch=#g' -e 's#NodeName=##g' |dshbak -c

#scontrol update nodename=$(echo ${a[*]}|tr ' ' ',') stat=undrain
scontrol show node $(echo ${a[*]}|tr ' ' ',') |grep -E 'NodeName|State'|paste - -|grep -o State.*|sort|uniq -c

## 1N test
for i in $(scontrol show hostname $(echo ${a[*]}|tr ' ' ',')); do
  sbatch --reservation=nvis \
    -N 1 \
    -w $i\
    -t 10:00 \
    --job-name=NCCL-1N \
    --output=${USER}-NCCL-1N-%N-%j.txt \
    nccl.sbatch
done

for i in $(ls -1rth *-NCCL-1N-*.txt); do
  printf "%30s%20s%10s\n" $i $(grep 17179869184.*float $i|awk '{print $8}') $(grep 'Out of bounds values' $i|awk '{print $NF}')
done|sort -k2nr|tee nccl-1n.log
grep -v OK nccl-1n.log

for i in $(scontrol show hostname $(echo ${a[*]}|tr ' ' ',')); do
  sbatch --reservation=nvis \
    -N 1 \
    -w $i\
    -t 10:00 \
    --job-name=NCCL-1N \
    --output=${USER}-NCCL-LOOPBACK-1N-%N-%j.txt \
    nccl-loopback.sbatch
done

for i in $(ls -1rth *-NCCL-LOOPBACK-1N-*.txt); do
  printf "%30s%20s%10s\n" $i $(grep 17179869184.*float $i|awk '{print $8}') $(grep 'Out of bounds values' $i|awk '{print $NF}')
done|sort -k2nr|tee nccl-loopback-1n.log

## Per rack test
for r in ${a[*]}
do
  rack=$(echo $r|cut -f1-2 -d'-')
  hosts=($(scontrol show hostname $r))
  #cat <<- EOF
  #for loop in {0..4}; do
  sbatch --reservation=nvis \
    -N ${#hosts[*]} \
    -w $(echo "${hosts[*]}"|tr ' ' ',') \
    -t 10:00 \
    --job-name=NCCL-1R \
    --output=${USER}-NCCL-1Rack-${rack}-${#hosts[*]}N-%j.txt \
    nccl.sbatch
  #done
#EOF
done

plog-1rack(){
printf "%20s%10s%20s%20s%20s%20s%20s\n"  RACK "Loop#" "MAX(GB/S)" "MIN(GB/s)" "AVG(GB/s)" "Vari(%)"
racks=($(ls -1 *-NCCL-1Rack-*.txt|cut -f4-5 -d'-'|sort|uniq))
for i in ${racks[*]}; do
  ret=($(grep -H 17179.*float *-NCCL-1Rack-*${i}*.txt|awk '{print $9}'|sort -nr))
  if [ ${#ret[*]} -gt 0 ]; then
    avg=$(echo ${ret[*]}|tr ' ' '\n'|awk 'BEGIN{sum=0}{sum+=$1}END{printf("%.2f\n", sum/NR)}')
    vari=$(echo | awk '{printf("%.2f\n", 100*(1-a/b))}' a=${ret[-1]} b=${ret[0]})
    printf "%20s%10s%20s%20s%20s%20s%20s\n" ${i} ${#ret[*]} ${ret[0]} ${ret[-1]} ${avg} ${vari}
  else
    printf "%20s%10s%20s%20s%20s%20s%20s\n" ${i} "N/A" "N/A" "N/A" "N/A" "N/A"
  fi
done
}
plog-1rack | tee plog-1rack.log

## Step Racks Test
step=2
rm -f *-NCCL-${step}R-*.txt
i=0; while [ $i -lt ${#a[*]} ]; do
  s0=$[i+1]
  s1=$[i+step]
  hosts=($(scontrol show hostname $(echo ${a[*]} ${a[*]}|cut -f${s0}-${s1} -d ' '|tr ' ' ',')))
  racks=($(echo ${hosts[*]}|tr ' ' '\n'|cut -f1-2 -d '-'|sort|uniq))
  #n=$[${#hosts[*]}/2*2]
  n=${#hosts[*]}
  #cat <<- EOF
  sbatch --reservation=nvis \
      -N ${n} \
      -w $(echo "${hosts[*]}"|tr ' ' ',') \
      -t 3:00:00 \
      --job-name=NCCL-${step}R \
      --output=${USER}-NCCL-${#racks[*]}R-$(echo ${racks[*]}|tr ' ' -d'_')-${n}N-%j.txt \
      nccl-mpirun.sh
#EOF
  i=${s1}
done
for i in $(ls -1rth *-NCCL-${step}R-*.txt); do
  printf "%30s%20s%10s\n" $i $(grep 17179869184.*float $i|awk '{print $8}') $(grep 'Out of bounds values' $i|awk '{print $NF}')
done|sort -k2nr|tee plog-${step}rack.log

## Cross rack test - segment test
max=16
hosts=($(
for i in ${a[*]}; do
  tmp_hosts=($(scontrol show hostname ${i}))
  if [ ${#tmp_hosts[*]} -ge ${max} ]; then
    echo ${tmp_hosts[*]}|cut -f1-${max} -d' '
    #echo ${tmp_hosts[*]}|tr ' ' '\n'|tac|paste -s -d' '|cut -f1-${max} -d' '
  else
    continue
  fi
done
))
echo ${#hosts[*]}
echo ${hosts[*]}
racks=($(echo ${hosts[*]}|tr ' ' '\n'|cut -d'-' -f1-2|sort|uniq))
sbatch --reservation=nvis \
  -N ${#hosts[*]} \
  -w "$(echo ${hosts[*]}|tr ' ' ',')" \
  -t 10:00 \
  --job-name=NCCL-${max}S \
  --output=${USER}-NCCL-${#racks[*]}R-${#hosts[*]}N-%j.txt \
  nccl-mpirun.sh

## Full run with all nodes (imbalance mostly)
all_hosts=($(scontrol show hostname $(echo ${a[*]}|tr ' ' ',')))
all_racks=($(echo ${all_hosts[*]}|tr ' ' '\n'|cut -f1-2 -d'-'|sort|uniq))
jobname=${#all_racks[*]}Rack-$(echo ${all_racks[*]}|/home/cmsupport/workspace/aihpc_val/tools/hc/nodetools/python3-hostlist/hostlist -c -)
sbatch --reservation=nvis \
  -N ${#all_hosts[*]} \
  -w "$(echo ${all_hosts[*]}|tr ' ' ',')" \
  -t 10:00 \
  --job-name=${jobname} \
  --output=${USER}-${jobname}-${#all_hosts[*]}N-%j.txt \
  nccl-mpirun.sh
