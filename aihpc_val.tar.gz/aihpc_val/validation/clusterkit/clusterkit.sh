#!/bin/bash
# Author: Junli Zhang<junliz@nvidia.com>

#SBATCH -p defq
#SBATCH --exclusive
#SBATCH --exclusive
#SBATCH --ntasks-per-node=1
#SBATCH --gpus-per-node=8
#SBATCH --job-name=clusterkit

## Define the affinity: NIC<->CPU<->NUMA<->GPU
declare -a hca_name
hca_name=(
###################### GB300 ######################
#Follow the "rdma_topo topo; nvidia-smi" output to set the correct core, UCX_NET_DEVICES and CUDA_VISIBLE_DEVICES
#Bypass the 1st core leaving for OS.
#
##INDEX=HCA_NAME,CORE,NUMA,GPU
#  [0]="mlx5_0,1,0,1"
#  [1]="mlx5_1,2,0,0"
#  [2]="mlx5_2,73,1,3"
#  [3]="mlx5_3,74,1,2"
###################### B300 ######################
#Follow the "nvidia-smi topo -m" output to set the correct core, UCX_NET_DEVICES and CUDA_VISIBLE_DEVICES
#Bypass the 1st core leaving for OS.
#
###INDEX=HCA_NAME,CORE,NUMA,GPU
  [0]="mlx5_0,1,0,0"
  [1]="mlx5_1,2,0,1"
  [2]="mlx5_8,3,0,2"
  [3]="mlx5_9,4,0,3"
  [4]="mlx5_10,87,1,4"
  [5]="mlx5_11,88,1,5"
  [6]="mlx5_12,89,1,6"
  [7]="mlx5_13,90,1,7"
)

## Setup HPCX/MPI environment
HPCX_INIT_SH=/home/cmsupport/workspace/hpcx-v2.26-gcc-doca_ofed-ubuntu24.04-cuda13-$(uname -m)/hpcx-init.sh
source ${HPCX_INIT_SH}
hpcx_load

## Setup CUDA environment
export CUDA_HOME=/home/cmsupport/workspace/cuda
export PATH=${CUDA_HOME}/bin:$PATH
export LD_LIBRARY_PATH=${CUDA_HOME}/lib64:${LD_LIBRARY_PATH}

## Hack for SLURM environment variables
[ -z ${SLURM_SUBMIT_DIR} ] && SLURM_SUBMIT_DIR=$PWD
[ -z ${SLURM_JOB_ID} ] && SLURM_JOB_ID=$$
[ -z ${SLURM_NODELIST} ] && SLURM_NODELIST=$1

## Prepare hostfile
HOSTFILE=${SLURM_SUBMIT_DIR}/machinefile.${SLURM_JOB_ID}
source /etc/profile
module load slurm
scontrol show hostname $SLURM_NODELIST > $HOSTFILE
# Check if there are at least 2 nodes
if [ $(cat $HOSTFILE|wc -l) -lt 2 ]; then
  echo "ERROR: not enough nodes in $HOSTFILE"
  exit 1
fi

## Prepare mapper script for NIC<->CPU<->NUMA<->GPU mapping
mapper=${SLURM_SUBMIT_DIR}/hca_to_core-${SLURM_JOB_ID}.sh
if [ ! -f ${mapper} ]; then
cat > ${mapper} << 'EOF'
#!/bin/bash
export UCX_TLS=rc,cuda  # dc will hurt the performance
export CUDA_DEVICE_ORDER=PCI_BUS_ID
export UCX_NET_DEVICES=${CLUSTERKIT_HCA}:1
export CUDA_VISIBLE_DEVICES=${GPU}
cmd="numactl -C ${CORE} -m ${NUMA} $@"
echo "HOST=$(hostname), RANK=${OMPI_COMM_WORLD_RANK}, LOCALRANK=${OMPI_COMM_WORLD_LOCAL_RANK}, UCX_NET_DEVICES=${UCX_NET_DEVICES}, CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES} cmd=${cmd}"
eval $cmd
EOF
chmod a+x ${mapper}
fi

## Register cleanup action
trap "[ -f $HOSTFILE ] && rm -f $HOSTFILE; [ -f $mapper ] && rm -f $mapper" INT TERM #EXIT

## Run ClusterKit tests

checker_f=/home/cmsupport/workspace/aihpc_val/tools/hc/sysinfo.sh
[ -f ${checker_f} ] && timeout 120 bash ${checker_f}

HPCX_DIR=$HPCX_DIR
CK_DIR=$HPCX_DIR/clusterkit
mpi_opt+="--allow-run-as-root --bind-to none -x PATH -x LD_LIBRARY_PATH -x CK_OUTPUT_SUBDIR -x CLUSTERKIT_HCA -x CORE -x NUMA -x GPU --mca btl ^openib,smcuda -x SLURM_CPU_BIND=none"
for i in ${!hca_name[@]}; do
  ret=($(echo ${hca_name[$i]}|tr ',' ' '))
  export CLUSTERKIT_HCA=${ret[0]}
  export CORE=${ret[1]}
  export NUMA=${ret[2]}
  export GPU=${ret[3]}
  export CK_OUTPUT_SUBDIR=${SLURM_SUBMIT_DIR}/$(date "+%Y%m%d_%H%M%S")_${SLURM_JOB_ID}_${CLUSTERKIT_HCA}
  export HCA_TAG=${CLUSTERKIT_HCA}
  echo -e "\n================== ${CLUSTERKIT_HCA}:BEGIN ==================\n"
  #Traffic flow: local CPUx <-> NICy <-> NICy <-> remote CPUx
  timeout 300 $CK_DIR/bin/clusterkit.sh --mpi_opt "$mpi_opt" -r $HPCX_DIR -f $HOSTFILE --mapper ${mapper} --exe_opt "-d bw -d lat" --unidirectional # --biters=200
  #Traffic flow: local GPUx <-> NICy <-> NICy <-> remote GPUx
  timeout 300 $CK_DIR/bin/clusterkit.sh --mpi_opt "$mpi_opt" -r $HPCX_DIR -f $HOSTFILE --mapper ${mapper} --exe_opt "-d gpu_gpu_bw -d gpu_gpu_lat -G -z" --unidirectional # --biters=200
  echo -e "\n================== ${CLUSTERKIT_HCA}:END ==================\n"
done
rm -f $HOSTFILE ${mapper}

echo "Done."

# grep -i Average *_mlx5_*/{bandwidth.txt,latency.txt} | paste - -|column -t
# grep -i Average *_mlx5_*/{GPU0_to_GPU0_bandwidth.txt,GPU0_to_GPU0_latency.txt} | paste - -|column -t
